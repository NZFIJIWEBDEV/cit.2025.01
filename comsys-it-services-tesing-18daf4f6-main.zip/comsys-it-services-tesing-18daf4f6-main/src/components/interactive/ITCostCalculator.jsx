import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calculator, TrendingDown, CheckCircle, ArrowRight, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ITCostCalculator() {
  const [inputs, setInputs] = useState({
    employees: 10,
    currentITBudget: 5000,
    downtimeHours: 8,
    hourlyWage: 25,
    hasBackup: false,
    hasCybersecurity: false,
    hasCloudServices: false,
    hasManagedSupport: false
  });

  const [results, setResults] = useState(null);
  const [showResults, setShowResults] = useState(false);

  const calculateSavings = () => {
    const { employees, currentITBudget, downtimeHours, hourlyWage, hasBackup, hasCybersecurity, hasCloudServices, hasManagedSupport } = inputs;

    // Current annual costs
    const currentAnnualBudget = currentITBudget * 12;
    const downtimeCost = downtimeHours * employees * hourlyWage * 12; // Monthly downtime cost
    const securityRiskCost = hasCybersecurity ? 0 : employees * 500; // Risk premium
    const inefficiencyPenalty = (hasCloudServices && hasManagedSupport) ? 0 : employees * 200; // Inefficiency cost

    const totalCurrentCost = currentAnnualBudget + downtimeCost + securityRiskCost + inefficiencyPenalty;

    // COMSYS managed services cost (competitive pricing)
    const managedServicesCost = employees * 85 * 12; // $85 per user per month
    const reducedDowntime = Math.max(downtimeHours * 0.1, 1); // 90% reduction in downtime
    const newDowntimeCost = reducedDowntime * employees * hourlyWage * 12;

    const totalComsysCost = managedServicesCost + newDowntimeCost;

    const annualSavings = totalCurrentCost - totalComsysCost;
    const savingsPercentage = ((annualSavings / totalCurrentCost) * 100);

    setResults({
      currentCost: totalCurrentCost,
      comsysCost: totalComsysCost,
      annualSavings: Math.max(annualSavings, 0),
      monthlySavings: Math.max(annualSavings / 12, 0),
      savingsPercentage: Math.max(savingsPercentage, 0),
      reducedDowntime: downtimeHours - reducedDowntime,
      productivityGain: (downtimeHours - reducedDowntime) * employees * hourlyWage * 12
    });

    setShowResults(true);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-8 md:mb-12"
        >
          <div className="flex items-center justify-center mb-4">
            <Calculator className="w-10 md:w-12 h-10 md:h-12 text-blue-600 mr-3" />
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-[#3A4E62]">IT Cost Savings Calculator</h2>
          </div>
          <p className="text-lg md:text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            Discover how much your business could save with COMSYS managed IT services
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Input Form */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center text-[#3A4E62]">
                <DollarSign className="w-6 h-6 mr-2 text-blue-600" />
                Your Current Situation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base font-semibold text-[#3A4E62] mb-3 block">
                  Number of Employees: {inputs.employees}
                </Label>
                <Slider
                  value={[inputs.employees]}
                  onValueChange={(value) => setInputs(prev => ({ ...prev, employees: value[0] }))}
                  max={200}
                  min={5}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>5</span>
                  <span>200+</span>
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold text-[#3A4E62]">Monthly IT Budget (NZD)</Label>
                <Input
                  type="number"
                  value={inputs.currentITBudget}
                  onChange={(e) => setInputs(prev => ({ ...prev, currentITBudget: parseInt(e.target.value) || 0 }))}
                  className="mt-2"
                />
              </div>

              <div>
                <Label className="text-base font-semibold text-[#3A4E62] mb-3 block">
                  Monthly Downtime Hours: {inputs.downtimeHours}
                </Label>
                <Slider
                  value={[inputs.downtimeHours]}
                  onValueChange={(value) => setInputs(prev => ({ ...prev, downtimeHours: value[0] }))}
                  max={40}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>1hr</span>
                  <span>40hrs+</span>
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold text-[#3A4E62]">Average Hourly Wage (NZD)</Label>
                <Input
                  type="number"
                  value={inputs.hourlyWage}
                  onChange={(e) => setInputs(prev => ({ ...prev, hourlyWage: parseInt(e.target.value) || 0 }))}
                  className="mt-2"
                />
              </div>

              <div className="space-y-3">
                <Label className="text-base font-semibold text-[#3A4E62]">Current IT Services</Label>
                {[
                  { key: 'hasBackup', label: 'Automated Data Backup' },
                  { key: 'hasCybersecurity', label: 'Advanced Cybersecurity' },
                  { key: 'hasCloudServices', label: 'Cloud Services (Microsoft 365)' },
                  { key: 'hasManagedSupport', label: '24/7 Managed Support' }
                ].map((service) => (
                  <div key={service.key} className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id={service.key}
                      checked={inputs[service.key]}
                      onChange={(e) => setInputs(prev => ({ ...prev, [service.key]: e.target.checked }))}
                      className="w-4 h-4 text-blue-600 rounded"
                    />
                    <label htmlFor={service.key} className="text-[#3A4E62]">{service.label}</label>
                  </div>
                ))}
              </div>

              <Button 
                onClick={calculateSavings}
                className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white py-3"
                size="lg"
              >
                Calculate My Savings
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <AnimatePresence mode="wait">
            {showResults && results && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <Card className="bg-gradient-to-br from-green-50 to-emerald-100 shadow-xl border-green-200">
                  <CardHeader>
                    <CardTitle className="flex items-center text-green-700">
                      <TrendingDown className="w-6 h-6 mr-2" />
                      Your Potential Savings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-2xl md:text-3xl font-bold text-green-600">
                          ${Math.round(results.annualSavings).toLocaleString()}
                        </div>
                        <div className="text-green-700 font-medium text-sm md:text-base">Annual Savings</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl md:text-3xl font-bold text-green-600">
                          {Math.round(results.savingsPercentage)}%
                        </div>
                        <div className="text-green-700 font-medium text-sm md:text-base">Cost Reduction</div>
                      </div>
                    </div>
                    
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Current Annual IT Costs:</span>
                        <span className="font-semibold">${Math.round(results.currentCost).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">COMSYS Managed Services:</span>
                        <span className="font-semibold">${Math.round(results.comsysCost).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span className="text-green-700 font-semibold">Monthly Savings:</span>
                        <span className="text-green-600 font-bold">${Math.round(results.monthlySavings).toLocaleString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-blue-50 shadow-lg border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-blue-700">Additional Benefits</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-[#3A4E62] text-sm md:text-base">Reduce downtime by {Math.round(results.reducedDowntime)} hours/month</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-[#3A4E62] text-sm md:text-base">Productivity gain worth ${Math.round(results.productivityGain).toLocaleString()}/year</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-[#3A4E62] text-sm md:text-base">24/7 proactive monitoring & support</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-[#3A4E62] text-sm md:text-base">Enterprise-grade cybersecurity</span>
                    </div>
                  </CardContent>
                </Card>

                <Link to={createPageUrl("ContactUs?subject=ITAssessment")}>
                  <Button className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white" size="lg">
                    Get Your Free IT Assessment
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}