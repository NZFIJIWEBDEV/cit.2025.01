
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wifi, WifiOff, RotateCcw, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom

// This is a placeholder for createPageUrl. In a real application,
// this function would likely be imported from a utility file (e.g., '@/utils/url')
// or defined globally if part of a routing context.
const createPageUrl = (path) => `/${path.toLowerCase()}`;

export default function WiFiCoverageMap() {
  const [showAfter, setShowAfter] = useState(false);

  const beforeAreas = [
    { id: 1, x: 20, y: 20, strength: 'strong', size: 'small' },
    { id: 2, x: 60, y: 80, strength: 'weak', size: 'small' },
    { id: 3, x: 15, y: 70, strength: 'none', size: 'none' },
    { id: 4, x: 85, y: 40, strength: 'none', size: 'none' },
    { id: 5, x: 45, y: 45, strength: 'medium', size: 'medium' },
  ];

  const afterAreas = [
    { id: 1, x: 20, y: 20, strength: 'strong', size: 'large' },
    { id: 2, x: 60, y: 80, strength: 'strong', size: 'large' },
    { id: 3, x: 15, y: 70, strength: 'strong', size: 'medium' },
    { id: 4, x: 85, y: 40, strength: 'medium', size: 'medium' },
    { id: 5, x: 45, y: 45, strength: 'strong', size: 'large' },
    { id: 6, x: 75, y: 15, strength: 'strong', size: 'medium' },
    { id: 7, x: 30, y: 85, strength: 'medium', size: 'medium' },
  ];

  const getSignalColor = (strength) => {
    switch (strength) {
      case 'strong': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'weak': return 'bg-red-500';
      default: return 'bg-gray-300';
    }
  };

  const getSignalSize = (size) => {
    switch (size) {
      case 'large': return 'w-24 h-24';
      case 'medium': return 'w-16 h-16';
      case 'small': return 'w-8 h-8';
      default: return 'w-0 h-0';
    }
  };

  const currentAreas = showAfter ? afterAreas : beforeAreas;

  return (
    <section className="py-24 bg-gradient-to-br from-blue-50 via-slate-50 to-gray-100">
      <div className="max-w-6xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
            WiFi Coverage Transformation
          </h2>
          <p className="text-xl text-[#3A4E62]/80">
            See how our professional WiFi upgrade eliminates dead zones and weak signals
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Interactive Map */}
          <Card className="bg-white shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <Wifi className="w-6 h-6 mr-2 text-cyan-600" />
                  {showAfter ? 'After COMSYS WiFi Upgrade' : 'Current WiFi Coverage'}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAfter(!showAfter)}
                  className="border-cyan-600 text-cyan-600 hover:bg-cyan-600 hover:text-white"
                >
                  {showAfter ? <RotateCcw className="w-4 h-4 mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                  {showAfter ? 'Show Before' : 'Show After'}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative bg-gray-100 rounded-xl p-4" style={{ minHeight: '400px' }}>
                {/* House Layout */}
                <div className="absolute inset-4 border-2 border-gray-400 rounded-lg bg-white/50">
                  {/* Rooms */}
                  <div className="absolute top-2 left-2 w-1/3 h-1/3 border border-gray-300 rounded bg-blue-50 flex items-center justify-center text-xs font-semibold text-gray-600">Living Room</div>
                  <div className="absolute top-2 right-2 w-1/3 h-1/3 border border-gray-300 rounded bg-green-50 flex items-center justify-center text-xs font-semibold text-gray-600">Kitchen</div>
                  <div className="absolute bottom-2 left-2 w-1/3 h-1/3 border border-gray-300 rounded bg-yellow-50 flex items-center justify-center text-xs font-semibold text-gray-600">Bedroom</div>
                  <div className="absolute bottom-2 right-2 w-1/3 h-1/3 border border-gray-300 rounded bg-purple-50 flex items-center justify-center text-xs font-semibold text-gray-600">Office</div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1/4 h-1/4 border border-gray-300 rounded bg-red-50 flex items-center justify-center text-xs font-semibold text-gray-600">Hall</div>
                </div>

                {/* WiFi Coverage Areas */}
                {currentAreas.map((area) => (
                  <motion.div
                    key={`${area.id}-${showAfter}`}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 0.6 }}
                    transition={{ duration: 0.5, delay: area.id * 0.1 }}
                    className={`absolute rounded-full ${getSignalColor(area.strength)} ${getSignalSize(area.size)} flex items-center justify-center`}
                    style={{ left: `${area.x}%`, top: `${area.y}%`, transform: 'translate(-50%, -50%)' }}
                  >
                    {area.strength !== 'none' && (
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        {area.strength === 'none' ?
                          <WifiOff className="w-4 h-4 text-white" /> :
                          <Wifi className="w-4 h-4 text-white" />
                        }
                      </motion.div>
                    )}
                  </motion.div>
                ))}

                {/* Router Positions */}
                {showAfter && (
                  <>
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute w-6 h-6 bg-black rounded-lg flex items-center justify-center"
                      style={{ left: '50%', top: '30%', transform: 'translate(-50%, -50%)' }}
                    >
                      <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                    </motion.div>
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2 }}
                      className="absolute w-4 h-4 bg-gray-700 rounded flex items-center justify-center"
                      style={{ left: '20%', top: '70%', transform: 'translate(-50%, -50%)' }}
                    >
                      <div className="w-1 h-1 bg-cyan-400 rounded-full animate-pulse"></div>
                    </motion.div>
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.4 }}
                      className="absolute w-4 h-4 bg-gray-700 rounded flex items-center justify-center"
                      style={{ left: '80%', top: '60%', transform: 'translate(-50%, -50%)' }}
                    >
                      <div className="w-1 h-1 bg-cyan-400 rounded-full animate-pulse"></div>
                    </motion.div>
                  </>
                )}
              </div>

              {/* Legend */}
              <div className="mt-4 flex justify-center space-x-6">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Strong Signal</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Medium Signal</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Weak Signal</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-gray-300 rounded-full"></div>
                  <span className="text-sm text-gray-600">Dead Zone</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comparison Stats */}
          <div className="space-y-6">
            <Card className={`${showAfter ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
              <CardHeader>
                <CardTitle className={showAfter ? 'text-green-700' : 'text-red-700'}>
                  {showAfter ? 'After Upgrade Results' : 'Current Issues'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {showAfter ? (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>100% coverage in all areas</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>Average speed: 300+ Mbps</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>Zero dead zones</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>Seamless roaming between access points</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>Support for 50+ devices simultaneously</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <WifiOff className="w-5 h-5 text-red-600" />
                      <span>Multiple dead zones</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <WifiOff className="w-5 h-5 text-red-600" />
                      <span>Inconsistent speeds (5-50 Mbps)</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <WifiOff className="w-5 h-5 text-red-600" />
                      <span>Frequent disconnections</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <WifiOff className="w-5 h-5 text-red-600" />
                      <span>Poor performance with many devices</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <WifiOff className="w-5 h-5 text-red-600" />
                      <span>Buffering during video calls</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <motion.div
              key={showAfter ? 'after' : 'before'}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <div className={`text-4xl font-bold mb-2 ${showAfter ? 'text-green-600' : 'text-red-600'}`}>
                {showAfter ? '100%' : '40%'}
              </div>
              <div className="text-gray-600 text-lg">
                {showAfter ? 'Reliable Coverage' : 'Coverage Success Rate'}
              </div>
            </motion.div>
            <Link to={createPageUrl("ContactUs")} className="block">
              <Button className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white" size="lg">
                Get Your WiFi Assessment
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
