
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, X, Star, Shield, Clock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const comparisonData = [
  {
    category: 'Response Time',
    comsys: '< 1 Hour',
    comsysIcon: <Clock className="w-5 h-5 text-[#53B289]" />,
    competitor1: '4-24 hours',
    competitor2: '2-8 hours',
    inHouse: 'Depends on staff'
  },
  {
    category: 'Local Support',
    comsys: 'Auckland-based team',
    comsysIcon: <Users className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'Offshore support',
    competitor2: 'Mixed local/offshore',
    inHouse: 'If available'
  },
  {
    category: 'Proactive Monitoring',
    comsys: '24/7 automated monitoring',
    comsysIcon: <CheckCircle className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'Business hours only',
    competitor2: 'Limited monitoring',
    inHouse: 'Manual checks'
  },
  {
    category: 'Cybersecurity',
    comsys: 'Enterprise-grade protection',
    comsysIcon: <Shield className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'Basic antivirus',
    competitor2: 'Standard security',
    inHouse: 'DIY solutions'
  },
  {
    category: 'Data Backup',
    comsys: 'Automated cloud + local',
    comsysIcon: <CheckCircle className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'Cloud backup only',
    competitor2: 'Manual backups',
    inHouse: 'External drives'
  },
  {
    category: 'Cost Structure',
    comsys: 'Flat monthly rate',
    comsysIcon: <CheckCircle className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'Per-incident billing',
    competitor2: 'Tiered pricing',
    inHouse: 'Salary + benefits'
  },
  {
    category: 'Expertise Level',
    comsys: 'Microsoft certified specialists',
    comsysIcon: <Star className="w-5 h-5 text-[#53B289]" />,
    competitor1: 'General IT knowledge',
    competitor2: 'Mixed skill levels',
    inHouse: 'Limited specialization'
  },
  {
    category: 'Business Hours Support',
    comsys: '8AM - 6PM + Emergency',
    comsysIcon: <CheckCircle className="w-5 h-5 text-[#53B289]" />,
    competitor1: '9AM - 5PM',
    competitor2: '8AM - 5PM',
    inHouse: 'Standard work hours'
  }
];

export default function ComparisonChart() {
  const [activeTab, setActiveTab] = useState('competitor');

  return (
    <section className="py-24 bg-gradient-to-br from-slate-50 via-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
            A Clear Advantage
          </h2>
          <p className="text-xl text-[#3A4E62]/80 mb-8">
            See how we stack up against other IT providers and in-house teams.
          </p>
          
          <div className="flex justify-center">
            <div className="bg-white rounded-full p-2 shadow-lg">
              <Button
                variant={activeTab === 'competitor' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('competitor')}
                className={`rounded-full px-6 ${activeTab === 'competitor' ? 'bg-[#53B289] hover:bg-[#4aa07b]' : ''}`}
              >
                vs Other Providers
              </Button>
              <Button
                variant={activeTab === 'inhouse' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('inhouse')}
                className={`rounded-full px-6 ${activeTab === 'inhouse' ? 'bg-[#53B289] hover:bg-[#4aa07b]' : ''}`}
              >
                vs In-House IT
              </Button>
            </div>
          </div>
        </motion.div>

        <Card className="shadow-2xl bg-white/95 backdrop-blur-sm border-gray-200/50">
          <CardHeader className="bg-gray-50/80">
            <CardTitle className="text-center text-2xl text-[#3A4E62]">
              {activeTab === 'competitor' ? 'COMSYS vs Other IT Providers' : 'COMSYS vs In-House IT Team'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left p-6 text-[#3A4E62] font-semibold">Feature</th>
                    <th className="text-center p-6 bg-[#53B289]/10">
                      <div className="flex flex-col items-center space-y-2">
                        <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                          <Star className="w-6 h-6 text-white" />
                        </div>
                        <span className="font-bold text-[#53B289]">COMSYS</span>
                      </div>
                    </th>
                    {activeTab === 'competitor' ? (
                      <>
                        <th className="text-center p-6 text-gray-600">Other Providers</th>
                        <th className="text-center p-6 text-gray-600 hidden sm:table-cell">Typical In-House</th>
                      </>
                    ) : (
                      <th className="text-center p-6 text-gray-600">In-House IT</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {comparisonData.map((row, index) => (
                    <motion.tr
                      key={row.category}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="p-6 font-semibold text-[#3A4E62]">{row.category}</td>
                      <td className="p-6 bg-[#53B289]/5">
                        <div className="flex items-center justify-center space-x-3 text-center">
                          {row.comsysIcon}
                          <span className="font-semibold text-[#3A4E62]">{row.comsys}</span>
                        </div>
                      </td>
                      {activeTab === 'competitor' ? (
                        <>
                          <td className="p-6 text-center text-gray-600">
                            <div className="flex items-center justify-center space-x-2">
                              <X className="w-4 h-4 text-red-500/70" />
                              <span>{row.competitor1}</span>
                            </div>
                          </td>
                          <td className="p-6 text-center text-gray-600 hidden sm:table-cell">
                            <div className="flex items-center justify-center space-x-2">
                              <X className="w-4 h-4 text-orange-500/70" />
                              <span>{row.inHouse}</span>
                            </div>
                          </td>
                        </>
                      ) : (
                        <td className="p-6 text-center text-gray-600">
                          <div className="flex items-center justify-center space-x-2">
                            <X className="w-4 h-4 text-orange-500/70" />
                            <span>{row.inHouse}</span>
                          </div>
                        </td>
                      )}
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-12"
        >
          <div className="bg-white/90 rounded-2xl shadow-xl p-8 max-w-2xl mx-auto border-2 border-gray-100">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">
              Ready to Experience the COMSYS Advantage?
            </h3>
            <p className="text-[#3A4E62]/80 mb-6">
              Join hundreds of New Zealand businesses who've made the switch to reliable, professional IT support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                  Get Free Assessment
                </Button>
              </Link>
              <Link to={createPageUrl("ContactUs")}>
                <Button variant="outline" size="lg" className="border-[#53B289] text-[#53B289] hover:bg-[#53B289]/10">
                  Schedule Consultation
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
