
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const serviceFeatures = [
  {
    id: 'it-support',
    title: 'IT Support & Helpdesk',
    icon: '🛠️',
    summary: 'Comprehensive technical support for all your IT needs',
    features: [
      'Remote troubleshooting and problem resolution',
      'On-site technical support when needed',
      'Software installation and configuration',
      'Hardware diagnostics and repair coordination',
      'User account management and permissions',
      'Email and communication system support',
      'Network connectivity troubleshooting',
      '1 hour response time for critical issues'
    ],
    benefits: [
      'Minimize downtime and productivity loss',
      'Access to expert technicians without hiring costs',
      'Proactive problem prevention',
      'Standardized IT processes and documentation'
    ]
  },
  {
    id: 'cybersecurity',
    title: 'Cybersecurity & Threat Protection',
    icon: '🛡️',
    summary: 'Multi-layered security to protect against modern cyber threats',
    features: [
      'Advanced endpoint detection and response',
      'Email security and phishing protection',
      'Firewall management and monitoring',
      'Regular security assessments and vulnerability scans',
      'Employee cybersecurity training programs',
      'Incident response and recovery planning',
      'Compliance reporting and documentation',
      '24/7 security monitoring and alerts'
    ],
    benefits: [
      'Protect against ransomware and malware',
      'Maintain regulatory compliance',
      'Reduce risk of data breaches',
      'Peace of mind with continuous monitoring'
    ]
  },
  {
    id: 'cloud-services',
    title: 'Cloud Solutions & Migration',
    icon: '☁️',
    summary: 'Seamless cloud adoption and management for modern businesses',
    features: [
      'Microsoft 365 setup, migration, and management',
      'Cloud infrastructure design and implementation',
      'Data migration with zero data loss',
      'Cloud backup and disaster recovery',
      'User training and adoption support',
      'License optimization and cost management',
      'Integration with existing business applications',
      'Ongoing cloud optimization and monitoring'
    ],
    benefits: [
      'Access files and applications anywhere',
      'Reduce hardware costs and maintenance',
      'Automatic updates and enhanced security',
      'Scalable solutions that grow with your business'
    ]
  },
  {
    id: 'backup-recovery',
    title: 'Data Backup & Recovery',
    icon: '💾',
    summary: 'Comprehensive data protection with rapid recovery capabilities',
    features: [
      'Automated daily backups with monitoring',
      'Cloud and local backup redundancy',
      'Point-in-time recovery options',
      'Bare metal restoration for complete system recovery',
      'Regular backup testing and verification',
      'Ransomware-protected backup repositories',
      'Granular file and folder recovery',
      'Business continuity planning and testing'
    ],
    benefits: [
      'Protect against data loss from any cause',
      'Meet compliance and regulatory requirements',
      'Minimize recovery time objectives',
      'Ensure business continuity during disasters'
    ]
  }
];

export default function ExpandableServiceFeatures() {
  const [expandedService, setExpandedService] = useState(null);

  const toggleService = (serviceId) => {
    setExpandedService(expandedService === serviceId ? null : serviceId);
  };

  return (
    <section className="py-24 bg-gradient-to-br from-slate-50 via-gray-50 to-blue-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
            Explore Our Service Features
          </h2>
          <p className="text-xl text-[#3A4E62]/80">
            Click on any service to discover the comprehensive features and benefits included
          </p>
        </motion.div>

        <div className="space-y-4">
          {serviceFeatures.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden border-2 hover:border-[#53B289]/50 transition-colors cursor-pointer">
                <CardHeader 
                  className="bg-gradient-to-r from-gray-50 to-blue-50 hover:from-[#53B289]/10 hover:to-[#C0E3D4]/20 transition-colors"
                  onClick={() => toggleService(service.id)}
                >
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{service.icon}</span>
                      <div>
                        <h3 className="text-xl font-bold text-[#3A4E62]">{service.title}</h3>
                        <p className="text-[#3A4E62]/70 font-normal text-base">{service.summary}</p>
                      </div>
                    </div>
                    <motion.div
                      animate={{ rotate: expandedService === service.id ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <ChevronDown className="w-6 h-6 text-[#53B289]" />
                    </motion.div>
                  </CardTitle>
                </CardHeader>
                
                <AnimatePresence>
                  {expandedService === service.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <CardContent className="pt-6 bg-white">
                        <div className="grid md:grid-cols-2 gap-8">
                          {/* Features */}
                          <div>
                            <h4 className="text-lg font-semibold text-[#3A4E62] mb-4 flex items-center">
                              <ChevronRight className="w-5 h-5 mr-2 text-[#53B289]" />
                              What's Included
                            </h4>
                            <div className="space-y-3">
                              {service.features.map((feature, fIndex) => (
                                <motion.div
                                  key={fIndex}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: fIndex * 0.05 }}
                                  className="flex items-start space-x-3"
                                >
                                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                                  <span className="text-[#3A4E62]/80">{feature}</span>
                                </motion.div>
                              ))}
                            </div>
                          </div>

                          {/* Benefits */}
                          <div>
                            <h4 className="text-lg font-semibold text-[#3A4E62] mb-4 flex items-center">
                              <ChevronRight className="w-5 h-5 mr-2 text-[#53B289]" />
                              Business Benefits
                            </h4>
                            <div className="space-y-3">
                              {service.benefits.map((benefit, bIndex) => (
                                <motion.div
                                  key={bIndex}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: (service.features.length * 0.05) + (bIndex * 0.05) }}
                                  className="flex items-start space-x-3"
                                >
                                  <div className="w-5 h-5 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <CheckCircle className="w-3 h-3 text-white" />
                                  </div>
                                  <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
