import React from 'react';
import { Phone, Clock, User, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function TopBar() {
  return (
    <div className="bg-[#3A4E62] text-white/90 text-xs hidden md:block">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex justify-between items-center h-8">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5 text-[#53B289]" />
              <span>Mon - Fri: 8:00am - 6:00pm</span>
            </div>
            <a href="tel:0800724526" className="flex items-center space-x-1.5 hover:text-white transition-colors">
              <Phone className="w-3.5 h-3.5 text-[#53B289]" />
              <span>Emergency Support: 0800 724 526</span>
            </a>
          </div>
          <div className="flex items-center space-x-4">
            <a href="https://portal.comsys.co.nz/authentication/login" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-1.5 hover:text-white transition-colors">
              <User className="w-3.5 h-3.5 text-[#53B289]" />
              <span>Portal Login</span>
            </a>
            {/* Can add more links here if needed, e.g., Careers, etc. */}
          </div>
        </div>
      </div>
    </div>
  );
}