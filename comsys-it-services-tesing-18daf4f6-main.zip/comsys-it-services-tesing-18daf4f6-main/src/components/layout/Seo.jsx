import { useEffect } from 'react';

const Seo = ({ 
  title, 
  description, 
  schemas = [], 
  canonical, 
  ogTitle, 
  ogDescription, 
  ogImage,
  keywords
}) => {
  useEffect(() => {
    // Store original values for cleanup
    const originalTitle = document.title;
    const originalMetas = {};
    
    // Meta tags to manage
    const metaTags = [
      { name: 'description', content: description },
      { name: 'keywords', content: keywords },
      { property: 'og:title', content: ogTitle || title },
      { property: 'og:description', content: ogDescription || description },
      { property: 'og:image', content: ogImage },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: ogTitle || title },
      { name: 'twitter:description', content: ogDescription || description }
    ];

    // Set page title
    if (title) {
      document.title = title;
    }

    // Handle meta tags
    const addedElements = [];
    
    metaTags.forEach(({ name, property, content }) => {
      if (!content) return;
      
      const selector = name ? `meta[name="${name}"]` : `meta[property="${property}"]`;
      let meta = document.querySelector(selector);
      
      if (!meta) {
        meta = document.createElement('meta');
        if (name) meta.name = name;
        if (property) meta.property = property;
        document.head.appendChild(meta);
        addedElements.push(meta);
      } else {
        // Store original for cleanup
        const key = name || property;
        originalMetas[key] = meta.content;
      }
      
      meta.content = content;
    });

    // Handle canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    const originalCanonical = canonicalLink?.href;
    
    if (canonical) {
      if (!canonicalLink) {
        canonicalLink = document.createElement('link');
        canonicalLink.rel = 'canonical';
        document.head.appendChild(canonicalLink);
        addedElements.push(canonicalLink);
      }
      canonicalLink.href = canonical;
    }

    // Add schema scripts
    schemas.forEach(schema => {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.dataset.seoComponent = 'true';
      script.innerHTML = JSON.stringify(schema);
      document.head.appendChild(script);
      addedElements.push(script);
    });

    // Cleanup function
    return () => {
      document.title = originalTitle;
      
      // Restore or remove meta tags
      Object.entries(originalMetas).forEach(([key, originalContent]) => {
        const selector = key.startsWith('og:') || key.startsWith('twitter:') 
          ? `meta[property="${key}"]` 
          : `meta[name="${key}"]`;
        const meta = document.querySelector(selector);
        if (meta) {
          if (originalContent) {
            meta.content = originalContent;
          } else {
            meta.remove();
          }
        }
      });
      
      // Restore canonical
      if (originalCanonical && canonicalLink) {
        canonicalLink.href = originalCanonical;
      }
      
      // Remove added elements
      addedElements.forEach(element => {
        if (document.head.contains(element)) {
          document.head.removeChild(element);
        }
      });
    };
  }, [title, description, schemas, canonical, ogTitle, ogDescription, ogImage, keywords]);

  return null;
};

export default Seo;