
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import {
  Menu,
  X,
  ChevronDown,
  Phone,
  Wifi,
  Globe,
  Headphones,
  Video
} from 'lucide-react';

const NavLink = ({ to, children }) => (
  <Link 
    to={to} 
    className="text-[#3A4E62] hover:text-[#53B289] font-semibold transition-colors py-2"
  >
    {children}
  </Link>
);

const allServices = [
  { 
    category: "Core IT Services",
    icon: Headphones,
    links: [
      { name: "IT Support", page: "ITSupport" },
      { name: "Data Backup & Recovery", page: "DataBackupRecovery" },
      { name: "PC & Laptop Repair", page: "PCLaptopRepair" },
      { name: "Microsoft Office 365", page: "MicrosoftOffice" },
      { name: "Managed Print Services", page: "PrinterServices" },
    ]
  },
  { 
    category: "Connectivity",
    icon: Wifi,
    links: [
      { name: "Business Fibre", page: "BusinessFibre" },
      { name: "Home Fibre", page: "HomeFibre" },
      { name: "WiFi Network Upgrades", page: "WiFiUpgrade" },
      { name: "SIP Trunks", page: "SIPTrunks" },
    ]
  },
  {
    category: "Communications & Web",
    icon: Globe,
    links: [
        { name: "VoIP Phone Systems", page: "VoIPSolutions" },
        { name: "Cloud PBX", page: "CloudPBX" },
        { name: "Phone Numbers", page: "PhoneNumbers" },
        { name: "Web Design & Hosting", page: "WebDesignHosting" },
    ]
  },
  { 
    category: "Security",
    icon: Video,
    links: [
      { name: "Business CCTV", page: "CCTVBusiness" },
      { name: "Home CCTV", page: "CCTVHome" },
      { name: "Residential Security", page: "CCTVResidential" },
    ]
  }
];


export default function Header() {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isServicesMenuOpen, setServicesMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    // Close mobile menu on route change
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header className="bg-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link to={createPageUrl('Home')} className="flex-shrink-0">
            <img 
              src="https://comsys.co.nz/wp-content/uploads/2024/02/logo-5-1-1.png"
              alt="Comsys IT Logo" 
              className="h-10 lg:h-12 w-auto object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <NavLink to={createPageUrl('Home')}>Home</NavLink>
            <NavLink to={createPageUrl('About')}>About</NavLink>
            {/* Services Mega Menu */}
            <div 
              className="relative"
              onMouseEnter={() => setServicesMenuOpen(true)}
              onMouseLeave={() => setServicesMenuOpen(false)}
            >
              <button className="flex items-center space-x-1 text-[#3A4E62] hover:text-[#53B289] font-semibold transition-colors py-2">
                <span>Services</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isServicesMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              {isServicesMenuOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-max bg-white rounded-xl shadow-2xl border border-gray-100 p-6 z-50">
                  <div className="grid grid-cols-4 gap-x-10">
                    {allServices.map((serviceCat) => (
                      <div key={serviceCat.category} className="space-y-4">
                        <div className="flex items-center space-x-3 text-[#53B289]">
                          <serviceCat.icon className="w-5 h-5" />
                          <h3 className="font-bold text-sm uppercase tracking-wider">{serviceCat.category}</h3>
                        </div>
                        <ul className="space-y-2">
                          {serviceCat.links.map(link => (
                            <li key={link.name}>
                              <Link
                                to={createPageUrl(link.page)}
                                className="block text-sm text-[#3A4E62] hover:text-[#53B289] hover:translate-x-1 transition-all"
                              >
                                {link.name}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <NavLink to={createPageUrl('Pricing')}>Pricing</NavLink>
            <NavLink to={createPageUrl('RemoteSupport')}>Support</NavLink>
            <NavLink to={createPageUrl('ContactUs')}>Contact</NavLink>
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center space-x-4">
            <a href="tel:0800724526" className="flex items-center space-x-2 text-[#53B289] hover:text-[#4aa07b] transition-colors">
                <Phone className="w-4 h-4"/>
                <span className="font-semibold">0800 724 526</span>
            </a>
            <Link to={createPageUrl('ContactUs')}>
                <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                  Get Free Quote
                </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-md text-[#3A4E62] hover:text-[#53B289] transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-4 space-y-2">
            <NavLink to={createPageUrl('Home')}>Home</NavLink>
            <NavLink to={createPageUrl('About')}>About</NavLink>
            
            {/* Mobile Services Dropdown */}
            <div>
              <button 
                onClick={() => setServicesMenuOpen(!isServicesMenuOpen)}
                className="w-full flex justify-between items-center text-[#3A4E62] hover:text-[#53B289] font-semibold transition-colors py-2"
              >
                <span>Services</span>
                <ChevronDown className={`w-5 h-5 transition-transform ${isServicesMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              {isServicesMenuOpen && (
                <div className="pl-4 pt-2 pb-2 border-l border-gray-200 space-y-2">
                  {allServices.flatMap(cat => cat.links).map(link => (
                     <Link key={link.page} to={createPageUrl(link.page)} className="block py-1 text-sm text-gray-600 hover:text-[#53B289]">
                       {link.name}
                     </Link>
                  ))}
                </div>
              )}
            </div>

            <NavLink to={createPageUrl('Pricing')}>Pricing</NavLink>
            <NavLink to={createPageUrl('RemoteSupport')}>Support</NavLink>
            <NavLink to={createPageUrl('ContactUs')}>Contact</NavLink>
            
            <div className="border-t border-gray-200 pt-4 space-y-3">
                <a href="tel:0800724526" className="flex items-center space-x-2 text-[#53B289]">
                    <Phone className="w-4 h-4"/>
                    <span className="font-semibold">0800 724 526</span>
                </a>
                <Link to={createPageUrl('ContactUs')}>
                    <Button className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white">
                        Get Free Quote
                    </Button>
                </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
