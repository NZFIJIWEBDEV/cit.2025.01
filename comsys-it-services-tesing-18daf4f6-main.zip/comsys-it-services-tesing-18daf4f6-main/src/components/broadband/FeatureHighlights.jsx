import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Zap, Infinity, MapPin } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Business Grade',
    description: 'SLA-backed connections with guaranteed uptime and priority support'
  },
  {
    icon: Zap,
    title: 'Ultra Fast',
    description: 'Speeds up to 2Gbps for demanding applications and large teams'
  },
  {
    icon: Infinity,
    title: 'No Limits',
    description: 'Unlimited data usage - no caps, no throttling, no surprises'
  },
  {
    icon: MapPin,
    title: 'NZ-Wide Coverage',
    description: 'Fibre, Fixed Wireless, and DSL options across New Zealand'
  }
];

export default function FeatureHighlights() {
  return (
    <section className="py-16 bg-gradient-to-r from-[#C0E3D4]/20 to-[#53B289]/10">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-[#53B289] rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{feature.title}</h3>
              <p className="text-[#3A4E62]/80 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}