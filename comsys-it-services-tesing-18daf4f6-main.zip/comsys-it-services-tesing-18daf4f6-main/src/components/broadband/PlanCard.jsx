import React from 'react';
import { CheckCircle, Wifi, Shield, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function PlanCard({ plan, showGST = true, isPopular = false }) {
  const price = showGST ? plan.priceIncGST : plan.priceExGST;

  return (
    <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl ${
      isPopular ? 'border-[#53B289] border-2 shadow-lg transform scale-105' : 'border-gray-200'
    }`}>
      {isPopular && (
        <div className="absolute top-0 left-0 right-0 bg-[#53B289] text-white text-center py-2 text-sm font-semibold">
          Most Popular
        </div>
      )}
      
      <CardHeader className={`text-center ${isPopular ? 'pt-12' : 'pt-6'}`}>
        <CardTitle className="text-2xl font-bold text-[#3A4E62]">{plan.name}</CardTitle>
        <div className="space-y-2">
          <div className="text-4xl font-bold text-[#53B289]">
            ${price}
            <span className="text-lg font-normal text-gray-600">/month</span>
          </div>
          <p className="text-sm text-gray-500">
            {showGST ? 'inc GST' : 'ex GST'}
          </p>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Speed Badge */}
        <div className="text-center">
          <Badge variant="outline" className="text-lg px-4 py-2 border-[#53B289] text-[#53B289]">
            <Wifi className="w-4 h-4 mr-2" />
            {plan.speed}
          </Badge>
        </div>

        {/* Key Features */}
        <div className="space-y-3">
          {plan.features.map((feature, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-[#3A4E62] text-sm">{feature}</span>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        {plan.sla && (
          <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-blue-600" />
              <span className="text-blue-700 font-semibold text-sm">Business SLA</span>
            </div>
            <p className="text-blue-600 text-xs mt-1">{plan.sla}</p>
          </div>
        )}

        {plan.setup && (
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>Setup:</span>
            <span className={plan.setup === 'Free' ? 'text-green-600 font-semibold' : ''}>
              {plan.setup}
            </span>
          </div>
        )}

        <Button 
          className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white"
          size="lg"
        >
          Sign Up Now
        </Button>

        {plan.installTime && (
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
              <Clock className="w-4 h-4" />
              <span>Typical install: {plan.installTime}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}