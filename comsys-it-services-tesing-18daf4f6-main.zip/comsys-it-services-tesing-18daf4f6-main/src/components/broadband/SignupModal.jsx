import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/toast';

export default function SignupModal({ isOpen, onClose, selectedPlan }) {
  const [formData, setFormData] = useState({
    firstname: '',
    lastname: '',
    company: '',
    email: '',
    phone: '',
    building: '',
    streetnumber: '',
    streetname: '',
    suburb: '',
    city: '',
    postcode: '',
    state: '',
  });

  const [geolocation, setGeolocation] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);
  const [error, setError] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      // Reset form state when modal opens
      setSubmitStatus(null);
      setError('');
      setFormData({
        firstname: '', lastname: '', company: '', email: '', phone: '',
        building: '', streetnumber: '', streetname: '', suburb: '', city: '', postcode: '', state: '',
      });

      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGeolocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (err) => {
          console.warn(`Could not get geolocation: ${err.message}`);
          setGeolocation('Not available');
        }
      );
    }
  }, [isOpen]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    const requiredFields = ['firstname', 'lastname', 'email', 'phone', 'streetnumber', 'streetname', 'suburb', 'city', 'postcode'];
    for (const field of requiredFields) {
      if (!formData[field].trim()) {
        setError(`Please fill in the '${field}' field.`);
        setIsSubmitting(false);
        return;
      }
    }
    
    const messageBody = `New Broadband Signup Request
-----------------------------
Plan: ${selectedPlan?.name} (${selectedPlan?.price}/month)

Personal Details:
Name: ${formData.firstname} ${formData.lastname}
Company: ${formData.company || 'N/A'}
Email: ${formData.email}
Phone: ${formData.phone}

Installation Address:
Building: ${formData.building || 'N/A'}
Street: ${formData.streetnumber} ${formData.streetname}
Suburb: ${formData.suburb}
City: ${formData.city}
Postcode: ${formData.postcode}
State/Region: ${formData.state || 'N/A'}

Geolocation Data:
${geolocation ? (typeof geolocation === 'object' ? `Latitude: ${geolocation.latitude}, Longitude: ${geolocation.longitude}` : geolocation) : 'Not available'}
Google Maps Link: ${geolocation && typeof geolocation === 'object' ? `https://www.google.com/maps?q=${geolocation.latitude},${geolocation.longitude}` : 'N/A'}
`;

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: `${formData.firstname} ${formData.lastname}`,
          email: formData.email,
          phone: formData.phone,
          company: formData.company,
          subject: `New Broadband Signup: ${selectedPlan?.name}`,
          message: messageBody,
          page_source: 'Broadband Signup Modal'
        })
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        setSubmitStatus('success');
      } else {
        throw new Error(result.message || 'Failed to send inquiry');
      }
    } catch (err) {
      setError(err.message || 'Failed to submit form. Please try again.');
      setSubmitStatus('error');
      toast({ title: "Submission Failed", description: `Error: ${err.message}. Please try again or contact us directly.`, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div>
              <h2 className="text-2xl font-bold text-[#3A4E62]">Sign Up for {selectedPlan?.name}</h2>
              <p className="text-[#3A4E62]/70 mt-1">Submit your details and we'll be in touch to confirm.</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-6 h-6" />
            </Button>
          </div>

          <div className="p-6">
            {submitStatus === 'success' ? (
              <div className="text-center py-8">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-[#3A4E62] mb-2">Inquiry Sent Successfully!</h3>
                <p className="text-[#3A4E62]/80 mb-6">Thank you for your interest. Our team will review your details and get back to you shortly to finalize your setup.</p>
                <Button onClick={onClose} className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                  Close
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="font-semibold text-[#3A4E62] mb-4">Personal Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstname">First Name *</Label>
                      <Input id="firstname" value={formData.firstname} onChange={(e) => handleInputChange('firstname', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="lastname">Last Name *</Label>
                      <Input id="lastname" value={formData.lastname} onChange={(e) => handleInputChange('lastname', e.target.value)} required />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-[#3A4E62] mb-4">Contact Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input id="email" type="email" value={formData.email} onChange={(e) => handleInputChange('email', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input id="phone" value={formData.phone} onChange={(e) => handleInputChange('phone', e.target.value)} required />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-[#3A4E62] mb-4">Installation Address</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="streetnumber">Street Number *</Label>
                      <Input id="streetnumber" value={formData.streetnumber} onChange={(e) => handleInputChange('streetnumber', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="streetname">Street Name *</Label>
                      <Input id="streetname" value={formData.streetname} onChange={(e) => handleInputChange('streetname', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="suburb">Suburb *</Label>
                      <Input id="suburb" value={formData.suburb} onChange={(e) => handleInputChange('suburb', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="city">City *</Label>
                      <Input id="city" value={formData.city} onChange={(e) => handleInputChange('city', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="postcode">Postcode *</Label>
                      <Input id="postcode" value={formData.postcode} onChange={(e) => handleInputChange('postcode', e.target.value)} required />
                    </div>
                    <div>
                      <Label htmlFor="state">State/Region</Label>
                      <Input id="state" value={formData.state} onChange={(e) => handleInputChange('state', e.target.value)} />
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg">
                    <AlertCircle className="w-5 h-5" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                  <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                  <Button type="submit" disabled={isSubmitting} className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                    {isSubmitting ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting Inquiry...</>
                    ) : (
                      'Submit Inquiry'
                    )}
                  </Button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}