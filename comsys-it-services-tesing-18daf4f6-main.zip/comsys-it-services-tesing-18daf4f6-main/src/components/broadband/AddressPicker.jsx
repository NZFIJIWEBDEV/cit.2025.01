import React, { useState } from 'react';
import { Search, MapPin, CheckCircle, AlertCircle, Wifi } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';

export default function AddressPicker({ onAddressSelect, placeholder = "Enter your address to check availability..." }) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = async (e) => {
    const value = e.target.value;
    setQuery(value);
    setSelectedAddress(null);
    if(onAddressSelect) onAddressSelect(null);

    if (value.length > 3) {
      setIsLoading(true);
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value)}&countrycodes=nz&addressdetails=1`);
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setSuggestions(data.map(item => ({ id: item.place_id, address: item.display_name })));
        setShowSuggestions(true);
      } catch (error) {
        console.error("Failed to fetch addresses:", error);
        setSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleAddressSelect = (address) => {
    const fibreAvailableResult = {
      address: address.address,
      fibre: true,
      wireless: true,
      vdsl: true,
      maxSpeed: "2000/2000 Mbps",
      technology: "Fibre"
    };

    setSelectedAddress(fibreAvailableResult);
    setQuery(fibreAvailableResult.address);
    setShowSuggestions(false);
    if(onAddressSelect) onAddressSelect(fibreAvailableResult);
  };

  const getAvailabilityIcon = (hasService) => {
    return hasService ? (
      <CheckCircle className="w-5 h-5 text-green-500" />
    ) : (
      <AlertCircle className="w-5 h-5 text-red-500" />
    );
  };

  return (
    <div className="relative max-w-3xl mx-auto">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 text-gray-400" />
        <Input
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={handleInputChange}
          className="pl-12 pr-4 py-4 text-lg border-2 border-[#53B289]/30 focus:border-[#53B289] rounded-xl shadow-lg h-14"
        />
        {isLoading && (
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
            <div className="w-5 h-5 border-2 border-[#53B289] border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showSuggestions && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-10 w-full mt-3 bg-white border border-gray-200 rounded-xl shadow-2xl overflow-hidden"
          >
            {suggestions.map((address) => (
              <div
                key={address.id}
                className="p-4 hover:bg-[#53B289]/5 cursor-pointer border-b border-gray-100 last:border-b-0 transition-colors"
                onClick={() => handleAddressSelect(address)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-[#53B289]" />
                    <span className="text-[#3A4E62] font-medium">{address.address}</span>
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {showSuggestions && suggestions.length === 0 && query.length > 2 && !isLoading && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute z-10 w-full mt-3 bg-white border border-gray-200 rounded-xl shadow-xl p-6 text-center"
        >
          <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
          <p className="text-[#3A4E62] font-medium">No addresses found</p>
          <p className="text-[#3A4E62]/70 text-sm mt-2">
            Try entering a more specific address or contact us to check availability
          </p>
          <Button className="mt-4 bg-[#53B289] hover:bg-[#4aa07b] text-white">
            Contact Us
          </Button>
        </motion.div>
      )}

      {selectedAddress && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6"
        >
          <Card className="bg-gradient-to-r from-green-50 via-blue-50 to-[#53B289]/10 border-[#53B289]/30 shadow-lg">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                <h3 className="text-2xl font-bold text-[#3A4E62] mb-2">Great news! Fibre is available.</h3>
                <p className="text-[#3A4E62]/80">
                  High-speed broadband is available at your address.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-white rounded-lg p-4 border border-[#53B289]/20">
                  <h4 className="font-bold text-[#3A4E62] mb-2">Best Technology Available:</h4>
                  <div className="flex items-center space-x-3">
                    <Wifi className="w-6 h-6 text-[#53B289]" />
                    <div>
                      <p className="font-semibold text-[#53B289]">{selectedAddress.technology}</p>
                      <p className="text-sm text-[#3A4E62]/70">Up to {selectedAddress.maxSpeed}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-4 border border-[#53B289]/20">
                  <h4 className="font-bold text-[#3A4E62] mb-3">All Available Services:</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3">
                      {getAvailabilityIcon(selectedAddress.fibre)}
                      <span className={`text-sm ${selectedAddress.fibre ? 'text-green-700 font-semibold' : 'text-red-600'}`}>
                        Fibre Broadband (up to 2Gbps)
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      {getAvailabilityIcon(selectedAddress.wireless)}
                      <span className={`text-sm ${selectedAddress.wireless ? 'text-green-700 font-semibold' : 'text-red-600'}`}>
                        Fixed Wireless 4G (up to 100Mbps)
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      {getAvailabilityIcon(selectedAddress.vdsl)}
                      <span className={`text-sm ${selectedAddress.vdsl ? 'text-green-700 font-semibold' : 'text-red-600'}`}>
                        VDSL/ADSL (up to 30Mbps)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white px-8 py-3">
                  View Available Plans
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}