html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comsys IT | IT Support, CCTV, VoIP & Business Fibre Solutions</title>
    <meta name="description" content="Comsys IT provides reliable IT support, CCTV, VoIP, and business fibre services in Auckland. Expert IT services tailored for businesses across New Zealand.">
    <meta name="keywords" content="IT support Auckland, CCTV installation, VoIP solutions, business fibre, managed IT services, cybersecurity Auckland">
    <link rel="canonical" href="https://www.comsys.co.nz/">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Comsys IT | Auckland's Most Trusted IT Support & Solutions">
    <meta property="og:description" content="Professional IT support, CCTV, VoIP and business fibre solutions for Auckland businesses. Local expertise, reliable service.">
    <meta property="og:image" content="https://www.comsys.co.nz/wp-content/uploads/2021/04/Comsys-logo-150x55-1.png">
    <meta property="og:type" content="website">
    
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container">
            <div class="top-bar-content">
                <div class="contact-info">
                    <a href="tel:0800724526" class="contact-link">
                        <span class="icon">📞</span>
                        <span>0800 724 526</span>
                    </a>
                    <a href="mailto:info@comsys.co.nz" class="contact-link">
                        <span class="icon">✉️</span>
                        <span>info@comsys.co.nz</span>
                    </a>
                </div>
                <div class="business-hours">
                    <span class="icon">🕘</span>
                    <span>Mon-Fri: 8AM-6PM</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Header -->
    <header class="site-header">
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <a href="index.html">
                        <img src="images/comsys-logo.png" alt="COMSYS IT & Communications" width="150" height="55">
                    </a>
                </div>
                
                <nav class="main-nav">
                    <ul class="nav-menu">
                        <li class="nav-item dropdown">
                            <a href="services.html" class="nav-link">Services</a>
                            <div class="dropdown-menu">
                                <div class="dropdown-grid">
                                    <div class="dropdown-column">
                                        <h4>IT Support</h4>
                                        <a href="it-support.html">Managed IT Services</a>
                                        <a href="data-backup-recovery.html">Data Backup & Recovery</a>
                                        <a href="pc-laptop-repair.html">PC/Laptop Repair</a>
                                        <a href="wifi-upgrade.html">WiFi Network Upgrades</a>
                                    </div>
                                    <div class="dropdown-column">
                                        <h4>Business Solutions</h4>
                                        <a href="microsoft-office.html">Microsoft Office 365</a>
                                        <a href="printer-services.html">Managed Print Services</a>
                                        <a href="business-fibre.html">Business Fibre</a>
                                        <a href="voip-solutions.html">VoIP Phone Systems</a>
                                    </div>
                                    <div class="dropdown-column">
                                        <h4>Other Services</h4>
                                        <a href="web-design-hosting.html">Web Design & Hosting</a>
                                        <a href="home-fibre.html">Home Fibre</a>
                                        <a href="cctv-business.html">CCTV Solutions</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a href="industries.html" class="nav-link">Industries</a>
                            <div class="dropdown-menu">
                                <div class="dropdown-grid">
                                    <div class="dropdown-column">
                                        <a href="industries-healthcare.html">Healthcare</a>
                                        <a href="industries-legal.html">Legal</a>
                                        <a href="industries-accounting.html">Accounting</a>
                                        <a href="industries-financial.html">Financial</a>
                                    </div>
                                    <div class="dropdown-column">
                                        <a href="industries-construction.html">Construction</a>
                                        <a href="industries-retail.html">Retail</a>
                                        <a href="industries-education.html">Education</a>
                                        <a href="industries-government.html">Government</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a href="about.html" class="nav-link">About</a>
                        </li>
                        <li class="nav-item">
                            <a href="insights.html" class="nav-link">Insights</a>
                        </li>
                        <li class="nav-item">
                            <a href="contact.html" class="nav-link">Contact</a>
                        </li>
                    </ul>
                </nav>
                
                <div class="header-cta">
                    <a href="contact.html" class="btn btn-primary">Get Free Assessment</a>
                </div>
                
                <button class="mobile-menu-toggle" aria-label="Toggle mobile menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <div class="mobile-menu-content">
            <nav class="mobile-nav">
                <ul>
                    <li><a href="services.html">Services</a></li>
                    <li><a href="industries.html">Industries</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="insights.html">Insights</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
            <div class="mobile-cta">
                <a href="contact.html" class="btn btn-primary">Get Free Assessment</a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="site-main">
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="hero-background">
                <div class="hero-pattern"></div>
                <div class="hero-shapes">
                    <div class="hero-shape hero-shape-1"></div>
                    <div class="hero-shape hero-shape-2"></div>
                    <div class="hero-shape hero-shape-3"></div>
                </div>
            </div>
            
            <div class="container">
                <div class="hero-content">
                    <div class="hero-text">
                        <div class="hero-badge">
                            <span class="badge-icon">⭐</span>
                            <span>Auckland's Most Trusted IT Partner</span>
                        </div>
                        
                        <h1 class="hero-title">
                            Auckland's Most Trusted
                            <span class="hero-title-gradient">IT Support & Solutions Provider</span>
                        </h1>
                        
                        <p class="hero-description">
                            From data backup to business broadband, we deliver reliable IT services that keep 
                            your Auckland business running 24/7. Fast response times, local expertise, and 
                            comprehensive support you can count on.
                        </p>

                        <!-- Mini Testimonial -->
                        <div class="hero-testimonial">
                            <div class="testimonial-stars">
                                <span>⭐⭐⭐⭐⭐</span>
                            </div>
                            <p class="testimonial-text">
                                "COMSYS transformed our IT infrastructure completely. Their response times are incredible!"
                            </p>
                            <p class="testimonial-author">- Sarah Johnson, Auckland Marketing Ltd</p>
                        </div>

                        <div class="hero-cta">
                            <a href="contact.html" class="btn btn-primary btn-large">
                                Get a Free IT Assessment
                                <span class="btn-arrow">→</span>
                            </a>
                            <a href="contact.html" class="btn btn-outline btn-large">
                                Contact Our Team
                            </a>
                        </div>

                        <!-- Key Features -->
                        <div class="hero-features">
                            <div class="hero-feature">
                                <div class="feature-icon">🛡️</div>
                                <div class="feature-content">
                                    <h3 class="feature-number">
                                        <span class="counter" data-target="99.9">0</span>% Uptime
                                    </h3>
                                    <p>Enterprise security</p>
                                </div>
                            </div>
                            
                            <div class="hero-feature">
                                <div class="feature-icon">⚡</div>
                                <div class="feature-content">
                                    <h3>&lt;1 Hour Response</h3>
                                    <p>Critical issue support</p>
                                </div>
                            </div>
                            
                            <div class="hero-feature">
                                <div class="feature-icon">👥</div>
                                <div class="feature-content">
                                    <h3 class="feature-number">
                                        <span class="counter" data-target="500">0</span>+ Clients
                                    </h3>
                                    <p>Trusted businesses</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="hero-visual">
                        <div class="hero-image-container">
                            <img src="https://images.unsplash.com/photo-1556740758-90de374c12ad?w=1200&h=800&fit=crop" 
                                 alt="COMSYS IT support team collaborating in a modern Auckland office" 
                                 class="hero-image"
                                 width="1200" height="800">
                            <div class="hero-image-overlay"></div>
                            
                            <!-- Floating service icons -->
                            <div class="floating-icon floating-icon-1">🛡️</div>
                            <div class="floating-icon floating-icon-2">⚡</div>
                            <div class="floating-icon floating-icon-3">👥</div>
                        </div>
                        
                        <!-- Enhanced floating contact card -->
                        <div class="hero-contact-card">
                            <div class="contact-card-header">
                                <div class="contact-card-icon">✓</div>
                                <div>
                                    <h4>Get Expert Help</h4>
                                    <p>Available 24/7</p>
                                </div>
                            </div>
                            <div class="contact-card-links">
                                <a href="tel:0800724526" class="contact-card-link">
                                    <span class="contact-icon">📞</span>
                                    <span>0800 724 526</span>
                                </a>
                                <a href="mailto:info@comsys.co.nz" class="contact-card-link">
                                    <span class="contact-icon">✉️</span>
                                    <span>info@comsys.co.nz</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section -->
        <section class="stats-section">
            <div class="container">
                <div class="stats-header">
                    <div class="section-badge">
                        <span class="badge-icon">🏆</span>
                        <span>Proven Track Record</span>
                    </div>
                    <h2 class="section-title">Trusted by New Zealand Businesses</h2>
                    <p class="section-description">
                        Our track record speaks for itself. We've been delivering exceptional IT services 
                        and building lasting partnerships with businesses of all sizes.
                    </p>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">🏢</div>
                        <div class="stat-number">
                            <span class="counter" data-target="500">0</span>+
                        </div>
                        <div class="stat-label">Businesses Served</div>
                        <div class="stat-description">Trusted by companies across New Zealand</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">🏆</div>
                        <div class="stat-number">
                            <span class="counter" data-target="15">0</span>+
                        </div>
                        <div class="stat-label">Years Experience</div>
                        <div class="stat-description">Decades of IT expertise and innovation</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">🛡️</div>
                        <div class="stat-number">
                            <span class="counter" data-target="99.9" data-decimals="1">0</span>%
                        </div>
                        <div class="stat-label">Uptime Guarantee</div>
                        <div class="stat-description">Industry-leading reliability standards</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">🕘</div>
                        <div class="stat-number">24<span>/7</span></div>
                        <div class="stat-label">Support Available</div>
                        <div class="stat-description">Round-the-clock monitoring and assistance</div>
                    </div>
                </div>

                <div class="stats-badges">
                    <div class="stat-badge">
                        <span class="badge-icon">🛡️</span>
                        <span>Microsoft Certified</span>
                    </div>
                    <div class="stat-badge">
                        <span class="badge-icon">🏆</span>
                        <span>ISO Compliant</span>
                    </div>
                    <div class="stat-badge">
                        <span class="badge-icon">👥</span>
                        <span>Local Team</span>
                    </div>
                    <div class="stat-badge">
                        <span class="badge-icon">⚡</span>
                        <span>Rapid Response</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section -->
        <section class="services-section">
            <div class="services-background">
                <div class="bg-shape bg-shape-1"></div>
                <div class="bg-shape bg-shape-2"></div>
                <div class="bg-shape bg-shape-3"></div>
            </div>
            
            <div class="container">
                <div class="services-header">
                    <div class="section-badge">
                        <span class="badge-icon">✨</span>
                        <span>Complete IT Solutions</span>
                    </div>
                    <h2 class="section-title">Our Comprehensive IT Services</h2>
                    <p class="section-description">
                        From essential IT support to strategic technology solutions, we provide everything your New Zealand business needs to thrive.
                    </p>
                </div>

                <div class="services-grid">
                    <div class="service-card service-card-popular">
                        <div class="service-badge">
                            <span class="badge-icon">⭐</span>
                            <span>Most Popular</span>
                        </div>
                        <div class="service-icon">🎧</div>
                        <h3 class="service-title">IT Support & Managed Services</h3>
                        <p class="service-description">
                            Proactive, responsive IT support for NZ businesses. We act as your outsourced IT department, minimizing downtime and resolving issues fast with our local expert team.
                        </p>
                        <a href="it-support.html" class="service-cta">
                            <span>Get IT Support</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">💾</div>
                        <h3 class="service-title">Data Backup & Disaster Recovery</h3>
                        <p class="service-description">
                            Protect your most valuable asset with automated, secure data backups. Our robust solutions ensure rapid recovery from hardware failure, cyber-attacks, or accidental deletion.
                        </p>
                        <a href="data-backup-recovery.html" class="service-cta">
                            <span>Secure My Data</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">💻</div>
                        <h3 class="service-title">PC/Laptop Parts & Repair</h3>
                        <p class="service-description">
                            Extend the life of your devices with our expert repair and upgrade services. From cracked screens to performance-boosting SSD upgrades, we get you back to work quickly.
                        </p>
                        <a href="pc-laptop-repair.html" class="service-cta">
                            <span>Fix My Device</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">📶</div>
                        <h3 class="service-title">WiFi Network Upgrades</h3>
                        <p class="service-description">
                            Eliminate dead zones and slow speeds with a professional WiFi upgrade. We design and install robust wireless networks for seamless coverage in your home or office.
                        </p>
                        <a href="wifi-upgrade.html" class="service-cta">
                            <span>Upgrade WiFi</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">📄</div>
                        <h3 class="service-title">Microsoft Office 365</h3>
                        <p class="service-description">
                            Unlock your team's productivity with expert Microsoft 365 setup, management, and support. We handle licensing, security, and training to optimize your workflow.
                        </p>
                        <a href="microsoft-office.html" class="service-cta">
                            <span>Setup Office 365</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">🖨️</div>
                        <h3 class="service-title">Managed Print Services</h3>
                        <p class="service-description">
                            Reduce costs and hassle with our managed printer solutions. We handle repairs, maintenance, and automated toner supply for a predictable, low monthly cost.
                        </p>
                        <a href="printer-services.html" class="service-cta">
                            <span>Fix Printer Issues</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">🌐</div>
                        <h3 class="service-title">Business Fibre & Broadband</h3>
                        <p class="service-description">
                            Get the full speed of your internet plan with our business broadband solutions. We provide reliable, high-speed connections tailored for commercial use.
                        </p>
                        <a href="business-fibre.html" class="service-cta">
                            <span>Get Faster Internet</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">🏠</div>
                        <h3 class="service-title">Home Fibre & Internet</h3>
                        <p class="service-description">
                            Transform your home internet with ultra-fast fibre broadband. Perfect for streaming, gaming, and working from home with no contracts and unlimited data.
                        </p>
                        <a href="home-fibre.html" class="service-cta">
                            <span>Upgrade Home Internet</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">📞</div>
                        <h3 class="service-title">VoIP Business Phone Systems</h3>
                        <p class="service-description">
                            Modernize your business communications with a flexible and cost-effective VoIP system. Get enterprise-grade features and work from anywhere.
                        </p>
                        <a href="voip-solutions.html" class="service-cta">
                            <span>Get VoIP Quote</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>

                    <div class="service-card">
                        <div class="service-icon">🖥️</div>
                        <h3 class="service-title">Web Design & Hosting</h3>
                        <p class="service-description">
                            Establish a professional online presence with a custom-designed website. We build beautiful, responsive sites and provide secure, high-performance hosting.
                        </p>
                        <a href="web-design-hosting.html" class="service-cta">
                            <span>Build My Website</span>
                            <span class="cta-arrow">→</span>
                        </a>
                    </div>
                </div>

                <!-- Bottom CTA Section -->
                <div class="services-cta">
                    <div class="cta-card">
                        <div class="cta-icon">✨</div>
                        <h3>Need help choosing the right IT solution?</h3>
                        <p>Get personalized recommendations from our IT experts with a complimentary consultation tailored to your business needs.</p>
                        <a href="contact.html" class="btn btn-primary btn-large">
                            Book a Free IT Consultation
                            <span class="btn-arrow">→</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Calculator CTA Section -->
        <section class="calculator-cta-section">
            <div class="calculator-background">
                <div class="grid-pattern"></div>
            </div>
            <div class="container">
                <div class="calculator-cta">
                    <div class="calculator-icon">🧮</div>
                    <h2>Curious About Your IT Spending?</h2>
                    <p>Use our free interactive calculator to discover how much your business could potentially save by switching to COMSYS for your managed IT services. Get a personalized estimate in under a minute.</p>
                    <a href="contact.html" class="btn btn-primary btn-large">
                        Request a Consultation
                        <span class="btn-arrow">→</span>
                    </a>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="footer-main">
            <div class="container">
                <div class="footer-content">
                    <div class="footer-column footer-about">
                        <div class="footer-logo">
                            <img src="images/comsys-logo-white.png" alt="COMSYS IT & Communications" width="150" height="55">
                        </div>
                        <p class="footer-description">
                            Your trusted IT partner in Auckland. We provide comprehensive IT solutions that keep your business running smoothly and securely.
                        </p>
                        <div class="footer-contact">
                            <div class="contact-item">
                                <span class="contact-icon">📞</span>
                                <a href="tel:0800724526">0800 724 526</a>
                            </div>
                            <div class="contact-item">
                                <span class="contact-icon">✉️</span>
                                <a href="mailto:info@comsys.co.nz">info@comsys.co.nz</a>
                            </div>
                            <div class="contact-item">
                                <span class="contact-icon">📍</span>
                                <span>Level 1, 30 St Benedicts Street, Eden Terrace, Auckland 1010</span>
                            </div>
                        </div>
                    </div>

                    <div class="footer-column">
                        <h4>Services</h4>
                        <ul class="footer-links">
                            <li><a href="it-support.html">IT Support & Managed Services</a></li>
                            <li><a href="data-backup-recovery.html">Data Backup & Recovery</a></li>
                            <li><a href="pc-laptop-repair.html">PC/Laptop Repair</a></li>
                            <li><a href="wifi-upgrade.html">WiFi Network Upgrades</a></li>
                            <li><a href="microsoft-office.html">Microsoft Office 365</a></li>
                            <li><a href="business-fibre.html">Business Fibre</a></li>
                            <li><a href="voip-solutions.html">VoIP Solutions</a></li>
                        </ul>
                    </div>

                    <div class="footer-column">
                        <h4>Industries</h4>
                        <ul class="footer-links">
                            <li><a href="industries-healthcare.html">Healthcare</a></li>
                            <li><a href="industries-legal.html">Legal</a></li>
                            <li><a href="industries-accounting.html">Accounting</a></li>
                            <li><a href="industries-construction.html">Construction</a></li>
                            <li><a href="industries-retail.html">Retail</a></li>
                            <li><a href="industries-education.html">Education</a></li>
                        </ul>
                    </div>

                    <div class="footer-column">
                        <h4>Company</h4>
                        <ul class="footer-links">
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="insights.html">Insights</a></li>
                            <li><a href="contact.html">Contact</a></li>
                            <li><a href="pricing.html">Pricing</a></li>
                            <li><a href="areas-we-serve.html">Areas We Serve</a></li>
                        </ul>
                    </div>

                    <div class="footer-column">
                        <h4>Get Help</h4>
                        <ul class="footer-links">
                            <li><a href="remote-support.html">Remote Support</a></li>
                            <li><a href="contact.html">Emergency Support</a></li>
                            <li><a href="contact.html">Request Quote</a></li>
                            <li><a href="contact.html">Book Consultation</a></li>
                        </ul>
                        
                        <div class="footer-social">
                            <h5>Follow Us</h5>
                            <div class="social-links">
                                <a href="https://www.facebook.com/comsysnz/" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                                    <span class="social-icon">📘</span>
                                </a>
                                <a href="https://www.linkedin.com/company/comsys-it-&-communications-ltd/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                                    <span class="social-icon">💼</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-content">
                    <div class="footer-copyright">
                        <p>&copy; 2024 COMSYS IT & Communications Ltd. All rights reserved.</p>
                    </div>
                    <div class="footer-legal">
                        <a href="privacy-policy.html">Privacy Policy</a>
                        <a href="terms-of-service.html">Terms of Service</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" aria-label="Back to top">
        <span class="back-to-top-icon">↑</span>
    </button>

    <!-- Scripts -->
    <script src="js/main.js"></script>

    <!-- Schema Markup -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "COMSYS IT & Communications",
        "image": "https://comsys.co.nz/wp-content/uploads/2024/02/logo-5-1-1.png",
        "@id": "https://www.comsys.co.nz/",
        "url": "https://www.comsys.co.nz/",
        "telephone": "0800 724 526",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Level 1, 30 St Benedicts Street, Eden Terrace",
            "addressLocality": "Auckland",
            "postalCode": "1010",
            "addressCountry": "NZ"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": -36.8622,
            "longitude": 174.7618
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            "opens": "08:00",
            "closes": "18:00"
        },
        "sameAs": [
            "https://www.facebook.com/comsysnz/",
            "https://www.linkedin.com/company/comsys-it-&-communications-ltd/"
        ]
    }
    </script>
</body>
</html>
