/* COMSYS IT - Complete Website Styles */

/* CSS Reset and Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    font-size: 16px;
    scroll-behavior: smooth;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: #3A4E62;
    background-color: #ffffff;
    overflow-x: hidden;
}

/* Container */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

@media (max-width: 768px) {
    .container {
        padding: 0 1rem;
    }
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
    font-weight: 700;
    line-height: 1.2;
    color: #3A4E62;
}

p {
    margin-bottom: 1rem;
}

a {
    text-decoration: none;
    color: inherit;
    transition: all 0.3s ease;
}

/* Buttons */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 0.75rem;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    gap: 0.5rem;
}

.btn-large {
    padding: 1rem 2rem;
    font-size: 1.125rem;
}

.btn-primary {
    background: linear-gradient(135deg, #53B289 0%, #4aa07b 100%);
    color: white;
    box-shadow: 0 4px 15px rgba(83, 178, 137, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #4aa07b 0%, #53B289 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(83, 178, 137, 0.4);
}

.btn-outline {
    border: 2px solid rgba(255, 255, 255, 0.3);
    background: rgba(255, 255, 255, 0.1);
    color: white;
    backdrop-filter: blur(10px);
}

.btn-outline:hover {
    background: white;
    color: #3A4E62;
    border-color: white;
}

.btn-arrow {
    transition: transform 0.3s ease;
}

.btn:hover .btn-arrow {
    transform: translateX(4px);
}

/* Section Badges */
.section-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(83, 178, 137, 0.15);
    border: 1px solid rgba(83, 178, 137, 0.3);
    border-radius: 2rem;
    padding: 0.5rem 1.5rem;
    font-weight: 600;
    color: #53B289;
    margin-bottom: 2rem;
}

/* Section Titles */
.section-title {
    font-size: 3rem;
    font-weight: 800;
    text-align: center;
    margin-bottom: 1.5rem;
    color: #3A4E62;
}

.section-description {
    font-size: 1.25rem;
    text-align: center;
    color: rgba(58, 78, 98, 0.8);
    max-width: 800px;
    margin: 0 auto 3rem;
}

@media (max-width: 768px) {
    .section-title {
        font-size: 2rem;
    }
    
    .section-description {
        font-size: 1.125rem;
    }
}

/* Top Bar */
.top-bar {
    background: #2a3749;
    color: white;
    padding: 0.5rem 0;
    font-size: 0.875rem;
}

.top-bar-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.contact-info {
    display: flex;
    gap: 2rem;
}

.contact-link {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: white;
    transition: color 0.3s ease;
}

.contact-link:hover {
    color: #53B289;
}

.business-hours {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

@media (max-width: 768px) {
    .top-bar-content {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .contact-info {
        gap: 1rem;
    }
}

/* Header */
.site-header {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    position: fixed;
    top: 40px;
    left: 0;
    right: 0;
    z-index: 1000;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
    border-bottom: 1px solid rgba(83, 178, 137, 0.1);
}

.header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem 0;
}

.logo img {
    height: 50px;
    width: auto;
}

/* Navigation */
.main-nav {
    display: flex;
    align-items: center;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-item {
    position: relative;
}

.nav-link {
    font-weight: 500;
    color: #3A4E62;
    padding: 0.5rem 0;
    transition: color 0.3s ease;
}

.nav-link:hover {
    color: #53B289;
}

/* Dropdown Menu */
.dropdown {
    position: relative;
}

.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    background: white;
    border-radius: 1rem;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
    padding: 2rem;
    min-width: 600px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(10px);
    transition: all 0.3s ease;
    border: 1px solid rgba(83, 178, 137, 0.1);
}

.dropdown:hover .dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.dropdown-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
}

.dropdown-column h4 {
    font-size: 1.125rem;
    font-weight: 700;
    color: #3A4E62;
    margin-bottom: 1rem;
    border-bottom: 2px solid #53B289;
    padding-bottom: 0.5rem;
}

.dropdown-column a {
    display: block;
    padding: 0.5rem 0;
    color: rgba(58, 78, 98, 0.8);
    transition: all 0.3s ease;
}

.dropdown-column a:hover {
    color: #53B289;
    padding-left: 0.5rem;
}

/* Mobile Menu */
.mobile-menu-toggle {
    display: none;
    flex-direction: column;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0.5rem;
    gap: 0.25rem;
}

.mobile-menu-toggle span {
    width: 25px;
    height: 3px;
    background: #3A4E62;
    border-radius: 2px;
    transition: all 0.3s ease;
}

.mobile-menu {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(58, 78, 98, 0.95);
    backdrop-filter: blur(20px);
    z-index: 2000;
}

.mobile-menu-content {
    padding: 2rem;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.mobile-nav ul {
    list-style: none;
    text-align: center;
}

.mobile-nav li {
    margin: 1rem 0;
}

.mobile-nav a {
    color: white;
    font-size: 1.5rem;
    font-weight: 600;
}

.mobile-cta {
    margin-top: 2rem;
}

@media (max-width: 992px) {
    .main-nav,
    .header-cta {
        display: none;
    }
    
    .mobile-menu-toggle {
        display: flex;
    }
    
    .dropdown-menu {
        min-width: 400px;
    }
    
    .dropdown-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .site-header {
        top: 35px;
    }
    
    .dropdown-menu {
        min-width: 300px;
        left: -200px;
    }
    
    .dropdown-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}

/* Hero Section */
.hero-section {
    background: linear-gradient(135deg, #3A4E62 0%, #2a3749 50%, #1e2832 100%);
    color: white;
    padding: 160px 0 100px;
    position: relative;
    overflow: hidden;
    min-height: 100vh;
    display: flex;
    align-items: center;
}

.hero-background {
    position: absolute;
    inset: 0;
    overflow: hidden;
}

.hero-pattern {
    position: absolute;
    inset: 0;
    opacity: 0.05;
    background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2353B289' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}

.hero-shapes {
    position: absolute;
    inset: 0;
}

.hero-shape {
    position: absolute;
    border-radius: 50%;
    background: rgba(83, 178, 137, 0.1);
}

.hero-shape-1 {
    width: 20rem;
    height: 20rem;
    top: 5rem;
    left: 2.5rem;
    animation: float 6s ease-in-out infinite;
}

.hero-shape-2 {
    width: 16rem;
    height: 16rem;
    bottom: 8rem;
    right: 4rem;
    animation: float 8s ease-in-out infinite reverse;
}

.hero-shape-3 {
    width: 12rem;
    height: 12rem;
    top: 50%;
    right: 2rem;
    animation: pulse 4s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.1; }
    50% { transform: scale(1.05); opacity: 0.2; }
}

.hero-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
    position: relative;
    z-index: 10;
}

.hero-text {
    space-y: 2rem;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(83, 178, 137, 0.2);
    border: 1px solid rgba(83, 178, 137, 0.3);
    border-radius: 2rem;
    padding: 0.75rem 1.5rem;
    font-weight: 600;
    color: #53B289;
    margin-bottom: 2rem;
    backdrop-filter: blur(10px);
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 800;
    line-height: 1.1;
    margin-bottom: 1.5rem;
}

.hero-title-gradient {
    background: linear-gradient(135deg, #53B289 0%, #C0E3D4 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: block;
}

.hero-description {
    font-size: 1.25rem;
    line-height: 1.6;
    opacity: 0.9;
    margin-bottom: 2rem;
    max-width: 600px;
}

.hero-testimonial {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 1rem;
    padding: 1.5rem;
    margin: 2rem 0;
    backdrop-filter: blur(10px);
    max-width: 500px;
}

.testimonial-stars {
    margin-bottom: 0.75rem;
}

.testimonial-text {
    font-size: 0.875rem;
    font-style: italic;
    opacity: 0.9;
    margin-bottom: 0.5rem;
}

.testimonial-author {
    font-size: 0.75rem;
    opacity: 0.7;
}

.hero-cta {
    display: flex;
    gap: 1rem;
    margin: 2rem 0;
    flex-wrap: wrap;
}

.hero-features {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
    margin-top: 3rem;
}

.hero-feature {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.feature-icon {
    width: 3rem;
    height: 3rem;
    background: #53B289;
    border-radius: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    box-shadow: 0 4px 15px rgba(83, 178, 137, 0.3);
}

.feature-content h3 {
    font-size: 1rem;
    font-weight: 700;
    color: white;
    margin-bottom: 0.25rem;
}

.feature-content p {
    font-size: 0.875rem;
    opacity: 0.7;
    margin: 0;
}

/* Hero Visual */
.hero-visual {
    position: relative;
}

.hero-image-container {
    position: relative;
    border-radius: 2rem;
    overflow: hidden;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.hero-image {
    width: 100%;
    height: 400px;
    object-fit: cover;
}

.hero-image-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(58, 78, 98, 0.8) 0%, transparent 50%, rgba(83, 178, 137, 0.6) 100%);
}

.floating-icon {
    position: absolute;
    width: 3rem;
    height: 3rem;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(10px);
    animation: float 3s ease-in-out infinite;
}

.floating-icon-1 {
    top: 1.5rem;
    left: 1.5rem;
    animation-delay: 0s;
}

.floating-icon-2 {
    top: 1.5rem;
    right: 1.5rem;
    animation-delay: 1s;
}

.floating-icon-3 {
    bottom: 1.5rem;
    right: 1.5rem;
    animation-delay: 2s;
}

.hero-contact-card {
    position: absolute;
    bottom: -2rem;
    left: -2rem;
    background: white;
    border-radius: 1.5rem;
    padding: 1.5rem;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
    border: 1px solid rgba(192, 227, 212, 0.3);
    min-width: 280px;
}

.contact-card-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
}

.contact-card-icon {
    width: 2.5rem;
    height: 2.5rem;
    background: #53B289;
    border-radius: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

.contact-card-header h4 {
    font-size: 1rem;
    font-weight: 700;
    color: #3A4E62;
    margin-bottom: 0.25rem;
}

.contact-card-header p {
    font-size: 0.75rem;
    color: rgba(58, 78, 98, 0.7);
    margin: 0;
}

.contact-card-links {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.contact-card-link {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    color: #3A4E62;
    font-size: 0.875rem;
    font-weight: 500;
    transition: color 0.3s ease;
}

.contact-card-link:hover {
    color: #53B289;
}

@media (max-width: 992px) {
    .hero-content {
        grid-template-columns: 1fr;
        gap: 3rem;
        text-align: center;
    }
    
    .hero-title {
        font-size: 3rem;
    }
    
    .hero-features {
        justify-content: center;
    }
    
    .hero-contact-card {
        position: static;
        margin: 2rem auto 0;
        max-width: 300px;
    }
}

@media (max-width: 768px) {
    .hero-section {
        padding: 120px 0 80px;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-description {
        font-size: 1.125rem;
    }
    
    .hero-features {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .hero-cta {
        flex-direction: column;
        align-items: center;
    }
    
    .btn-large {
        width: 100%;
        max-width: 300px;
    }
}

/* Stats Section */
.stats-section {
    padding: 100px 0;
    background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 50%, #dbeafe 100%);
    position: relative;
    overflow: hidden;
}

.stats-section::before {
    content: '';
    position: absolute;
    top: -40%;
    right: -40%;
    width: 80%;
    height: 80%;
    background: radial-gradient(circle, rgba(83, 178, 137, 0.1) 0%, transparent 70%);
    border-radius: 50%;
}

.stats-section::after {
    content: '';
    position: absolute;
    bottom: -40%;
    left: -40%;
    width: 80%;
    height: 80%;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
    border-radius: 50%;
}

.stats-header {
    text-align: center;
    margin-bottom: 4rem;
    position: relative;
    z-index: 10;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
    position: relative;
    z-index: 10;
}

.stat-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 2rem;
    padding: 2.5rem 1.5rem;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    border: 2px solid rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(20px);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #53B289 0%, #4aa07b 100%);
    transform: scaleX(0);
    transition: transform 0.3s ease;
    transform-origin: left;
}

.stat-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    border-color: rgba(83, 178, 137, 0.4);
}

.stat-card:hover::before {
    transform: scaleX(1);
}

.stat-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    display: block;
}

.stat-number {
    font-size: 3rem;
    font-weight: 800;
    color: #53B289;
    margin-bottom: 0.5rem;
    line-height: 1;
}

.stat-label {
    font-size: 1.25rem;
    font-weight: 700;
    color: #3A4E62;
    margin-bottom: 0.5rem;
}

.stat-description {
    color: rgba(58, 78, 98, 0.7);
    font-size: 0.875rem;
    line-height: 1.4;
}

.stats-badges {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 2rem;
    position: relative;
    z-index: 10;
    padding-top: 2rem;
    border-top: 1px solid rgba(58, 78, 98, 0.1);
}

.stat-badge {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: rgba(58, 78, 98, 0.7);
    font-weight: 500;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
    
    .stat-card {
        padding: 2rem 1rem;
    }
    
    .stat-number {
        font-size: 2.5rem;
    }
    
    .stats-badges {
        flex-direction: column;
        align-items: center;
        gap: 1rem;
    }
}

/* Services Section */
.services-section {
    padding: 120px 0;
    background: linear-gradient(135deg, rgba(83, 178, 137, 0.08) 0%, rgba(192, 227, 212, 0.12) 50%, rgba(248, 250, 252, 1) 100%);
    position: relative;
    overflow: hidden;
}

.services-background {
    position: absolute;
    inset: 0;
    overflow: hidden;
}

.bg-shape {
    position: absolute;
    border-radius: 50%;
    filter: blur(100px);
}

.bg-shape-1 {
    width: 400px;
    height: 400px;
    background: rgba(83, 178, 137, 0.15);
    top: 25%;
    right: 25%;
}

.bg-shape-2 {
    width: 320px;
    height: 320px;
    background: rgba(192, 227, 212, 0.1);
    bottom: 25%;
    left: 25%;
}

.bg-shape-3 {
    width: 200px;
    height: 200px;
    background: rgba(83, 178, 137, 0.05);
    top: 10%;
    left: 10%;
}

.services-header {
    text-align: center;
    margin-bottom: 4rem;
    position: relative;
    z-index: 10;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
    margin-bottom: 4rem;
    position: relative;
    z-index: 10;
}

.service-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 2rem;
    padding: 2.5rem;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    border: 2px solid rgba(83, 178, 137, 0.1);
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
    backdrop-filter: blur(20px);
}

.service-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(83, 178, 137, 0.1), transparent);
    transition: left 0.6s ease;
}

.service-card:hover::before {
    left: 100%;
}

.service-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    border-color: rgba(83, 178, 137, 0.3);
}

.service-card-popular {
    border-color: rgba(83, 178, 137, 0.3);
    background: linear-gradient(135deg, rgba(83, 178, 137, 0.05) 0%, rgba(255, 255, 255, 0.95) 100%);
}

.service-badge {
    position: absolute;
    top: -0.5rem;
    right: 2rem;
    background: linear-gradient(135deg, #53B289 0%, #4aa07b 100%);
    color: white;
    padding: 0.5rem 1.25rem;
    border-radius: 2rem;
    font-size: 0.75rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    box-shadow: 0 4px 15px rgba(83, 178, 137, 0.3);
    z-index: 10;
}

.service-icon {
    width: 5rem;
    height: 5rem;
    background: linear-gradient(135deg, rgba(83, 178, 137, 0.1) 0%, rgba(192, 227, 212, 0.15) 100%);
    border-radius: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 8px 25px rgba(83, 178, 137, 0.15);
    transition: all 0.3s ease;
}

.service-card:hover .service-icon {
    transform: scale(1.1) rotate(-3deg);
    box-shadow: 0 12px 35px rgba(83, 178, 137, 0.25);
}

.service-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #3A4E62;
    margin-bottom: 1rem;
    line-height: 1.3;
}

.service-description {
    color: rgba(58, 78, 98, 0.8);
    line-height: 1.6;
    margin-bottom: 2rem;
}

.service-cta {
    display: inline-flex;
    align-items: center;
    gap: 0.75rem;
    background: linear-gradient(135deg, #53B289 0%, #4aa07b 100%);
    color: white;
    padding: 1rem 2rem;
    border-radius: 1.5rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(83, 178, 137, 0.3);
    width: 100%;
    justify-content: center;
}

.service-cta:hover {
    background: linear-gradient(135deg, #4aa07b 0%, #53B289 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(83, 178, 137, 0.4);
}

.cta-arrow {
    transition: transform 0.3s ease;
}

.service-cta:hover .cta-arrow {
    transform: translateX(4px);
}

.services-cta {
    text-align: center;
    position: relative;
    z-index: 10;
}

.cta-card {
    background: linear-gradient(135deg, rgba(83, 178, 137, 0.08) 0%, rgba(248, 250, 252, 0.9) 100%);
    border-radius: 2rem;
    padding: 3rem 2rem;
    max-width: 800px;
    margin: 0 auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
    border: 2px solid rgba(83, 178, 137, 0.2);
    backdrop-filter: blur(20px);
    position: relative;
    overflow: hidden;
}

.cta-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at center, rgba(83, 178, 137, 0.05) 0%, transparent 70%);
}

.cta-icon {
    font-size: 3rem;
    margin-bottom: 1.5rem;
}

.cta-card h3 {
    font-size: 2rem;
    font-weight: 800;
    color: #3A4E62;
    margin-bottom: 1rem;
}

.cta-card p {
    font-size: 1.125rem;
    color: rgba(58, 78, 98, 0.8);
    margin-bottom: 2rem;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

@media (max-width: 768px) {
    .services-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .service-card {
        padding: 2rem;
    }
    
    .service-icon {
        width: 4rem;
        height: 4rem;
        font-size: 1.75rem;
    }
    
    .cta-card {
        padding: 2rem 1.5rem;
    }
    
    .cta-card h3 {
        font-size: 1.75rem;
    }
}

/* Calculator CTA Section */
.calculator-cta-section {
    padding: 120px 0;
    background: white;
    position: relative;
    overflow: hidden;
}

.calculator-background {
    position: absolute;
    inset: 0;
}

.grid-pattern {
    position: absolute;
    inset: 0;
    opacity: 0.05;
    background-image: linear-gradient(rgba(83, 178, 137, 0.3) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(83, 178, 137, 0.3) 1px, transparent 1px);
    background-size: 20px 20px;
}

.calculator-cta {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 3rem;
    padding: 4rem;
    text-align: center;
    max-width: 800px;
    margin: 0 auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
    border: 2px solid rgba(83, 178, 137, 0.2);
    backdrop-filter: blur(20px);
    position: relative;
    z-index: 10;
}

.calculator-icon {
    width: 4rem;
    height: 4rem;
    background: linear-gradient(135deg, #3A4E62 0%, #53B289 100%);
    border-radius: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    margin: 0 auto 2rem;
    box-shadow: 0 8px 25px rgba(58, 78, 98, 0.3);
}

.calculator-cta h2 {
    font-size: 2.5rem;
    font-weight: 800;
    color: #3A4E62;
    margin-bottom: 1.5rem;
}

.calculator-cta p {
    font-size: 1.25rem;
    color: rgba(58, 78, 98, 0.8);
    line-height: 1.6;
    margin-bottom: 2.5rem;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

@media (max-width: 768px) {
    .calculator-cta {
        padding: 3rem 2rem;
    }
    
    .calculator-cta h2 {
        font-size: 2rem;
    }
    
    .calculator-cta p {
        font-size: 1.125rem;
    }
}

/* Footer */
.site-footer {
    background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%);
    color: white;
}

.footer-main {
    padding: 80px 0 40px;
}

.footer-content {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
    gap: 3rem;
}

.footer-about {
    max-width: 400px;
}

.footer-logo {
    margin-bottom: 2rem;
}

.footer-logo img {
    height: 50px;
    width: auto;
}

.footer-description {
    font-size: 1rem;
    line-height: 1.6;
    opacity: 0.9;
    margin-bottom: 2rem;
}

.footer-contact {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
}

.contact-icon {
    font-size: 1.125rem;
    flex-shrink: 0;
    margin-top: 0.125rem;
}

.contact-item a {
    color: white;
    transition: color 0.3s ease;
}

.contact-item a:hover {
    color: #53B289;
}

.footer-column h4 {
    font-size: 1.25rem;
    font-weight: 700;
    color: white;
    margin-bottom: 1.5rem;
    position: relative;
    padding-bottom: 0.5rem;
}

.footer-column h4::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 2rem;
    height: 2px;
    background: #53B289;
}

.footer-links {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.footer-links a {
    color: rgba(255, 255, 255, 0.8);
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.footer-links a:hover {
    color: #53B289;
    padding-left: 0.5rem;
}

.footer-social {
    margin-top: 2rem;
}

.footer-social h5 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 1rem;
    color: white;
}

.social-links {
    display: flex;
    gap: 1rem;
}

.social-links a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 2.5rem;
    height: 2.5rem;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 0.75rem;
    transition: all 0.3s ease;
    font-size: 1.25rem;
}

.social-links a:hover {
    background: #53B289;
    transform: translateY(-2px);
}

.footer-bottom {
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    padding: 2rem 0;
}

.footer-bottom-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.footer-copyright {
    color: rgba(255, 255, 255, 0.7);
    font-size: 0.875rem;
}

.footer-legal {
    display: flex;
    gap: 2rem;
}

.footer-legal a {
    color: rgba(255, 255, 255, 0.7);
    font-size: 0.875rem;
    transition: color 0.3s ease;
}

.footer-legal a:hover {
    color: #53B289;
}

@media (max-width: 992px) {
    .footer-content {
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
    }
    
    .footer-about {
        grid-column: 1 / -1;
        max-width: none;
        margin-bottom: 1rem;
    }
}

@media (max-width: 768px) {
    .footer-content {
        grid-template-columns: 1fr;
        text-align: center;
        gap: 2rem;
    }
    
    .footer-column h4::after {
        left: 50%;
        transform: translateX(-50%);
    }
    
    .footer-bottom-content {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .footer-legal {
        justify-content: center;
    }
}

/* Back to Top Button */
.back-to-top {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    width: 3rem;
    height: 3rem;
    background: #53B289;
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 15px rgba(83, 178, 137, 0.3);
    transition: all 0.3s ease;
    opacity: 0;
    visibility: hidden;
    z-index: 1000;
}

.back-to-top.visible {
    opacity: 1;
    visibility: visible;
}

.back-to-top:hover {
    background: #4aa07b;
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(83, 178, 137, 0.4);
}

.back-to-top-icon {
    font-size: 1.25rem;
    font-weight: bold;
}

/* Utility Classes */
.counter {
    display: inline-block;
}

.space-y-2rem > * + * {
    margin-top: 2rem;
}

/* Animation Classes */
.fade-in {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s ease;
}

.fade-in.visible {
    opacity: 1;
    transform: translateY(0);
}

.slide-in-left {
    opacity: 0;
    transform: translateX(-30px);
    transition: all 0.6s ease;
}

.slide-in-left.visible {
    opacity: 1;
    transform: translateX(0);
}

.slide-in-right {
    opacity: 0;
    transform: translateX(30px);
    transition: all 0.6s ease;
}

.slide-in-right.visible {
    opacity: 1;
    transform: translateX(0);
}

/* Loading States */
.loading {
    opacity: 0.7;
    pointer-events: none;
}

.loading::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 20px;
    height: 20px;
    margin: -10px 0 0 -10px;
    border: 2px solid #53B289;
    border-top-color: transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to {
        transform: rotate(360deg);
    }
}

/* Focus States for Accessibility */
*:focus {
    outline: 2px solid #53B289;
    outline-offset: 2px;
}

.btn:focus,
.nav-link:focus,
.contact-link:focus {
    outline-color: #53B289;
}

/* Print Styles */
@media print {
    .site-header,
    .mobile-menu,
    .back-to-top,
    .hero-section,
    .calculator-cta-section {
        display: none;
    }
    
    body {
        font-size: 12pt;
        line-height: 1.4;
        color: black;
    }
    
    .container {
        max-width: none;
        padding: 0;
    }
}