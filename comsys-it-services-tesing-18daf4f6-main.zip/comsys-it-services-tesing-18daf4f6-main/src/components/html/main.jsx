
// COMSYS IT - Main JavaScript File

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    // Initialize image optimization. This was previously in a separate DOMContentLoaded listener.
    optimizeImages(); 
});

// Initialize Application
function initializeApp() {
    initMobileMenu();
    initScrollEffects();
    initCounters();
    initBackToTop();
    initSmoothScrolling();
    initContactForms();
    initAnimations();
    initDropdowns();
}

// Mobile Menu
function initMobileMenu() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    // Added siteHeader as per outline's mobile menu changes
    const siteHeader = document.querySelector('.site-header'); 
    const body = document.body;

    if (mobileToggle && mobileMenu && siteHeader) {
        mobileToggle.addEventListener('click', function() {
            // Updated to use classList.toggle as per outline
            mobileMenu.classList.toggle('active');
            siteHeader.classList.toggle('mobile-menu-active'); // New from outline

            // Preserve body overflow functionality, adapting to new class-based state
            if (mobileMenu.classList.contains('active')) {
                body.style.overflow = 'hidden';
            } else {
                body.style.overflow = '';
            }
            // The mobileToggle 'active' class is now implicitly managed by the menu's state
        });

        // Close mobile menu when clicking outside (adapted for classList)
        mobileMenu.addEventListener('click', function(e) {
            if (e.target === mobileMenu && mobileMenu.classList.contains('active')) {
                mobileMenu.classList.remove('active');
                siteHeader.classList.remove('mobile-menu-active');
                body.style.overflow = '';
            }
        });

        // Close mobile menu on window resize (adapted for classList)
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992 && mobileMenu.classList.contains('active')) {
                mobileMenu.classList.remove('active');
                siteHeader.classList.remove('mobile-menu-active');
                body.style.overflow = '';
            }
        });
    }
}

// Scroll Effects (Combined existing header hide/show with new sticky threshold)
function initScrollEffects() {
    const header = document.querySelector('.site-header');
    let lastScrollY = window.scrollY;
    let ticking = false;

    if (!header) return;

    function updateHeader() {
        const scrollY = window.scrollY;
        
        // Header sticky on scroll (updated threshold based on outline)
        if (scrollY > 50) { // Changed from 100 to 50
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }

        // Hide/show header on scroll (Preserved existing functionality)
        if (scrollY > lastScrollY && scrollY > 200) {
            header.style.transform = 'translateY(-100%)';
        } else {
            header.style.transform = 'translateY(0)';
        }

        lastScrollY = scrollY;
        ticking = false;
    }

    function requestTick() {
        if (!ticking) {
            requestAnimationFrame(updateHeader);
            ticking = true;
        }
    }

    window.addEventListener('scroll', requestTick);
}

// Counter Animation (REPLACED based on outline's logic)
// The outline's animateCounter uses setTimeout, which replaces the existing requestAnimationFrame with easing.
const speed = 200; // From outline: The lower the slower

function animateCounter(counter) {
    const target = +counter.getAttribute('data-target');
    const decimals = +counter.getAttribute('data-decimals') || 0;
    
    const updateCount = () => {
        const count = +counter.innerText;
        const inc = target / speed;
        
        if (count < target) {
            counter.innerText = (count + inc).toFixed(decimals);
            setTimeout(updateCount, 15);
        } else {
            // Ensure exact target value is displayed when animation finishes
            counter.innerText = target.toFixed(decimals);
        }
    };
    updateCount();
}

function initCounters() {
    const counters = document.querySelectorAll('.counter');
    
    const observerOptions = {
        root: null,
        threshold: 0.5 // From outline
    };

    const counterObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    counters.forEach(counter => {
        counterObserver.observe(counter);
    });
}

// Back to Top Button (Updated based on outline's threshold and class name)
function initBackToTop() {
    const backToTopBtn = document.querySelector('.back-to-top');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) { // Updated threshold from 500 to 300
                backToTopBtn.classList.add('show'); // Updated class from 'visible' to 'show'
            } else {
                backToTopBtn.classList.remove('show'); // Updated class from 'visible' to 'show'
            }
        });

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// Smooth Scrolling for Anchor Links (Preserved existing functionality)
function initSmoothScrolling() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') return;
            
            const target = document.querySelector(href);
            
            if (target) {
                e.preventDefault();
                
                const headerHeight = document.querySelector('.site-header')?.offsetHeight || 0;
                const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Contact Forms (Preserved existing functionality)
function initContactForms() {
    const forms = document.querySelectorAll('form[data-form="contact"]');
    
    forms.forEach(form => {
        form.addEventListener('submit', handleFormSubmit);
    });
}

async function handleFormSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    
    // Show loading state
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    form.classList.add('loading');
    
    try {
        // Here you would integrate with your form handling service
        // For now, we'll simulate a form submission
        await simulateFormSubmission(formData);
        
        // Show success message
        showFormMessage(form, 'Thank you! Your message has been sent successfully.', 'success');
        form.reset();
        
    } catch (error) {
        // Show error message
        showFormMessage(form, 'Sorry, there was an error sending your message. Please try again.', 'error');
    } finally {
        // Reset button state
        submitBtn.textContent = originalBtnText;
        submitBtn.disabled = false;
        form.classList.remove('loading');
    }
}

function simulateFormSubmission(formData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate success most of the time
            if (Math.random() > 0.1) {
                resolve();
            } else {
                reject(new Error('Simulated error'));
            }
        }, 1500);
    });
}

function showFormMessage(form, message, type) {
    // Remove existing messages
    const existingMessage = form.querySelector('.form-message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Create new message
    const messageEl = document.createElement('div');
    messageEl.className = `form-message form-message-${type}`;
    messageEl.textContent = message;
    
    // Insert message
    form.insertBefore(messageEl, form.firstChild);
    
    // Remove message after 5 seconds
    setTimeout(() => {
        if (messageEl.parentNode) {
            messageEl.remove();
        }
    }, 5000);
}

// Animation Observer (Updated selector to include 'section' elements as per outline)
function initAnimations() {
    // Combined selectors: existing animation classes + 'section' from outline
    const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, section');
    
    const observerOptions = {
        threshold: 0.1, // Same as existing and outline
        rootMargin: '0px 0px -50px 0px' // Preserved existing rootMargin
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    animatedElements.forEach(element => {
        observer.observe(element);
    });
}

// Dropdown Menus (Preserved existing functionality)
function initDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        const menu = dropdown.querySelector('.dropdown-menu');
        let timeoutId;
        
        dropdown.addEventListener('mouseenter', function() {
            clearTimeout(timeoutId);
            menu.style.opacity = '1';
            menu.style.visibility = 'visible';
            menu.style.transform = 'translateY(0)';
        });
        
        dropdown.addEventListener('mouseleave', function() {
            timeoutId = setTimeout(() => {
                menu.style.opacity = '0';
                menu.style.visibility = 'hidden';
                menu.style.transform = 'translateY(10px)';
            }, 150);
        });
    });
}

// Utility Functions (Preserved existing functionality)
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Performance Optimization (Preserved existing functionality)
function optimizeImages() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Export functions for external use (Preserved existing exports, animateCounter updated to new version)
window.COMSYS = {
    initMobileMenu,
    initScrollEffects,
    initCounters,
    animateCounter,
    showFormMessage,
    debounce,
    throttle
};
