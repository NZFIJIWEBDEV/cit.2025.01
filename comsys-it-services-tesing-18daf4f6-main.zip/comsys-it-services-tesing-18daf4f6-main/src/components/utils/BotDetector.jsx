import { useEffect } from 'react';

export default function BotDetector({ onBotDetected }) {
  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    
    const bots = [
      'googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baiduspider',
      'yandexbot', 'facebookexternalhit', 'twitterbot', 'linkedinbot'
    ];
    
    const isBot = bots.some(bot => userAgent.includes(bot));
    
    if (isBot && onBotDetected) {
      onBotDetected(userAgent);
    }
  }, [onBotDetected]);

  return null; // This component doesn't render anything
}