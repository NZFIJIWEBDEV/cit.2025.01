import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    company: 'Auckland Marketing Ltd',
    position: 'Managing Director',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    text: 'COMSYS transformed our IT infrastructure. Their data backup solution saved us during a recent hardware failure. The response time was incredible - they had us back online within 30 minutes!',
    results: 'Reduced downtime by 95%'
  },
  {
    id: 2,
    name: 'Mike Chen',
    company: 'Wellington Tech Startup',
    position: 'CEO',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    text: 'Outstanding IT support! They set up our entire office network and their proactive monitoring catches issues before they affect our team. Incredibly fast response times.',
    results: '99.9% network uptime achieved'
  },
  {
    id: 3,
    name: 'Emma Thompson',
    company: 'Christchurch Consulting',
    position: 'Operations Manager',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    text: 'Their web design service exceeded our expectations. Our new website looks amazing and has increased our online inquiries by 300%. The hosting is rock-solid.',
    results: '300% increase in online leads'
  },
];

export default function TestimonialsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  const prevTestimonial = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const interval = setInterval(nextTestimonial, 7000);
    return () => clearInterval(interval);
  }, []);

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="py-24 bg-slate-800 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Trusted by NZ Businesses
          </h2>
          <p className="text-xl text-slate-300/80 max-w-3xl mx-auto">
            Real feedback from businesses we've helped succeed across New Zealand.
          </p>
        </div>

        <div className="relative h-96">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -50, scale: 0.95 }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
              className="absolute inset-0 flex flex-col lg:flex-row items-center justify-center lg:space-x-12"
            >
              <div className="flex-shrink-0 text-center lg:text-left mb-6 lg:mb-0">
                <img
                  src={currentTestimonial.image}
                  alt={currentTestimonial.name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-[#53B289] mx-auto lg:mx-0 shadow-lg"
                />
                <h4 className="font-bold text-white text-xl mt-4">
                  {currentTestimonial.name}
                </h4>
                <p className="text-slate-300/90 font-medium">
                  {currentTestimonial.position}, {currentTestimonial.company}
                </p>
              </div>
              
              <div className="relative max-w-2xl text-center lg:text-left">
                <Quote className="absolute -top-4 -left-4 w-12 h-12 text-slate-600/70 hidden lg:block" />
                <div className="flex justify-center lg:justify-start mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-2xl text-slate-100 mb-6 leading-relaxed italic">
                  "{currentTestimonial.text}"
                </p>
                <div className="bg-[#53B289]/20 border border-[#53B289]/40 rounded-full px-5 py-2 inline-block">
                  <span className="text-[#53B289] font-semibold text-sm">
                    ✓ Key Result: {currentTestimonial.results}
                  </span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation */}
        <div className="flex justify-center items-center space-x-6 mt-16">
            <Button variant="outline" size="icon" onClick={prevTestimonial} className="rounded-full w-14 h-14 bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white">
              <ChevronLeft className="w-6 h-6" />
            </Button>
            
            <div className="flex space-x-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-[#53B289] scale-125' : 'bg-slate-600'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <Button variant="outline" size="icon" onClick={nextTestimonial} className="rounded-full w-14 h-14 bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white">
              <ChevronRight className="w-6 h-6" />
            </Button>
          </div>
      </div>
    </section>
  );
}