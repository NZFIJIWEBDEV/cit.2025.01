import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Award, Users, MapPin } from 'lucide-react';

const badges = [
    { icon: ShieldCheck, text: "Cyber Security Partner" },
    { icon: Award, text: "Certified Professionals" },
    { icon: Users, text: "15+ Years Experience" },
    { icon: MapPin, text: "100% NZ Owned" },
];

export default function SecurityBadges() {
    return (
        <section className="py-16 bg-white">
            <div className="max-w-7xl mx-auto px-6 lg:px-12">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                    {badges.map((badge, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="flex flex-col items-center space-y-3"
                        >
                            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                                <badge.icon className="w-8 h-8 text-[#53B289]" />
                            </div>
                            <p className="font-semibold text-[#3A4E62]">{badge.text}</p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}