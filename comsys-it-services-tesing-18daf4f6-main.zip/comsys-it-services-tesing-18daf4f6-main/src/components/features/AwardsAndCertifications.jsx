
import React from 'react';
import { motion } from 'framer-motion';

const awards = [
  {
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/99f98f0f0_microsoft.png',
    title: 'Microsoft Partner',
    description: 'Certified Microsoft Solutions Partner',
    width: 140,
    height: 40
  },
  {
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/910754440_images.png',
    title: 'Sophos Silver Partner',
    description: 'Certified Sophos Security Partner',
    width: 120,
    height: 40
  },
  {
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/e7d34ecdc_hewlett-packard-enterprise-color-logo_600xundefined.png',
    title: 'Hewlett Packard Enterprise',
    description: 'Authorized HPE Partner',
    width: 100,
    height: 50
  },
  {
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a8102b21b_images.png',
    title: 'Yealink Partner',
    description: 'Certified Yealink VoIP Partner',
    width: 130,
    height: 30
  }
];

export default function AwardsAndCertifications() {
  return (
    <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
            Certifications & Partnerships
          </h2>
          <p className="text-xl text-[#3A4E62]/80">
            Trusted partnerships with leading technology providers
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {awards.map((award, index) => (
            <motion.div
              key={award.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 text-center shadow-lg hover:shadow-xl transition-all duration-300 group border border-gray-200/50 hover:border-[#53B289]/30"
            >
              <div className="w-40 h-20 bg-white rounded-2xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-300">
                <img 
                  src={award.image} 
                  alt={`${award.title} logo`}
                  className="max-w-full max-h-full object-contain"
                  loading="lazy"
                  width={award.width}
                  height={award.height}
                />
              </div>
              
              <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{award.title}</h3>
              <p className="text-[#3A4E62]/70 text-sm leading-relaxed">{award.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
