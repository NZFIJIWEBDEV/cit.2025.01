
import React from "react";
import { motion } from "framer-motion";

const logos = [
  { name: "Microsoft", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1e2f78f66_99f98f0f0_microsoft.png" },
  { name: "HP", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/3c6f8097b_hp.png" },
  { name: "Sophos", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/91c4ffd9c_image.png" },
  { name: "Cisco", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/2f140219d_cisco.png" },
  { name: "Hewlett Packard Enterprise", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fa092c634_e7d34ecdc_hewlett-packard-enterprise-color-logo_600xundefined.png" },
  { name: "Proofpoint", src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/63ac35696_1200px-Proofpoint_R_Logo.png" },
];

const sliderVariants = {
  animate: {
    x: ["0%", "-100%"],
    transition: {
      x: {
        repeat: Infinity,
        repeatType: "loop",
        duration: 20,
        ease: "linear",
      },
    },
  },
};

export default function PartnerLogos() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <h2 className="text-center text-2xl font-bold text-[#3A4E62] mb-12">
          Our Trusted Partners
        </h2>
        <div className="relative w-full overflow-hidden">
          <motion.div
            className="flex"
            variants={sliderVariants}
            animate="animate"
          >
            {[...logos, ...logos].map((logo, index) => (
              <div key={index} className="flex-shrink-0 w-1/4 md:w-1/6 p-4 flex items-center justify-center">
                <img
                  src={logo.src}
                  alt={logo.name}
                  className="h-10 object-contain"
                />
              </div>
            ))}
          </motion.div>
          <div className="absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-gray-50 to-transparent"></div>
          <div className="absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-gray-50 to-transparent"></div>
        </div>
      </div>
    </section>
  );
}
