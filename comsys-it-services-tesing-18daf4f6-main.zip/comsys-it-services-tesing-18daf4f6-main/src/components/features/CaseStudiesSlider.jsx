
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const caseStudies = [
  {
    id: 1,
    client: 'Auckland Legal Partners',
    industry: 'Legal Services',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/2f04e12e7_legal-office.jpg',
    problem: {
      title: 'Critical IT Vulnerabilities',
      description: 'Frequent server crashes, no backup strategy, and outdated security systems putting sensitive client data at risk.'
    },
    solution: {
      title: 'Comprehensive IT Overhaul',
      description: 'Implemented managed IT services with 24/7 monitoring, automated backups, and enterprise-grade security.'
    },
    results: [
      '99.9% server uptime achieved',
      '15-minute recovery point for all data',
      'Zero security incidents in 24 months',
      '40% reduction in IT-related downtime'
    ],
    timeframe: '3 months implementation',
    investment: 'ROI achieved within 6 months'
  },
  {
    id: 2,
    client: 'KiwiBuild Construction',
    industry: 'Construction',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/21a12006d_construction-site.jpg',
    problem: {
      title: 'Poor Site Connectivity',
      description: 'Unreliable internet at job sites causing project delays and communication breakdowns between teams.'
    },
    solution: {
      title: 'Mobile Network Solutions',
      description: 'Deployed portable WiFi units and cloud-based project management systems across 5 active construction sites.'
    },
    results: [
      'Reliable connectivity at all sites',
      '50% faster project updates',
      '30% improvement in team coordination',
      'Real-time access to blueprints and schedules'
    ],
    timeframe: '2 weeks deployment',
    investment: '25% increase in project efficiency'
  },
  {
    id: 3,
    client: 'Bay Medical Centre',
    industry: 'Healthcare',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/9f34fcc46_medical-clinic.jpg',
    problem: {
      title: 'Compliance & Security Risks',
      description: 'Outdated systems failing to meet healthcare compliance requirements and putting patient data at risk.'
    },
    solution: {
      title: 'Healthcare-Compliant IT Infrastructure',
      description: 'Implemented HIPAA-compliant systems with encrypted data storage, secure patient portals, and audit trails.'
    },
    results: [
      '100% compliance with healthcare regulations',
      'Secure patient data management',
      '60% faster patient check-ins',
      'Enhanced doctor-patient communication'
    ],
    timeframe: '4 months implementation',
    investment: 'Full compliance achieved with zero breaches'
  }
];

export default function CaseStudiesSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextCase = () => {
    setCurrentIndex((prev) => (prev + 1) % caseStudies.length);
  };

  const prevCase = () => {
    setCurrentIndex((prev) => (prev - 1 + caseStudies.length) % caseStudies.length);
  };

  const currentCase = caseStudies[currentIndex];

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
            Real Results for Real Businesses
          </h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            See how we've transformed IT challenges into business success stories across New Zealand
          </p>
        </motion.div>

        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="grid lg:grid-cols-2 gap-12 items-center"
            >
              {/* Image */}
              <div className="relative">
                <img
                  src={currentCase.image}
                  alt={`${currentCase.client} case study`}
                  className="w-full h-80 lg:h-96 object-cover rounded-3xl shadow-2xl"
                  loading="lazy"
                  width="800"
                  height="600"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#3A4E62]/60 to-transparent rounded-3xl"></div>
                <div className="absolute bottom-6 left-6 text-white">
                  <h3 className="text-2xl font-bold mb-1">{currentCase.client}</h3>
                  <p className="text-white/90">{currentCase.industry}</p>
                </div>
              </div>

              {/* Content */}
              <div className="space-y-8">
                {/* Problem */}
                <div className="bg-red-50 border-l-4 border-red-500 p-6 rounded-r-xl">
                  <h4 className="text-xl font-bold text-red-700 mb-3">
                    The Challenge
                  </h4>
                  <h5 className="font-semibold text-red-600 mb-2">{currentCase.problem.title}</h5>
                  <p className="text-red-600/80">{currentCase.problem.description}</p>
                </div>

                {/* Solution */}
                <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-xl">
                  <h4 className="text-xl font-bold text-blue-700 mb-3">
                    Our Solution
                  </h4>
                  <h5 className="font-semibold text-blue-600 mb-2">{currentCase.solution.title}</h5>
                  <p className="text-blue-600/80">{currentCase.solution.description}</p>
                </div>

                {/* Results */}
                <div className="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-xl">
                  <h4 className="text-xl font-bold text-green-700 mb-4">
                    The Results
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {currentCase.results.map((result, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-green-700 font-medium">{result}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-green-200">
                    <div>
                      <span className="text-green-600 text-sm font-medium">Timeline:</span>
                      <p className="text-green-700 font-semibold">{currentCase.timeframe}</p>
                    </div>
                    <div>
                      <span className="text-green-600 text-sm font-medium">Impact:</span>
                      <p className="text-green-700 font-semibold">{currentCase.investment}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex justify-center items-center space-x-6 mt-12">
            <Button
              variant="outline"
              size="sm"
              onClick={prevCase}
              className="rounded-full w-12 h-12 p-0 border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white"
              aria-label="Previous Case Study"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            
            <div className="flex space-x-2">
              {caseStudies.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-[#53B289] w-8' : 'bg-[#53B289]/30'
                  }`}
                   aria-label={`Go to case study ${index + 1}`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={nextCase}
              className="rounded-full w-12 h-12 p-0 border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white"
              aria-label="Next Case Study"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
