import React, { useEffect, useRef } from "react";
import { useInView, animate } from "framer-motion";

export default function DynamicCounter({ to, from = 0, suffix, precision = 0 }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      animate(from, to, {
        duration: 2,
        onUpdate(value) {
          if (ref.current) {
            ref.current.textContent = value.toFixed(precision);
          }
        },
      });
    }
  }, [isInView, to, from, precision]);

  return (
    <>
      <span ref={ref}>{from}</span>
      {suffix}
    </>
  );
}