import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CheckCircle, Shield, MessageCircle, ArrowRight, TrendingUp, Users, Clock } from 'lucide-react';
import PartnerLogos from '../features/PartnerLogos';

const servicePageMap = {
  'Managed IT Support': 'ITSupport',
  'Cybersecurity': 'ITSupport', // Assuming cybersecurity is part of IT support, adjust if a dedicated page exists
  'Backup & Disaster Recovery': 'DataBackupRecovery',
  'Microsoft 365 & Cloud': 'MicrosoftOffice',
  'VoIP & Contact': 'VoIPSolutions',
  'Business Broadband & Wi-Fi': 'BusinessFibre',
  'Networking & Switching': 'WiFiUpgrade',
};

// Generic sections defined once to ensure consistency
const SecuritySection = () => (
  <div className="bg-gray-50 rounded-2xl p-8 lg:p-12 mt-16">
    <h2 className="text-3xl font-bold text-[#3A4E62] mb-6 text-center">Security and Compliance First</h2>
    <div className="grid md:grid-cols-2 gap-8 text-[#3A4E62]/80 leading-relaxed">
      <p>
        Our security approach is built on modern, best-practice principles. We enforce Multi-Factor Authentication (MFA) across all critical systems, apply a policy of least-privilege access to ensure users only have the permissions they need, and implement rigorous, automated patch management to protect against known vulnerabilities. Continuous monitoring and logging provide the visibility needed to detect and respond to threats swiftly.
      </p>
      <p>
        We operate with a deep understanding of the responsibilities outlined in New Zealand's Privacy Act 2020. Our solutions are designed to help you meet your obligations for protecting personal and client information, ensuring data is handled securely, stored appropriately, and protected against unauthorized access or disclosure. We help you build the technical foundation for a strong privacy posture.
      </p>
    </div>
  </div>
);

const EngagementSection = () => (
  <section className="py-16 md:py-24">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12 text-center">How We Work With You</h2>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <Card className="shadow-lg">
            <CardHeader><CardTitle>Managed Plan</CardTitle></CardHeader>
            <CardContent>
              <p className="mb-4">For proactive, all-inclusive support, our fixed-fee monthly plans provide unlimited remote assistance, 24/7 monitoring, and strategic guidance. This is the best choice for businesses seeking predictable costs and maximum uptime.</p>
              <Link to={createPageUrl("ContactUs?subject=ManagedPlanInquiry")}><Button>Get a Plan Quote</Button></Link>
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardHeader><CardTitle>Project-Based</CardTitle></CardHeader>
            <CardContent>
              <p className="mb-4">Have a specific goal, like a cloud migration, office move, or network upgrade? We deliver on-time, on-budget projects with clear scopes and dedicated project management to achieve your desired outcomes.</p>
              <Link to={createPageUrl("ContactUs?subject=ProjectInquiry")}><Button>Discuss a Project</Button></Link>
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardHeader><CardTitle>On-Demand Support</CardTitle></CardHeader>
            <CardContent>
              <p className="mb-4">For ad-hoc issues or businesses not ready for a full managed plan, our on-demand support provides expert assistance when you need it. You get access to our skilled engineers on an hourly or daily basis.</p>
              <Link to={createPageUrl("ContactUs?subject=OnDemandSupport")}><Button>Request Support</Button></Link>
            </CardContent>
          </Card>
        </div>
    </div>
  </section>
);


export default function IndustryPageLayout({ industry }) {
  const {
    name,
    h1,
    subtitle,
    heroImage,
    challenges,
    outcomes,
    solutions,
    integrations,
    caseStudy,
    faqs
  } = industry;

  return (
    <div className="bg-white text-[#3A4E62]">
      {/* SEO TITLE: {`${name} IT Services | Comsys (Auckland)`} */}
      {/* SEO META: {`Specialized IT services for ${name} in Auckland. We provide [Service 1], [Service 2], and strategic support to improve efficiency and security.`} */}
      
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gray-800 text-white">
        <div className="absolute inset-0">
          <img src={heroImage} alt={`IT Services for ${name}`} className="w-full h-full object-cover opacity-30" />
        </div>
        <div className="relative max-w-7xl mx-auto px-6 lg:px-12 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="text-4xl lg:text-6xl font-bold mb-6"
          >
            {h1}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="text-lg md:text-xl max-w-3xl mx-auto text-white/90 mb-8"
          >
            {subtitle}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to={createPageUrl(`ContactUs?subject=QuoteFor_${name}`)}>
              <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full sm:w-auto">Get a Quote</Button>
            </Link>
            <Link to={createPageUrl(`ContactUs?subject=TalkToEngineer_${name}`)}>
              <Button size="lg" variant="outline" className="text-white border-white/50 hover:bg-white hover:text-[#3A4E62] w-full sm:w-auto">Talk to an Engineer</Button>
            </Link>
          </motion.div>
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm max-w-2xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex items-center justify-center gap-2"><Users className="w-4 h-4 text-[#53B289]"/>Local NZ support</div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex items-center justify-center gap-2"><Clock className="w-4 h-4 text-[#53B289]"/>Fast response SLAs</div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex items-center justify-center gap-2"><Shield className="w-4 h-4 text-[#53B289]"/>Security-first</div>
          </div>
        </div>
      </section>

      {/* Problem -> Outcome */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Overcoming Your Challenges</h2>
            <ul className="space-y-4">
              {challenges.map((challenge, i) => (
                <li key={i} className="flex items-start">
                  <MessageCircle className="w-6 h-6 text-red-500 mr-3 mt-1 flex-shrink-0" />
                  <span>{challenge}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-green-50 p-8 rounded-2xl">
            <h2 className="text-3xl font-bold mb-6 text-green-800">Achieving Better Outcomes</h2>
            <ul className="space-y-4">
               {outcomes.map((outcome, i) => (
                <li key={i} className="flex items-start">
                  <CheckCircle className="w-6 h-6 text-green-600 mr-3 mt-1 flex-shrink-0" />
                  <span className="font-medium text-green-900">{outcome}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Solution Stack */}
      <section className="py-16 md:py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12 text-center">Our {name} Solution Stack</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {solutions.map((service, i) => (
                      <Card key={i} className="flex flex-col">
                          <CardHeader>
                              <CardTitle>{service.title}</CardTitle>
                          </CardHeader>
                          <CardContent className="flex-grow">
                              <p className="text-[#3A4E62]/80">{service.description}</p>
                          </CardContent>
                          <div className="p-6 pt-0">
                            <Link to={createPageUrl(servicePageMap[service.title] || 'Services')}>
                              <Button variant="outline" className="w-full group">
                                Learn more <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                              </Button>
                            </Link>
                          </div>
                      </Card>
                  ))}
              </div>
          </div>
      </section>
      
      {/* Integrations */}
      <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12 text-center">Works With Your Tools</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 text-center">
                  {integrations.map((tool, i) => (
                      <div key={i} className="bg-gray-100 p-4 rounded-lg">
                          <p className="font-bold text-[#3A4E62]">{tool.name}</p>
                          <p className="text-sm text-[#3A4E62]/70">{tool.note}</p>
                      </div>
                  ))}
              </div>
          </div>
      </section>

      {/* Security & Case Study */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
            <h2 className="text-3xl font-bold text-[#3A4E62] mb-6 text-center">Customer Story: {caseStudy.client}</h2>
            <blockquote className="text-center italic text-lg text-[#3A4E62]/90 border-l-4 border-[#53B289] pl-6 py-4">
              "{caseStudy.quote}"
            </blockquote>
            <p className="mt-4 text-center text-[#3A4E62]/80 leading-relaxed">{caseStudy.story}</p>
            <SecuritySection />
        </div>
      </section>

      <EngagementSection />

      {/* FAQs */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
           <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12 text-center">Frequently Asked Questions</h2>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-white mb-4 rounded-lg shadow-sm">
                  <AccordionTrigger className="p-6 text-left font-semibold text-lg hover:no-underline">{faq.q}</AccordionTrigger>
                  <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">{faq.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-[#3A4E62] text-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
           <h2 className="text-3xl lg:text-4xl font-bold mb-6">Ready to improve your {name} IT?</h2>
           <p className="text-xl text-white/80 mb-8">Let's discuss how Comsys can provide a secure, reliable, and efficient technology foundation for your business.</p>
           <Link to={createPageUrl(`ContactUs?subject=StrategyCall_${name}`)}>
              <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">Book a Free Strategy Call</Button>
           </Link>
        </div>
      </section>
      
      <PartnerLogos />
    </div>
  );
}