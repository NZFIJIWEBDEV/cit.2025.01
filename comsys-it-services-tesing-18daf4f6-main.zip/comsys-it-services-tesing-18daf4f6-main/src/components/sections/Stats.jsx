import React from "react";
import { motion } from "framer-motion";
import { Building2, Trophy, ShieldCheck, Clock, Users, Star, Award, Zap } from "lucide-react";
import DynamicCounter from "../features/DynamicCounters";

const stats = [
  {
    icon: Building2,
    value: 500,
    suffix: "+",
    label: "Businesses Served",
    description: "Trusted by companies across New Zealand",
  },
  {
    icon: Award,
    value: 15,
    suffix: "+",
    label: "Years Experience",
    description: "Decades of IT expertise and innovation",
  },
  {
    icon: ShieldCheck,
    value: 99.9,
    suffix: "%",
    precision: 1,
    label: "Uptime Guarantee",
    description: "Industry-leading reliability standards",
  },
  {
    icon: Clock,
    value: 24,
    suffix: "/7",
    label: "Support Available",
    description: "Round-the-clock monitoring and assistance",
  }
];

export default function Stats() {
  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 via-gray-50 to-blue-50 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#53B289]/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-200/20 rounded-full blur-3xl"></div>
        <div className="absolute top-20 left-20 w-64 h-64 bg-[#53B289]/5 rounded-full blur-2xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center space-x-2 bg-[#53B289]/15 backdrop-blur-sm border border-[#53B289]/30 rounded-full px-6 py-2 mb-6"
          >
            <Trophy className="w-5 h-5 text-[#53B289]" />
            <span className="text-[#53B289] font-semibold">Proven Track Record</span>
          </motion.div>

          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl lg:text-5xl font-bold text-[#3A4E62] mb-6"
          >
            Trusted by New Zealand Businesses
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto leading-relaxed"
          >
            Our track record speaks for itself. We've been delivering exceptional IT services 
            and building lasting partnerships with businesses of all sizes.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className={`
                relative group cursor-pointer
                bg-white/90 backdrop-blur-sm rounded-3xl p-8 text-center 
                shadow-lg hover:shadow-2xl transition-all duration-500
                border border-gray-200/50 hover:border-[#53B289]/40
                transform hover:-translate-y-2
              `}
            >
              <div className="relative mb-6">
                <div className={`
                  w-20 h-20 bg-[#53B289]/10 group-hover:bg-[#53B289]/20 rounded-2xl flex items-center justify-center mb-4 mx-auto
                  shadow-lg group-hover:shadow-xl transition-all duration-500
                  group-hover:scale-110 group-hover:-rotate-3
                `}>
                  <stat.icon className="w-10 h-10 text-[#53B289] group-hover:text-[#4aa07b] transition-colors duration-300" />
                </div>
              </div>
              
              <div className="relative z-10">
                <div className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-3">
                  <DynamicCounter 
                    to={stat.value} 
                    suffix={stat.suffix} 
                    precision={stat.precision}
                  />
                </div>
                <div className="text-xl font-bold text-[#3A4E62] mb-3">
                  {stat.label}
                </div>
                <p className="text-[#3A4E62]/70 leading-relaxed text-sm">
                  {stat.description}
                </p>
              </div>

              <div className={`
                absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#53B289] to-[#4aa07b]
                rounded-b-3xl transform scale-x-0 group-hover:scale-x-100 
                transition-transform duration-500 origin-left
              `}></div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap justify-center items-center gap-8 mt-16 pt-8 border-t border-gray-200"
        >
          <div className="flex items-center space-x-2 text-[#3A4E62]/70">
            <ShieldCheck className="w-5 h-5 text-[#53B289]" />
            <span className="font-medium">Microsoft Certified</span>
          </div>
          <div className="flex items-center space-x-2 text-[#3A4E62]/70">
            <Award className="w-5 h-5 text-[#53B289]" />
            <span className="font-medium">ISO Compliant</span>
          </div>
          <div className="flex items-center space-x-2 text-[#3A4E62]/70">
            <Users className="w-5 h-5 text-[#53B289]" />
            <span className="font-medium">Local Team</span>
          </div>
          <div className="flex items-center space-x-2 text-[#3A4E62]/70">
            <Zap className="w-5 h-5 text-[#53B289]" />
            <span className="font-medium">Rapid Response</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}