import React from "react";
import { motion } from "framer-motion";
import { CheckCircle, Headphones, Shield, TrendingUp, Users, Clock, Star } from "lucide-react";

const reasons = [
  {
    icon: Headphones,
    title: "Local New Zealand Team",
    description: "Get responsive, personalized support from our Auckland-based experts who understand the local business landscape."
  },
  {
    icon: Shield,
    title: "Proactive Security",
    description: "We stay ahead of cyber threats with 24/7 monitoring and advanced security protocols to protect your valuable data."
  },
  {
    icon: TrendingUp,
    title: "Scalable Solutions",
    description: "Our flexible IT infrastructure grows with your business, ensuring you always have the technology you need to succeed."
  },
  {
    icon: Users,
    title: "Dedicated Account Manager",
    description: "Enjoy a single point of contact who understands your business inside-out for truly personalized service."
  },
  {
    icon: Clock,
    title: "Rapid Response",
    description: "Minimizing your downtime is our priority. Critical issues are addressed with industry-leading speed and efficiency."
  },
  {
    icon: Star,
    title: "Proven Excellence",
    description: "With 15+ years of experience, we have a track record of delivering reliable results for hundreds of NZ businesses."
  }
];

export default function WhyChooseUs() {
  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 via-slate-50 to-[#C0E3D4]/10">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
            The COMSYS Advantage
          </h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            We're more than an IT provider; we're your strategic partner, committed to driving your business forward.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <motion.div
              key={reason.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="group relative bg-white/90 backdrop-blur-sm rounded-3xl p-8 overflow-hidden transition-all duration-300 ease-in-out hover:bg-white hover:shadow-2xl hover:-translate-y-2 border-2 border-[#53B289]/10 hover:border-[#53B289]/30"
            >
              <div className="absolute top-0 right-0 -mt-16 -mr-16 w-40 h-40 bg-[#53B289]/5 rounded-full transition-all duration-500 group-hover:scale-[10] group-hover:bg-[#53B289]/10"></div>

              <div className="relative z-10">
                <div className="w-16 h-16 bg-[#53B289]/10 border border-[#53B289]/20 rounded-2xl flex items-center justify-center mb-6 shadow-sm group-hover:border-[#53B289]/40 group-hover:bg-[#53B289]/20 transition-colors">
                  <reason.icon className="w-8 h-8 text-[#53B289] group-hover:text-[#4aa07b] transition-colors" />
                </div>
                
                <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{reason.title}</h3>
                <p className="text-[#3A4E62]/80 leading-relaxed">{reason.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}