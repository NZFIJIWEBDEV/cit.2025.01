import React from "react";
import { motion } from "framer-motion";
import { MapPin, Building, Users, Home } from "lucide-react";

const serviceAreas = [
  {
    icon: Building,
    title: "Auckland",
    description: "Comprehensive IT services throughout the greater Auckland region, from North Shore to South Auckland."
  },
  {
    icon: Users,
    title: "Wellington",
    description: "Professional IT support for businesses and government organizations in the capital region."
  },
  {
    icon: Home,
    title: "Christchurch",
    description: "Reliable technology solutions for Canterbury businesses, from SMEs to large enterprises."
  }
];

export default function ServiceAreas() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Map/Visual */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-[#C0E3D4]/30 to-[#53B289]/10 rounded-3xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#53B289]/10 to-[#C0E3D4]/20 rounded-full transform translate-x-8 -translate-y-8"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-[#53B289]/15 to-[#C0E3D4]/10 rounded-full transform -translate-x-4 translate-y-4"></div>
              
              <div className="relative z-10">
                <img
                  src="https://images.unsplash.com/photo-1582653291997-079a1c04e5a1?w=500&h=400&fit=crop"
                  alt="New Zealand map showing COMSYS service areas"
                  className="w-full h-80 object-cover rounded-2xl shadow-lg"
                />
                
                <div className="absolute inset-0 bg-[#3A4E62]/20 rounded-2xl flex items-center justify-center">
                  <div className="text-center text-white">
                    <MapPin className="w-16 h-16 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold">Nationwide Coverage</h3>
                    <p className="text-lg">Serving New Zealand</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
                Serving New Zealand
                <span className="block text-[#53B289]">From Coast to Coast</span>
              </h2>
              <p className="text-xl text-[#3A4E62]/80 leading-relaxed mb-6">
                While we're proudly based in Auckland, our expertise reaches across New Zealand. 
                We provide comprehensive IT services to businesses in major cities and regional centers nationwide.
              </p>
            </div>

            <div className="space-y-6">
              {serviceAreas.map((area, index) => (
                <motion.div
                  key={area.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start space-x-4 bg-white rounded-xl p-6 shadow-lg border border-[#C0E3D4]/30"
                >
                  <div className="w-12 h-12 bg-[#C0E3D4] rounded-lg flex items-center justify-center flex-shrink-0">
                    <area.icon className="w-6 h-6 text-[#53B289]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{area.title}</h3>
                    <p className="text-[#3A4E62]/70 leading-relaxed">{area.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-[#53B289]/10 to-[#C0E3D4]/20 rounded-xl p-6 border border-[#53B289]/20">
              <h4 className="font-bold text-[#3A4E62] mb-2">Remote Support Available Nationwide</h4>
              <p className="text-[#3A4E62]/80 text-sm">
                No matter where you are in New Zealand, our remote support capabilities ensure 
                you receive expert assistance when you need it most.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}