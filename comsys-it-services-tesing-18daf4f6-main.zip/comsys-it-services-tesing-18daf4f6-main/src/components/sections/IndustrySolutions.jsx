import React from 'react';
import { motion } from 'framer-motion';
import { Store, HeartPulse, Scale, Building } from 'lucide-react';

const industries = [
  {
    icon: HeartPulse,
    title: 'Healthcare Clinics',
    description: 'Secure, compliant IT solutions to protect patient data, ensure system uptime for critical applications, and support telehealth services.'
  },
  {
    icon: Scale,
    title: 'Legal & Financial Firms',
    description: 'Robust cybersecurity, data encryption, and disaster recovery planning to meet strict regulatory requirements and safeguard sensitive client information.'
  },
  {
    icon: Store,
    title: 'Retail & eCommerce',
    description: 'Reliable POS system support, network security to protect customer payments, and scalable solutions for inventory management and online stores.'
  },
  {
    icon: Building,
    title: 'Construction & Trades',
    description: 'Rugged hardware solutions, mobile device management for on-site teams, and cloud collaboration tools to keep your projects on track.'
  }
];

export default function IndustrySolutions() {
  return (
    <section className="py-24 bg-gradient-to-br from-blue-50 via-slate-50 to-[#C0E3D4]/15">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">IT Solutions for Your Industry</h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            We provide specialized IT services for a range of New Zealand industries, understanding the unique challenges and compliance needs of your sector.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {industries.map((industry, index) => (
            <motion.div
              key={industry.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white/90 backdrop-blur-sm rounded-3xl p-8 text-center shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-[#53B289]/10 hover:border-[#53B289]/30"
            >
              <div className="w-16 h-16 bg-[#53B289]/10 group-hover:bg-[#53B289]/20 rounded-2xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-all duration-300 shadow-md">
                <industry.icon className="w-8 h-8 text-[#53B289] group-hover:text-[#4aa07b] transition-colors" />
              </div>
              
              <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{industry.title}</h3>
              <p className="text-[#3A4E62]/80 leading-relaxed">{industry.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}