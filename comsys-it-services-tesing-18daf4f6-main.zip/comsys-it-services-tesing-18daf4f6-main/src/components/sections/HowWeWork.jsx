import React from 'react';
import { motion } from 'framer-motion';
import { ClipboardCheck, Lightbulb, Rocket, ArrowRight } from 'lucide-react';

const steps = [
  {
    icon: ClipboardCheck,
    title: 'Discovery & Assessment',
    description: 'We start with a complimentary, in-depth assessment of your current IT environment to identify pain points, risks, and opportunities.'
  },
  {
    icon: Lightbulb,
    title: 'Tailored Solution Design',
    description: 'Our experts craft a bespoke IT strategy and solution proposal, complete with clear deliverables and transparent, predictable pricing.'
  },
  {
    icon: Rocket,
    title: 'Seamless Implementation & Proactive Support',
    description: 'We execute a smooth rollout with minimal disruption, then provide ongoing 24/7 monitoring and support to keep your systems optimized.'
  }
];

export default function HowWeWork() {
  return (
    <section className="py-24 bg-gradient-to-br from-slate-100 via-gray-100 to-blue-100 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-96 h-96 bg-[#53B289]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-blue-200/15 rounded-full blur-3xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">Our Streamlined Process</h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            A simple, transparent, and effective 3-step approach to elevate your IT.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connecting line */}
          <div className="hidden lg:block absolute top-12 left-0 w-full h-px bg-[#53B289]/30"></div>
          
          <div className="grid lg:grid-cols-3 gap-12 text-left relative">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15, duration: 0.6 }}
                className="relative p-8 bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl border border-gray-200/50 hover:border-[#53B289]/30 transition-colors duration-300"
              >
                <div className="absolute -top-10 left-8">
                  <div className="bg-gray-100/80 w-20 h-20 rounded-full flex items-center justify-center border-4 border-gray-200/50 shadow-lg backdrop-blur-sm">
                    <div className="bg-gradient-to-br from-[#53B289] to-[#4aa07b] text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg">
                      <step.icon className="w-8 h-8" />
                    </div>
                  </div>
                </div>

                <div className="pt-12">
                  <span className="font-bold text-[#53B289] text-lg">Step {index + 1}</span>
                  <h3 className="text-2xl font-bold text-[#3A4E62] mt-2 mb-4">{step.title}</h3>
                  <p className="text-[#3A4E62]/80 leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}