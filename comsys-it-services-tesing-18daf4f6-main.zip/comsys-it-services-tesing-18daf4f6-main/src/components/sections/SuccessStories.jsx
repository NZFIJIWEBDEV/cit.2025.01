import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const stories = [
  {
    client: 'Auckland Legal Partners',
    industry: 'Legal Services',
    before: {
      title: 'Before COMSYS',
      problems: ['Frequent server downtime', 'Slow network performance', 'No formal data backup plan']
    },
    after: {
      title: 'After COMSYS',
      solutions: ['99.9% server uptime with proactive monitoring', '4x faster network speeds after infrastructure upgrade', 'Fully automated, encrypted daily backups with 15-minute recovery point']
    },
    quote: "COMSYS completely stabilized our IT systems. Their proactive approach means we no longer worry about technology and can focus on our clients."
  },
  {
    client: 'KiwiBuild Construction',
    industry: 'Construction',
    before: {
      title: 'Before COMSYS',
      problems: ['Poor WiFi on job sites', 'Difficulty sharing large blueprint files', 'Security concerns with mobile devices']
    },
    after: {
      title: 'After COMSYS',
      solutions: ['Robust, site-wide WiFi coverage at 5+ locations', 'Cloud file-sharing solution for real-time collaboration', 'Mobile device management for enhanced security and tracking']
    },
    quote: "The ability to reliably access project files from anywhere has been a game-changer for our site managers. Productivity is way up."
  }
];

export default function SuccessStories() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">Client Success Stories</h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            We deliver real, measurable results for New Zealand businesses. See the impact of a strategic IT partnership.
          </p>
        </motion.div>

        <div className="space-y-16">
          {stories.map((story, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="grid lg:grid-cols-2 gap-12 items-center"
            >
              <div className={`space-y-6 ${index % 2 !== 0 ? 'lg:order-2' : ''}`}>
                <div className="bg-[#53B289]/10 border-l-4 border-[#53B289] p-4 rounded-r-lg">
                  <h3 className="text-2xl font-bold text-[#3A4E62]">{story.client}</h3>
                  <p className="text-[#3A4E62]/80 font-medium">{story.industry}</p>
                </div>
                <p className="text-lg text-[#3A4E62] italic leading-relaxed">"{story.quote}"</p>
              </div>

              <div className="bg-gray-50 rounded-2xl p-8 shadow-lg border border-gray-200/50">
                <div className="mb-6">
                  <h4 className="font-bold text-lg text-red-600 mb-3">{story.before.title}</h4>
                  <ul className="space-y-2">
                    {story.before.problems.map((problem, i) => (
                      <li key={i} className="flex items-center text-gray-600">
                        <span className="w-2 h-2 bg-red-500 rounded-full mr-3 flex-shrink-0"></span>
                        {problem}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="text-center my-4">
                  <ArrowDown className="w-8 h-8 text-gray-400 mx-auto" />
                </div>

                <div>
                  <h4 className="font-bold text-lg text-green-600 mb-3">{story.after.title}</h4>
                   <ul className="space-y-2">
                    {story.after.solutions.map((solution, i) => (
                      <li key={i} className="flex items-start text-gray-800">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-1" />
                        {solution}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-16">
            <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                    Become Our Next Success Story
                </Button>
            </Link>
        </div>
      </div>
    </section>
  );
}