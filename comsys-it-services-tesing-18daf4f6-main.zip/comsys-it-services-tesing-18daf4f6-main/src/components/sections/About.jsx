import React from "react";
import { motion } from "framer-motion";
import { Award, Users, Clock, MapPin, Shield, Zap } from "lucide-react";

const achievements = [
  { icon: Award, value: "15+", label: "Years in Business", description: "Established IT expertise" },
  { icon: Users, value: "500+", label: "Happy Clients", description: "Businesses we've helped grow" },
  { icon: Clock, value: "24/7", label: "Support", description: "Always available when needed" },
  { icon: MapPin, value: "NZ", label: "Local Team", description: "Auckland-based professionals" }
];

const values = [
  {
    icon: Shield,
    title: "Security First",
    description: "We prioritize the security of your data and systems above all else, implementing industry-leading cybersecurity practices to protect your business."
  },
  {
    icon: Zap,
    title: "Innovation Driven",
    description: "We stay at the forefront of technology trends, bringing cutting-edge solutions that give your business a competitive advantage."
  },
  {
    icon: Users,
    title: "Partnership Focused",
    description: "We believe in building long-term relationships with our clients, becoming a trusted extension of your team rather than just a service provider."
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-[#C0E3D4]/20">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Company Story */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
          {/* Image/Visual */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square bg-gradient-to-br from-[#53B289] to-[#3A4E62] rounded-3xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&h=600&fit=crop&crop=center"
                alt="COMSYS IT professionals at work"
                className="w-full h-full object-cover mix-blend-overlay"
              />
            </div>
            
            {/* Floating cards */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl p-6 shadow-xl border border-[#C0E3D4]">
              <div className="text-3xl font-bold text-[#53B289]">15+</div>
              <div className="text-[#3A4E62]/70 text-sm">Years Excellence</div>
            </div>
            
            <div className="absolute -top-6 -left-6 bg-white rounded-2xl p-6 shadow-xl border border-[#C0E3D4]">
              <div className="text-3xl font-bold text-[#53B289]">NZ</div>
              <div className="text-[#3A4E62]/70 text-sm">Owned & Operated</div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
                About
                <span className="block text-[#53B289]">COMSYS</span>
              </h2>
              <p className="text-xl text-[#3A4E62]/80 leading-relaxed mb-6">
                Founded in Auckland over 15 years ago, COMSYS has grown from a small IT consultancy 
                into New Zealand's trusted technology partner for businesses of all sizes.
              </p>
              <p className="text-[#3A4E62]/70 leading-relaxed mb-6">
                Our journey began with a simple mission: to make technology work better for Kiwi businesses. 
                Today, we're proud to serve over 500 companies across New Zealand, from innovative startups 
                to established enterprises, providing comprehensive IT solutions that drive growth and success.
              </p>
              <p className="text-[#3A4E62]/70 leading-relaxed">
                What sets us apart is our commitment to understanding your unique business needs and 
                delivering personalized solutions that not only solve today's challenges but prepare 
                you for tomorrow's opportunities.
              </p>
            </div>

            {/* Achievements Grid */}
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl p-6 shadow-lg border border-[#C0E3D4]/30 text-center"
                >
                  <div className="flex items-center justify-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-[#C0E3D4] rounded-lg flex items-center justify-center">
                      <achievement.icon className="w-5 h-5 text-[#53B289]" />
                    </div>
                    <div className="text-2xl font-bold text-[#3A4E62]">{achievement.value}</div>
                  </div>
                  <div className="text-[#3A4E62] font-semibold text-sm mb-1">{achievement.label}</div>
                  <div className="text-[#3A4E62]/70 text-xs">{achievement.description}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Company Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h3 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-6">Our Values</h3>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            These core principles guide everything we do and shape how we serve our clients every day.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 group border border-[#C0E3D4]/30 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] rounded-2xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-300">
                <value.icon className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-bold text-[#3A4E62] mb-4">{value.title}</h4>
              <p className="text-[#3A4E62]/80 leading-relaxed">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}