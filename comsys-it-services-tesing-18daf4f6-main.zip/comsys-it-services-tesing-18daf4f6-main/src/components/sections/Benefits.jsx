
import React from "react";
import { motion } from "framer-motion";
import { CheckCircle, TrendingUp, Clock, Users } from "lucide-react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Increased Productivity",
    description: "Minimize downtime and maximize efficiency with our proactive IT management approach."
  },
  {
    icon: CheckCircle,
    title: "Predictable Costs",
    description: "Fixed monthly pricing with no surprise fees. Budget with confidence and scale as you grow."
  },
  {
    icon: Clock,
    title: "24/7 Monitoring",
    description: "Round-the-clock system monitoring ensures issues are identified and resolved before they impact your business."
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Access to a full team of certified IT professionals without the overhead of hiring internally."
  }
];

export default function Benefits() {
  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
                Why Choose Our 
                <span className="block text-[#53B289]">Managed IT Services?</span>
              </h2>
              <p className="text-xl text-[#3A4E62]/80 leading-relaxed">
                Partner with us to transform your IT infrastructure into a strategic advantage. 
                Our comprehensive approach ensures your technology works for you, not against you.
              </p>
            </div>

            <div className="space-y-6">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start space-x-4"
                >
                  <div className="w-12 h-12 bg-[#C0E3D4] rounded-lg flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-[#53B289]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{benefit.title}</h3>
                    <p className="text-[#3A4E62]/70 leading-relaxed">{benefit.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-[#C0E3D4]/30 to-[#53B289]/10 rounded-3xl p-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#53B289]/10 to-[#C0E3D4]/20 rounded-full transform translate-x-8 -translate-y-8"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-[#53B289]/15 to-[#C0E3D4]/10 rounded-full transform -translate-x-4 translate-y-4"></div>
              
              <div className="relative z-10 text-center">
                <div className="text-6xl font-bold text-[#53B289] mb-4">99.9%</div>
                <div className="text-2xl font-semibold text-[#3A4E62] mb-2">Uptime Guarantee</div>
                <p className="text-[#3A4E62]/70">
                  Industry-leading reliability with comprehensive SLA coverage
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-12 relative z-10">
                <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 text-center border border-[#C0E3D4]/30">
                  <div className="text-3xl font-bold text-[#3A4E62] mb-2">15min</div>
                  <div className="text-[#3A4E62]/70 text-sm">Average Response Time</div>
                </div>
                <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 text-center border border-[#C0E3D4]/30">
                  <div className="text-3xl font-bold text-[#3A4E62] mb-2">500+</div>
                  <div className="text-[#3A4E62]/70 text-sm">Happy Clients</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
