
import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Zap, Users, Phone, Mail, CheckCircle, Star } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import DynamicCounter from "../features/DynamicCounters";

export default function Hero() {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-[#3A4E62] via-[#2a3749] to-[#1e2832] overflow-hidden flex flex-col justify-center">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2353B289' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        {/* Animated floating shapes - reduced motion for performance */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-[#53B289]/10 rounded-full animate-pulse"></div>
        <div className="absolute bottom-32 right-16 w-16 h-16 bg-[#C0E3D4]/20 rounded-full animate-bounce"></div>
        <div className="absolute top-1/2 right-8 w-12 h-12 bg-[#53B289]/15 rounded-full animate-ping"></div>
      </div>
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-20">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Content */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-6 lg:space-y-8 text-center lg:text-left"
            >
              <div className="space-y-4 lg:space-y-6">
                {/* Trust Badge */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="inline-flex items-center space-x-2 bg-[#53B289]/20 backdrop-blur-sm border border-[#53B289]/30 rounded-full px-4 py-2"
                >
                  <Star className="w-4 h-4 text-[#53B289]" />
                  <span className="text-[#53B289] font-medium text-sm">Auckland's Most Trusted IT Partner</span>
                </motion.div>
                
                <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold text-white leading-tight">
                  Auckland's Most Trusted
                  <span className="block bg-gradient-to-r from-[#53B289] to-[#C0E3D4] bg-clip-text text-transparent">
                    IT Support & Solutions Provider
                  </span>
                </h1>
                <p className="text-lg sm:text-xl text-white/90 max-w-lg leading-relaxed mx-auto lg:mx-0">
                  From data backup to business broadband, we deliver reliable IT services that keep 
                  your Auckland business running 24/7. Fast response times, local expertise, and 
                  comprehensive support you can count on.
                </p>

                {/* Mini Testimonial */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 max-w-lg mx-auto lg:mx-0"
                >
                  <div className="flex items-center space-x-2 mb-2 justify-center lg:justify-start">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-white/90 text-sm italic">
                    "COMSYS transformed our IT infrastructure completely. Their response times are incredible!"
                  </p>
                  <p className="text-white/70 text-xs mt-2">- Sarah Johnson, Auckland Marketing Ltd</p>
                </motion.div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to={createPageUrl("ContactUs")}>
                  <Button 
                    size="lg"
                    className="w-full sm:w-auto bg-[#53B289] hover:bg-[#4aa07b] text-white px-6 lg:px-8 py-3 lg:py-4 text-base lg:text-lg font-medium group shadow-xl hover:shadow-2xl transition-all duration-300"
                  >
                    Get a Free IT Assessment
                    <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Link to={createPageUrl("ContactUs")}>
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="w-full sm:w-auto border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-[#3A4E62] px-6 lg:px-8 py-3 lg:py-4 text-base lg:text-lg font-medium transition-all duration-300"
                  >
                    Contact Our Team
                  </Button>
                </Link>
              </div>

              {/* Key Features with animated counters */}
              <div className="mt-8 lg:mt-12">
                <div className="grid grid-cols-3 gap-4 lg:gap-6">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.0 }}
                    className="text-center"
                  >
                    <div className="w-10 lg:w-12 h-10 lg:h-12 bg-[#53B289] rounded-xl flex items-center justify-center mb-2 lg:mb-3 mx-auto group-hover:scale-110 transition-transform">
                      <Shield className="w-5 lg:w-6 h-5 lg:h-6 text-white" />
                    </div>
                    <h3 className="text-white font-semibold mb-1 text-sm lg:text-base">
                      <DynamicCounter to={99.9} precision={1} suffix="%" /> Uptime
                    </h3>
                    <p className="text-white/70 text-xs lg:text-sm">Enterprise security</p>
                  </motion.div>
                  
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.2 }}
                    className="text-center"
                  >
                    <div className="w-10 lg:w-12 h-10 lg:h-12 bg-[#53B289] rounded-xl flex items-center justify-center mb-2 lg:mb-3 mx-auto group-hover:scale-110 transition-transform">
                      <Zap className="w-5 lg:w-6 h-5 lg:h-6 text-white" />
                    </div>
                    <h3 className="text-white font-semibold mb-1 text-sm lg:text-base">
                      &lt;1 Hour Response
                    </h3>
                    <p className="text-white/70 text-xs lg:text-sm">Critical issue support</p>
                  </motion.div>
                  
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.4 }}
                    className="text-center"
                  >
                    <div className="w-10 lg:w-12 h-10 lg:h-12 bg-[#53B289] rounded-xl flex items-center justify-center mb-2 lg:mb-3 mx-auto group-hover:scale-110 transition-transform">
                      <Users className="w-5 lg:w-6 h-5 lg:h-6 text-white" />
                    </div>
                    <h3 className="text-white font-semibold mb-1 text-sm lg:text-base">
                      <DynamicCounter to={500} suffix="+" /> Clients
                    </h3>
                    <p className="text-white/70 text-xs lg:text-sm">Trusted businesses</p>
                  </motion.div>
                </div>
              </div>
            </motion.div>

            {/* Enhanced Visual */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="relative order-first lg:order-last"
            >
              <div className="relative">
                {/* Main hero image with overlay */}
                <div className="relative overflow-hidden rounded-2xl lg:rounded-3xl shadow-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1556740758-90de374c12ad?w=1200&h=800&fit=crop"
                    alt="COMSYS IT support team collaborating in a modern Auckland office"
                    className="w-full h-64 sm:h-80 lg:h-96 xl:h-[500px] object-cover"
                    loading="eager"
                    width="1200"
                    height="800"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#3A4E62]/80 via-transparent to-[#53B289]/60"></div>
                  
                  {/* Floating service icons */}
                  <div className="absolute top-4 lg:top-6 left-4 lg:left-6 bg-white/90 backdrop-blur-sm rounded-xl p-2 lg:p-3 shadow-lg">
                    <Shield className="w-4 lg:w-6 h-4 lg:h-6 text-[#53B289]" />
                  </div>
                  <div className="absolute top-4 lg:top-6 right-4 lg:right-6 bg-white/90 backdrop-blur-sm rounded-xl p-2 lg:p-3 shadow-lg">
                    <Zap className="w-4 lg:w-6 h-4 lg:h-6 text-[#53B289]" />
                  </div>
                  <div className="absolute bottom-4 lg:bottom-6 right-4 lg:right-6 bg-white/90 backdrop-blur-sm rounded-xl p-2 lg:p-3 shadow-lg">
                    <Users className="w-4 lg:w-6 h-4 lg:h-6 text-[#53B289]" />
                  </div>
                </div>
                
                {/* Enhanced floating contact card */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.0 }}
                  className="absolute -bottom-6 lg:-bottom-8 -left-4 lg:-left-8 bg-white rounded-xl lg:rounded-2xl p-4 lg:p-6 shadow-2xl border border-[#C0E3D4] w-72 max-w-[calc(100vw-2rem)]"
                >
                  <div className="flex items-center space-x-3 mb-3 lg:mb-4">
                    <div className="w-8 lg:w-10 h-8 lg:h-10 bg-[#53B289] rounded-lg flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-4 lg:w-6 h-4 lg:h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#3A4E62] text-sm lg:text-base">Get Expert Help</h4>
                      <p className="text-[#3A4E62]/70 text-xs">Available 24/7</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <a href="tel:0800724526" className="flex items-center space-x-3 text-[#3A4E62] hover:text-[#53B289] transition-colors group">
                      <Phone className="w-4 h-4 text-[#53B289] flex-shrink-0" />
                      <span className="text-sm font-medium">0800 724 526</span>
                    </a>
                    <a href="mailto:info@comsys.co.nz" className="flex items-center space-x-3 text-[#3A4E62] hover:text-[#53B289] transition-colors group">
                      <Mail className="w-4 h-4 text-[#53B289] flex-shrink-0" />
                      <span className="text-sm font-medium break-all">info@comsys.co.nz</span>
                    </a>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
