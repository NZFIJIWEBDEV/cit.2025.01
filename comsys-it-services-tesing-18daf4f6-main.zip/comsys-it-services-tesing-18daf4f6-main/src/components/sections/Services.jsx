
import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  HardDrive, 
  Headphones, 
  Laptop, 
  Wifi,
  FileText,
  Printer,
  Globe,
  Phone,
  Monitor,
  Home,
  ArrowRight,
  Sparkles,
  CheckCircle,
  Star
} from "lucide-react";

const services = [
  {
    icon: Headphones,
    title: "IT Support & Managed Services",
    description: "Proactive, responsive IT support for NZ businesses. We act as your outsourced IT department, minimizing downtime and resolving issues fast with our local expert team.",
    page: "ITSupport",
    cta: "Get IT Support",
    popular: true
  },
  {
    icon: HardDrive,
    title: "Data Backup & Disaster Recovery",
    description: "Protect your most valuable asset with automated, secure data backups. Our robust solutions ensure rapid recovery from hardware failure, cyber-attacks, or accidental deletion.",
    page: "DataBackupRecovery",
    cta: "Secure My Data",
  },
  {
    icon: Laptop,
    title: "PC/Laptop Parts & Repair",
    description: "Extend the life of your devices with our expert repair and upgrade services. From cracked screens to performance-boosting SSD upgrades, we get you back to work quickly.",
    page: "PCLaptopRepair",
    cta: "Fix My Device",
  },
  {
    icon: Wifi,
    title: "WiFi Network Upgrades",
    description: "Eliminate dead zones and slow speeds with a professional WiFi upgrade. We design and install robust wireless networks for seamless coverage in your home or office.",
    page: "WiFiUpgrade",
    cta: "Upgrade WiFi",
  },
  {
    icon: FileText,
    title: "Microsoft Office 365",
    description: "Unlock your team's productivity with expert Microsoft 365 setup, management, and support. We handle licensing, security, and training to optimize your workflow.",
    page: "MicrosoftOffice",
    cta: "Setup Office 365",
  },
  {
    icon: Printer,
    title: "Managed Print Services",
    description: "Reduce costs and hassle with our managed printer solutions. We handle repairs, maintenance, and automated toner supply for a predictable, low monthly cost.",
    page: "PrinterServices",
    cta: "Fix Printer Issues",
  },
  {
    icon: Globe,
    title: "Business Fibre & Broadband",
    description: "Get the full speed of your internet plan with our business broadband solutions. We provide reliable, high-speed connections tailored for commercial use.",
    page: "BusinessFibre",
    cta: "Get Faster Internet",
  },
  {
    icon: Home,
    title: "Home Fibre & Internet",
    description: "Transform your home internet with ultra-fast fibre broadband. Perfect for streaming, gaming, and working from home with no contracts and unlimited data.",
    page: "HomeFibre",
    cta: "Upgrade Home Internet",
  },
  {
    icon: Phone,
    title: "VoIP Business Phone Systems",
    description: "Modernize your business communications with a flexible and cost-effective VoIP system. Get enterprise-grade features and work from anywhere.",
    page: "VoIPSolutions",
    cta: "Get VoIP Quote",
  },
  {
    icon: Monitor,
    title: "Web Design & Hosting",
    description: "Establish a professional online presence with a custom-designed website. We build beautiful, responsive sites and provide secure, high-performance hosting.",
    page: "WebDesignHosting",
    cta: "Build My Website",
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 md:py-28 bg-gradient-to-br from-[#53B289]/8 via-[#C0E3D4]/12 to-slate-100 relative overflow-hidden">
      {/* Enhanced background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-[#53B289]/15 to-[#C0E3D4]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-to-tr from-slate-200/20 to-[#53B289]/8 rounded-full blur-3xl"></div>
        <div className="absolute top-10 left-10 w-32 h-32 bg-[#53B289]/5 rounded-full blur-2xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-20"
        >
          <div className="inline-flex items-center space-x-2 bg-[#53B289]/15 backdrop-blur-sm border border-[#53B289]/30 rounded-full px-6 py-3 mb-8">
            <Sparkles className="w-5 h-5 text-[#53B289]/80" />
            <span className="text-[#53B289] font-semibold text-sm">Complete IT Solutions</span>
          </div>

          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#3A4E62] mb-6 tracking-tight">
            Our Comprehensive IT Services
          </h2>
          <p className="text-xl md:text-2xl text-[#3A4E62]/75 max-w-4xl mx-auto leading-relaxed">
            From essential IT support to strategic technology solutions, we provide everything your New Zealand business needs to thrive.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className={`
                relative group flex flex-col h-full
                bg-white/95 backdrop-blur-sm rounded-3xl p-8 md:p-10
                shadow-lg hover:shadow-2xl border-2 border-slate-200/50
                transition-all duration-700 ease-out
                hover:-translate-y-2 hover:scale-[1.02]
                ${service.popular ? 'ring-2 ring-[#53B289]/30 bg-gradient-to-br from-[#53B289]/5 to-white' : ''}
              `}
            >
              {/* Popular Badge */}
              {service.popular && (
                <motion.div
                  initial={{ scale: 0, rotate: -10 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
                  className="absolute -top-4 right-8 bg-gradient-to-r from-[#53B289] to-[#4aa07b] text-white px-5 py-2 rounded-full text-xs font-bold flex items-center space-x-2 shadow-lg z-10"
                >
                  <Star className="w-3 h-3" />
                  <span>Most Popular</span>
                </motion.div>
              )}
              
              <div className="flex-grow">
                {/* Icon Container */}
                <div className="mb-8">
                  <div className="relative">
                    <div className="w-20 h-20 bg-gradient-to-br from-[#53B289]/10 to-[#C0E3D4]/15 rounded-3xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-500 group-hover:scale-110 group-hover:-rotate-3">
                      <service.icon className="w-10 h-10 text-[#53B289] group-hover:text-[#4aa07b] transition-all duration-500" />
                    </div>
                    {/* Green accent dot */}
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#53B289] rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500 transform scale-0 group-hover:scale-100"></div>
                  </div>
                </div>
                
                {/* Content */}
                <div className="space-y-4">
                  <h3 className="text-2xl md:text-2xl font-bold text-[#3A4E62] leading-tight group-hover:text-[#2a3749] transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-[#3A4E62]/70 leading-relaxed text-base group-hover:text-[#3A4E62]/80 transition-colors duration-300">
                    {service.description}
                  </p>
                </div>
              </div>

              {/* CTA Button */}
              <div className="mt-8 pt-6 border-t border-slate-100">
                <Link 
                  to={createPageUrl("ContactUs")}
                  className="group/button w-full inline-flex items-center justify-center bg-gradient-to-r from-[#53B289] to-[#4aa07b] hover:from-[#4aa07b] hover:to-[#53B289] text-white font-semibold px-8 py-4 rounded-2xl transition-all duration-500 transform hover:scale-105 shadow-lg hover:shadow-xl relative overflow-hidden"
                >
                  <span className="relative z-10">{service.cta || "Learn More"}</span>
                  <ArrowRight className="relative z-10 w-5 h-5 ml-3 group-hover/button:translate-x-1 transition-transform duration-300" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-20 md:mt-24"
        >
          <div className="bg-gradient-to-br from-[#53B289]/8 to-slate-100/90 backdrop-blur-sm rounded-3xl p-10 md:p-16 shadow-2xl border border-[#53B289]/20 max-w-5xl mx-auto relative overflow-hidden">
            {/* Subtle background pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0" style={{
                backgroundImage: `radial-gradient(circle at 2px 2px, #53B289 1px, transparent 0)`
              }}></div>
            </div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-center mb-8">
                <div className="flex items-center space-x-3 bg-[#53B289]/15 rounded-full px-8 py-4">
                  <Sparkles className="w-6 h-6 text-[#53B289]" />
                  <span className="text-[#53B289] font-semibold text-lg">Free Consultation</span>
                </div>
              </div>
              
              <h3 className="text-3xl md:text-4xl font-bold text-[#3A4E62] mb-6 leading-tight">
                Need help choosing the right IT solution?
              </h3>
              <p className="text-xl text-[#3A4E62]/75 mb-10 max-w-3xl mx-auto leading-relaxed">
                Get personalized recommendations from our IT experts with a complimentary consultation tailored to your business needs.
              </p>
              
              <Link to={createPageUrl("ContactUs")}>
                <button className="bg-gradient-to-r from-[#53B289] to-[#4aa07b] hover:from-[#4aa07b] hover:to-[#53B289] text-white px-10 py-5 text-xl font-semibold rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-500 transform hover:scale-105 group relative overflow-hidden">
                  <span className="relative z-10 flex items-center">
                    Book a Free IT Consultation
                    <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
                  </span>
                </button>
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
