
import React from 'react';
import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const faqs = [
  {
    q: 'What kind of businesses do you support?',
    a: 'We support a wide range of New Zealand businesses, from small startups to medium-sized enterprises across various industries like legal, healthcare, construction, and retail. Our solutions are scalable and tailored to your specific needs.'
  },
  {
    q: 'How quickly can you respond to an urgent IT issue?',
    a: 'We guarantee a 15-minute response time for critical, business-impacting issues. Our local Auckland-based team is ready to provide rapid remote and on-site support to minimize downtime.'
  },
  {
    q: 'What are the benefits of managed IT services?',
    a: 'Managed IT services provide proactive monitoring, maintenance, and support for a fixed monthly fee. This leads to predictable costs, increased uptime, enhanced security, and allows you to focus on your core business instead of technology problems.'
  },
  {
    q: 'Can you help us move our services to the cloud?',
    a: 'Absolutely. We specialize in cloud migration and management, including Microsoft 365 and other cloud platforms. We can help you create a secure, efficient, and cost-effective cloud strategy.'
  }
];

export default function HomeFAQ() {
  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 via-slate-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">Frequently Asked Questions</h2>
          <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
            Have questions? We have answers. Here are some of the most common inquiries we receive from prospective clients.
          </p>
        </motion.div>

        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
             <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem value={`item-${index}`} className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg mb-4 border-2 border-[#53B289]/10 hover:border-[#53B289]/30 transition-colors">
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
        
        <div className="text-center mt-12">
            <p className="text-[#3A4E62]/80 mb-4">Don't see your question here? Get in touch with our expert team.</p>
            <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-gradient-to-r from-[#53B289] to-[#4aa07b] hover:from-[#4aa07b] hover:to-[#53B289] text-white shadow-lg hover:shadow-xl">
                    Ask a Question
                </Button>
            </Link>
        </div>
      </div>
    </section>
  );
}
