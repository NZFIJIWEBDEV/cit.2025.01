import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Mail, MapPin, Send, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/toast";
import { useLocation } from "react-router-dom";
import { contact } from "@/api/functions";

export default function ContactSection({ pageSource = "Contact Page" }) {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const { toast } = useToast();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const subject = params.get('subject');
    if (subject) {
      setFormData(prev => ({ ...prev, message: `Inquiry about ${subject}: ` }));
    }
  }, [location.search]);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.message.trim()) newErrors.message = 'Message is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast({ 
        title: "Please fix the errors below", 
        description: "Check the highlighted fields and try again.", 
        variant: "destructive" 
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const payload = {
        fullName: formData.name,
        company: formData.company,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
        page_source: pageSource
      };

      console.log('Submitting contact form with payload:', payload);

      const response = await contact(payload);
      
      console.log('Contact response status:', response?.status);
      console.log('Contact response data:', response?.data);
      
      // Check if the response indicates success
      if (response?.status === 200 && response?.data?.success) {
        toast({ 
          title: "Message Sent Successfully!", 
          description: response.data.message || "Thank you for your inquiry! We'll get back to you within 24 hours.", 
          variant: "default" 
        });
        setFormData({ name: '', company: '', email: '', phone: '', message: '' });
      } else {
        // Handle error response
        const errorMessage = response?.data?.message || 'Failed to send message. Please try again.';
        toast({ 
          title: "Message Failed to Send", 
          description: errorMessage, 
          variant: "destructive" 
        });
      }
    } catch (error) {
      console.error('Contact form submission error:', error);
      
      let errorDescription = "There was a problem sending your message. Please try again or contact us directly at info@comsys.co.nz or 0800 724 526.";
      
      if (error.message.includes('Network Error') || error.message.includes('fetch')) {
        errorDescription = "Network connection issue. Please check your internet connection and try again.";
      }
      
      toast({ 
        title: "Message Failed to Send", 
        description: errorDescription, 
        variant: "destructive" 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-4 md:mb-6">
            Contact COMSYS
          </h2>
          <p className="text-lg md:text-xl text-[#3A4E62]/80 max-w-3xl mx-auto leading-relaxed">
            Ready to get your IT sorted? Get in touch with our New Zealand team 
            for professional IT support and solutions.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-[#3A4E62] mb-4 md:mb-6">Get in Touch</h3>
              <p className="text-[#3A4E62]/70 leading-relaxed mb-6 md:mb-8">
                Whether you're a business needing comprehensive IT support or a home user 
                requiring technical assistance, our team is ready to help with customized 
                solutions for your needs.
              </p>
            </div>

            <div className="space-y-4 md:space-y-6">
              <a href="tel:0800724526" className="flex items-center space-x-4 group hover:bg-gray-50 p-3 rounded-lg transition-colors">
                <div className="w-12 h-12 bg-[#C0E3D4] rounded-lg flex items-center justify-center group-hover:bg-[#53B289] transition-colors flex-shrink-0">
                  <Phone className="w-6 h-6 text-[#53B289] group-hover:text-white transition-colors" />
                </div>
                <div>
                  <div className="font-semibold text-[#3A4E62]">Phone</div>
                  <div className="text-[#3A4E62]/70">0800 724 526</div>
                </div>
              </a>

              <a href="mailto:info@comsys.co.nz" className="flex items-center space-x-4 group hover:bg-gray-50 p-3 rounded-lg transition-colors">
                <div className="w-12 h-12 bg-[#C0E3D4] rounded-lg flex items-center justify-center group-hover:bg-[#53B289] transition-colors flex-shrink-0">
                  <Mail className="w-6 h-6 text-[#53B289] group-hover:text-white transition-colors" />
                </div>
                <div>
                  <div className="font-semibold text-[#3A4E62]">Email</div>
                  <div className="text-[#3A4E62]/70 break-all">info@comsys.co.nz</div>
                </div>
              </a>

              <div className="flex items-start space-x-4 p-3">
                <div className="w-12 h-12 bg-[#C0E3D4] rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <div className="font-semibold text-[#3A4E62]">Location</div>
                  <div className="text-[#3A4E62]/70">Auckland, New Zealand (Nationwide Support)</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-[#C0E3D4]/20 rounded-2xl md:rounded-3xl p-6 md:p-8 border border-[#C0E3D4]/30"
          >
            <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6" noValidate>
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-[#3A4E62] mb-2">
                    Full Name *
                  </label>
                  <Input 
                    id="name" 
                    name="name" 
                    value={formData.name} 
                    onChange={handleInputChange} 
                    className={`w-full ${errors.name ? 'border-red-500 focus:border-red-500' : ''}`}
                    placeholder="Your Name" 
                    aria-describedby={errors.name ? "name-error" : undefined}
                  />
                  {errors.name && <p id="name-error" className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle className="w-3 h-3 mr-1" />{errors.name}</p>}
                </div>
                
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-[#3A4E62] mb-2">
                    Company/Organization
                  </label>
                  <Input 
                    id="company" 
                    name="company" 
                    value={formData.company} 
                    onChange={handleInputChange} 
                    className="w-full" 
                    placeholder="Your Company" 
                  />
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-[#3A4E62] mb-2">
                          Email Address *
                        </label>
                        <Input 
                          id="email" 
                          type="email" 
                          name="email" 
                          value={formData.email} 
                          onChange={handleInputChange} 
                          className={`w-full ${errors.email ? 'border-red-500 focus:border-red-500' : ''}`}
                          placeholder="your@email.com" 
                          aria-describedby={errors.email ? "email-error" : undefined}
                        />
                        {errors.email && <p id="email-error" className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle className="w-3 h-3 mr-1" />{errors.email}</p>}
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-[#3A4E62] mb-2">
                          Phone Number
                        </label>
                        <Input 
                          id="phone" 
                          type="tel" 
                          name="phone" 
                          value={formData.phone} 
                          onChange={handleInputChange} 
                          className={`w-full ${errors.phone ? 'border-red-500 focus:border-red-500' : ''}`}
                          placeholder="Your phone number" 
                          aria-describedby={errors.phone ? "phone-error" : undefined}
                        />
                        {errors.phone && <p id="phone-error" className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle className="w-3 h-3 mr-1" />{errors.phone}</p>}
                    </div>
                </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-[#3A4E62] mb-2">
                  How can we help? *
                </label>
                <Textarea 
                  id="message" 
                  name="message" 
                  value={formData.message} 
                  onChange={handleInputChange} 
                  className={`w-full h-28 md:h-32 resize-none ${errors.message ? 'border-red-500 focus:border-red-500' : ''}`}
                  placeholder="Tell us about your IT needs..." 
                  aria-describedby={errors.message ? "message-error" : undefined}
                />
                {errors.message && <p id="message-error" className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle className="w-3 h-3 mr-1" />{errors.message}</p>}
              </div>
              
              <Button 
                type="submit" 
                disabled={isSubmitting} 
                className="w-full bg-gradient-to-r from-[#53B289] to-[#4aa07b] hover:from-[#4aa07b] hover:to-[#3e8c67] text-white py-3 text-base md:text-lg font-medium group disabled:opacity-60"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <Send className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}