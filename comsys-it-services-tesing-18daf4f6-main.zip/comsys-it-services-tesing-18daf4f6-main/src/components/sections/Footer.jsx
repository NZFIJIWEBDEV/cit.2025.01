
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Phone, Mail, MapPin } from 'lucide-react';

// Defines the links for the 'Our Services' section of the footer.
const services = [
    { name: "IT Support", page: "ITSupport" },
    { name: "Data Backup & Recovery", page: "DataBackupRecovery" },
    { name: "VoIP Solutions", page: "VoIPSolutions" },
    { name: "Business Fibre", page: "BusinessFibre" },
    { name: "Microsoft Office 365", page: "MicrosoftOffice" },
    { name: "Web Design & Hosting", page: "WebDesignHosting" }
];

// Defines the links for the 'Quick Links' section of the footer.
const quickLinks = [
    { name: "About Us", page: "About" },
    { name: "Areas We Serve", page: "AreasWeServe" },
    { name: "Industries", page: "Industries" },
    { name: "Insights", page: "Insights" },
    { name: "Contact Us", page: "ContactUs" },
    { name: "Remote Support", page: "RemoteSupport" },
    { name: "IT Cost Calculator", page: "ITCalculator" },
    { name: "Privacy Policy", page: "PrivacyPolicy" }
];

export default function Footer() {
  // `useLocation` is retained as per original comment, for potential implicit use with `createPageUrl` via `Link`.
  const location = useLocation();

  return (
    <footer className="bg-slate-800 text-white pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info - Original first column, displaying primary business details */}
          <div className="md:col-span-2 lg:col-span-1">
            <img
              src="https://comsys.co.nz/wp-content/uploads/2024/02/logo-5-1-1.png"
              alt="Comsys IT Logo"
              className="h-12 mb-6"
            />
            <p className="text-slate-400 mb-6 leading-relaxed">
              Leading IT support, CCTV, VoIP, and business fibre services for businesses across Auckland and New Zealand.
            </p>
            <div className="space-y-3 text-slate-200">
                <div className="flex items-start">
                    <MapPin className="w-5 h-5 mr-3 mt-1 flex-shrink-0 text-[#53B289]"/>
                    <span>
                        <strong className="block text-white">Comsys IT</strong>
                        26 Bancroft Crescent, Glendene<br/>
                        Auckland 0602, New Zealand
                    </span>
                </div>
                <div className="flex items-center">
                    <Phone className="w-5 h-5 mr-3 text-[#53B289]"/>
                    <span><strong className="text-white">Phone:</strong> 09 242 3700</span>
                </div>
                <div className="flex items-center">
                    <Mail className="w-5 h-5 mr-3 text-[#53B289]"/>
                    <span><strong className="text-white">Email:</strong> info@comsys.co.nz</span>
                </div>
            </div>
          </div>

          {/* Quick Links - New column added as per outline */}
          <div>
            <h3 className="text-xl font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={createPageUrl(link.page)}
                    className="text-slate-400 hover:text-[#53B289] transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Our Services - New column added as per outline, uses 'services' data */}
          <div>
            <h3 className="text-xl font-bold mb-6">Our Services</h3>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.name}>
                  <Link
                    to={createPageUrl(service.page)}
                    className="text-slate-400 hover:text-[#53B289] transition-colors duration-300 text-sm"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Us - New column with specific contact details as per outline */}
          <div>
            <h3 className="text-xl font-bold mb-6">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <p className="text-slate-400">
                  Level 1, 30 St Benedicts Street<br />
                  Eden Terrace, Auckland 1010
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-[#53B289]" />
                <a href="tel:0800724526" className="text-slate-400 hover:text-[#53B289] transition-colors">
                  0800 724 526
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-[#53B289]" />
                <a href="mailto:info@comsys.co.nz" className="text-slate-400 hover:text-[#53B289] transition-colors">
                  info@comsys.co.nz
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Sub-footer with Brand Divisions */}
        <div className="border-t border-slate-700 pt-10 mt-10 mb-2">
          <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-4 text-center">
            {/* Comsys IT */}
            <div className="relative group">
              <span className="text-base font-semibold text-slate-300 cursor-pointer hover:text-[#53B289] transition-colors">
                Comsys IT
              </span>
              <div className="absolute bottom-full mb-3 w-60 p-4 bg-slate-700 rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform group-hover:-translate-y-1 origin-bottom z-10 text-left">
                <p className="text-slate-400 text-sm font-bold mb-3 pb-2 border-b border-slate-600">Complete IT Support</p>
                <div className="space-y-2">
                  <Link to={createPageUrl('ITSupport')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">IT Support & Helpdesk</Link>
                  <Link to={createPageUrl('DataBackupRecovery')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Data Backup & Recovery</Link>
                  <Link to={createPageUrl('MicrosoftOffice')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Microsoft 365</Link>
                  <Link to={createPageUrl('PCLaptopRepair')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">PC/Laptop Repair</Link>
                </div>
              </div>
            </div>

            {/* Comsys CCTV */}
            <div className="relative group">
              <span className="text-base font-semibold text-slate-300 cursor-pointer hover:text-[#53B289] transition-colors">
                Comsys CCTV
              </span>
              <div className="absolute bottom-full mb-3 w-60 p-4 bg-slate-700 rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform group-hover:-translate-y-1 origin-bottom z-10 text-left">
                <p className="text-slate-400 text-sm font-bold mb-3 pb-2 border-b border-slate-600">Professional Security</p>
                <div className="space-y-2">
                  <Link to={createPageUrl('CCTVBusiness')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Business CCTV Systems</Link>
                  <Link to={createPageUrl('CCTVHome')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Home Security Systems</Link>
                  <Link to={createPageUrl('CCTVResidential')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Residential CCTV</Link>
                </div>
              </div>
            </div>
            
            {/* Comsys Services */}
            <div className="relative group">
              <span className="text-base font-semibold text-slate-300 cursor-pointer hover:text-[#53B289] transition-colors">
                Comsys Services
              </span>
              <div className="absolute bottom-full mb-3 w-60 p-4 bg-slate-700 rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform group-hover:-translate-y-1 origin-bottom z-10 text-left">
                <p className="text-slate-400 text-sm font-bold mb-3 pb-2 border-b border-slate-600">Communications</p>
                <div className="space-y-2">
                  <Link to={createPageUrl('VoIPSolutions')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">VoIP Phone Systems</Link>
                  <Link to={createPageUrl('BusinessFibre')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Business Fibre</Link>
                  <Link to={createPageUrl('HomeFibre')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Home Fibre</Link>
                  <Link to={createPageUrl('WiFiUpgrade')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">WiFi Network Upgrades</Link>
                  <Link to={createPageUrl('WebDesignHosting')} className="block text-slate-300 hover:text-[#53B289] transition-colors text-sm">Web Design & Hosting</Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-700 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
            <p className="text-slate-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} COMSYS IT & Communications Ltd. All Rights Reserved.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white text-sm">Privacy Policy</a>
              <a href="#" className="text-slate-400 hover:text-white text-sm">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
