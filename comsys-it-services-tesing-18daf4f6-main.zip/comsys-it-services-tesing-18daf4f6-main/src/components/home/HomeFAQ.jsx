import React from 'react';
import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight } from 'lucide-react';

const faqs = [
  {
    q: 'What types of businesses do you typically support?',
    a: 'We partner with a diverse range of New Zealand businesses, from ambitious startups to established medium-sized enterprises across sectors like legal, healthcare, construction, and retail. Our solutions are designed to be scalable and are customized to fit your specific industry and operational needs.'
  },
  {
    q: 'How quickly can you resolve an urgent IT problem?',
    a: 'We pride ourselves on our rapid response. For critical, business-impacting issues, we guarantee a response within 15 minutes. Our local Auckland-based team is equipped for swift remote and on-site support to get you back to full operational capacity with minimal delay.'
  },
  {
    q: 'What are the main advantages of managed IT services over in-house IT?',
    a: 'Managed IT services offer a strategic advantage by providing proactive monitoring, maintenance, and expert support for a predictable monthly fee. This translates to reduced downtime, enhanced cybersecurity, predictable budgeting, and allows your team to focus on core business objectives instead of troubleshooting technology.'
  },
  {
    q: 'Can you assist with migrating our business to the cloud?',
    a: 'Absolutely. Cloud migration and management are core competencies for us. We specialize in seamless transitions to platforms like Microsoft 365, ensuring a secure, efficient, and cost-effective cloud infrastructure that empowers your team to work from anywhere.'
  }
];

export default function HomeFAQ() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 grid lg:grid-cols-5 gap-12 items-start">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="lg:col-span-2"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
            Have Questions?
          </h2>
          <p className="text-xl text-[#3A4E62]/80 mb-8 leading-relaxed">
            We have answers. Here are some of the most common inquiries we receive. If you don't see your question here, please get in touch.
          </p>
          <Link to={createPageUrl("ContactUs")}>
              <Button size="lg" className="bg-gradient-to-r from-slate-800 to-[#3A4E62] hover:shadow-xl text-white group transition-all duration-300 ease-in-out px-8 py-6 text-base font-semibold rounded-xl shadow-lg">
                  Ask a Question
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
          </Link>
        </motion.div>
        
        <div className="lg:col-span-3">
          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqs.map((faq, index) => (
               <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <AccordionItem value={`item-${index}`} className="bg-slate-50/70 rounded-2xl shadow-sm border border-slate-200/80 transition-shadow hover:shadow-md">
                  <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}