<?php
/**
 * COMSYS IT Theme Functions
 */

// Theme setup
function comsys_theme_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => 'Primary Menu',
        'footer' => 'Footer Menu'
    ));
}
add_action('after_setup_theme', 'comsys_theme_setup');

// Enqueue styles and scripts
function comsys_enqueue_assets() {
    // Main stylesheet
    wp_enqueue_style('comsys-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Custom JavaScript
    wp_enqueue_script('comsys-script', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0.0', true);
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'comsys_enqueue_assets');

// Custom post types
function comsys_custom_post_types() {
    // Services Post Type
    register_post_type('service', array(
        'labels' => array(
            'name' => 'Services',
            'singular_name' => 'Service',
            'add_new' => 'Add New Service',
            'add_new_item' => 'Add New Service',
            'edit_item' => 'Edit Service',
            'new_item' => 'New Service',
            'view_item' => 'View Service',
            'search_items' => 'Search Services',
            'not_found' => 'No services found',
            'not_found_in_trash' => 'No services found in trash'
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'services'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-admin-tools'
    ));
    
    // Testimonials Post Type
    register_post_type('testimonial', array(
        'labels' => array(
            'name' => 'Testimonials',
            'singular_name' => 'Testimonial',
            'add_new' => 'Add New Testimonial',
            'add_new_item' => 'Add New Testimonial',
            'edit_item' => 'Edit Testimonial',
            'new_item' => 'New Testimonial',
            'view_item' => 'View Testimonial',
            'search_items' => 'Search Testimonials',
            'not_found' => 'No testimonials found',
            'not_found_in_trash' => 'No testimonials found in trash'
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-quote'
    ));
}
add_action('init', 'comsys_custom_post_types');

// Add custom fields for testimonials
function comsys_testimonial_meta_boxes() {
    add_meta_box(
        'testimonial_details',
        'Testimonial Details',
        'comsys_testimonial_meta_box_callback',
        'testimonial',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'comsys_testimonial_meta_boxes');

function comsys_testimonial_meta_box_callback($post) {
    wp_nonce_field('comsys_testimonial_meta_box', 'comsys_testimonial_meta_box_nonce');
    
    $client_name = get_post_meta($post->ID, '_client_name', true);
    $company = get_post_meta($post->ID, '_company', true);
    $position = get_post_meta($post->ID, '_position', true);
    $rating = get_post_meta($post->ID, '_rating', true);
    
    echo '<table class="form-table">';
    echo '<tr><th><label for="client_name">Client Name:</label></th>';
    echo '<td><input type="text" id="client_name" name="client_name" value="' . esc_attr($client_name) . '" size="25" /></td></tr>';
    echo '<tr><th><label for="company">Company:</label></th>';
    echo '<td><input type="text" id="company" name="company" value="' . esc_attr($company) . '" size="25" /></td></tr>';
    echo '<tr><th><label for="position">Position:</label></th>';
    echo '<td><input type="text" id="position" name="position" value="' . esc_attr($position) . '" size="25" /></td></tr>';
    echo '<tr><th><label for="rating">Rating (1-5):</label></th>';
    echo '<td><select id="rating" name="rating">';
    for ($i = 1; $i <= 5; $i++) {
        echo '<option value="' . $i . '"' . selected($rating, $i, false) . '>' . $i . ' Star' . ($i > 1 ? 's' : '') . '</option>';
    }
    echo '</select></td></tr>';
    echo '</table>';
}

// Save testimonial meta data
function comsys_save_testimonial_meta($post_id) {
    if (!isset($_POST['comsys_testimonial_meta_box_nonce'])) return;
    if (!wp_verify_nonce($_POST['comsys_testimonial_meta_box_nonce'], 'comsys_testimonial_meta_box')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    $fields = array('client_name', 'company', 'position', 'rating');
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'comsys_save_testimonial_meta');

// Custom widgets
function comsys_widgets_init() {
    register_sidebar(array(
        'name' => 'Footer Widget Area',
        'id' => 'footer-widgets',
        'description' => 'Widgets in this area will be shown in the footer.',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'comsys_widgets_init');

// Contact form shortcode
function comsys_contact_form_shortcode($atts) {
    $atts = shortcode_atts(array(
        'email' => get_option('admin_email'),
        'subject' => 'Contact Form Submission'
    ), $atts);
    
    $output = '';
    
    if ($_POST['comsys_contact_submit']) {
        $name = sanitize_text_field($_POST['contact_name']);
        $email = sanitize_email($_POST['contact_email']);
        $phone = sanitize_text_field($_POST['contact_phone']);
        $message = sanitize_textarea_field($_POST['contact_message']);
        
        $email_body = "Name: $name\nEmail: $email\nPhone: $phone\n\nMessage:\n$message";
        
        if (wp_mail($atts['email'], $atts['subject'], $email_body)) {
            $output .= '<div class="success-message">Thank you! Your message has been sent.</div>';
        } else {
            $output .= '<div class="error-message">Sorry, there was an error sending your message.</div>';
        }
    }
    
    $output .= '
    <form method="post" class="comsys-contact-form">
        <div class="form-group">
            <label for="contact_name">Full Name *</label>
            <input type="text" id="contact_name" name="contact_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="contact_email">Email Address *</label>
            <input type="email" id="contact_email" name="contact_email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="contact_phone">Phone Number</label>
            <input type="tel" id="contact_phone" name="contact_phone" class="form-control">
        </div>
        <div class="form-group">
            <label for="contact_message">Message *</label>
            <textarea id="contact_message" name="contact_message" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" name="comsys_contact_submit" class="btn btn-primary">Send Message</button>
    </form>';
    
    return $output;
}
add_shortcode('comsys_contact_form', 'comsys_contact_form_shortcode');

// SEO improvements
function comsys_add_meta_tags() {
    if (is_single() || is_page()) {
        global $post;
        if (has_post_thumbnail($post->ID)) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large');
            echo '<meta property="og:image" content="' . $image[0] . '">';
        }
    }
}
add_action('wp_head', 'comsys_add_meta_tags');

// Custom excerpt length
function comsys_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'comsys_excerpt_length');

// Custom more link
function comsys_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'comsys_excerpt_more');
?>