<?php get_header(); ?>

<main class="site-main">
    <!-- Page Header -->
    <section class="page-header" style="background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%); color: white; padding: 150px 0 80px; text-align: center;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 2rem;">
            <h1 style="font-size: 3rem; font-weight: 800; margin-bottom: 1rem;">Our IT Services</h1>
            <p style="font-size: 1.25rem; opacity: 0.9;">
                Comprehensive technology solutions for New Zealand businesses
            </p>
        </div>
    </section>

    <!-- Services Grid -->
    <section class="services-section">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 2rem;">
            <?php
            $services = new WP_Query(array(
                'post_type' => 'service',
                'posts_per_page' => -1,
                'orderby' => 'menu_order',
                'order' => 'ASC'
            ));
            
            if ($services->have_posts()) : ?>
                <div class="services-grid">
                    <?php while ($services->have_posts()) : $services->the_post(); ?>
                        <div class="service-card">
                            <div class="service-icon">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('thumbnail'); ?>
                                <?php else : ?>
                                    🛠️
                                <?php endif; ?>
                            </div>
                            <h3 class="service-title"><?php the_title(); ?></h3>
                            <div class="service-description">
                                <?php the_excerpt(); ?>
                            </div>
                            <a href="<?php the_permalink(); ?>" class="btn btn-primary">Learn More</a>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else : ?>
                <!-- Fallback if no custom services are created -->
                <div class="services-grid">
                    <div class="service-card">
                        <div class="service-icon">🛠️</div>
                        <h3 class="service-title">IT Support & Managed Services</h3>
                        <p class="service-description">
                            Proactive, responsive IT support for NZ businesses. We act as your outsourced IT department.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Get Support</a>
                    </div>
                    
                    <div class="service-card">
                        <div class="service-icon">💾</div>
                        <h3 class="service-title">Data Backup & Recovery</h3>
                        <p class="service-description">
                            Protect your valuable data with automated, secure backup solutions and rapid recovery.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Secure Data</a>
                    </div>
                    
                    <div class="service-card">
                        <div class="service-icon">📶</div>
                        <h3 class="service-title">WiFi Network Upgrades</h3>
                        <p class="service-description">
                            Eliminate dead zones with professional WiFi upgrades and network optimization.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Upgrade WiFi</a>
                    </div>
                    
                    <div class="service-card">
                        <div class="service-icon">☁️</div>
                        <h3 class="service-title">Cloud Solutions</h3>
                        <p class="service-description">
                            Microsoft 365 setup, cloud migration, and ongoing management for modern businesses.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Go Cloud</a>
                    </div>
                    
                    <div class="service-card">
                        <div class="service-icon">🔒</div>
                        <h3 class="service-title">Cybersecurity</h3>
                        <p class="service-description">
                            Protect your business with enterprise-grade security solutions and monitoring.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Get Protected</a>
                    </div>
                    
                    <div class="service-card">
                        <div class="service-icon">🌐</div>
                        <h3 class="service-title">Business Broadband</h3>
                        <p class="service-description">
                            High-speed, reliable internet connections tailored for business requirements.
                        </p>
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">Get Connected</a>
                    </div>
                </div>
            <?php endif; 
            wp_reset_postdata(); ?>
        </div>
    </section>

    <!-- Call to Action -->
    <section style="padding: 80px 0; background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%); color: white; text-align: center;">
        <div style="max-width: 800px; margin: 0 auto; padding: 0 2rem;">
            <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 1.5rem;">Ready to Get Started?</h2>
            <p style="font-size: 1.25rem; margin-bottom: 2.5rem; opacity: 0.9;">
                Let our experts assess your current IT setup and recommend the best solutions for your business.
            </p>
            <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary" style="font-size: 1.125rem; padding: 1rem 2.5rem;">
                Get Free Consultation
            </a>
        </div>
    </section>
</main>

<?php get_footer(); ?>