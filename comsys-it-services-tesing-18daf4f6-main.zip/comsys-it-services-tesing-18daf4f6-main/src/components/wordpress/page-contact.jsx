<?php get_header(); ?>

<main class="site-main">
    <!-- Page Header -->
    <section class="page-header" style="background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%); color: white; padding: 150px 0 80px; text-align: center;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 2rem;">
            <h1 style="font-size: 3rem; font-weight: 800; margin-bottom: 1rem;">Contact Us</h1>
            <p style="font-size: 1.25rem; opacity: 0.9;">
                Get in touch with Auckland's most trusted IT support team
            </p>
        </div>
    </section>

    <!-- Contact Content -->
    <section style="padding: 80px 0;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 2rem;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: start;">
                <!-- Contact Information -->
                <div>
                    <h2 style="font-size: 2rem; color: #3A4E62; margin-bottom: 2rem;">Get in Touch</h2>
                    <p style="font-size: 1.125rem; color: #6B7280; margin-bottom: 3rem; line-height: 1.6;">
                        Ready to transform your IT infrastructure? Our Auckland-based team is here to help. 
                        Contact us today for a free consultation and discover how we can support your business.
                    </p>

                    <div style="space-y: 2rem;">
                        <!-- Phone -->
                        <div style="display: flex; align-items: center; margin-bottom: 2rem;">
                            <div style="width: 60px; height: 60px; background: #53B289; border-radius: 15px; display: flex; align-items: center; justify-content: center; margin-right: 1.5rem;">
                                <span style="font-size: 1.5rem;">📞</span>
                            </div>
                            <div>
                                <h3 style="color: #3A4E62; font-weight: 600; margin-bottom: 0.25rem;">Call Us</h3>
                                <a href="tel:0800724526" style="color: #53B289; text-decoration: none; font-size: 1.125rem; font-weight: 600;">0800 724 526</a>
                                <p style="color: #6B7280; font-size: 0.875rem;">Monday - Friday, 8AM - 6PM</p>
                            </div>
                        </div>

                        <!-- Email -->
                        <div style="display: flex; align-items: center; margin-bottom: 2rem;">
                            <div style="width: 60px; height: 60px; background: #53B289; border-radius: 15px; display: flex; align-items: center; justify-content: center; margin-right: 1.5rem;">
                                <span style="font-size: 1.5rem;">✉️</span>
                            </div>
                            <div>
                                <h3 style="color: #3A4E62; font-weight: 600; margin-bottom: 0.25rem;">Email Us</h3>
                                <a href="mailto:info@comsys.co.nz" style="color: #53B289; text-decoration: none; font-size: 1.125rem; font-weight: 600;">info@comsys.co.nz</a>
                                <p style="color: #6B7280; font-size: 0.875rem;">We'll respond within 2 hours</p>
                            </div>
                        </div>

                        <!-- Address -->
                        <div style="display: flex; align-items: center; margin-bottom: 2rem;">
                            <div style="width: 60px; height: 60px; background: #53B289; border-radius: 15px; display: flex; align-items: center; justify-content: center; margin-right: 1.5rem;">
                                <span style="font-size: 1.5rem;">📍</span>
                            </div>
                            <div>
                                <h3 style="color: #3A4E62; font-weight: 600; margin-bottom: 0.25rem;">Visit Us</h3>
                                <p style="color: #6B7280; font-size: 1.125rem; line-height: 1.4;">
                                    Level 1, 30 St Benedicts Street<br>
                                    Eden Terrace, Auckland 1010
                                </p>
                            </div>
                        </div>

                        <!-- Emergency Support -->
                        <div style="background: #FEF2F2; border: 1px solid #FECACA; border-radius: 12px; padding: 1.5rem; margin-top: 2rem;">
                            <h3 style="color: #DC2626; font-weight: 600; margin-bottom: 0.5rem;">Emergency Support</h3>
                            <p style="color: #7F1D1D; font-size: 0.875rem;">
                                For critical IT issues outside business hours, call our emergency line: 
                                <strong>0800 724 526</strong>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div>
                    <div style="background: white; padding: 3rem; border-radius: 1.5rem; box-shadow: 0 20px 40px rgba(0,0,0,0.1); border: 1px solid #E5E7EB;">
                        <h2 style="font-size: 1.75rem; color: #3A4E62; margin-bottom: 1.5rem;">Send us a Message</h2>
                        
                        <?php echo do_shortcode('[comsys_contact_form]'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section (Optional - you can add Google Maps embed here) -->
    <section style="padding: 80px 0; background: #F9FAFB;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 2rem;">
            <h2 style="text-align: center; font-size: 2.5rem; color: #3A4E62; margin-bottom: 3rem;">Find Our Office</h2>
            
            <!-- Google Maps Embed (Replace with your actual embed code) -->
            <div style="background: #E5E7EB; height: 400px; border-radius: 1.5rem; display: flex; align-items: center; justify-content: center;">
                <p style="color: #6B7280; font-size: 1.125rem;">Google Maps Integration</p>
                <!-- 
                Replace this div with actual Google Maps embed code:
                <iframe src="YOUR_GOOGLE_MAPS_EMBED_URL" width="100%" height="400" frameborder="0" style="border-radius: 1.5rem;" allowfullscreen></iframe>
                -->
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>