<?php get_header(); ?>

<main class="site-main">
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content">
            <h1 class="hero-title">
                Auckland's Most Trusted
                <span style="background: linear-gradient(135deg, #53B289 0%, #C0E3D4 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                    IT Support & Solutions Provider
                </span>
            </h1>
            <p class="hero-subtitle">
                From data backup to business broadband, we deliver reliable IT services that keep 
                your Auckland business running 24/7. Fast response times, local expertise, and 
                comprehensive support you can count on.
            </p>
            <div class="cta-buttons">
                <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">
                    Get a Free IT Assessment
                </a>
                <a href="<?php echo home_url('/contact'); ?>" class="btn btn-outline">
                    Contact Our Team
                </a>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number">500+</div>
                <div class="stat-label">Businesses Served</div>
                <div class="stat-description">Trusted by companies across New Zealand</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">15+</div>
                <div class="stat-label">Years Experience</div>
                <div class="stat-description">Decades of IT expertise and innovation</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">99.9%</div>
                <div class="stat-label">Uptime Guarantee</div>
                <div class="stat-description">Industry-leading reliability standards</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">24/7</div>
                <div class="stat-label">Support Available</div>
                <div class="stat-description">Round-the-clock monitoring and assistance</div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services-section">
        <h2 class="section-title">Our Comprehensive IT Services</h2>
        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon">🛠️</div>
                <h3 class="service-title">IT Support & Managed Services</h3>
                <p class="service-description">
                    Proactive, responsive IT support for NZ businesses. We act as your outsourced IT department, 
                    minimizing downtime and resolving issues fast with our local expert team.
                </p>
                <a href="<?php echo home_url('/services/it-support'); ?>" class="btn btn-primary">Get IT Support</a>
            </div>

            <div class="service-card">
                <div class="service-icon">💾</div>
                <h3 class="service-title">Data Backup & Disaster Recovery</h3>
                <p class="service-description">
                    Protect your most valuable asset with automated, secure data backups. Our robust solutions ensure 
                    rapid recovery from hardware failure, cyber-attacks, or accidental deletion.
                </p>
                <a href="<?php echo home_url('/services/data-backup'); ?>" class="btn btn-primary">Secure My Data</a>
            </div>

            <div class="service-card">
                <div class="service-icon">💻</div>
                <h3 class="service-title">PC/Laptop Parts & Repair</h3>
                <p class="service-description">
                    Extend the life of your devices with our expert repair and upgrade services. From cracked screens 
                    to performance-boosting SSD upgrades, we get you back to work quickly.
                </p>
                <a href="<?php echo home_url('/services/pc-repair'); ?>" class="btn btn-primary">Fix My Device</a>
            </div>

            <div class="service-card">
                <div class="service-icon">📶</div>
                <h3 class="service-title">WiFi Network Upgrades</h3>
                <p class="service-description">
                    Eliminate dead zones and slow speeds with a professional WiFi upgrade. We design and install 
                    robust wireless networks for seamless coverage in your home or office.
                </p>
                <a href="<?php echo home_url('/services/wifi-upgrade'); ?>" class="btn btn-primary">Upgrade WiFi</a>
            </div>

            <div class="service-card">
                <div class="service-icon">☁️</div>
                <h3 class="service-title">Microsoft Office 365</h3>
                <p class="service-description">
                    Unlock your team's productivity with expert Microsoft 365 setup, management, and support. 
                    We handle licensing, security, and training to optimize your workflow.
                </p>
                <a href="<?php echo home_url('/services/office-365'); ?>" class="btn btn-primary">Setup Office 365</a>
            </div>

            <div class="service-card">
                <div class="service-icon">🌐</div>
                <h3 class="service-title">Business Fibre & Broadband</h3>
                <p class="service-description">
                    Get the full speed of your internet plan with our business broadband solutions. We provide 
                    reliable, high-speed connections tailored for commercial use.
                </p>
                <a href="<?php echo home_url('/services/business-fibre'); ?>" class="btn btn-primary">Get Faster Internet</a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="contact-container">
            <h2 class="section-title" style="color: white; margin-bottom: 2rem;">Ready to Get Started?</h2>
            <p style="font-size: 1.25rem; margin-bottom: 3rem; opacity: 0.9;">
                Get personalized recommendations from our IT experts with a complimentary consultation.
            </p>
            
            <div class="contact-form">
                <?php echo do_shortcode('[contact-form-7 id="1" title="Contact form 1"]'); ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>