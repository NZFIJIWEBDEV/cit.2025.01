/*
Theme Name: COMSYS IT Theme
Description: Professional IT services WordPress theme for COMSYS
Version: 1.0
Author: Base44 Migration
*/

/* Reset and Base Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  line-height: 1.6;
  color: #3A4E62;
  background: #f8fafc;
}

/* Header Styles */
.site-header {
  background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%);
  color: white;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
  box-shadow: 0 2px 20px rgba(0,0,0,0.1);
}

.header-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.site-logo img {
  height: 50px;
  width: auto;
}

.main-navigation ul {
  display: flex;
  list-style: none;
  gap: 2rem;
}

.main-navigation a {
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s ease;
}

.main-navigation a:hover {
  color: #53B289;
}

/* Hero Section */
.hero-section {
  background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%);
  color: white;
  padding: 150px 0 100px;
  text-align: center;
  position: relative;
  overflow: hidden;
}

.hero-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
}

.hero-title {
  font-size: 3.5rem;
  font-weight: 800;
  margin-bottom: 1.5rem;
  line-height: 1.2;
}

.hero-subtitle {
  font-size: 1.25rem;
  margin-bottom: 2rem;
  opacity: 0.9;
}

.cta-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.btn {
  display: inline-block;
  padding: 1rem 2rem;
  border-radius: 0.75rem;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  cursor: pointer;
  border: none;
}

.btn-primary {
  background: #53B289;
  color: white;
}

.btn-primary:hover {
  background: #4aa07b;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(83, 178, 137, 0.3);
}

.btn-outline {
  border: 2px solid rgba(255,255,255,0.3);
  background: rgba(255,255,255,0.1);
  color: white;
}

.btn-outline:hover {
  background: white;
  color: #3A4E62;
}

/* Services Section */
.services-section {
  padding: 100px 0;
  background: linear-gradient(135deg, rgba(83, 178, 137, 0.08) 0%, rgba(192, 227, 212, 0.12) 50%, rgba(248, 250, 252, 1) 100%);
}

.section-title {
  text-align: center;
  font-size: 3rem;
  font-weight: 800;
  color: #3A4E62;
  margin-bottom: 4rem;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
}

.service-card {
  background: rgba(255,255,255,0.95);
  padding: 2.5rem;
  border-radius: 1.5rem;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
  border: 2px solid rgba(83, 178, 137, 0.1);
}

.service-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
  border-color: rgba(83, 178, 137, 0.3);
}

.service-icon {
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, rgba(83, 178, 137, 0.1) 0%, rgba(192, 227, 212, 0.15) 100%);
  border-radius: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 2rem;
  font-size: 2rem;
}

.service-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: #3A4E62;
  margin-bottom: 1rem;
}

.service-description {
  color: rgba(58, 78, 98, 0.8);
  line-height: 1.6;
  margin-bottom: 2rem;
}

/* Stats Section */
.stats-section {
  padding: 80px 0;
  background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
}

.stat-card {
  text-align: center;
  background: white;
  padding: 2.5rem 1.5rem;
  border-radius: 1.5rem;
  box-shadow: 0 10px 25px rgba(0,0,0,0.08);
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
}

.stat-number {
  font-size: 3rem;
  font-weight: 800;
  color: #53B289;
  margin-bottom: 0.5rem;
}

.stat-label {
  font-size: 1.25rem;
  font-weight: 600;
  color: #3A4E62;
  margin-bottom: 0.5rem;
}

.stat-description {
  color: rgba(58, 78, 98, 0.7);
  font-size: 0.9rem;
}

/* Contact Section */
.contact-section {
  padding: 100px 0;
  background: linear-gradient(135deg, #3A4E62 0%, #2a3749 100%);
  color: white;
}

.contact-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 0 2rem;
  text-align: center;
}

.contact-form {
  background: rgba(255,255,255,0.1);
  padding: 3rem;
  border-radius: 1.5rem;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255,255,255,0.2);
}

.form-group {
  margin-bottom: 1.5rem;
  text-align: left;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.form-control {
  width: 100%;
  padding: 1rem;
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 0.75rem;
  background: rgba(255,255,255,0.1);
  color: white;
  font-size: 1rem;
}

.form-control::placeholder {
  color: rgba(255,255,255,0.6);
}

.form-control:focus {
  outline: none;
  border-color: #53B289;
  box-shadow: 0 0 0 3px rgba(83, 178, 137, 0.3);
}

textarea.form-control {
  min-height: 120px;
  resize: vertical;
}

/* Footer */
.site-footer {
  background: #1e2832;
  color: white;
  padding: 60px 0 30px;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 3rem;
}

.footer-section h3 {
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  color: #53B289;
}

.footer-section ul {
  list-style: none;
}

.footer-section ul li {
  margin-bottom: 0.75rem;
}

.footer-section a {
  color: rgba(255,255,255,0.8);
  text-decoration: none;
  transition: color 0.3s ease;
}

.footer-section a:hover {
  color: #53B289;
}

.footer-bottom {
  margin-top: 3rem;
  padding-top: 2rem;
  border-top: 1px solid rgba(255,255,255,0.1);
  text-align: center;
  color: rgba(255,255,255,0.6);
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-title {
    font-size: 2.5rem;
  }
  
  .section-title {
    font-size: 2rem;
  }
  
  .services-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
  
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .cta-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .main-navigation ul {
    flex-direction: column;
    gap: 1rem;
  }
}

@media (max-width: 480px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .service-card,
  .contact-form {
    padding: 1.5rem;
  }
  
  .hero-content {
    padding: 0 1rem;
  }
}