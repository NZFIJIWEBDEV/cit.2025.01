<footer class="site-footer">
    <div class="footer-content">
        <div class="footer-section">
            <h3>Services</h3>
            <ul>
                <li><a href="<?php echo home_url('/services/it-support'); ?>">IT Support</a></li>
                <li><a href="<?php echo home_url('/services/data-backup'); ?>">Data Backup</a></li>
                <li><a href="<?php echo home_url('/services/wifi-upgrade'); ?>">WiFi Upgrades</a></li>
                <li><a href="<?php echo home_url('/services/business-fibre'); ?>">Business Fibre</a></li>
                <li><a href="<?php echo home_url('/services/office-365'); ?>">Microsoft 365</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3>Industries</h3>
            <ul>
                <li><a href="<?php echo home_url('/industries/healthcare'); ?>">Healthcare</a></li>
                <li><a href="<?php echo home_url('/industries/legal'); ?>">Legal & Financial</a></li>
                <li><a href="<?php echo home_url('/industries/retail'); ?>">Retail & eCommerce</a></li>
                <li><a href="<?php echo home_url('/industries/construction'); ?>">Construction</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3>Company</h3>
            <ul>
                <li><a href="<?php echo home_url('/about'); ?>">About Us</a></li>
                <li><a href="<?php echo home_url('/contact'); ?>">Contact</a></li>
                <li><a href="<?php echo home_url('/privacy'); ?>">Privacy Policy</a></li>
                <li><a href="<?php echo home_url('/terms'); ?>">Terms of Service</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3>Contact Info</h3>
            <ul>
                <li>📞 <a href="tel:0800724526">0800 724 526</a></li>
                <li>✉️ <a href="mailto:info@comsys.co.nz">info@comsys.co.nz</a></li>
                <li>📍 Level 1, 30 St Benedicts Street<br>Eden Terrace, Auckland 1010</li>
            </ul>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> COMSYS IT & Communications. All rights reserved.</p>
    </div>
</footer>

<?php wp_footer(); ?>

<script>
// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const navigation = document.querySelector('.main-navigation');
    
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            navigation.classList.toggle('active');
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});
</script>

</body>
</html>