import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Landmark, Shield, Lock, FileText, ExternalLink, Users } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Government Agencies in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Secure IT services for Auckland government agencies. Comsys IT provides cybersecurity, backup, and IT support for public sector organisations.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=GovernmentIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Government IT Consultation
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const RequirementsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Requirements in Government
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?w=600&h=400&fit=crop" 
            alt="Government IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Upholding Public Trust Through Technology</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Government agencies require robust, secure, and compliant IT infrastructure to deliver public services effectively, protect sensitive citizen data, and maintain public trust.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Shield,
                title: "Cybersecurity & National Security",
                desc: "Protecting against state-sponsored attacks and cyber espionage."
              },
              {
                icon: FileText,
                title: "Regulatory & Compliance Mandates",
                desc: "Adherence to government IT standards, privacy laws, and accessibility requirements."
              },
              {
                icon: Lock,
                title: "Citizen Data Protection",
                desc: "Securing vast amounts of personally identifiable information (PII)."
              },
              {
                icon: Landmark,
                title: "Service Continuity & Reliability",
                desc: "Ensuring essential public services remain operational 24/7."
              }
            ].map((req, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <req.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{req.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{req.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CybersecuritySection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Cybersecurity Solutions for Government
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Defence-in-Depth Strategy</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We provide a multi-layered security framework designed to meet the stringent requirements of government agencies, protecting against internal and external threats.
            </p>
          </div>
          
          <div className="space-y-4">
            {[
              { title: "Threat Intelligence & Prevention", desc: "Proactive defence using real-time global threat data." },
              { title: "Secure Cloud Environments", desc: "Certified cloud solutions for government workloads." },
              { title: "Endpoint Detection & Response (EDR)", desc: "Advanced protection for all government devices." },
              { title: "Security Audits & Compliance Reporting", desc: "Regular assessments to ensure adherence to standards." },
              { title: "Incident Response Planning", desc: "Established protocols for handling security breaches swiftly." },
            ].map((feature) => (
              <div key={feature.title} className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-[#3A4E62]/80">{feature.title}: <span className="text-sm">{feature.desc}</span></span>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=600&h=400&fit=crop" 
            alt="Government Cybersecurity Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const BackupComplianceSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Backup & Compliance
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Data Sovereignty",
            desc: "All primary and backup data is stored securely within New Zealand to comply with government data residency policies.",
            icon: "🇳🇿"
          },
          {
            title: "Immutable Backups",
            desc: "Ransomware-proof backups that cannot be altered or deleted, ensuring data integrity and recoverability.",
            icon: "🛡️"
          },
          {
            title: "Compliance Archiving",
            desc: "Long-term data archiving solutions that meet public records retention requirements and legal discovery needs.",
            icon: "🗄️"
          }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
          >
            <div className="text-4xl mb-4 text-center">{item.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4 text-center">{item.title}</h3>
            <p className="text-[#3A4E62]/80 text-sm text-center">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Comsys IT for Government
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">A Trusted Public Sector Partner</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We provide government agencies with reliable, secure, and compliant IT solutions, enabling them to serve the public effectively while safeguarding national interests.
            </p>
          </div>
          
          <div className="space-y-4">
            {[
              "Adherence to Government Chief Digital Officer (GCDO) standards",
              "Experience with All-of-Government (AoG) procurement processes",
              "Security-cleared personnel available for sensitive projects",
              "Commitment to data sovereignty and the Privacy Act 2020",
              "Scalable solutions for agencies of all sizes"
            ].map((benefit) => (
              <div key={benefit} className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT migrated our entire department to a secure government cloud environment ahead of schedule and under budget. Their understanding of public sector security requirements is second to none. We've passed every security audit with flying colors since they took over."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Landmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Jane Doe</div>
              <div className="text-sm text-[#3A4E62]/70">IT Director, Auckland Regional Council</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you meet government IT compliance standards?",
            answer: "Yes, our services are designed to meet and exceed New Zealand government IT compliance standards, including those set by the Government Chief Digital Officer (GCDO). We ensure compliance with the Privacy Act 2020, the Public Records Act 2005, and relevant security frameworks."
          },
          {
            question: "Do you provide cloud migration services?",
            answer: "Absolutely. We specialize in migrating government agencies to secure cloud environments, including government-certified community clouds and private cloud infrastructure. We manage the entire process from planning and data migration to security configuration and ongoing management, ensuring a seamless and secure transition."
          },
          {
            question: "Can you secure sensitive data?",
            answer: "Yes, securing sensitive government and citizen data is our top priority. We use a defence-in-depth approach including advanced encryption, multi-factor authentication, strict access controls, and 24/7 monitoring. All data is stored within New Zealand to meet data sovereignty requirements."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesGovernment() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Government Agencies Auckland",
      "description": "Secure IT services for Auckland government agencies. Comsys IT provides cybersecurity, backup, and IT support for public sector organisations.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": { "@type": "City", "name": "Auckland" },
        "serviceType": "Government IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you meet government IT compliance standards?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, our services are designed to meet and exceed New Zealand government IT compliance standards, including those set by the Government Chief Digital Officer (GCDO). We ensure compliance with the Privacy Act 2020, the Public Records Act 2005, and relevant security frameworks." }
        },
        {
          "@type": "Question",
          "name": "Do you provide cloud migration services?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in migrating government agencies to secure cloud environments, including government-certified community clouds and private cloud infrastructure. We manage the entire process from planning and data migration to security configuration and ongoing management, ensuring a seamless and secure transition." }
        },
        {
          "@type": "Question",
          "name": "Can you secure sensitive data?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, securing sensitive government and citizen data is our top priority. We use a defence-in-depth approach including advanced encryption, multi-factor authentication, strict access controls, and 24/7 monitoring. All data is stored within New Zealand to meet data sovereignty requirements." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Government Agencies Auckland", "item": "https://www.comsys.co.nz/IndustriesGovernment" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Government Agencies Auckland | Comsys IT"
        description="Secure IT services for Auckland government agencies. Comsys IT provides cybersecurity, backup, and IT support for public sector organisations."
        keywords="government IT support Auckland, public sector IT services, GCDO compliance, government cybersecurity NZ"
        canonical="https://www.comsys.co.nz/IndustriesGovernment"
        schemas={schemas}
      />
      
      <PageHero />
      <RequirementsSection />
      <CybersecuritySection />
      <BackupComplianceSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}