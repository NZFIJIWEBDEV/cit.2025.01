import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, MapPin, Wifi, Calendar, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Tourism Businesses in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland tourism operators. Comsys IT provides booking system support, guest WiFi, and reliable IT infrastructure for tours.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=TourismIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Tourism IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Tourism Operators
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop" 
            alt="Tourism IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Creating Memorable Experiences</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Tourism businesses need reliable technology to manage bookings, provide excellent customer service, 
              and create seamless experiences for visitors to New Zealand.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Calendar, title: "Booking System Support", desc: "Reliable support for online booking platforms and reservation systems." },
              { icon: Wifi, title: "Guest WiFi Solutions", desc: "Fast, secure WiFi networks for visitors and staff operations." },
              { icon: MapPin, title: "Mobile & Remote Operations", desc: "IT solutions for tour operators working in remote locations." },
              { icon: Shield, title: "Customer Data Security", desc: "Protecting guest information and payment data from cyber threats." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BookingSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Booking Systems & Online Presence
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Streamline Your Reservations</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We ensure your booking systems, websites, and online platforms are always available and performing optimally, 
              so you never miss a booking opportunity.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "24/7 monitoring of booking platforms and websites.",
              "Integration with popular booking engines (BookMe, Viator, etc.).",
              "Mobile-optimized booking systems for on-the-go customers.",
              "Payment processing security and PCI compliance.",
              "Real-time availability and inventory management.",
              "Backup systems to prevent booking disruptions."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Booking System Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Increased Bookings</h5>
              <p className="text-sm text-[#3A4E62]/80">Fast, user-friendly booking systems convert more visitors into customers.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Reduced Admin</h5>
              <p className="text-sm text-[#3A4E62]/80">Automated booking confirmations, reminders, and payment processing.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Better Planning</h5>
              <p className="text-sm text-[#3A4E62]/80">Real-time visibility of bookings helps optimize tours and resources.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Tourism Operators
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Show New Zealand at Its Best</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our tourism IT solutions help you deliver exceptional experiences to visitors, 
            manage operations efficiently, and grow your business in New Zealand's competitive tourism market.
          </p>
          {[
            "Maximized booking opportunities with reliable systems.",
            "Enhanced guest experience with quality WiFi and tech.",
            "Streamlined operations and reduced administrative tasks.",
            "Secure handling of guest data and payments.",
            "Scalable IT solutions to support business growth."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT transformed our booking system reliability. Before working with them, we were losing bookings due to website crashes during peak season. Now our systems run flawlessly, and we've increased our online bookings by 35%. Their support team understands the unique challenges of tourism operators."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Rachel Thompson</div>
              <div className="text-sm text-[#3A4E62]/70">Owner, Bay of Islands Adventure Tours</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support online booking platforms like BookMe and Viator?",
            answer: "Yes, we provide comprehensive IT support to ensure your integration with popular booking platforms runs smoothly. We monitor your website, booking systems, and payment processing to minimize downtime and maximize booking opportunities."
          },
          {
            question: "Can you provide IT support for remote tour locations?",
            answer: "Absolutely. We specialize in providing IT solutions for tourism operators working in remote locations. This includes mobile internet solutions, satellite connectivity, portable WiFi hotspots, and remote support for staff operating tours away from the main office."
          },
          {
            question: "Do you help with guest WiFi and digital experiences?",
            answer: "Yes, we design and install guest WiFi networks that enhance the visitor experience while keeping your business operations secure. We can also help integrate digital elements like QR codes, mobile apps, and interactive displays to create memorable experiences for your guests."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesTourism() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Tourism Businesses in Auckland",
      "description": "IT support for Auckland tourism operators. Comsys IT provides booking system support, guest WiFi, and reliable IT infrastructure for tours.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Tourism IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support online booking platforms like BookMe and Viator?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive IT support to ensure your integration with popular booking platforms runs smoothly. We monitor your website, booking systems, and payment processing to minimize downtime and maximize booking opportunities." }
        },
        {
          "@type": "Question", "name": "Can you provide IT support for remote tour locations?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in providing IT solutions for tourism operators working in remote locations. This includes mobile internet solutions, satellite connectivity, portable WiFi hotspots, and remote support for staff operating tours away from the main office." }
        },
        {
          "@type": "Question", "name": "Do you help with guest WiFi and digital experiences?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we design and install guest WiFi networks that enhance the visitor experience while keeping your business operations secure. We can also help integrate digital elements like QR codes, mobile apps, and interactive displays to create memorable experiences for your guests." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Tourism Businesses in Auckland", "item": "https://www.comsys.co.nz/IndustriesTourism" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Tourism Businesses Auckland | Comsys IT"
        description="IT support for Auckland tourism operators. Comsys IT provides booking system support, guest WiFi, and reliable IT infrastructure for tours."
        keywords="tourism IT support Auckland, booking system support, tour operator IT, guest WiFi, tourism technology"
        canonical="https://www.comsys.co.nz/IndustriesTourism"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <BookingSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}