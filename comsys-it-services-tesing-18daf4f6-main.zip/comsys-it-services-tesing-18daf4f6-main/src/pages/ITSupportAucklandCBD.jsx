
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, ShoppingCart, ShoppingBag } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Auckland CBD businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Rapid IT Support for Auckland CBD
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        Running a business in Auckland's bustling CBD means you can't afford IT downtime. Comsys IT delivers professional, fast, and reliable IT support services specifically designed for the fast-paced Auckland CBD environment, ensuring your business stays competitive and secure.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=AucklandCBDITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free CBD IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Your CBD Business?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "15-Minute Response Time", 
            desc: "Critical issues in the CBD get immediate attention with our rapid response guarantee.",
            icon: Clock
          },
          { 
            title: "Local Auckland Team", 
            desc: "Our technicians are based in Auckland and understand CBD business requirements.",
            icon: Users
          },
          { 
            title: "Transparent Pricing", 
            desc: "No hidden fees or surprise costs - just affordable, predictable IT support.",
            icon: CheckCircle
          },
          { 
            title: "24/7 Proactive Monitoring", 
            desc: "Proactive monitoring prevents issues before they impact your business operations.",
            icon: Shield
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT Support & Helpdesk", 
      desc: "Comprehensive support acting as your dedicated IT department. We provide proactive monitoring, rapid issue resolution, and ongoing system maintenance for CBD businesses.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Backup & Disaster Recovery", 
      desc: "Protect your critical business data with automated backup and disaster recovery solutions, essential for any business operating in the competitive Auckland CBD.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Phone, 
      title: "Enterprise VoIP Phone Systems", 
      desc: "Transform your office communications with advanced, cloud-based VoIP phone systems designed for the modern, flexible CBD workplace.",
      link: "VoIPSolutions",
      imageUrl: "https://images.unsplash.com/photo-1596524430615-b46475ddff6e?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Video, 
      title: "Professional CCTV Security Systems", 
      desc: "Protect your Auckland CBD business premises with our professional-grade CCTV security systems. We design and install comprehensive surveillance solutions tailored to your specific location and security requirements. Our systems include high-definition cameras, remote monitoring capabilities, motion detection, night vision, and secure cloud storage. Perfect for retail stores on Queen Street, office buildings, restaurants, and professional services. We ensure your CCTV system integrates seamlessly with your existing security infrastructure and provide ongoing maintenance and support.",
      link: "CCTVSecurity",
      imageUrl: "https://images.unsplash.com/photo-1579737151046-86d7ce7e6a77?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Server, 
      title: "High-Speed Business Fibre Internet", 
      desc: "Keep your Auckland CBD business connected with lightning-fast business fibre internet designed for commercial use. We provide dedicated business-grade connections with guaranteed speeds, priority support, and service level agreements that ensure maximum uptime. Our business fibre solutions include static IP addresses, enhanced security features, and scalable bandwidth to grow with your business. Perfect for offices that rely on cloud applications, video conferencing, large file transfers, and real-time collaboration tools.",
      link: "BusinessFibre",
      imageUrl: "https://images.unsplash.com/photo-1572044810795-0210f84501eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Building, 
      title: "Complete IT Infrastructure Management", 
      desc: "Let us manage your entire IT infrastructure so you can focus on running your business. Our managed services include server management, network administration, software updates, security monitoring, and strategic technology planning. We provide regular system health reports, capacity planning, and technology recommendations to keep your infrastructure current and efficient. Perfect for Auckland CBD businesses that want enterprise-level IT capabilities without the overhead of maintaining an internal IT department.",
      link: "ITInfrastructureManagement",
      imageUrl: "https://images.unsplash.com/photo-1581093556754-046645391c78?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Comprehensive IT Services for Auckland CBD
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Auckland CBD businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Industries We Support in Auckland CBD
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {[
          {
            title: "Legal & Professional Services",
            desc: "Law firms, accounting practices, and professional consultancies require secure, reliable IT systems to protect sensitive client information and ensure seamless operations."
          },
          {
            title: "Financial Services & Banking",
            desc: "Financial institutions need robust cybersecurity, compliance-ready systems, and reliable communications to serve clients and meet regulatory requirements."
          },
          {
            title: "Retail & Hospitality",
            desc: "Restaurants, cafes, retail stores, and hospitality businesses rely on point-of-sale systems, inventory management, and customer Wi-Fi solutions."
          },
          {
            title: "Corporate Offices & Startups",
            desc: "From small startups to large corporations, we provide scalable IT solutions that grow with your business and support remote work capabilities."
          },
          {
            title: "Healthcare & Medical",
            desc: "Medical practices and healthcare providers need HIPAA-compliant systems, secure patient data management, and reliable telehealth infrastructure."
          },
          {
            title: "Creative & Marketing Agencies",
            desc: "Design agencies and marketing firms require high-performance workstations, large file storage solutions, and collaborative tools for creative projects."
          }
        ].map((industry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 p-6 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{industry.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{industry.desc}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-[#53B289]/10 p-8 rounded-2xl border border-[#53B289]/20">
        <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Auckland CBD Success Story</h3>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Challenge:</strong> A growing law firm on Queen Street was experiencing frequent network outages and slow internet speeds that were impacting client service and productivity. Their old IT setup couldn't handle their expanding team or increasing file sizes.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Solution:</strong> Comsys IT implemented a complete network overhaul including business fibre internet, upgraded networking equipment, cloud-based file sharing, and 24/7 monitoring. We also installed a VoIP phone system to improve client communications.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed">
          <strong>Result:</strong> The firm experienced 99.9% uptime over the next 12 months, increased productivity by 40%, and improved client satisfaction scores. They can now handle larger cases and have expanded their team without IT limitations.
        </p>
      </div>
    </div>
  </section>
);

const LocationSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Auckland CBD Service Area & Location
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Prime Auckland CBD Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our Auckland IT team provides comprehensive coverage throughout the entire Auckland CBD, from the waterfront precinct to the upper Queen Street area. We service businesses in all major CBD locations including Commercial Bay, Britomart, Viaduct Harbour, Wynyard Quarter, and the traditional business district around Queen Street and surrounding areas.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              With our strategic location and local knowledge, we can reach any Auckland CBD business within 15 minutes for emergency support. Our technicians are familiar with building access procedures, parking arrangements, and the unique infrastructure challenges present in different areas of the CBD.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Our Auckland Office
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p>26 Bancroft Crescent, Glendene</p>
              <p>Auckland 0602, New Zealand</p>
              <p className="flex items-center">
                <Phone className="w-4 h-4 mr-2 text-[#53B289]" />
                09 242 3700
              </p>
              <p className="text-sm mt-3">
                <strong>Emergency Support:</strong> Available 24/7 for critical issues affecting your Auckland CBD business operations.
              </p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25608.354815557194!2d174.74374167639161!3d-36.84846494822049!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47e5f4a3a3a3%3A0x500ef6143a29903!2sAuckland%20CBD%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Auckland CBD IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our Auckland IT team provides fast onsite support throughout the Auckland CBD and surrounding areas.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "How quickly can you respond to IT emergencies in Auckland CBD?",
      a: "We guarantee a 15-minute response time for critical IT emergencies in the Auckland CBD during business hours. Our local technicians are strategically positioned to reach any CBD location quickly. For after-hours emergencies, we provide 24/7 remote support and can be onsite within 1 hour for critical issues that cannot be resolved remotely."
    },
    {
      q: "Do you provide onsite IT support for small CBD businesses?",
      a: "Absolutely! We provide onsite IT support for businesses of all sizes in the Auckland CBD, from single-person startups to large corporate offices. Our flexible service options include both scheduled maintenance visits and on-demand support calls. We understand that small businesses need cost-effective solutions, which is why we offer affordable monthly support packages tailored to your specific needs."
    },
    {
      q: "Can you help with building access and parking in the CBD?",
      a: "Yes, our technicians are experienced with Auckland CBD building procedures and access requirements. We can coordinate with building management for access cards, understand parking restrictions and options, and work efficiently within the constraints of CBD locations. We're familiar with most major CBD buildings and their specific requirements."
    },
    {
      q: "What makes your IT support different from other Auckland providers?",
      a: "Our key differentiators include: local Auckland-based team with CBD expertise, 15-minute emergency response times, transparent fixed-price support packages, proactive monitoring to prevent issues, and personalized service where you deal with the same technicians who understand your business. We focus exclusively on the Auckland market, which allows us to provide superior local service."
    },
    {
      q: "Do you support businesses with remote workers and flexible office arrangements?",
      a: "Yes, we specialize in hybrid work environments that are common in Auckland CBD businesses. We can set up secure VPN access, cloud-based applications, mobile device management, and ensure your team can work seamlessly whether they're in your CBD office, at home, or meeting clients around Auckland. Our solutions support the modern flexible workplace."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Transform Your Auckland CBD Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let IT issues slow you down. Contact Comsys IT today for a free, no-obligation consultation and discover how our rapid, reliable support can benefit your CBD business.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=AucklandCBDITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportAucklandCBD() {
  const pageUrl = "https://www.comsys.co.nz/it-support-auckland-cbd";
  const title = "IT Support Auckland CBD | Comsys IT - 15min Response";
  const description = "Professional IT support for Auckland CBD businesses. 15-minute response times, VoIP, CCTV, business fibre & data backup. Local experts serving Queen St, Commercial Bay & CBD.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT support services for Auckland CBD businesses",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Auckland CBD"
      },
      "serviceType": [
        "IT Support", "VoIP Solutions", "CCTV Systems", "Business Fibre", "Data Backup"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Auckland CBD, Auckland, New Zealand"
      },
      "description": description
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How quickly can you respond to IT emergencies in Auckland CBD?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We guarantee a 15-minute response time for critical IT emergencies in the Auckland CBD during business hours. Our local technicians are strategically positioned to reach any CBD location quickly."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide onsite IT support for small CBD businesses?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We provide onsite IT support for businesses of all sizes in the Auckland CBD, from single-person startups to large corporate offices."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Auckland CBD, Queen Street IT services, Commercial Bay IT support, Auckland CBD business IT, VoIP Auckland CBD, CCTV Auckland CBD"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <IndustriesSection />
      <LocationSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
