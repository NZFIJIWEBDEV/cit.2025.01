import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, HardHat, Wifi, Phone, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Construction Companies in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support and communications for Auckland construction companies. Comsys IT provides rugged IT, VoIP, and project connectivity.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ConstructionIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Construction IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Challenges in Construction
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600&h=400&fit=crop" 
            alt="Construction IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Connecting Construction Sites</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Construction projects require reliable communication between sites, offices, and teams. 
              Harsh environments and temporary locations create unique IT challenges.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Wifi, title: "Site Connectivity", desc: "Reliable internet access at remote construction sites for project management and communication." },
              { icon: Phone, title: "Mobile Communications", desc: "VoIP systems that work on-site and connect field teams with office staff." },
              { icon: HardHat, title: "Rugged Equipment", desc: "IT hardware that can withstand dust, moisture, and harsh construction environments." },
              { icon: Shield, title: "Data Security", desc: "Protecting sensitive project data, plans, and client information from cyber threats." }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const OnsiteSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Mobile & Onsite IT Support
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">IT Support Where You Need It</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We provide onsite IT support at construction sites and mobile solutions that keep your teams 
              connected and productive, whether they're in the office or on-site.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "Onsite IT setup and support at construction sites.",
              "Mobile hotspots and portable WiFi solutions.",
              "Rugged tablets and laptops for field use.",
              "Project management software setup and training.",
              "Integration with construction management tools.",
              "Secure remote access to office systems from sites."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&h=400&fit=crop" 
            alt="Construction Site IT Support Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const VoIPSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        VoIP for Project Teams
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Seamless Communication Between Sites</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our VoIP solutions keep your construction teams connected across multiple sites, 
            enabling instant communication between field teams, project managers, and office staff.
          </p>
          {[
            "Mobile VoIP apps for smartphones and tablets.",
            "Rugged desk phones for site offices and trailers.",
            "Conference calling for project meetings.",
            "Integration with project management software.",
            "Call forwarding between office and sites."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Construction VoIP Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Cost Savings</h5>
              <p className="text-sm text-[#3A4E62]/80">Reduce phone bills by up to 60% with VoIP technology.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Mobility</h5>
              <p className="text-sm text-[#3A4E62]/80">Take your office number anywhere with mobile apps.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Professional Image</h5>
              <p className="text-sm text-[#3A4E62]/80">Maintain a professional presence even from construction sites.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Builds Success</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our construction IT solutions are designed to improve project efficiency, 
            enhance communication, and ensure your teams stay connected no matter where they are.
          </p>
          {[
            "Improved project communication and coordination.",
            "Faster decision-making with real-time data access.",
            "Reduced project delays due to communication issues.",
            "Enhanced data security for sensitive project information.",
            "Professional image with reliable communications."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT set up reliable WiFi and VoIP across all our construction sites. Communication between our site managers and office has never been better. Their rugged equipment handles the tough conditions perfectly, and their support team understands our industry."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <HardHat className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Steve Thompson</div>
              <div className="text-sm text-[#3A4E62]/70">Project Manager, Auckland Construction Ltd</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide onsite IT at construction sites?",
            answer: "Yes, we provide comprehensive onsite IT support at construction sites. This includes setting up temporary network infrastructure, installing rugged equipment, and providing ongoing technical support to keep your teams connected and productive throughout the project lifecycle."
          },
          {
            question: "Can you integrate project management tools?",
            answer: "Absolutely. We can integrate and provide support for popular construction project management platforms such as Procore, Buildertrend, and PlanGrid. We ensure seamless data flow between your office systems and field operations for better project coordination."
          },
          {
            question: "Do you offer rugged WiFi setups?",
            answer: "Yes, we specialize in rugged WiFi solutions designed for harsh construction environments. Our equipment is weatherproof, dust-resistant, and can handle the demands of active construction sites while providing reliable internet connectivity for your teams and equipment."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesConstruction() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Construction Companies in Auckland",
      "description": "IT support and communications for Auckland construction companies. Comsys IT provides rugged IT, VoIP, and project connectivity.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Construction IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you provide onsite IT at construction sites?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive onsite IT support at construction sites. This includes setting up temporary network infrastructure, installing rugged equipment, and providing ongoing technical support to keep your teams connected and productive throughout the project lifecycle." }
        },
        {
          "@type": "Question", "name": "Can you integrate project management tools?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We can integrate and provide support for popular construction project management platforms such as Procore, Buildertrend, and PlanGrid. We ensure seamless data flow between your office systems and field operations for better project coordination." }
        },
        {
          "@type": "Question", "name": "Do you offer rugged WiFi setups?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we specialize in rugged WiFi solutions designed for harsh construction environments. Our equipment is weatherproof, dust-resistant, and can handle the demands of active construction sites while providing reliable internet connectivity for your teams and equipment." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Construction Companies in Auckland", "item": "https://www.comsys.co.nz/IndustriesConstruction" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Construction Companies Auckland | Comsys IT"
        description="IT support and communications for Auckland construction companies. Comsys IT provides rugged IT, VoIP, and project connectivity."
        keywords="construction IT support Auckland, construction site connectivity, project management IT, rugged IT equipment"
        canonical="https://www.comsys.co.nz/IndustriesConstruction"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <OnsiteSection />
      <VoIPSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}