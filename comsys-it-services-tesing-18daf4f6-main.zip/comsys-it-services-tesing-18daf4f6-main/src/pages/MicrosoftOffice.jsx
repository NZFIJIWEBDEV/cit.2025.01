import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Users, Cloud, Shield, MessageSquare, FileText, Mail, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Microsoft 365 Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Comsys IT provides setup, licensing, and support for Microsoft 365. Boost productivity with Word, Excel, Teams, and Outlook.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=Microsoft365")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Microsoft 365 Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyMicrosoft365Section = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Microsoft 365
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1553877522-43269d4ea984?w=600&h=400&fit=crop" 
            alt="Microsoft 365 Auckland Business"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Productivity Suite</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Microsoft 365 provides everything your Auckland business needs to stay productive, collaborative, 
              and secure. Access your files and applications from anywhere, on any device.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { 
                icon: FileText, 
                title: "Office Applications", 
                desc: "Word, Excel, PowerPoint, and more with always up-to-date features"
              },
              { 
                icon: Cloud, 
                title: "Cloud Storage", 
                desc: "1TB OneDrive storage per user with automatic sync and backup"
              },
              { 
                icon: MessageSquare, 
                title: "Microsoft Teams", 
                desc: "Video conferencing, chat, and collaboration in one platform"
              },
              { 
                icon: Mail, 
                title: "Professional Email", 
                desc: "50GB Outlook mailbox with your custom domain name"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-[#3A4E62] mb-2">{feature.title}</h4>
                  <p className="text-[#3A4E62]/80">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Microsoft 365 ROI for Businesses:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• 25% increase in productivity from anywhere access</li>
              <li>• 50% reduction in IT infrastructure costs</li>
              <li>• 40% faster document collaboration</li>
              <li>• 99.9% uptime guarantee from Microsoft</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SetupLicensingSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Setup & Licensing
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Microsoft 365 Business Basic",
            price: "$8.20/user/month",
            desc: "Essential cloud services for small businesses",
            features: [
              "Web versions of Office apps",
              "1TB OneDrive storage",
              "Microsoft Teams",
              "Exchange email (50GB)",
              "SharePoint and Forms"
            ],
            popular: false
          },
          {
            title: "Microsoft 365 Business Standard",
            price: "$16.40/user/month",
            desc: "Full Office apps plus cloud services",
            features: [
              "Desktop Office applications",
              "Web and mobile Office apps",
              "1TB OneDrive storage",
              "Microsoft Teams with recording",
              "Exchange email (50GB)",
              "SharePoint and Forms",
              "Bookings and Lists"
            ],
            popular: true
          },
          {
            title: "Microsoft 365 Business Premium",
            price: "$28.70/user/month",
            desc: "Complete solution with advanced security",
            features: [
              "Everything in Business Standard",
              "Advanced security features",
              "Microsoft Defender",
              "Intune device management",
              "Azure Information Protection",
              "Advanced compliance tools"
            ],
            popular: false
          }
        ].map((plan, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className={`bg-white rounded-xl p-8 shadow-lg ${plan.popular ? 'ring-2 ring-[#53B289] transform scale-105' : ''} relative`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-[#53B289] text-white px-4 py-2 rounded-full text-sm font-semibold">
                  Most Popular
                </span>
              </div>
            )}
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{plan.title}</h3>
              <div className="text-3xl font-bold text-[#53B289] mb-2">{plan.price}</div>
              <p className="text-[#3A4E62]/80">{plan.desc}</p>
            </div>
            <ul className="space-y-3 mb-8">
              {plan.features.map((feature, fIndex) => (
                <li key={fIndex} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-[#3A4E62]/80">{feature}</span>
                </li>
              ))}
            </ul>
            <Link to={createPageUrl(`ContactUs?subject=${plan.title.replace(/\s+/g, '')}`)}>
              <Button className={`w-full ${plan.popular ? 'bg-[#53B289] hover:bg-[#4aa07b]' : 'bg-[#3A4E62] hover:bg-[#2a3749]'} text-white`}>
                Get Started
              </Button>
            </Link>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Professional Setup & Migration Service</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-6">
            Don't worry about the technical details. Our certified Microsoft 365 specialists handle everything from initial setup 
            to data migration, ensuring a smooth transition with zero downtime.
          </p>
          <div className="grid md:grid-cols-2 gap-6 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-3">Migration Services:</h4>
              <ul className="space-y-2">
                {[
                  "Email migration from any provider",
                  "File and document migration",
                  "User account setup and permissions",
                  "Domain configuration and DNS setup"
                ].map((service, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                    <span className="text-[#3A4E62]/80">{service}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-3">Ongoing Support:</h4>
              <ul className="space-y-2">
                {[
                  "User training and onboarding",
                  "Security configuration and monitoring",
                  "License management and optimization",
                  "24/7 technical support"
                ].map((support, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                    <span className="text-[#3A4E62]/80">{support}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const TeamsCollaborationSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Teams & Collaboration Tools
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Microsoft Teams: Your Digital Workplace</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Microsoft Teams brings your entire workforce together, whether they're in the office, working from home, 
              or on the go. Create a connected, productive workplace that works for everyone.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Teams Features:</h4>
            {[
              {
                title: "Video Meetings & Webinars",
                desc: "HD video calls for up to 1,000 participants with meeting recording"
              },
              {
                title: "Chat & Instant Messaging",
                desc: "Persistent chat channels organized by teams, projects, or topics"
              },
              {
                title: "File Sharing & Co-authoring",
                desc: "Real-time collaboration on documents with version control"
              },
              {
                title: "App Integration",
                desc: "Integrate with 700+ business applications and custom workflows"
              },
              {
                title: "Phone System Integration",
                desc: "Replace your traditional phone system with Teams calling"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-[#3A4E62] mb-2">{feature.title}</h5>
                <p className="text-sm text-[#3A4E62]/80">{feature.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-green-800 mb-3">Teams Success Stories:</h4>
            <ul className="space-y-2 text-green-700">
              <li>• 250% increase in remote collaboration efficiency</li>
              <li>• 60% reduction in email volume</li>
              <li>• 45% faster project completion times</li>
              <li>• 80% of employees report improved work satisfaction</li>
            </ul>
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&h=400&fit=crop" 
            alt="Microsoft Teams Collaboration Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const OngoingSupportSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Ongoing Support
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Microsoft 365 Managed Services</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Get the most out of your Microsoft 365 investment with our comprehensive managed services. 
              We handle the technical complexities so you can focus on your business.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">What We Manage:</h4>
            {[
              "License optimization and cost management",
              "Security monitoring and threat protection",
              "User onboarding and offboarding",
              "Email and collaboration setup",
              "Data backup and recovery planning",
              "Compliance and governance policies",
              "Performance monitoring and optimization",
              "24/7 proactive support and maintenance"
            ].map((service, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{service}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Training & User Adoption</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Technology is only as good as how well your team uses it. We provide comprehensive training 
              and support to ensure high user adoption and maximum productivity gains.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Training Services:</h4>
            {[
              "Initial user onboarding sessions",
              "Advanced feature training workshops",
              "Custom training materials and guides",
              "One-on-one executive coaching",
              "Teams and collaboration best practices",
              "Security awareness training",
              "Ongoing user support and Q&A sessions",
              "Change management consulting"
            ].map((training, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Users className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{training}</span>
              </div>
            ))}
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-[#3A4E62] mb-3">Training Success Metrics:</h4>
            <div className="grid md:grid-cols-2 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-[#53B289]">95%</div>
                <div className="text-sm text-[#3A4E62]/80">User Adoption Rate</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[#53B289]">40%</div>
                <div className="text-sm text-[#3A4E62]/80">Productivity Increase</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you migrate emails to Office 365?",
            answer: "Yes, we provide complete email migration services from any email provider including Gmail, Yahoo, Exchange, or other hosting providers. We use professional migration tools to ensure zero data loss and minimal downtime during the transition. The process typically takes 1-3 days depending on mailbox size."
          },
          {
            question: "Do you provide Teams training?",
            answer: "Absolutely! We offer comprehensive Microsoft Teams training including initial setup, basic functionality, advanced features, and best practices for collaboration. Training can be delivered on-site, remotely, or through a hybrid approach. We also provide ongoing support and refresher training as needed."
          },
          {
            question: "What license plans are available?",
            answer: "We offer all Microsoft 365 business plans including Business Basic ($8.20/month), Business Standard ($16.40/month), and Business Premium ($28.70/month) per user. We also provide Enterprise plans for larger organizations. We'll help you choose the right plan based on your specific needs and budget."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function MicrosoftOffice() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Microsoft 365 Services",
      "name": "Microsoft Office 365 Solutions Auckland",
      "description": "Comsys IT provides setup, licensing, and support for Microsoft 365. Boost productivity with Word, Excel, Teams, and Outlook.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you migrate emails to Office 365?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide complete email migration services from any email provider including Gmail, Yahoo, Exchange, or other hosting providers. We use professional migration tools to ensure zero data loss and minimal downtime during the transition. The process typically takes 1-3 days depending on mailbox size."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide Teams training?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We offer comprehensive Microsoft Teams training including initial setup, basic functionality, advanced features, and best practices for collaboration. Training can be delivered on-site, remotely, or through a hybrid approach. We also provide ongoing support and refresher training as needed."
          }
        },
        {
          "@type": "Question",
          "name": "What license plans are available?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We offer all Microsoft 365 business plans including Business Basic ($8.20/month), Business Standard ($16.40/month), and Business Premium ($28.70/month) per user. We also provide Enterprise plans for larger organizations. We'll help you choose the right plan based on your specific needs and budget."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Microsoft Office 365 Solutions Auckland",
          "item": "https://www.comsys.co.nz/MicrosoftOffice"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="Microsoft Office 365 Solutions | Comsys IT Auckland"
        description="Comsys IT provides setup, licensing, and support for Microsoft 365. Boost productivity with Word, Excel, Teams, and Outlook."
        keywords="Microsoft 365 Auckland, Office 365 setup, Teams training, email migration, cloud productivity"
        canonical="https://www.comsys.co.nz/MicrosoftOffice"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyMicrosoft365Section />
      <SetupLicensingSection />
      <TeamsCollaborationSection />
      <OngoingSupportSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Transform Your Business with Microsoft 365?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free consultation and discover how Microsoft 365 can boost your team's productivity and collaboration.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=Microsoft365Setup")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Microsoft 365 Consultation
              </Button>
            </Link>
            <Link to="https://www.microsoft.com/en-nz/microsoft-365" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn More About Microsoft 365 <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}