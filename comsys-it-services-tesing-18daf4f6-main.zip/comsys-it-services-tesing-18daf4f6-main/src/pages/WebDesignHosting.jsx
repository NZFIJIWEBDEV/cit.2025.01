import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Globe, Palette, Shield, Zap, Smartphone, Search, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Web Design & Hosting Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Comsys IT creates professional websites and provides fast, secure hosting for Auckland businesses.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=WebDesign")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Website Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WebsiteDesignSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Website Design
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Professional Website Design</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Your website is often the first impression customers have of your Auckland business. 
              We create stunning, professional websites that convert visitors into customers and grow your business online.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Design Features:</h4>
            {[
              {
                icon: Palette,
                title: "Custom Design",
                desc: "Unique, branded designs tailored to your business and industry"
              },
              {
                icon: Smartphone,
                title: "Mobile Responsive",
                desc: "Perfect display on all devices - desktop, tablet, and mobile"
              },
              {
                icon: Search,
                title: "SEO Optimized",
                desc: "Built-in search engine optimization to help customers find you"
              },
              {
                icon: Zap,
                title: "Fast Loading",
                desc: "Optimized for speed to keep visitors engaged and improve rankings"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h5 className="font-semibold text-[#3A4E62] mb-2">{feature.title}</h5>
                  <p className="text-sm text-[#3A4E62]/80">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-[#3A4E62] mb-3">Website Types We Create:</h4>
            <div className="grid md:grid-cols-2 gap-2 text-sm text-[#3A4E62]/80">
              <div>• Business Websites</div>
              <div>• E-commerce Stores</div>
              <div>• Portfolio Websites</div>
              <div>• Service Directories</div>
              <div>• Booking Systems</div>
              <div>• Corporate Sites</div>
            </div>
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=600&h=400&fit=crop" 
            alt="Website Design Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const HostingSecuritySection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Hosting & Security
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&h=400&fit=crop" 
            alt="Web Hosting Security Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Fast, Secure, Reliable Hosting</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Your website needs a solid foundation. Our premium hosting infrastructure ensures your site is always 
              fast, secure, and available when your customers need it.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Hosting Features:</h4>
            {[
              {
                title: "99.9% Uptime Guarantee",
                desc: "Reliable hosting with minimal downtime and maximum availability"
              },
              {
                title: "SSL Security Certificates",
                desc: "Free SSL certificates to encrypt data and build customer trust"
              },
              {
                title: "Daily Backups",
                desc: "Automatic daily backups with easy restore options for peace of mind"
              },
              {
                title: "CDN & Speed Optimization",
                desc: "Content delivery network for lightning-fast loading worldwide"
              },
              {
                title: "24/7 Security Monitoring",
                desc: "Continuous monitoring for threats with automatic protection"
              },
              {
                title: "Regular Updates & Patches",
                desc: "Automatic security updates and software patches applied"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
                <h5 className="font-semibold text-[#3A4E62] mb-2">{feature.title}</h5>
                <p className="text-sm text-[#3A4E62]/80">{feature.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-green-800 mb-3">Hosting Performance Stats:</h4>
            <div className="grid md:grid-cols-2 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-600">99.98%</div>
                <div className="text-sm text-green-700">Average Uptime</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">&lt;2s</div>
                <div className="text-sm text-green-700">Page Load Time</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const OngoingMaintenanceSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Ongoing Maintenance
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Content Updates",
            icon: "📝",
            desc: "Regular content updates, new pages, and information changes",
            includes: [
              "Text and image updates",
              "New page creation",
              "Menu and navigation changes",
              "Blog post publishing",
              "Product catalog updates"
            ]
          },
          {
            title: "Security & Updates",
            icon: "🔒",
            desc: "Proactive security monitoring and software updates",
            includes: [
              "Security plugin updates",
              "Core software patches",
              "Malware scanning & removal",
              "Firewall configuration",
              "SSL certificate management"
            ]
          },
          {
            title: "Performance Optimization",
            icon: "⚡",
            desc: "Ongoing optimization for speed and search rankings",
            includes: [
              "Speed optimization",
              "SEO improvements",
              "Image compression",
              "Cache management",
              "Mobile optimization"
            ]
          }
        ].map((service, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8 text-center"
          >
            <div className="text-4xl mb-4">{service.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{service.title}</h3>
            <p className="text-[#3A4E62]/80 mb-6">{service.desc}</p>
            <ul className="space-y-2 text-left">
              {service.includes.map((item, iIndex) => (
                <li key={iIndex} className="flex items-start space-x-2 text-sm">
                  <CheckCircle className="w-4 h-4 text-[#53B289] flex-shrink-0 mt-0.5" />
                  <span className="text-[#3A4E62]/80">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Website Maintenance Plans</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-6">
            Keep your website secure, updated, and performing optimally with our maintenance plans. 
            Choose from basic security updates to full content management services.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { plan: "Basic", price: "$89/month", desc: "Security & updates only" },
              { plan: "Standard", price: "$189/month", desc: "Security, updates & content changes" },
              { plan: "Premium", price: "$289/month", desc: "Full management & optimization" }
            ].map((plan, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <h4 className="font-bold text-[#3A4E62] mb-2">{plan.plan}</h4>
                <div className="text-2xl font-bold text-[#53B289] mb-2">{plan.price}</div>
                <p className="text-sm text-[#3A4E62]/80">{plan.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const WhyChooseComsysSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Local Auckland Web Design Experts</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              As a local Auckland company, we understand the New Zealand market and can create websites 
              that resonate with your target audience and comply with local requirements.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Our Advantages:</h4>
            {[
              "Local market knowledge and cultural understanding",
              "New Zealand domain registration and hosting",
              "GDPR and NZ Privacy Act compliance built-in",
              "Local search optimization for Auckland businesses",
              "Same-day support during NZ business hours",
              "Integration with local payment systems and services",
              "Understanding of NZ consumer behavior and preferences",
              "Compliance with NZ accessibility standards"
            ].map((advantage, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{advantage}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Digital Solution</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Beyond just web design, we provide complete digital solutions including IT support, 
              ensuring your website and technology work seamlessly together.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Complete Service Package:</h4>
            {[
              "Web design, hosting, and maintenance in one package",
              "IT support for your business technology needs",
              "Email setup and Microsoft 365 integration",
              "Domain management and DNS configuration",
              "Backup and security services for peace of mind",
              "Training and support for content management",
              "Analytics and performance reporting",
              "Ongoing consultation and digital strategy advice"
            ].map((service, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Globe className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{service}</span>
              </div>
            ))}
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Client Success Stories:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• 40% increase in online inquiries within 3 months</li>
              <li>• 60% improvement in website loading speed</li>
              <li>• 100% client satisfaction with our web services</li>
              <li>• 85% of clients return for additional services</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you design e-commerce sites?",
            answer: "Yes, we specialize in e-commerce website design and development. We can create online stores using platforms like WooCommerce, Shopify, or custom solutions. This includes product catalogs, shopping carts, payment gateway integration, inventory management, and order processing systems tailored to New Zealand businesses."
          },
          {
            question: "Do you provide domains?",
            answer: "Absolutely! We handle complete domain registration and management including .co.nz, .nz, .com, and other extensions. We also manage DNS settings, domain renewals, and can transfer existing domains. Our domain services are integrated with our hosting packages for seamless management."
          },
          {
            question: "Can I upgrade hosting later?",
            answer: "Yes, our hosting plans are fully scalable. You can easily upgrade your hosting package as your website grows and requires more resources. We offer seamless migrations between plans with no downtime, and our team handles all technical aspects of the upgrade process."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function WebDesignHosting() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Web Design",
      "name": "Web Design & Hosting Auckland",
      "description": "Comsys IT creates professional websites and provides fast, secure hosting for Auckland businesses.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you design e-commerce sites?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in e-commerce website design and development. We can create online stores using platforms like WooCommerce, Shopify, or custom solutions. This includes product catalogs, shopping carts, payment gateway integration, inventory management, and order processing systems tailored to New Zealand businesses."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide domains?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We handle complete domain registration and management including .co.nz, .nz, .com, and other extensions. We also manage DNS settings, domain renewals, and can transfer existing domains. Our domain services are integrated with our hosting packages for seamless management."
          }
        },
        {
          "@type": "Question",
          "name": "Can I upgrade hosting later?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, our hosting plans are fully scalable. You can easily upgrade your hosting package as your website grows and requires more resources. We offer seamless migrations between plans with no downtime, and our team handles all technical aspects of the upgrade process."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Web Design & Hosting Auckland",
          "item": "https://www.comsys.co.nz/WebDesignHosting"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="Web Design & Hosting Auckland | Comsys IT"
        description="Comsys IT creates professional websites and provides fast, secure hosting for Auckland businesses."
        keywords="web design Auckland, website hosting, e-commerce websites, responsive design, SEO optimization"
        canonical="https://www.comsys.co.nz/WebDesignHosting"
        schemas={schemas}
      />
      
      <PageHero />
      <WebsiteDesignSection />
      <HostingSecuritySection />
      <OngoingMaintenanceSection />
      <WhyChooseComsysSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Launch Your Professional Website?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a custom website that grows your business with professional design, reliable hosting, and ongoing support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=WebsiteProject")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Website Quote
              </Button>
            </Link>
            <Link to="https://wordpress.org" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Website Examples <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}