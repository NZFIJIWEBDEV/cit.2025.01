import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Factory, Shield, Database, Wifi } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Manufacturing in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT services for Auckland manufacturing companies. Comsys IT provides reliable network infrastructure, cybersecurity, and system support for factories and production facilities.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ManufacturingIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Manufacturing IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Manufacturing Companies
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1581092921462-2375373a8e99?w=600&h=400&fit=crop" 
            alt="Manufacturing IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Keeping Production Lines Running</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Manufacturing relies on a complex chain of technology, from production machinery and ERP systems 
              to supply chain management. Downtime is not an option when production targets need to be met.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Factory, title: "Production Line Uptime", desc: "Ensuring network connectivity and system support for production machinery and control systems." },
              { icon: Database, title: "ERP & Inventory Systems", desc: "Supporting Enterprise Resource Planning and inventory management software to track resources and output." },
              { icon: Shield, title: "Operational Technology (OT) Security", desc: "Protecting industrial control systems and production networks from cyber threats." },
              { icon: Wifi, title: "Factory Floor Connectivity", desc: "Providing reliable WiFi and network infrastructure across large production facilities." }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const NetworkSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Network Infrastructure & OT Security
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">A Foundation for Production</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We build and maintain robust network infrastructure that provides the reliable connectivity your 
              production environment demands, while securing your Operational Technology (OT) from cyber threats.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "High-availability network design to minimize downtime.",
              "Factory-wide WiFi solutions for scanners, tablets, and machinery.",
              "Network segmentation to isolate production systems from business networks.",
              "Security for Industrial Control Systems (ICS) and SCADA.",
              "24/7 network monitoring and proactive support.",
              "Secure remote access for equipment monitoring and maintenance."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1611095965923-b98945b9a463?w=600&h=400&fit=crop" 
            alt="Manufacturing Network Security Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const ERPSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        ERP & System Support
      </h2>
       <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Integrating Your Operations</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            We provide IT support for the critical software that runs your manufacturing business, from ERPs 
            and inventory management to supply chain and quality control systems.
          </p>
          {[
            "Support for cloud-based and on-premise ERP systems.",
            "Database management and performance tuning.",
            "Integration between ERP, CRM, and production floor systems.",
            "Data backup and disaster recovery for critical business systems.",
            "Troubleshooting and support for end-users."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
            <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Supported Platforms Include:</h4>
            <div className="grid grid-cols-2 gap-4">
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">MYOB Advanced</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">SAP Business One</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">NetSuite</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">and custom systems...</span>
            </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Manufacturing Companies
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Boosts Production</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our manufacturing IT solutions are designed to maximize uptime, improve operational visibility, 
            and secure your production environment against costly disruptions.
          </p>
          {[
            "Increased production uptime with reliable network infrastructure.",
            "Improved data visibility for better decision-making.",
            "Enhanced security for intellectual property and operational technology.",
            "Reduced risk of production stoppages due to IT failures.",
            "Streamlined operations with integrated business systems."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT implemented a new, reliable network across our factory floor. The connectivity for our machinery has been flawless, and we've seen a significant reduction in production interruptions. Their understanding of OT security gave us peace of mind."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Factory className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">John Davis</div>
              <div className="text-sm text-[#3A4E62]/70">Operations Manager, Auckland Manufacturing Co.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support factory floor machinery and networks?",
            answer: "Yes, we specialize in providing robust network infrastructure for factory floors, including reliable WiFi for scanners and machinery, and wired connections for critical equipment. We ensure your production line has the stable connectivity it needs to operate without interruption."
          },
          {
            question: "How do you secure Operational Technology (OT) and Industrial Control Systems (ICS)?",
            answer: "We implement specific security measures for OT environments, such as network segmentation to isolate your production network from your business IT network. We also manage firewalls and implement access controls to protect your sensitive industrial control systems from cyber threats."
          },
          {
            question: "Can you provide support for our ERP system?",
            answer: "Yes, we provide comprehensive support for various Enterprise Resource Planning (ERP) systems, whether they are cloud-based or on-premise. This includes system maintenance, database management, user support, and ensuring seamless integration with your other business and production systems."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesManufacturing() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Manufacturing in Auckland",
      "description": "IT services for Auckland manufacturing companies. Comsys IT provides reliable network infrastructure, cybersecurity, and system support for factories and production facilities.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Manufacturing IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support factory floor machinery and networks?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we specialize in providing robust network infrastructure for factory floors, including reliable WiFi for scanners and machinery, and wired connections for critical equipment. We ensure your production line has the stable connectivity it needs to operate without interruption." }
        },
        {
          "@type": "Question", "name": "How do you secure Operational Technology (OT) and Industrial Control Systems (ICS)?",
          "acceptedAnswer": { "@type": "Answer", "text": "We implement specific security measures for OT environments, such as network segmentation to isolate your production network from your business IT network. We also manage firewalls and implement access controls to protect your sensitive industrial control systems from cyber threats." }
        },
        {
          "@type": "Question", "name": "Can you provide support for our ERP system?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive support for various Enterprise Resource Planning (ERP) systems, whether they are cloud-based or on-premise. This includes system maintenance, database management, user support, and ensuring seamless integration with your other business and production systems." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Manufacturing in Auckland", "item": "https://www.comsys.co.nz/IndustriesManufacturing" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Manufacturing in Auckland | Comsys IT"
        description="IT services for Auckland manufacturing companies. Comsys IT provides reliable network infrastructure, cybersecurity, and system support for factories and production facilities."
        keywords="manufacturing IT support Auckland, factory IT services, OT security, ERP support, industrial networking"
        canonical="https://www.comsys.co.nz/IndustriesManufacturing"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <NetworkSection />
      <ERPSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}