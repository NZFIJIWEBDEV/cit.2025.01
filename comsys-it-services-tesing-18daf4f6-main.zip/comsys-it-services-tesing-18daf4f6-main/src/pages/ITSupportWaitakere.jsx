
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, Truck } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Waitākere businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Comprehensive IT Support for Waitākere
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        From the industrial hubs of Henderson to the growing residential areas, businesses across the Waitākere Ranges need a reliable and versatile IT partner. Comsys IT provides robust, expert support for the diverse range of industries throughout West Auckland.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=WaitakereITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Waitākere Businesses Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            title: "True West Auckland Locals",
            desc: "Our team is based in and services all of West Auckland, providing genuine local knowledge and fast response times across Waitākere.",
            icon: Users
          },
          {
            title: "Versatile Industry Support",
            desc: "Expertise supporting the diverse mix of industrial, commercial, and residential businesses throughout the Waitākere area.",
            icon: Building
          },
          {
            title: "Reliable Connectivity Solutions",
            desc: "Specialists in providing robust fibre and network solutions, even in the more remote parts of the Waitākere Ranges.",
            icon: Wifi
          },
          {
            title: "Scalable for Growth",
            desc: "Our IT services are designed to grow with your Waitākere business, from a small home office to a large industrial site.",
            icon: CheckCircle
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    {
      icon: Truck,
      title: "IT for Industrial & Commercial",
      desc: "We provide robust IT solutions for Waitākere's commercial and industrial sectors, including reliable network infrastructure, data backup, and cybersecurity to prevent operational disruption.",
      link: "IndustriesManufacturing",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Users,
      title: "Managed IT for Small Businesses",
      desc: "Our managed IT plans are perfect for small businesses across Waitākere. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Shield,
      title: "Data Security & Backup",
      desc: "Protect your valuable business data with our robust data backup and cybersecurity solutions, designed to keep your Waitākere business secure and operational.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Waitākere Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Waitākere businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Proudly Serving All of Waitākere
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Your Local West Auckland IT Partner</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             Comsys IT's service area covers the entire Waitākere district. From the commercial centres of Henderson and New Lynn to the suburbs of Glen Eden, Titirangi, and Massey, and out to the rural areas of the Waitākere Ranges, our team is equipped and ready to provide expert IT support.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our deep understanding of West Auckland's geography and business landscape means we can provide relevant, effective, and timely IT solutions for any business located within Waitākere.
            </p>
          </div>

          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Fast local response across West Auckland</p>
              <p><strong>Coverage:</strong> Henderson, New Lynn, Glen Eden, Titirangi, Massey, and entire Waitākere region</p>
              <p><strong>Support:</strong> Onsite, Remote, and Managed IT Services</p>
              <p><strong>Specialization:</strong> Industrial, Commercial, and Home Business IT</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d102140.7932085741!2d174.4938927972656!3d-36.8778848!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d6ce985ab8231%3A0x879784da63841103!2sWaitakere%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695862145892!5m2!1sen!2snz"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Waitākere Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Comsys IT offers comprehensive support across the entire Waitākere district.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My business is located in a more rural part of Waitākere. Can you still provide reliable internet and support?",
      a: "Yes. We specialize in providing connectivity solutions for businesses outside the main urban fibre areas. We can assess your location and recommend the best rural broadband, satellite, or fixed wireless options to ensure you have a stable and fast connection. Our remote support tools allow us to resolve most issues without needing a site visit, but we are always ready to travel onsite anywhere in Waitākere when required."
    },
    {
      q: "We are a manufacturing business in Henderson. Do you have experience with industrial IT?",
      a: "Absolutely. We have extensive experience supporting industrial and manufacturing clients in the Henderson and wider Waitākere area. We understand the need for rugged hardware, reliable network infrastructure for production systems, and robust security to protect valuable intellectual property and operational data."
    },
    {
      q: "How does your managed IT service benefit a small business in Waitākere?",
      a: "Our managed service gives your small business the advantage of a full team of IT experts for a single, predictable monthly cost. We proactively manage your systems to prevent problems, provide unlimited helpdesk support for your staff, and handle all your security and backup needs. This is far more cost-effective and comprehensive than hiring an in-house IT person or relying on reactive, break-fix support."
    },
    {
      q: "Is your team actually based in West Auckland?",
      a: "Yes, our roots and main operations are in West Auckland. This means we are not just a city-based company extending our reach; we are genuine locals who understand the specific needs, challenges, and character of the Waitākere business community. This local presence ensures faster response times and a better understanding of your context."
    },
    {
      q: "Can you set up a professional IT system for my home office in Waitākere?",
      a: "Yes, providing professional setups for home offices is a core part of our service. We can install business-grade internet, a professional VoIP phone line, secure networking to separate work and personal traffic, and automated data backup to ensure your home-based business is as secure, professional, and efficient as a corporate office."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Waitākere Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=WaitakereITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportWaitakere() {
  const pageUrl = "https://www.comsys.co.nz/it-support-waitakere-auckland";
  const title = "IT Support Waitākere | Expert Business IT Services in West Auckland";
  const description = "Local IT support for Waitākere businesses. Comsys IT offers managed services, cybersecurity, and reliable network solutions for all industries in West Auckland.";
  const keywords = "IT support Waitākere, West Auckland IT services, Henderson IT, industrial IT support, small business IT Waitākere";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Local IT support services for businesses throughout the Waitākere, Auckland region.",
      "url": pageUrl,
      "telephone": "0800724526",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Waitākere, Auckland"
      },
      "serviceType": [
        "IT Support", "Managed IT Services", "Cybersecurity", "Data Backup & Recovery", "Business IT Consulting"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "My business is in a rural part of Waitākere. Can you provide reliable internet?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in providing connectivity solutions for businesses outside main urban fibre areas. We can assess your Waitākere location and recommend the best rural broadband, satellite, or fixed wireless options for a stable, fast connection."
          }
        },
        {
          "@type": "Question",
          "name": "Is your team actually based in West Auckland?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, our main operations are in West Auckland. We are genuine locals who understand the specific needs of the Waitākere business community, ensuring faster response times and relevant solutions."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords={keywords}
        canonical={pageUrl}
        schemas={schemas}
      />

      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      {/* IndustriesSection removed as per outline */}
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
