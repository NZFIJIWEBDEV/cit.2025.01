
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Download, Upload, Shield, Clock, Users, Zap, HelpCircle, MapPin, Star, ArrowRight, Home, Wifi, Gamepad2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import AddressPicker from '../components/broadband/AddressPicker';
import FeatureHighlights from '../components/broadband/FeatureHighlights';
import ContactSection from '../components/sections/Contact';
import SignupModal from '../components/broadband/SignupModal';

const residentialPlans = [
  {
    name: 'Residential 50/10Mb Fibre',
    priceExGST: 56.52,
    priceIncGST: 65.00,
    speed: '50/10 Mbps',
    features: [
      'Residential Only',
      'Unlimited Data',
      'No fixed term contract',
      'Coverage areas only',
      'Perfect for basic browsing',
      'Email and social media'
    ],
    popular: false,
    note: null
  },
  {
    name: 'Residential 300/100Mb Fibre',
    priceExGST: 79,
    priceIncGST: 90.85,
    speed: '300/100 Mbps',
    features: [
      'Residential Only',
      'Unlimited Data',
      'No fixed term contract',
      'Coverage areas only',
      'Great for streaming & gaming',
      'Multiple device support'
    ],
    popular: true,
    note: null
  },
  {
    name: 'Residential Fibre Max',
    priceExGST: 99,
    priceIncGST: 113.85,
    speed: '950/500 Mbps',
    features: [
      'Residential Only',
      'Unlimited Data',
      'No fixed term contract',
      'Coverage areas only',
      'Ultra-fast for large households',
      'Premium streaming & gaming'
    ],
    popular: false,
    note: null
  }
];

const benefits = [
  {
    icon: Home,
    title: 'Perfect for Families',
    description: 'Stream, game, work, and browse simultaneously without any slowdowns'
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Download movies in minutes and enjoy buffer-free 4K streaming'
  },
  {
    icon: Clock,
    title: 'No Contract Lock-in',
    description: 'Flexible plans with no fixed terms - change or cancel anytime'
  },
  {
    icon: MapPin,
    title: 'Reliable Connection',
    description: 'Consistent speeds and reliable performance you can count on'
  }
];

const useCases = [
  {
    title: 'Light Users',
    households: '1-2 people',
    needs: ['Basic browsing', 'Email & social media', 'Standard video calls', 'Light streaming'],
    recommendation: 'Residential 50/10Mb Fibre',
    description: 'Perfect for singles or couples with basic internet needs.'
  },
  {
    title: 'Growing Families',
    households: '3-4 people',
    needs: ['HD streaming', 'Online gaming', 'Multiple devices', 'Work from home'],
    recommendation: 'Residential 300/100Mb Fibre',
    description: 'Ideal for families with teenagers and multiple connected devices.'
  },
  {
    title: 'Power Users',
    households: '4+ people',
    needs: ['4K streaming', 'Serious gaming', 'Large file downloads', 'Smart home devices'],
    recommendation: 'Residential Fibre Max',
    description: 'Designed for large households with heavy internet usage.'
  }
];

const faqs = [
  {
    q: 'What areas do you cover for home fibre?',
    a: 'Our residential fibre is available across New Zealand in major cities and towns. Use our address checker above to confirm availability at your specific address.'
  },
  {
    q: 'Is there really no data limit?',
    a: 'Absolutely! All our residential plans include unlimited data usage. Stream, download, and browse as much as you want without worrying about data caps or extra charges.'
  },
  {
    q: 'What equipment do I need?',
    a: 'We provide a high-quality modem/router that\'s included in your monthly plan. For larger homes, we can recommend WiFi extenders or mesh systems for complete coverage.'
  },
  {
    q: 'How long does installation take?',
    a: 'Installation typically takes 2-5 business days from order confirmation. Our technician will install the fibre connection and set up your equipment, usually completed in one visit.'
  },
  {
    q: 'Can I keep my current phone number?',
    a: 'If you have a landline, we can often port your existing number to our VoIP service. Contact us to discuss your specific requirements.'
  },
  {
    q: 'What if I\'m not happy with the service?',
    a: 'With no fixed-term contracts, you can cancel anytime. We also offer a 30-day satisfaction guarantee for new customers.'
  },
  {
    q: 'Do you offer technical support?',
    a: 'Yes! We provide friendly technical support during business hours. Our team can help with setup, troubleshooting, and optimization of your home network.'
  },
  {
    q: 'How do I know which plan is right for me?',
    a: 'Consider how many people use the internet simultaneously and what activities they do. Our 50/10 plan suits 1-2 light users, 300/100 is great for families, and Fibre Max handles power users and large households.'
  }
];

export default function HomeFibre() {
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [showGST, setShowGST] = useState(true);
  const [showSignupModal, setShowSignupModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  const handleSignUp = (plan) => {
    setSelectedPlan(plan);
    setShowSignupModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#3A4E62] via-[#2a3749] to-[#1e2832] pt-32 pb-16 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
          {/* Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center text-white mb-12"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Check what's available at your address
            </h1>
            <p className="text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto">
              Enter your home address to see available residential fibre plans and speeds
            </p>
          </motion.div>

          {/* Address Picker */}
          <div className="mb-8">
            <AddressPicker 
              onAddressSelect={setSelectedAddress}
              placeholder="Enter your home address (e.g., 123 Residential Street, Auckland)"
            />
          </div>
        </div>

        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=1920&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="Fibre optic cables and network connections representing high-speed internet"
            className="w-full h-full object-cover opacity-15"
          />
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="py-16 bg-gradient-to-r from-[#C0E3D4]/20 to-[#53B289]/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-[#53B289] rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <benefit.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{benefit.title}</h3>
                <p className="text-[#3A4E62]/80 text-sm leading-relaxed">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Plan Cards */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Choose Your Home Fibre Plan
            </h2>
            <p className="text-xl text-[#3A4E62]/80 mb-6">
              All plans include unlimited data and no fixed-term contracts
            </p>
            
            {/* GST Toggle */}
            <div className="flex items-center justify-center space-x-4 mb-8">
              <span className={`text-sm ${!showGST ? 'font-semibold text-[#3A4E62]' : 'text-gray-600'}`}>
                Ex GST
              </span>
              <button
                onClick={() => setShowGST(!showGST)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  showGST ? 'bg-[#53B289]' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    showGST ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
              <span className={`text-sm ${showGST ? 'font-semibold text-[#3A4E62]' : 'text-gray-600'}`}>
                Inc GST
              </span>
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {residentialPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl h-full ${
                  plan.popular ? 'border-[#53B289] border-2 shadow-lg transform scale-105' : 'border-gray-200 hover:shadow-lg'
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 left-0 right-0 bg-[#53B289] text-white text-center py-2 text-sm font-semibold">
                      Most Popular
                    </div>
                  )}
                  
                  <CardHeader className={`text-center ${plan.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                    <CardTitle className="text-xl font-bold text-[#3A4E62] mb-4">{plan.name}</CardTitle>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-[#53B289]">
                        ${showGST ? plan.priceIncGST.toFixed(2) : plan.priceExGST.toFixed(2)}
                        <span className="text-lg font-normal text-gray-600">/month</span>
                      </div>
                      <p className="text-sm text-gray-500">
                        {showGST ? 'inc GST' : 'ex GST'}
                      </p>
                    </div>
                    <div className="mt-4">
                      <div className="inline-flex items-center bg-[#53B289]/10 text-[#53B289] px-4 py-2 rounded-full text-lg font-semibold">
                        <Download className="w-4 h-4 mr-2" />
                        {plan.speed}
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6 flex-1 flex flex-col">
                    {/* Features */}
                    <div className="space-y-3 flex-1">
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-start space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-[#3A4E62] text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Button 
                      onClick={() => handleSignUp(plan)}
                      className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white"
                      size="lg"
                    >
                      Sign Up
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Find the Perfect Plan for Your Household
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Different households have different needs. Here's how to choose the right speed.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {useCases.map((useCase, index) => (
              <motion.div
                key={useCase.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full border-2 hover:border-[#53B289]/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-center space-x-3 mb-2">
                      <Users className="w-8 h-8 text-[#53B289]" />
                      <div>
                        <CardTitle className="text-xl text-[#3A4E62]">{useCase.title}</CardTitle>
                        <p className="text-sm text-[#3A4E62]/70">{useCase.households}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-[#3A4E62] mb-2">Perfect for:</h4>
                      <ul className="space-y-1">
                        {useCase.needs.map((need, i) => (
                          <li key={i} className="flex items-center space-x-2 text-sm">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span>{need}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="bg-[#53B289]/10 rounded-lg p-3">
                      <h4 className="font-semibold text-[#53B289] mb-1">Recommended Plan:</h4>
                      <p className="text-[#53B289] font-medium">{useCase.recommendation}</p>
                    </div>
                    <p className="text-[#3A4E62]/80 text-sm">{useCase.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Speed Comparison */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              See What You Can Do with Each Speed
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Real-world examples of what different speeds can handle
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-[#53B289]">50/10 Mbps</CardTitle>
                <p className="text-2xl font-bold text-[#3A4E62]">Light Usage</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>HD streaming</span>
                    <span className="text-green-600">2 streams</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Video calls</span>
                    <span className="text-green-600">2 calls</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Online gaming</span>
                    <span className="text-green-600">1 gamer</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Connected devices</span>
                    <span className="text-green-600">10+ devices</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center border-[#53B289] border-2">
              <CardHeader>
                <CardTitle className="text-[#53B289]">300/100 Mbps</CardTitle>
                <p className="text-2xl font-bold text-[#3A4E62]">Family Usage</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>4K streaming</span>
                    <span className="text-green-600">4 streams</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Video calls</span>
                    <span className="text-green-600">5+ calls</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Online gaming</span>
                    <span className="text-green-600">3 gamers</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Connected devices</span>
                    <span className="text-green-600">25+ devices</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-[#53B289]">950/500 Mbps</CardTitle>
                <p className="text-2xl font-bold text-[#3A4E62]">Power Usage</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>8K streaming</span>
                    <span className="text-green-600">Multiple</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Video calls</span>
                    <span className="text-green-600">10+ calls</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Online gaming</span>
                    <span className="text-green-600">5+ gamers</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Connected devices</span>
                    <span className="text-green-600">50+ devices</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Everything you need to know about home fibre broadband
            </p>
          </motion.div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <AccordionItem value={`item-${index}`} className="bg-white rounded-xl border border-gray-200 px-6">
                  <AccordionTrigger className="text-left font-semibold text-[#3A4E62] hover:no-underline py-6">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-[#3A4E62]/90 pb-6">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#4aa07b]">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              Ready to upgrade your home internet?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied customers enjoying ultra-fast, reliable home fibre broadband.
            </p>
            <Button 
              size="lg" 
              className="bg-white text-[#53B289] hover:bg-white/90 px-8 py-4 text-lg font-semibold"
              onClick={() => setShowSignupModal(true)} // Example, could open a generic signup if no plan is selected
            >
              Choose Your Plan Today
            </Button>
          </motion.div>
        </div>
      </section>

      <ContactSection />

      {/* Signup Modal */}
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        selectedPlan={selectedPlan}
      />
    </div>
  );
}
