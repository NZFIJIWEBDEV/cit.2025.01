
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Ranui businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Businesses in Ranui
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the diverse range of small businesses, community organisations, and local services in Ranui, having a reliable and affordable IT partner is key to success. Comsys IT provides friendly, expert IT support tailored to the needs of the West Auckland community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=RanuiITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why the Ranui Community Chooses Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Truly Local & Responsive", 
            desc: "Based in West Auckland, we provide fast, personal service to our neighbours in Ranui. We're just down the road.",
            icon: Clock
          },
          { 
            title: "Affordable for Small Business", 
            desc: "Our IT support plans are cost-effective, providing exceptional value for the small businesses and startups in Ranui.",
            icon: CheckCircle
          },
          { 
            title: "Community Focused", 
            desc: "We are committed to helping local businesses and community organisations in Ranui succeed through better technology.",
            icon: Users
          },
          { 
            title: "Down-to-Earth Advice", 
            desc: "We provide clear, practical, and honest IT advice without the technical jargon, helping you make the best choices.",
            icon: Home
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT for Small Businesses", 
      desc: "Our managed IT plans are perfect for local businesses in Ranui. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Backup", 
      desc: "Protect your valuable business and customer data with our robust data backup and cybersecurity solutions, designed to keep your Ranui business secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Wifi, 
      title: "Business & Home Fibre", 
      desc: "Ensure your Ranui business or home office has the connectivity it needs to thrive with our reliable, high-speed business and home fibre internet solutions.",
      link: "BusinessFibre",
      imageUrl: "https://images.unsplash.com/photo-1631173733712-e881b2a24f67?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Ranui Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-16 aspect-h-9 sm:aspect-h-12 lg:aspect-w-4 lg:aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Ranui businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Your Local Ranui IT Support
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Fast Support for the Ranui Area</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              As a West Auckland based IT company, we are perfectly positioned to provide fast and responsive support to the Ranui community. Our local presence means we can quickly get onsite if a problem cannot be solved remotely.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             We are proud to serve businesses throughout Ranui, from the local shops to the surrounding residential streets. We are your neighbours, and we're here to help.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Fast local response for the Ranui community</p>
              <p><strong>Coverage:</strong> Ranui central, Birdwood, and all surrounding areas</p>
              <p><strong>Support:</strong> Onsite, Remote, and Managed IT Services</p>
              <p><strong>Specialization:</strong> Small Business & Community IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25546.505067272183!2d174.57962457678586!3d-36.89069354757279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d691b0ab97851%3A0x500ef6143a2b400!2sR%C4%81nui%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695863004128!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Ranui Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our West Auckland team provides dedicated support across Ranui.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My internet in Ranui is really slow. Can you help?",
      a: "Yes, we can definitely help. We will check the best internet options available at your specific Ranui address, whether that's fibre, 4G/5G broadband, or another solution. We'll then manage the installation and setup to ensure you get the fastest and most reliable connection possible."
    },
    {
      q: "Is my small Ranui business big enough for managed IT support?",
      a: "Yes, our managed IT support plans are designed for businesses of all sizes, including sole traders and very small businesses. Our plans are scalable, so you only pay for what you need. It's a great way to get professional IT support on a small budget."
    },
    {
      q: "What is the most important IT service for a new business starting in Ranui?",
      a: "For a new business, the most important services are a reliable internet connection and a secure data backup system. These two things form the foundation of your technology. We can help you get both set up correctly from day one, which will save you a lot of headaches later on."
    },
    {
      q: "Can you make my home office in Ranui feel more professional?",
      a: "Absolutely. We can set you up with a VoIP phone system so you have a dedicated business number, and ensure your Wi-Fi is strong and reliable for video calls. These small touches make a huge difference in how professionally your business is perceived by clients."
    },
    {
      q: "Why should I use a local West Auckland IT company?",
      a: "Using a local company like Comsys IT means you get faster onsite support when you need it. We also have a better understanding of the local area and its specific challenges. Most importantly, we're part of your community and genuinely care about helping local businesses like yours in Ranui succeed."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Ranui Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=RanuiITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportRanui() {
  const pageUrl = "https://www.comsys.co.nz/it-support-ranui-auckland";
  const title = "IT Support Ranui | Comsys IT | Affordable Local IT Services";
  const description = "Affordable and friendly local IT support for small businesses in Ranui, West Auckland. We provide managed IT, internet, phone, and security services.";

  // FAQ data replicated here for schema generation consistency with the FAQSection
  const faqsForSchema = [
    {
      q: "My internet in Ranui is really slow. Can you help?",
      a: "Yes, we can definitely help. We will check the best internet options available at your specific Ranui address, whether that's fibre, 4G/5G broadband, or another solution. We'll then manage the installation and setup to ensure you get the fastest and most reliable connection possible."
    },
    {
      q: "Is my small Ranui business big enough for managed IT support?",
      a: "Yes, our managed IT support plans are designed for businesses of all sizes, including sole traders and very small businesses. Our plans are scalable, so you only pay for what you need. It's a great way to get professional IT support on a small budget."
    },
    {
      q: "What is the most important IT service for a new business starting in Ranui?",
      a: "For a new business, the most important services are a reliable internet connection and a secure data backup system. These two things form the foundation of your technology. We can help you get both set up correctly from day one, which will save you a lot of headaches later on."
    },
    {
      q: "Can you make my home office in Ranui feel more professional?",
      a: "Absolutely. We can set you up with a VoIP phone system so you have a dedicated business number, and ensure your Wi-Fi is strong and reliable for video calls. These small touches make a huge difference in how professionally your business is perceived by clients."
    },
    {
      q: "Why should I use a local West Auckland IT company?",
      a: "Using a local company like Comsys IT means you get faster onsite support when you need it. We also have a better understanding of the local area and its specific challenges. Most importantly, we're part of your community and genuinely care about helping local businesses like yours in Ranui succeed."
    }
  ];

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Affordable local IT support for small businesses and community organisations in Ranui, Auckland.",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Ranui, Auckland"
      },
      "serviceType": [
        "Small Business IT Support", "Managed IT Services", "Business Internet", "VoIP Phone Systems"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqsForSchema.map(faq => ({
        "@type": "Question",
        "name": faq.q,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq.a
        }
      }))
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Ranui, West Auckland IT services, Ranui business IT, small business IT support"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
