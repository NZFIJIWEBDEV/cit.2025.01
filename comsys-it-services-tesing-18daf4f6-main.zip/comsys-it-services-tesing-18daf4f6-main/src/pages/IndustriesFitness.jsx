import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Dumbbell, Users, Wifi, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Fitness & Gyms in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland fitness centers. Comsys IT provides gym management software support, member WiFi, and reliable IT infrastructure.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=FitnessIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Fitness IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Fitness Centers
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop" 
            alt="Fitness IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Keeping Your Members Connected</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Modern fitness centers need reliable technology to manage memberships, provide entertainment systems, 
              and keep members engaged with their fitness journey.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Users, title: "Gym Management Software", desc: "Support for membership management, access control, and billing systems." },
              { icon: Wifi, title: "High-Performance WiFi", desc: "Fast, reliable WiFi for members streaming workouts and music." },
              { icon: Dumbbell, title: "Entertainment & AV Systems", desc: "Support for TVs, sound systems, and interactive fitness equipment." },
              { icon: Shield, title: "Member Data Security", desc: "Protecting member personal information and payment details." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ManagementSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Gym Management & Member Systems
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Streamline Your Operations</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We ensure your gym management software, access control systems, and payment processing 
              are always running smoothly, so you can focus on helping your members achieve their fitness goals.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "24/7 monitoring of membership and access control systems.",
              "Integration with popular gym management software (Glofox, Mindbody, etc.).",
              "Automated membership renewals and payment processing.",
              "Member check-in systems and access card programming.",
              "Real-time reporting and analytics for business insights.",
              "Backup systems to prevent membership disruptions."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Management System Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Improved Member Experience</h5>
              <p className="text-sm text-[#3A4E62]/80">Seamless check-ins, easy booking, and automated renewals.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Increased Revenue</h5>
              <p className="text-sm text-[#3A4E62]/80">Better retention rates and automated billing reduces revenue leakage.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Operational Efficiency</h5>
              <p className="text-sm text-[#3A4E62]/80">Reduced admin tasks and better insights into gym usage patterns.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Fitness Centers
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Powering Your Members' Success</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our fitness IT solutions help you deliver exceptional member experiences, 
            streamline operations, and grow your fitness business in Auckland's competitive market.
          </p>
          {[
            "Enhanced member experience with reliable technology.",
            "Improved operational efficiency and reduced costs.",
            "Better member retention through seamless service.",
            "Secure handling of member data and payments.",
            "Scalable IT solutions to support gym expansion."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT revolutionized our gym's technology infrastructure. The new WiFi network can handle all our members streaming videos simultaneously, and our management system hasn't crashed once since they took over. Member satisfaction scores have increased by 25%, and we've reduced admin time by half."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Dumbbell className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Mike Johnson</div>
              <div className="text-sm text-[#3A4E62]/70">Owner, Auckland Fitness Plus</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support gym management software like Mindbody and Glofox?",
            answer: "Yes, we provide comprehensive IT support for all major gym management platforms including Mindbody, Glofox, Zen Planner, and others. We ensure your software runs smoothly, integrates with your payment systems, and provides reliable member access control."
          },
          {
            question: "Can you handle high-bandwidth requirements for member WiFi?",
            answer: "Absolutely. We specialize in designing high-capacity WiFi networks that can handle hundreds of members simultaneously streaming videos, using fitness apps, and posting on social media. Our networks are optimized for the unique demands of fitness centers."
          },
          {
            question: "Do you provide support for fitness equipment integration?",
            answer: "Yes, we support the IT aspects of modern fitness equipment integration, including network connectivity for smart equipment, entertainment systems, and interactive fitness displays. We ensure your members have access to all the digital features that enhance their workout experience."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesFitness() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Fitness & Gyms in Auckland",
      "description": "IT support for Auckland fitness centers. Comsys IT provides gym management software support, member WiFi, and reliable IT infrastructure.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Fitness IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support gym management software like Mindbody and Glofox?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive IT support for all major gym management platforms including Mindbody, Glofox, Zen Planner, and others. We ensure your software runs smoothly, integrates with your payment systems, and provides reliable member access control." }
        },
        {
          "@type": "Question", "name": "Can you handle high-bandwidth requirements for member WiFi?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in designing high-capacity WiFi networks that can handle hundreds of members simultaneously streaming videos, using fitness apps, and posting on social media. Our networks are optimized for the unique demands of fitness centers." }
        },
        {
          "@type": "Question", "name": "Do you provide support for fitness equipment integration?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we support the IT aspects of modern fitness equipment integration, including network connectivity for smart equipment, entertainment systems, and interactive fitness displays. We ensure your members have access to all the digital features that enhance their workout experience." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Fitness & Gyms in Auckland", "item": "https://www.comsys.co.nz/IndustriesFitness" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Fitness & Gyms Auckland | Comsys IT"
        description="IT support for Auckland fitness centers. Comsys IT provides gym management software support, member WiFi, and reliable IT infrastructure."
        keywords="gym IT support Auckland, fitness center IT, gym management software, member WiFi, fitness technology"
        canonical="https://www.comsys.co.nz/IndustriesFitness"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <ManagementSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}