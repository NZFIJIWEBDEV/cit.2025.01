import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Cloud, DollarSign, Users, Headphones, Building, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Business VoIP Phone Systems in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Affordable VoIP solutions for Auckland businesses. Cloud PBX, SIP trunks, and Microsoft Teams integration with professional setup and support.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=VoIPQuote")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Free VoIP Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyVoIPSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why VoIP is the Future
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          {[
            { icon: DollarSign, title: "Cost Savings", desc: "Save up to 60% on phone bills with VoIP technology" },
            { icon: Cloud, title: "Cloud-Based", desc: "No expensive hardware - everything runs in the cloud" },
            { icon: Phone, title: "Advanced Features", desc: "Call forwarding, voicemail to email, auto-attendant" },
            { icon: Users, title: "Scalability", desc: "Easily add or remove users as your business grows" }
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex space-x-4"
            >
              <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <item.icon className="w-6 h-6 text-[#53B289]" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{item.title}</h3>
                <p className="text-[#3A4E62]/80">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
        <div>
          <img 
            src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&h=400&fit=crop" 
            alt="VoIP Phone Systems Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const VoIPFeaturesSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        VoIP Features
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { title: "Auto Attendant", desc: "Professional greeting and call routing", icon: "🎯" },
          { title: "Call Forwarding", desc: "Forward calls to mobile, home, or other extensions", icon: "📞" },
          { title: "Voicemail to Email", desc: "Receive voicemails as audio files in your email", icon: "📧" },
          { title: "Conference Calling", desc: "Host conference calls with multiple participants", icon: "👥" },
          { title: "Call Recording", desc: "Record important calls for training and compliance", icon: "🎙️" },
          { title: "Mobile Apps", desc: "Take your business phone anywhere with mobile apps", icon: "📱" }
        ].map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-6 shadow-lg text-center"
          >
            <div className="text-4xl mb-4">{feature.icon}</div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{feature.title}</h3>
            <p className="text-[#3A4E62]/80">{feature.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const IndustriesSupportSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Industries We Support
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { name: "Legal Firms", desc: "Professional communication for law practices", link: "IndustriesLegal" },
          { name: "Healthcare", desc: "Secure, HIPAA-compliant communications", link: "IndustriesHealthcare" },
          { name: "Real Estate", desc: "Always-on communication for property professionals", link: "IndustriesRealEstate" },
          { name: "Construction", desc: "Reliable communication for job sites and offices", link: "IndustriesConstruction" }
        ].map((industry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
          >
            <Building className="w-12 h-12 text-[#53B289] mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{industry.name}</h3>
            <p className="text-[#3A4E62]/80 mb-4">{industry.desc}</p>
            <Link to={createPageUrl(industry.link)}>
              <Button variant="outline" size="sm" className="border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white">
                Learn More
              </Button>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const CostSavingsSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Cost Savings
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Traditional Phone System vs VoIP</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-red-50 rounded-lg">
                <span className="font-medium text-red-800">Traditional System</span>
                <span className="text-2xl font-bold text-red-600">$150+/month</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                <span className="font-medium text-green-800">VoIP System</span>
                <span className="text-2xl font-bold text-green-600">$60/month</span>
              </div>
              <div className="text-center py-4">
                <span className="text-3xl font-bold text-[#53B289]">Save $90+/month</span>
                <p className="text-[#3A4E62]/80 mt-2">That's over $1,000 per year in savings!</p>
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Additional Cost Benefits</h3>
          {[
            "No expensive hardware to purchase or maintain",
            "Reduced international calling costs",
            "Eliminate need for multiple phone lines",
            "Lower maintenance and support costs",
            "Scalable pricing - pay for what you use"
          ].map((benefit, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Can I keep my number?",
            answer: "Yes! We can port your existing business phone numbers to your new VoIP system. The process typically takes 1-3 business days and we handle all the paperwork for you."
          },
          {
            question: "What internet speed is needed?",
            answer: "For quality VoIP calls, we recommend at least 100kbps upload and download per concurrent call. For a typical 10-person office, a standard business broadband connection is sufficient."
          },
          {
            question: "Is VoIP secure?",
            answer: "Yes, modern VoIP systems use advanced encryption and security protocols. We implement enterprise-grade security measures including TLS encryption and secure authentication to protect your communications."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function VoIPSolutions() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "VoIP Solutions",
      "name": "VoIP Solutions Auckland",
      "description": "Affordable VoIP solutions for Auckland businesses. Comsys IT provides cloud PBX, SIP trunks, and Microsoft Teams integration.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can I keep my number?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes! We can port your existing business phone numbers to your new VoIP system. The process typically takes 1-3 business days and we handle all the paperwork for you."
          }
        },
        {
          "@type": "Question",
          "name": "What internet speed is needed?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "For quality VoIP calls, we recommend at least 100kbps upload and download per concurrent call. For a typical 10-person office, a standard business broadband connection is sufficient."
          }
        },
        {
          "@type": "Question",
          "name": "Is VoIP secure?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, modern VoIP systems use advanced encryption and security protocols. We implement enterprise-grade security measures including TLS encryption and secure authentication to protect your communications."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "VoIP Solutions Auckland",
          "item": "https://www.comsys.co.nz/VoIPSolutions"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="VoIP Solutions Auckland | Comsys IT"
        description="Affordable VoIP solutions for Auckland businesses. Comsys IT provides cloud PBX, SIP trunks, and Microsoft Teams integration."
        keywords="VoIP Auckland, business phone systems, cloud PBX, IP phone systems, VoIP providers Auckland"
        canonical="https://www.comsys.co.nz/VoIPSolutions"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyVoIPSection />
      <VoIPFeaturesSection />
      <IndustriesSupportSection />
      <CostSavingsSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Switch to VoIP?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free quote and discover how much you can save with modern VoIP technology.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=VoIP")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Quote
              </Button>
            </Link>
            <Link to="https://teams.microsoft.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn About Teams Integration <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}