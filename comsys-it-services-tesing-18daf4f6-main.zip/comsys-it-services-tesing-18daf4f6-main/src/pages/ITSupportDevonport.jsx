
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Devonport's heritage businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Historic Devonport
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        In the charming and historic village of Devonport, local businesses require modern IT solutions that respect their unique character. Comsys IT provides friendly, professional, and reliable IT support for the cafes, boutiques, galleries, and professional services that make Devonport special.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=DevonportITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Devonport Businesses Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Expertise in Heritage Buildings", 
            desc: "We are skilled at installing modern IT infrastructure, like Wi-Fi and cabling, discreetly within Devonport's historic buildings.",
            icon: Building
          },
          { 
            title: "Hospitality & Retail Focus", 
            desc: "Specialized support for the cafes, restaurants, and boutique shops that define the Devonport village experience.",
            icon: CheckCircle
          },
          { 
            title: "Local North Shore Team", 
            desc: "Fast, friendly support from our team based right here on the North Shore, ensuring we're always close by.",
            icon: Users
          },
          { 
            title: "Friendly, Personal Service", 
            desc: "We offer approachable, down-to-earth service that fits the friendly, community-focused vibe of Devonport.",
            icon: Home
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT Services", 
      desc: "Our managed services plan for Devonport businesses provides proactive 24/7 monitoring, regular maintenance, and unlimited support for a fixed monthly fee, giving you predictable costs and complete peace of mind.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Shield, 
      title: "Advanced Cybersecurity", 
      desc: "We implement multi-layered security strategies, including advanced firewalls, endpoint protection, and data backup solutions to protect your Devonport business from cyber threats and ensure business continuity.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Wifi, 
      title: "Guest WiFi & POS Systems", 
      desc: "Enhance the customer experience for your Devonport cafe or retail store with reliable guest WiFi and modern, secure Point-of-Sale (POS) systems.",
      link: "WiFiUpgrade",
      imageUrl: "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Devonport Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Devonport businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Local North Shore Support for Devonport
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Your Peninsula IT Partner</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Though a world away in feel, Devonport is a key part of the North Shore community we serve. Our North Shore base means we can easily reach Devonport for onsite support, providing a local touch that a city-based provider can't match.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             We understand the unique logistics of the peninsula and are committed to providing reliable and timely service to all businesses in the Devonport village and surrounding residential areas.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Fast local response for the Devonport peninsula</p>
              <p><strong>Coverage:</strong> Devonport, Bayswater, Stanley Point, and Cheltenham Beach</p>
              <p><strong>Support:</strong> Onsite, Remote, and Managed IT Services</p>
              <p><strong>Specialization:</strong> Hospitality, Retail & Heritage Building IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25565.4121406456!2d174.7816035767931!3d-36.8310931976077!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d376c11736933%3A0x500ef6143a2b400!2sDevonport%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695863412534!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Devonport Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our North Shore team offers dedicated IT support across the Devonport peninsula.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "Our business is in a heritage building in Devonport. Can you install Wi-Fi without damaging the character?",
      a: "Yes, this is our specialty. We use discreet, modern access points and clever cabling techniques to provide excellent Wi-Fi coverage while respecting the integrity and aesthetics of heritage buildings. We work carefully to ensure the technology blends in seamlessly."
    },
    {
      q: "We get very busy on weekends. Can you provide IT support outside of standard business hours?",
      a: "Absolutely. We understand that for hospitality and retail businesses in Devonport, the weekend is peak time. Our managed support plans include options for after-hours and weekend support to ensure that if an issue arises during a busy service, we are there to help you resolve it quickly."
    },
    {
      q: "Is it expensive to get a professional phone system for my small Devonport shop?",
      a: "Not at all. Our modern VoIP phone systems are very affordable, often costing less than a traditional landline. For a small monthly fee, you get a host of professional features that can significantly improve your customer service and efficiency."
    },
    {
      q: "How do you provide support if there's an issue? Do you have to take the ferry?",
      a: "The vast majority of IT issues (over 95%) can be resolved instantly using our secure remote support software. This means we can fix problems within minutes without needing to travel. For issues that do require a physical presence, our North Shore team can be in Devonport quickly via the bridge."
    },
    {
      q: "Why is a good backup system so important for a small business?",
      a: "A good backup is your ultimate insurance policy. It protects you from losing everything due to a hardware failure, theft, fire, or a cyberattack like ransomware. For a small business, losing client lists, financial data, or work history can be catastrophic. An automated backup ensures you can always recover and continue operating."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Devonport Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=DevonportITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportDevonport() {
  const pageUrl = "https://www.comsys.co.nz/it-support-devonport-auckland";
  const title = "IT Support Devonport | Comsys IT | Hospitality & Retail Experts";
  const description = "Local IT support for Devonport's unique businesses. We specialize in hospitality and retail IT, Wi-Fi solutions, and support for heritage buildings.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Local IT support for hospitality, retail, and professional services in Devonport, Auckland.",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Level 1, 30 St Benedicts Street",
        "addressLocality": "Auckland",
        "postalCode": "1010",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Devonport, Auckland"
      },
      "serviceType": [
        "IT Support", "Hospitality IT", "Retail IT Support", "Guest Wi-Fi", "VoIP Phone Systems"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Our business is in a heritage building in Devonport. Can you install Wi-Fi without damaging the character?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, this is our specialty. We use discreet, modern access points and clever cabling techniques to provide excellent Wi-Fi coverage while respecting the integrity and aesthetics of Devonport's heritage buildings."
          }
        },
        {
          "@type": "Question",
          "name": "We get very busy on weekends. Can you provide IT support outside of standard business hours?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. We understand that for hospitality and retail businesses in Devonport, the weekend is peak time. Our support plans include options for after-hours and weekend support to ensure we can help you resolve issues quickly."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Devonport, North Shore IT services, Devonport business IT, VoIP Devonport, CCTV Devonport"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
