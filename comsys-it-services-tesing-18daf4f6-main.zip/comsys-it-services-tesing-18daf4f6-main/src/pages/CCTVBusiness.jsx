import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Shield, Eye, Smartphone, Cloud, Building, Home, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        CCTV Security Camera Installation in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Comsys IT installs reliable CCTV systems for homes and businesses across Auckland. Keep your property safe with modern, remote-access security cameras.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=CCTVQuote")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Free CCTV Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for CCTV
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { icon: Shield, title: "Professional Installation", desc: "Certified technicians with years of experience" },
          { icon: Eye, title: "High-Quality Cameras", desc: "4K resolution with night vision capabilities" },
          { icon: Smartphone, title: "Remote Monitoring", desc: "View your cameras from anywhere via smartphone app" },
          { icon: Cloud, title: "Cloud Storage", desc: "Secure cloud backup of all your footage" }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 rounded-xl hover:shadow-lg transition-shadow"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-4 mx-auto">
              <item.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{item.title}</h3>
            <p className="text-[#3A4E62]/80">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const CCTVForHomesSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        CCTV for Homes
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop" 
            alt="Home CCTV Security System Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Protect Your Family and Property</h3>
          <p className="text-[#3A4E62]/80 text-lg">
            Our residential CCTV systems provide 24/7 monitoring and peace of mind for Auckland homeowners. 
            Monitor your property from anywhere and receive instant alerts.
          </p>
          <div className="space-y-4">
            {[
              "Wireless or wired camera options",
              "Motion detection with smartphone alerts",
              "Night vision up to 30 meters",
              "Weather-resistant outdoor cameras",
              "Easy-to-use mobile app",
              "Local and cloud storage options"
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{feature}</span>
              </div>
            ))}
          </div>
          <Link to={createPageUrl("ContactUs?subject=HomeCCTV")}>
            <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Home CCTV Quote
            </Button>
          </Link>
        </div>
      </div>
    </div>
  </section>
);

const CCTVForBusinessSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        CCTV for Businesses
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Advanced Security for Your Business</h3>
          <p className="text-[#3A4E62]/80 text-lg">
            Protect your Auckland business with enterprise-grade CCTV systems. 
            Multiple camera views, advanced analytics, and comprehensive coverage.
          </p>
          <div className="space-y-4">
            {[
              "High-resolution 4K cameras",
              "Advanced motion detection and alerts",
              "Facial recognition capabilities",
              "Integration with access control systems",
              "Multi-site monitoring from single dashboard",
              "Detailed reporting and analytics"
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{feature}</span>
              </div>
            ))}
          </div>
          <Link to={createPageUrl("ContactUs?subject=BusinessCCTV")}>
            <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Business CCTV Quote
            </Button>
          </Link>
        </div>
        <div>
          <img 
            src="https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?w=600&h=400&fit=crop" 
            alt="Business CCTV Security System Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const SystemFeaturesSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Features of Our Systems
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { title: "4K Ultra HD", desc: "Crystal clear footage in all lighting conditions", icon: "📹" },
          { title: "Night Vision", desc: "See clearly up to 30 meters in complete darkness", icon: "🌙" },
          { title: "Motion Detection", desc: "Intelligent alerts when movement is detected", icon: "🎯" },
          { title: "Remote Access", desc: "View live and recorded footage from anywhere", icon: "📱" },
          { title: "Cloud Storage", desc: "Secure backup of all footage to the cloud", icon: "☁️" },
          { title: "Two-Way Audio", desc: "Communicate through selected cameras", icon: "🔊" }
        ].map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-6 shadow-lg text-center"
          >
            <div className="text-4xl mb-4">{feature.icon}</div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{feature.title}</h3>
            <p className="text-[#3A4E62]/80">{feature.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide CCTV maintenance?",
            answer: "Yes, we offer comprehensive maintenance packages including regular system health checks, camera cleaning, software updates, and 24/7 technical support to ensure your CCTV system operates reliably."
          },
          {
            question: "Can I watch CCTV from my phone?",
            answer: "Absolutely! All our CCTV systems include mobile apps for iOS and Android. You can view live footage, receive instant alerts, and review recorded videos from anywhere with an internet connection."
          },
          {
            question: "Do you offer 24/7 monitoring services?",
            answer: "While we don't provide 24/7 monitoring services ourselves, we can integrate your system with professional monitoring services and help you set up comprehensive alert systems for immediate notification of any security events."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function CCTVBusiness() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "CCTV Installation",
      "name": "CCTV Security Cameras Auckland",
      "description": "Comsys IT installs reliable CCTV systems for homes and businesses across Auckland. Keep your property safe with modern, remote-access security cameras.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide CCTV maintenance?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we offer comprehensive maintenance packages including regular system health checks, camera cleaning, software updates, and 24/7 technical support to ensure your CCTV system operates reliably."
          }
        },
        {
          "@type": "Question",
          "name": "Can I watch CCTV from my phone?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! All our CCTV systems include mobile apps for iOS and Android. You can view live footage, receive instant alerts, and review recorded videos from anywhere with an internet connection."
          }
        },
        {
          "@type": "Question",
          "name": "Do you offer 24/7 monitoring services?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "While we don't provide 24/7 monitoring services ourselves, we can integrate your system with professional monitoring services and help you set up comprehensive alert systems for immediate notification of any security events."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "CCTV Security Cameras Auckland",
          "item": "https://www.comsys.co.nz/CCTVBusiness"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="CCTV Security Cameras Auckland | Comsys IT"
        description="Comsys IT installs reliable CCTV systems for homes and businesses across Auckland. Keep your property safe with modern, remote-access security cameras."
        keywords="CCTV Auckland, security cameras Auckland, CCTV installation, business security cameras, home security systems"
        canonical="https://www.comsys.co.nz/CCTVBusiness"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseSection />
      <CCTVForHomesSection />
      <CCTVForBusinessSection />
      <SystemFeaturesSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Secure Your Property?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free security assessment and CCTV quote tailored to your specific needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=CCTV")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Security Assessment
              </Button>
            </Link>
            <Link to="https://www.hikvision.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Camera Specifications <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}