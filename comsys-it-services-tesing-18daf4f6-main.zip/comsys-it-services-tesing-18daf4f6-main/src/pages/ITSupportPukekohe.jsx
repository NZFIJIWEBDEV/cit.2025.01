
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, Truck, ShoppingCart, ShoppingBag } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Pukekohe's businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Growing Pukekohe
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        From its agricultural roots to its thriving town centre, businesses in Pukekohe require robust and reliable IT solutions. Comsys IT provides expert, scalable support for the diverse range of industries that power this key South Auckland hub.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=PukekoheITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

// New component based on outline's reference
const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-12">
        Why Comsys IT for Your Pukekohe Business?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <MapPin className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Local Pukekohe Expertise</h3>
          <p className="text-[#3A4E62]/80">
            Based right here, our team understands the unique IT needs and challenges faced by Pukekohe businesses, ensuring fast, relevant support.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <Clock className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Prompt Onsite & Remote Support</h3>
          <p className="text-[#3A4E62]/80">
            Minimise downtime with our rapid response times. We offer both efficient remote assistance and timely onsite visits when required.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <CheckCircle className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Proven Track Record</h3>
          <p className="text-[#3A4E62]/80">
            Join numerous satisfied Pukekohe businesses who trust Comsys IT for reliable, proactive, and tailored IT solutions.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <Users className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Dedicated Team</h3>
          <p className="text-[#3A4E62]/80">
            You'll work with a consistent team of dedicated professionals who get to know your business and its specific IT ecosystem.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <Home className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Tailored Solutions</h3>
          <p className="text-[#3A4E62]/80">
            We don't offer one-size-fits-all. Our solutions are customised to fit your business size, industry, and growth aspirations.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="bg-gray-50 p-8 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center text-center"
        >
          <Wifi className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-bold text-[#3A4E62] mb-3">Comprehensive Services</h3>
          <p className="text-[#3A4E62]/80">
            From managed IT and cybersecurity to cloud solutions and VoIP, we cover all your technology needs under one roof.
          </p>
        </motion.div>
      </div>
    </div>
  </section>
);


const ServicesSection = () => {
    const services = [
    { 
      icon: Truck, 
      title: "IT for Agri-business & Industry", 
      desc: "We provide robust IT solutions for Pukekohe's agricultural and industrial sectors, including reliable network infrastructure, data management for crop yields, and resilient connectivity.",
      link: "IndustriesAgriculture",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Users, 
      title: "Managed IT for Town Centre Businesses", 
      desc: "For the retailers and professional services in Pukekohe's town centre, our managed IT plans provide unlimited helpdesk support and proactive monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Backup", 
      desc: "Protect your valuable business and client data with our robust data backup and cybersecurity solutions, designed to keep your Pukekohe business secure and operational.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Pukekohe Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-16 aspect-h-9 md:aspect-w-4 md:aspect-h-3 rounded-xl overflow-hidden ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Pukekohe businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Service Area Map</h2>
      <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Our Auckland IT team provides fast onsite support for businesses across Pukekohe and surrounding South Auckland areas.</p>
      <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25638.27481495748!2d174.87454485!3d-37.20318235!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d61a8b4c5c37d%3A0x500ef6143a299d0!2sPukekohe%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Pukekohe, Auckland"></iframe>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What kind of businesses do you support in Pukekohe?",
      a: "Comsys IT proudly supports a diverse range of businesses in Pukekohe, from small retail shops and professional services in the town centre to larger agri-businesses and industrial operations. We tailor our services to meet your specific industry needs.",
    },
    {
      q: "Do you offer onsite IT support in Pukekohe?",
      a: "Absolutely! Being local to the South Auckland area, we provide prompt onsite IT support for businesses in Pukekohe and surrounding Franklin district areas, alongside efficient remote assistance.",
    },
    {
      q: "Can you help with fibre internet and network setup?",
      a: "Yes, we specialize in reliable network infrastructure, including fibre internet setup, Wi-Fi solutions, and secure network configurations to ensure your Pukekohe business has fast and stable connectivity.",
    },
    {
      q: "What are your hours of operation for Pukekohe businesses?",
      a: "Our standard support hours are Monday to Friday, 8:30 AM to 5:00 PM. We also offer emergency support options for critical issues for our managed service clients.",
    },
    {
      q: "How can I get started with Comsys IT support?",
      a: "Getting started is easy! You can contact us for a free IT assessment by filling out our online form, calling us directly, or emailing our support team. We'll discuss your needs and propose the best solutions for your Pukekohe business.",
    },
  ];
  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Pukekohe Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=PukekoheITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportPukekohe() {
  const pageUrl = "https://www.comsys.co.nz/it-support-pukekohe-auckland";
  const title = "IT Support Pukekohe Auckland | Comsys IT";
  const description = "Comsys IT delivers professional IT support and technology services to businesses in Pukekohe, Auckland. Expert solutions for agri-business, town centre operations, data security, and more.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "image": "https://www.comsys.co.nz/logo.png", // Replace with actual logo URL
      "@id": "https://www.comsys.co.nz/#organization",
      "url": "https://www.comsys.co.nz/it-support-pukekohe-auckland",
      "telephone": "+64-800-724-526",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Level 1, 1 Wesley Street", // Example: Replace with Comsys Pukekohe address if available
        "addressLocality": "Pukekohe",
        "addressRegion": "Auckland",
        "postalCode": "2120", 
        "addressCountry": "NZ"
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday"
          ],
          "opens": "08:30",
          "closes": "17:00"
        }
      ],
      "priceRange": "$$", 
      "servesArea": {
        "@type": "City",
        "name": "Pukekohe"
      },
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "IT Support Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Managed IT Services"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Cybersecurity Solutions"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Data Backup and Recovery"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "VoIP Phone Systems"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Fibre Internet Installation"
            }
          }
        ]
      },
      "sameAs": [
        "https://www.facebook.com/ComsysIT/", // Replace or remove if not applicable
        "https://www.linkedin.com/company/comsys-it-solutions/" // Replace or remove if not applicable
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": title,
      "description": description,
      "url": pageUrl
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Pukekohe, agri-business IT, South Auckland IT, Pukekohe business IT, IT services Franklin district, data backup Pukekohe, cybersecurity Pukekohe"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
