import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Car, Wrench, Video, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Automotive Businesses in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland automotive industry. Comsys IT provides workshop management software support, CCTV systems, and reliable IT infrastructure.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=AutomotiveIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Automotive IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Automotive Businesses
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=600&h=400&fit=crop" 
            alt="Automotive IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Works as Hard as You Do</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Automotive businesses need reliable IT systems to manage jobs, track inventory, 
              secure valuable assets, and provide excellent customer service.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Wrench, title: "Workshop Management Systems", desc: "Support for job booking, invoicing, and workshop management software." },
              { icon: Video, title: "Security & CCTV Systems", desc: "Protecting valuable vehicles, parts, and equipment with surveillance systems." },
              { icon: Car, title: "Diagnostic Equipment Support", desc: "IT infrastructure to support modern diagnostic tools and equipment." },
              { icon: Shield, title: "Customer Data Security", desc: "Protecting customer vehicle information and payment details." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const WorkshopSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Workshop Management & Operations
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Streamline Your Workshop Operations</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We ensure your workshop management software, diagnostic tools, and operational systems 
              are always running reliably, so you can focus on delivering quality automotive services.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "Support for workshop management software (AutoTrader, Mitchell1, etc.).",
              "Integration with diagnostic equipment and scan tools.",
              "Customer relationship management and invoicing systems.",
              "Parts inventory tracking and ordering systems.",
              "Appointment booking and workshop scheduling.",
              "Backup systems to protect job records and customer data."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Workshop IT Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Improved Efficiency</h5>
              <p className="text-sm text-[#3A4E62]/80">Streamlined job tracking and automated invoicing saves time.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Better Customer Service</h5>
              <p className="text-sm text-[#3A4E62]/80">Quick access to vehicle history and service records.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Increased Profitability</h5>
              <p className="text-sm text-[#3A4E62]/80">Better inventory management and job costing accuracy.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Automotive Businesses
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Keeping Your Business in the Fast Lane</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our automotive IT solutions help you run more efficiently, provide better customer service, 
            and protect your valuable assets in Auckland's competitive automotive market.
          </p>
          {[
            "Enhanced workshop efficiency and productivity.",
            "Improved customer service and satisfaction.",
            "Better security for vehicles, parts, and equipment.",
            "Accurate job tracking and profitability analysis.",
            "Reliable IT systems that support modern diagnostic tools."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT transformed our workshop's IT infrastructure. The new system integrates our diagnostic equipment with our management software seamlessly, and the CCTV system gives us peace of mind. Our job turnaround time has improved by 20%, and we've had zero data loss incidents since they implemented our backup systems."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Car className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Tony Martinez</div>
              <div className="text-sm text-[#3A4E62]/70">Owner, Auckland Auto Repairs</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support workshop management software and diagnostic tools?",
            answer: "Yes, we provide comprehensive IT support for popular workshop management systems like AutoTrader, Mitchell1, and others. We also ensure your diagnostic equipment is properly networked and integrated with your management systems for seamless operation."
          },
          {
            question: "Can you install CCTV systems for automotive businesses?",
            answer: "Absolutely. We specialize in CCTV installations for automotive businesses, providing comprehensive coverage of workshop areas, parking lots, and parts storage. Our systems include features like night vision, remote monitoring, and integration with alarm systems for complete security."
          },
          {
            question: "Do you help with customer data security and compliance?",
            answer: "Yes, we implement robust security measures to protect customer vehicle information, service records, and payment data. This includes secure data storage, regular backups, network security, and compliance with privacy regulations to protect both your business and your customers."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesAutomotive() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Automotive Businesses in Auckland",
      "description": "IT support for Auckland automotive industry. Comsys IT provides workshop management software support, CCTV systems, and reliable IT infrastructure.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Automotive IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support workshop management software and diagnostic tools?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive IT support for popular workshop management systems like AutoTrader, Mitchell1, and others. We also ensure your diagnostic equipment is properly networked and integrated with your management systems for seamless operation." }
        },
        {
          "@type": "Question", "name": "Can you install CCTV systems for automotive businesses?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in CCTV installations for automotive businesses, providing comprehensive coverage of workshop areas, parking lots, and parts storage. Our systems include features like night vision, remote monitoring, and integration with alarm systems for complete security." }
        },
        {
          "@type": "Question", "name": "Do you help with customer data security and compliance?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we implement robust security measures to protect customer vehicle information, service records, and payment data. This includes secure data storage, regular backups, network security, and compliance with privacy regulations to protect both your business and your customers." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Automotive Businesses in Auckland", "item": "https://www.comsys.co.nz/IndustriesAutomotive" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Automotive Businesses Auckland | Comsys IT"
        description="IT support for Auckland automotive industry. Comsys IT provides workshop management software support, CCTV systems, and reliable IT infrastructure."
        keywords="automotive IT support Auckland, workshop management software, automotive CCTV, garage IT systems, auto repair technology"
        canonical="https://www.comsys.co.nz/IndustriesAutomotive"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <WorkshopSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}