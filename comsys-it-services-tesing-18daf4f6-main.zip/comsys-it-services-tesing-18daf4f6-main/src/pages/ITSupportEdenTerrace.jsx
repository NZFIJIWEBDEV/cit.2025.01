
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Eden Terrace businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Creative Eden Terrace
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        As the heart of Auckland's creative and design precinct, businesses in Eden Terrace need agile, powerful, and reliable IT. Comsys IT provides specialized support for creative agencies, design studios, and professional services, ensuring your technology fuels your innovation.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=EdenTerraceITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Eden Terrace Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "CBD Fringe Specialists", 
            desc: "We understand the IT needs of businesses in high-density commercial hubs like Eden Terrace.",
            icon: Building
          },
          { 
            title: "Rapid Onsite Response", 
            desc: "Our central location means we can provide extremely fast onsite support to resolve issues quickly.",
            icon: Clock
          },
          { 
            title: "Diverse Industry Experience", 
            desc: "Expertise supporting the mix of showrooms, offices, and light industrial clients in Eden Terrace.",
            icon: Users
          },
          { 
            title: "Proactive Management", 
            desc: "Our managed services prevent IT problems, which is crucial for businesses that can't afford downtime.",
            icon: Shield
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT for Creative Agencies", 
      desc: "Our managed services plan for Eden Terrace businesses provides proactive support for both Mac and PC environments, ensuring your creative workflows are never interrupted by technical issues.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Server, 
      title: "Cloud Solutions & Collaboration", 
      desc: "We implement powerful cloud solutions like Microsoft 365 and Google Workspace, along with secure, high-speed file sharing to facilitate seamless collaboration for your Eden Terrace team.",
      link: "MicrosoftOffice",
      imageUrl: "https://images.unsplash.com/photo-1586953208448-3151cf78716c?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Protection for IP", 
      desc: "Protect your valuable intellectual property and client data with our advanced cybersecurity services, including robust backups, threat detection, and proactive security management.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Eden Terrace Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`grid lg:grid-cols-2 gap-8 items-center ${index % 2 === 0 ? 'lg:grid-flow-col-dense' : ''}`}
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Eden Terrace businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Onsite Support for Eden Terrace
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Your Local Eden Terrace IT Partner</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Comsys IT is proud to serve the dynamic business community of Eden Terrace. Our central location allows our technicians to provide exceptionally fast onsite support, minimizing downtime and resolving issues efficiently for businesses along New North Road, Symonds Street, and the surrounding commercial streets.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              We are familiar with the commercial buildings and infrastructure in the area, allowing us to plan and execute IT projects and support calls with maximum efficiency.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Under 60-minute onsite response for critical issues</p>
              <p><strong>Coverage:</strong> Entire Eden Terrace commercial precinct</p>
              <p><strong>Support:</strong> Onsite & Remote Managed Services</p>
              <p><strong>Specialization:</strong> Commercial, Corporate & Showroom IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6381.189578103133!2d174.75239999645484!3d-36.87034432961819!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47b8a7b6951b%3A0x500ef6143a29950!2sEden%20Terrace%2C%20Auckland%201021!5e0!3m2!1sen!2snz!4v1695861616428!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Eden Terrace Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our team provides fast, professional IT support to the entire Eden Terrace business community.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My business is in a multi-tenanted office building in Eden Terrace. How do you handle support and installations?",
      a: "We have extensive experience working in multi-tenanted commercial buildings. We coordinate with building management for access, adhere to all building rules and regulations, and carry out our work with minimal disruption to your business and your neighbours. We can manage network cabling, installations, and support calls efficiently within these environments."
    },
    {
      q: "We need an IT solution that supports both our showroom floor and our back-office staff. Can you provide this?",
      a: "Yes, we specialize in creating integrated IT solutions. We can set up a secure, high-performance network that provides robust connectivity for your office staff while also delivering a seamless and impressive guest Wi-Fi experience for customers in your showroom."
    },
    {
      q: "How do your managed IT services help a business in Eden Terrace?",
      a: "Our managed services are ideal for the fast-paced Eden Terrace environment. By proactively monitoring and maintaining your systems, we prevent IT problems from occurring, which means less downtime and higher productivity for your business. It gives you a complete IT department for a fixed monthly fee, which is more cost-effective than hiring in-house staff."
    },
    {
      q: "What makes your cybersecurity offering suitable for an Eden Terrace business?",
      a: "Businesses in dense commercial areas are often targeted by cyberattacks. Our multi-layered security approach is crucial. We go beyond basic antivirus, implementing enterprise-grade firewalls, advanced threat detection, and continuous monitoring to protect your sensitive business and client data from sophisticated threats."
    },
    {
      q: "How can you help us improve our communication with clients and suppliers?",
      a: "Our modern VoIP phone systems are a major upgrade for any business. They offer superior call quality and advanced features like video conferencing and mobile integration. This enables your Eden Terrace team to communicate more professionally and efficiently with clients and partners, whether they are in the office or working remotely."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Eden Terrace Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=EdenTerraceITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportEdenTerrace() {
  const pageUrl = "https://www.comsys.co.nz/it-support-eden-terrace-auckland";
  const title = "IT Support Eden Terrace | Comsys IT | Creative & Design";
  const description = "Specialized IT support for creative agencies, design studios, and professional services in Eden Terrace, Auckland. Proactive managed services, cloud solutions, and data protection.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "IT support for creative and design businesses in Eden Terrace, Auckland.",
      "url": pageUrl,
      "telephone": "092423700", // Keeping original phone, as outline provided 0800 in CTA but 09 in original schema
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Eden Terrace, Auckland"
      },
      "serviceType": [
        "Managed IT Services for Creative Agencies", "Cloud Solutions", "Data Protection for Intellectual Property", "IT Consulting"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "My business is in a multi-tenanted office building in Eden Terrace. How do you handle support and installations?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We have extensive experience working in multi-tenanted commercial buildings. We coordinate with building management for access, adhere to all building rules and regulations, and carry out our work with minimal disruption to your business and your neighbours. We can manage network cabling, installations, and support calls efficiently within these environments."
          }
        },
        {
          "@type": "Question",
          "name": "How fast is your onsite response to Eden Terrace?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Our central location allows for extremely fast onsite response to Eden Terrace, typically under 60 minutes for critical business-affecting issues."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Eden Terrace, creative agency IT, design studio IT support, Auckland IT services"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
