import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Calculator, Cloud, Shield, DollarSign, ExternalLink, AlertTriangle } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Accounting Firms in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT services designed for Auckland accounting firms. Comsys IT provides secure cloud backup, VoIP, and IT support for financial practices.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=AccountingIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Accounting IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ITNeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Accountants
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop" 
            alt="Accounting IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Specialized IT Requirements for Accounting</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Accounting firms have unique IT needs driven by regulatory compliance, client data security, 
              and the demands of modern financial software and cloud-based accounting platforms.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Calculator,
                title: "Accounting Software Integration",
                desc: "Seamless operation of MYOB, Xero, QuickBooks, and other financial software"
              },
              {
                icon: Cloud,
                title: "Cloud-Based Solutions",
                desc: "Secure access to client files and accounting data from anywhere"
              },
              {
                icon: Shield,
                title: "Data Security & Compliance",
                desc: "Protection of sensitive financial data and regulatory compliance"
              },
              {
                icon: DollarSign,
                title: "Cost-Effective Operations",
                desc: "Streamlined IT systems that support efficient billing and client management"
              }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-orange-800 mb-3">Accounting Industry Challenges:</h4>
            <ul className="space-y-2 text-orange-700">
              <li>• Peak season IT demands during tax periods</li>
              <li>• Strict data retention and compliance requirements</li>
              <li>• Need for secure client data sharing</li>
              <li>• Integration between multiple accounting platforms</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CloudSoftwareSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Cloud & Software Support
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            category: "Accounting Software",
            platforms: [
              "MYOB AccountRight & Essentials",
              "Xero Online Accounting",
              "QuickBooks Online & Desktop",
              "Sage 50 Accounts",
              "Reckon Accounts",
              "FreshBooks"
            ],
            icon: "💰"
          },
          {
            category: "Tax & Compliance",
            platforms: [
              "MYOB Tax",
              "TaxLab",
              "Inland Revenue Online Services",
              "GST & PAYE Systems",
              "Tax Agent Portal",
              "KiwiSaver Integration"
            ],
            icon: "📊"
          },
          {
            category: "Practice Management",
            platforms: [
              "MYOB Practice",
              "Workpapers",
              "CCH iFirm",
              "Thomson Reuters ONESOURCE",
              "Wolters Kluwer",
              "Document Management Systems"
            ],
            icon: "📁"
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg"
          >
            <div className="text-4xl mb-4 text-center">{category.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6 text-center">{category.category}</h3>
            <ul className="space-y-3">
              {category.platforms.map((platform, pIndex) => (
                <li key={pIndex} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                  <span className="text-[#3A4E62]/80 text-sm">{platform}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Comprehensive Software Support Services</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-8">
            Our certified technicians provide complete support for all major accounting and practice management software, 
            ensuring your systems work seamlessly together and your team stays productive.
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Setup & Configuration:</h4>
              <ul className="space-y-2">
                {[
                  "Software installation and licensing",
                  "Multi-user setup and permissions",
                  "Chart of accounts configuration",
                  "Bank feed and payment integrations",
                  "Custom report templates"
                ].map((service, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{service}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Integration Services:</h4>
              <ul className="space-y-2">
                {[
                  "Software-to-software data sync",
                  "Third-party add-on integration",
                  "Bank and payment gateway setup",
                  "Document management integration",
                  "Email and communication tools"
                ].map((integration, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{integration}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Training & Support:</h4>
              <ul className="space-y-2">
                {[
                  "User training and onboarding",
                  "Best practice workshops",
                  "Troubleshooting and optimization",
                  "Software updates and migrations",
                  "24/7 technical support"
                ].map((training, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{training}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const DataBackupComplianceSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Data Backup & Compliance
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Compliance-Ready Backup Solutions</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Accounting firms must maintain accurate financial records for extended periods. Our backup solutions 
              ensure compliance with regulatory requirements while protecting against data loss.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Compliance Features:</h4>
            {[
              {
                title: "7-Year Data Retention",
                desc: "Automatic retention policies meeting IRD and compliance requirements"
              },
              {
                title: "Immutable Backups",
                desc: "Write-once, read-many backups that cannot be altered or deleted"
              },
              {
                title: "Audit Trail Preservation",
                desc: "Complete history of all data changes and access attempts"
              },
              {
                title: "New Zealand Data Residency",
                desc: "All backup data stored within New Zealand borders"
              },
              {
                title: "Point-in-Time Recovery",
                desc: "Restore data to any specific date and time for compliance needs"
              },
              {
                title: "Automated Compliance Reports",
                desc: "Regular reports documenting backup status and compliance adherence"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h5 className="font-semibold text-green-800 mb-2">{feature.title}</h5>
                <p className="text-sm text-green-700">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop" 
            alt="Accounting Data Backup Compliance Auckland"
            className="rounded-xl shadow-lg w-full"
          />
          
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Regulatory Compliance Standards:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Companies Act 1993 record-keeping requirements</li>
              <li>• IRD record retention obligations</li>
              <li>• Financial Reporting Act compliance</li>
              <li>• Privacy Act 2020 data protection</li>
              <li>• Anti-Money Laundering Act requirements</li>
              <li>• Professional accounting body standards</li>
            </ul>
          </div>
          
          <div className="mt-6 bg-red-50 border border-red-200 rounded-xl p-6">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="text-lg font-semibold text-red-800 mb-2">Data Loss Risks:</h4>
                <p className="text-red-700 text-sm mb-3">
                  Without proper backup, accounting firms risk:
                </p>
                <ul className="space-y-1 text-red-700 text-sm">
                  <li>• Regulatory penalties and fines</li>
                  <li>• Loss of client trust and business</li>
                  <li>• Inability to meet audit requirements</li>
                  <li>• Professional liability exposure</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const WhyAccountantsChooseSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Accountants Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Accounting Industry Expertise</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand the unique challenges facing accounting professionals and provide 
              specialized IT solutions that support your practice's growth and compliance needs.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                title: "Peak Season Support",
                desc: "Extra support during busy tax periods and year-end when IT issues can't wait"
              },
              {
                title: "Financial Software Expertise",
                desc: "Certified in MYOB, Xero, QuickBooks and other major accounting platforms"
              },
              {
                title: "Compliance Assurance",
                desc: "IT solutions designed to meet regulatory and professional standards"
              },
              {
                title: "Cost-Effective Solutions",
                desc: "Predictable IT costs that help with practice budgeting and profitability"
              },
              {
                title: "Secure Client Data Handling",
                desc: "Bank-level security for sensitive financial and personal information"
              },
              {
                title: "Local Auckland Support",
                desc: "On-site support from technicians who understand NZ accounting requirements"
              }
            ].map((benefit, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
            <blockquote className="text-[#3A4E62]/80 italic mb-4">
              "During our busiest tax season, Comsys IT kept our systems running flawlessly. 
              Their understanding of our MYOB and Xero requirements, combined with proactive monitoring, 
              helped us serve more clients efficiently. We processed 30% more returns this year with zero IT downtime."
            </blockquote>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-[#3A4E62]">Michael Chen</div>
                <div className="text-sm text-[#3A4E62]/70">Director, Chen & Associates Chartered Accountants</div>
              </div>
            </div>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-8">
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Complete Accounting IT Services:</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Software & Systems:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• MYOB, Xero, QuickBooks support</li>
                  <li>• Tax software integration</li>
                  <li>• Practice management systems</li>
                  <li>• Document management</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Infrastructure:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Secure cloud solutions</li>
                  <li>• Backup and disaster recovery</li>
                  <li>• Network security</li>
                  <li>• VoIP phone systems</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support MYOB, Xero, QuickBooks?",
            answer: "Yes, we provide comprehensive support for all major accounting software platforms including MYOB AccountRight & Essentials, Xero Online Accounting, QuickBooks Online & Desktop, Sage 50, and Reckon Accounts. Our certified technicians can handle installation, configuration, user training, troubleshooting, integrations, and ongoing support for these platforms."
          },
          {
            question: "Do you offer compliance-ready backup?",
            answer: "Absolutely. Our backup solutions are specifically designed for accounting firms with 7-year data retention, immutable backups, audit trail preservation, and New Zealand data residency. We ensure compliance with Companies Act 1993, IRD requirements, Financial Reporting Act, and Privacy Act 2020 standards."
          },
          {
            question: "Can you integrate accounting systems with VoIP?",
            answer: "Yes, we can integrate your accounting software with VoIP phone systems to enable features like click-to-dial from client records, automatic call logging, and CRM integration. This streamlines client communication and improves productivity by connecting your phone system directly with your practice management and accounting software."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesAccounting() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Accounting Firms Auckland",
      "description": "IT services designed for Auckland accounting firms. Comsys IT provides secure cloud backup, VoIP, and IT support for financial practices.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": {
          "@type": "City",
          "name": "Auckland"
        },
        "serviceType": "Accounting IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you support MYOB, Xero, QuickBooks?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide comprehensive support for all major accounting software platforms including MYOB AccountRight & Essentials, Xero Online Accounting, QuickBooks Online & Desktop, Sage 50, and Reckon Accounts. Our certified technicians can handle installation, configuration, user training, troubleshooting, integrations, and ongoing support for these platforms."
          }
        },
        {
          "@type": "Question",
          "name": "Do you offer compliance-ready backup?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. Our backup solutions are specifically designed for accounting firms with 7-year data retention, immutable backups, audit trail preservation, and New Zealand data residency. We ensure compliance with Companies Act 1993, IRD requirements, Financial Reporting Act, and Privacy Act 2020 standards."
          }
        },
        {
          "@type": "Question",
          "name": "Can you integrate accounting systems with VoIP?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we can integrate your accounting software with VoIP phone systems to enable features like click-to-dial from client records, automatic call logging, and CRM integration. This streamlines client communication and improves productivity by connecting your phone system directly with your practice management and accounting software."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Industries",
          "item": "https://www.comsys.co.nz/Industries"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Solutions for Accounting Firms Auckland",
          "item": "https://www.comsys.co.nz/IndustriesAccounting"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Accounting Firms Auckland | Comsys IT"
        description="IT services designed for Auckland accounting firms. Comsys IT provides secure cloud backup, VoIP, and IT support for financial practices."
        keywords="accounting firm IT support Auckland, MYOB support, Xero support, QuickBooks IT, accounting software support"
        canonical="https://www.comsys.co.nz/IndustriesAccounting"
        schemas={schemas}
      />
      
      <PageHero />
      <ITNeedsSection />
      <CloudSoftwareSection />
      <DataBackupComplianceSection />
      <WhyAccountantsChooseSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Streamline Your Accounting Practice with Expert IT Support
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get specialized IT solutions that understand the unique needs of accounting professionals. 
            Ensure compliance, protect client data, and maximize productivity.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=AccountingITAssessment")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Accounting IT Assessment
              </Button>
            </Link>
            <Link to="https://www.nzica.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Accounting Standards <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}