import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Wifi, Signal, Home, Building, Zap, Shield, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        WiFi Upgrade Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Boost your internet speed and coverage with professional WiFi upgrades. Comsys IT provides fast, reliable WiFi solutions for homes and offices.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=WiFiUpgrade")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get WiFi Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyUpgradeSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Upgrade WiFi
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="bg-red-50 border border-red-200 rounded-xl p-8 mb-8">
            <h3 className="text-xl font-bold text-red-800 mb-4">Signs You Need a WiFi Upgrade</h3>
            <ul className="space-y-3 text-red-700">
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>Slow internet speeds, especially during peak hours</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>WiFi dead zones in certain rooms or areas</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>Frequent disconnections and connection drops</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>Buffering during video streaming or online meetings</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>Router is more than 3-4 years old</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-red-500 font-bold">•</span>
                <span>Multiple devices competing for bandwidth</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Benefits of Professional WiFi Upgrade</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Don't settle for slow, unreliable internet. A professional WiFi upgrade can dramatically improve your online experience and productivity.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Zap, title: "Faster Speeds", desc: "Up to 10x faster internet speeds with latest WiFi 6 technology" },
              { icon: Signal, title: "Better Coverage", desc: "Eliminate dead zones with strategic access point placement" },
              { icon: Shield, title: "Enhanced Security", desc: "Latest WPA3 encryption and advanced security features" },
              { icon: Building, title: "More Devices", desc: "Support for 50+ devices simultaneously without slowdown" }
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <benefit.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const OfficeWiFiSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Office WiFi
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop" 
            alt="Office WiFi Upgrade Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Enterprise WiFi for Auckland Businesses</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Your business needs reliable, fast WiFi that can handle multiple users, devices, and demanding applications. 
              We design and install professional WiFi networks that deliver consistent performance.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Business WiFi Features:</h4>
            {[
              "Enterprise-grade access points with advanced antennas",
              "Seamless roaming between access points",
              "Guest network isolation for visitor access",
              "Bandwidth management and quality of service (QoS)",
              "Centralized management and monitoring",
              "VLAN support for network segmentation",
              "24/7 monitoring and proactive maintenance",
              "Scalable design that grows with your business"
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{feature}</span>
              </div>
            ))}
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-[#3A4E62] mb-3">Typical Office Upgrade Results:</h4>
            <div className="grid md:grid-cols-2 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-red-600">Before</div>
                <div className="text-sm text-[#3A4E62]/80">25 Mbps, frequent drops</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[#53B289]">After</div>
                <div className="text-sm text-[#3A4E62]/80">200+ Mbps, 99.9% uptime</div>
              </div>
            </div>
          </div>
          
          <Link to={createPageUrl("ContactUs?subject=OfficeWiFi")}>
            <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Office WiFi Quote
            </Button>
          </Link>
        </div>
      </div>
    </div>
  </section>
);

const HomeWiFiSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Home WiFi
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Whole-Home WiFi Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Enjoy fast, reliable WiFi in every room of your Auckland home. Our residential WiFi solutions eliminate 
              dead zones and provide seamless coverage for all your devices.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Home WiFi Solutions:</h4>
            {[
              "Mesh network systems for seamless coverage",
              "Single network name throughout your home",
              "Support for smart home devices and IoT",
              "Parental controls and guest network access",
              "Easy mobile app management",
              "Future-proof WiFi 6 technology"
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{feature}</span>
              </div>
            ))}
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Perfect for:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Working from home with reliable connectivity</li>
              <li>• 4K streaming on multiple devices simultaneously</li>
              <li>• Online gaming with low latency</li>
              <li>• Smart home automation and security systems</li>
              <li>• Large families with many connected devices</li>
            </ul>
          </div>
          
          <Link to={createPageUrl("ContactUs?subject=HomeWiFi")}>
            <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Home WiFi Quote
            </Button>
          </Link>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop" 
            alt="Home WiFi Upgrade Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const ProfessionalSetupSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Professional Setup
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Site Survey & Planning",
            desc: "We analyze your space and internet usage to design the optimal WiFi solution",
            icon: "📊",
            benefits: ["Heat mapping", "Coverage analysis", "Interference testing", "Capacity planning"]
          },
          {
            title: "Professional Installation",
            desc: "Clean, professional installation with proper cable management and positioning",
            icon: "🔧",
            benefits: ["Optimal placement", "Cable management", "Wall mounting", "Clean finish"]
          },
          {
            title: "Configuration & Testing",
            desc: "Complete setup, security configuration, and thorough testing of all areas",
            icon: "⚙️",
            benefits: ["Security setup", "Performance optimization", "Speed testing", "Device configuration"]
          },
          {
            title: "Network Security",
            desc: "Advanced security configuration to protect your network and devices",
            icon: "🔒",
            benefits: ["WPA3 encryption", "Firewall setup", "Guest isolation", "Access controls"]
          },
          {
            title: "Ongoing Support",
            desc: "Continued support and maintenance to ensure optimal performance",
            icon: "🛠️",
            benefits: ["Remote monitoring", "Firmware updates", "Performance tuning", "Technical support"]
          },
          {
            title: "Warranty & Guarantee",
            desc: "Comprehensive warranty on equipment and satisfaction guarantee on installation",
            icon: "✅",
            benefits: ["Equipment warranty", "Installation guarantee", "Performance promise", "Service commitment"]
          }
        ].map((benefit, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg"
          >
            <div className="text-4xl mb-4 text-center">{benefit.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4 text-center">{benefit.title}</h3>
            <p className="text-[#3A4E62]/80 mb-6 text-center">{benefit.desc}</p>
            <ul className="space-y-2">
              {benefit.benefits.map((item, bIndex) => (
                <li key={bIndex} className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                  <span className="text-[#3A4E62]/80">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Can you fix weak WiFi spots?",
            answer: "Yes! We specialize in eliminating WiFi dead zones. We conduct a thorough site survey to identify problem areas and use strategic placement of access points, WiFi extenders, or mesh systems to ensure strong, reliable coverage throughout your entire property."
          },
          {
            question: "Do you provide mesh systems?",
            answer: "Absolutely! We recommend and install professional mesh systems from leading brands like Ubiquiti, ASUS, and Netgear. Mesh systems provide seamless, whole-home coverage with a single network name and automatic device handoff as you move around."
          },
          {
            question: "Is installation included?",
            answer: "Yes, professional installation is included in all our WiFi upgrade packages. This includes site survey, equipment setup, configuration, security implementation, testing, and training on how to use your new system. We also provide ongoing support and maintenance."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function WiFiUpgrade() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "WiFi Installation",
      "name": "WiFi Upgrade Auckland",
      "description": "Boost your internet speed and coverage with professional WiFi upgrades. Comsys IT provides fast, reliable WiFi solutions for homes and offices.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can you fix weak WiFi spots?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes! We specialize in eliminating WiFi dead zones. We conduct a thorough site survey to identify problem areas and use strategic placement of access points, WiFi extenders, or mesh systems to ensure strong, reliable coverage throughout your entire property."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide mesh systems?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We recommend and install professional mesh systems from leading brands like Ubiquiti, ASUS, and Netgear. Mesh systems provide seamless, whole-home coverage with a single network name and automatic device handoff as you move around."
          }
        },
        {
          "@type": "Question",
          "name": "Is installation included?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, professional installation is included in all our WiFi upgrade packages. This includes site survey, equipment setup, configuration, security implementation, testing, and training on how to use your new system. We also provide ongoing support and maintenance."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "WiFi Upgrade Auckland",
          "item": "https://www.comsys.co.nz/WiFiUpgrade"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="WiFi Upgrade Auckland | Comsys IT"
        description="Boost your internet speed and coverage with professional WiFi upgrades. Comsys IT provides fast, reliable WiFi solutions for homes and offices."
        keywords="WiFi upgrade Auckland, mesh networks, wireless installation, WiFi dead zones, office WiFi, home WiFi"
        canonical="https://www.comsys.co.nz/WiFiUpgrade"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyUpgradeSection />
      <OfficeWiFiSection />
      <HomeWiFiSection />
      <ProfessionalSetupSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready for Lightning-Fast WiFi?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free WiFi assessment and eliminate dead zones with our professional upgrade service.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=WiFiUpgrade")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free WiFi Assessment
              </Button>
            </Link>
            <Link to="https://ui.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Professional Equipment <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}