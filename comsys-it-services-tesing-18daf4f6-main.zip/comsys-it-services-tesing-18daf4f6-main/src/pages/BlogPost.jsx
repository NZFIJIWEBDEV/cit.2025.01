import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Post } from '@/api/entities';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import { Calendar, User, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';

export default function BlogPostPage() {
  const [post, setPost] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const fetchPost = async () => {
      const params = new URLSearchParams(location.search);
      const slug = params.get('slug');
      if (!slug) {
        setIsLoading(false);
        return;
      }
      
      setIsLoading(true);
      try {
        const fetchedPosts = await Post.filter({ slug });
        if (fetchedPosts.length > 0) {
          setPost(fetchedPosts[0]);
        }
      } catch (error) {
        console.error("Failed to fetch post:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPost();
  }, [location.search]);

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">Loading post...</div>;
  }

  if (!post) {
    return (
        <div className="flex flex-col justify-center items-center h-screen text-center">
            <h2 className="text-2xl font-bold mb-4">Post not found</h2>
            <p className="mb-6">The article you're looking for doesn't exist or may have been moved.</p>
            <Link to={createPageUrl("Insights")}>
                <Button>
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to All Articles
                </Button>
            </Link>
        </div>
    );
  }

  return (
    <div className="bg-white text-[#3A4E62]">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-16 md:py-24">
        <motion.article initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="mb-8">
            <Link to={createPageUrl("Insights")} className="text-[#53B289] hover:text-[#4aa07b] flex items-center mb-4 text-sm font-semibold">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Insights
            </Link>
            <p className="text-[#53B289] font-bold text-base mb-2">{post.category}</p>
            <h1 className="text-3xl md:text-5xl font-bold text-[#3A4E62] mb-4 leading-tight">{post.title}</h1>
            <div className="flex items-center space-x-6 text-sm text-[#3A4E62]/70">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>By {post.authorName}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <time dateTime={post.publishedDate}>
                  Published on {format(new Date(post.publishedDate), 'MMMM d, yyyy')}
                </time>
              </div>
            </div>
          </div>
          
          <img 
            src={post.featuredImageUrl} 
            alt={post.title} 
            className="w-full h-auto max-h-96 object-cover rounded-2xl mb-8 md:mb-12 shadow-lg"
          />

          <div className="prose prose-lg max-w-none text-[#3A4E62] prose-headings:text-[#3A4E62] prose-a:text-[#53B289] prose-strong:text-[#3A4E62]">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>
        </motion.article>
      </div>
    </div>
  );
}