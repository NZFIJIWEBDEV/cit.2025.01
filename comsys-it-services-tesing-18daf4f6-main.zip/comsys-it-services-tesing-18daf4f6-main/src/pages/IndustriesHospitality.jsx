import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Utensils, Wifi, CreditCard, Monitor } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Hospitality in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT services for Auckland hospitality businesses. Comsys IT provides reliable POS systems, guest WiFi, and IT support for hotels, cafes, and restaurants.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=HospitalityIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Hospitality IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Hospitality Businesses
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&h=400&fit=crop" 
            alt="Hospitality IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Enhancing the Guest Experience</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              In hospitality, technology is key to providing a seamless guest experience, 
              from online bookings and reliable guest WiFi to efficient POS systems and secure payment processing.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Wifi, title: "Reliable Guest WiFi", desc: "Providing fast and secure internet access for guests is now a standard expectation." },
              { icon: CreditCard, title: "POS & Payment Systems", desc: "Ensuring payment systems are fast, reliable, and secure to keep service flowing." },
              { icon: Monitor, title: "Booking & Reservation Systems", desc: "Integration and support for online booking platforms and property management systems." },
              { icon: Utensils, title: "Operational Efficiency", desc: "Using technology to streamline orders, manage staff, and control inventory." }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const GuestWiFiSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Secure & Reliable Guest WiFi
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">5-Star WiFi for Your Guests</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We design and install robust WiFi networks that provide excellent coverage and speed for your guests, 
              while keeping your business network secure.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "Separate guest network to protect your business data.",
              "Branded login portal with your logo and terms of service.",
              "Bandwidth management to ensure fair usage and reliability.",
              "Content filtering to create a family-friendly environment.",
              "Full coverage across rooms, restaurants, and common areas.",
              "24/7 monitoring and support to ensure uptime."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1543269664-76bc3997d9ea?w=600&h=400&fit=crop" 
            alt="Guest WiFi Hospitality Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const POSSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        POS & Booking System Support
      </h2>
       <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Streamline Your Operations</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            We provide setup, integration, and support for leading hospitality POS, reservation, and property management systems.
          </p>
          {[
            "POS hardware and software setup and support.",
            "Integration with payment gateways and EFTPOS terminals.",
            "Support for online booking and reservation platforms.",
            "Integration with kitchen display systems and printers.",
            "Inventory and stock management system support."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
            <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Supported Platforms Include:</h4>
            <div className="grid grid-cols-2 gap-4">
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">Lightspeed</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">Toast</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">ResDiary</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">and more...</span>
            </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Hospitality Businesses
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Enhances Guest Stays</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our hospitality IT solutions are designed to improve guest satisfaction, increase positive reviews, 
            and streamline your operations for better profitability.
          </p>
          {[
            "Improved guest satisfaction with reliable WiFi and services.",
            "Increased operational efficiency with integrated systems.",
            "Faster checkout and payment processing.",
            "Enhanced security for guest and business data.",
            "Reduced downtime for critical systems like POS and bookings."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT revamped our hotel's guest WiFi network, and the positive feedback has been overwhelming. Guests love the speed and reliability. Their support for our POS system has also been fantastic, ensuring our restaurant service is never interrupted."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Utensils className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">David Miller</div>
              <div className="text-sm text-[#3A4E62]/70">General Manager, The Harbour View Hotel</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Can you provide reliable WiFi for our hotel/cafe guests?",
            answer: "Yes, we specialize in designing and installing high-performance, secure guest WiFi networks for hospitality venues. We ensure full coverage, fast speeds, and a secure, separate network that protects your business operations while providing an excellent online experience for your guests."
          },
          {
            question: "Do you support hospitality POS and booking systems?",
            answer: "Absolutely. We provide support for a wide range of Point-of-Sale (POS), reservation, and Property Management Systems (PMS) used in the hospitality industry. We can help with setup, integration with payment systems, and ongoing troubleshooting to keep your operations running smoothly."
          },
          {
            question: "How do you ensure our payment systems are secure?",
            answer: "We ensure your payment systems are secure and PCI DSS compliant by implementing secure network configurations, firewalls, and data encryption. We isolate your payment processing network from guest networks to protect sensitive customer credit card information."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesHospitality() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Hospitality in Auckland",
      "description": "IT services for Auckland hospitality businesses. Comsys IT provides reliable POS systems, guest WiFi, and IT support for hotels, cafes, and restaurants.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Hospitality IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Can you provide reliable WiFi for our hotel/cafe guests?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we specialize in designing and installing high-performance, secure guest WiFi networks for hospitality venues. We ensure full coverage, fast speeds, and a secure, separate network that protects your business operations while providing an excellent online experience for your guests." }
        },
        {
          "@type": "Question", "name": "Do you support hospitality POS and booking systems?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We provide support for a wide range of Point-of-Sale (POS), reservation, and Property Management Systems (PMS) used in the hospitality industry. We can help with setup, integration with payment systems, and ongoing troubleshooting to keep your operations running smoothly." }
        },
        {
          "@type": "Question", "name": "How do you ensure our payment systems are secure?",
          "acceptedAnswer": { "@type": "Answer", "text": "We ensure your payment systems are secure and PCI DSS compliant by implementing secure network configurations, firewalls, and data encryption. We isolate your payment processing network from guest networks to protect sensitive customer credit card information." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Hospitality in Auckland", "item": "https://www.comsys.co.nz/IndustriesHospitality" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Hospitality in Auckland | Comsys IT"
        description="IT services for Auckland hospitality businesses. Comsys IT provides reliable POS systems, guest WiFi, and IT support for hotels, cafes, and restaurants."
        keywords="hospitality IT support Auckland, hotel WiFi, restaurant POS systems, cafe IT support"
        canonical="https://www.comsys.co.nz/IndustriesHospitality"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <GuestWiFiSection />
      <POSSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}