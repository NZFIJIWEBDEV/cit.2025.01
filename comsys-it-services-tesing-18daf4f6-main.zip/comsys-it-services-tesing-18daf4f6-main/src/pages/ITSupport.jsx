import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Shield, Clock, Users, ExternalLink, Headphones, Monitor, Wifi, Database } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Support Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Reliable IT support for Auckland businesses. Local helpdesk, remote, and onsite support with fast response times from Comsys IT.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ITSupportQuote")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { icon: Clock, title: "Fast Response", desc: "Less than 1 hour response for critical issues" },
          { icon: Shield, title: "Proactive Security", desc: "Advanced cybersecurity and threat protection" },
          { icon: Users, title: "Local Team", desc: "Auckland-based technicians who understand your business" },
          { icon: CheckCircle, title: "Proven Results", desc: "99.9% uptime guarantee with 500+ satisfied clients" }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 rounded-xl hover:shadow-lg transition-shadow"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-4 mx-auto">
              <item.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{item.title}</h3>
            <p className="text-[#3A4E62]/80">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const FullITSupportSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Full IT Support Services
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="space-y-6">
            {[
              { icon: Headphones, title: "24/7 Helpdesk Support", desc: "Unlimited support tickets with priority handling for critical issues" },
              { icon: Monitor, title: "Proactive System Monitoring", desc: "Continuous monitoring to prevent issues before they impact your business" },
              { icon: Wifi, title: "Network Management", desc: "Complete network setup, optimization, and ongoing maintenance" },
              { icon: Database, title: "Data Management", desc: "Backup, recovery, and data security to protect your valuable information" }
            ].map((service, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <service.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{service.title}</h3>
                  <p className="text-[#3A4E62]/80">{service.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:pl-8">
          <img 
            src="https://images.unsplash.com/photo-1556075798-4825dfaaf498?w=600&h=400&fit=crop" 
            alt="IT Support Team Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const ProactiveMonitoringSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Proactive Monitoring & Security
      </h2>
      <div className="grid md:grid-cols-3 gap-8">
        {[
          { title: "24/7 System Monitoring", desc: "Continuous monitoring of servers, networks, and critical systems", benefits: ["Early issue detection", "Automated alerts", "Performance optimization"] },
          { title: "Advanced Cybersecurity", desc: "Multi-layered security protection against modern threats", benefits: ["Endpoint protection", "Email security", "Threat intelligence"] },
          { title: "Automated Maintenance", desc: "Scheduled updates, patches, and system maintenance", benefits: ["Security patches", "Software updates", "System optimization"] }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{item.title}</h3>
            <p className="text-[#3A4E62]/80 mb-6">{item.desc}</p>
            <ul className="space-y-2">
              {item.benefits.map((benefit, bIndex) => (
                <li key={bIndex} className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                  <span className="text-[#3A4E62]/80">{benefit}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const FlexiblePlansSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Flexible Support Plans
      </h2>
      <div className="grid md:grid-cols-3 gap-8">
        {[
          { name: "Essential", price: "From $99/month", desc: "Perfect for small businesses", features: ["Remote support", "Email support", "Basic monitoring", "Patch management"] },
          { name: "Professional", price: "From $199/month", desc: "Comprehensive IT management", features: ["24/7 monitoring", "On-site support", "Cybersecurity", "Data backup"], popular: true },
          { name: "Enterprise", price: "Custom quote", desc: "Full IT outsourcing solution", features: ["Dedicated account manager", "Strategic planning", "Custom solutions", "SLA guarantees"] }
        ].map((plan, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className={`bg-white rounded-xl p-8 shadow-lg relative ${plan.popular ? 'ring-2 ring-[#53B289] scale-105' : ''}`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#53B289] text-white px-4 py-1 rounded-full text-sm font-semibold">
                Most Popular
              </div>
            )}
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-2">{plan.name}</h3>
            <div className="text-3xl font-bold text-[#53B289] mb-4">{plan.price}</div>
            <p className="text-[#3A4E62]/80 mb-6">{plan.desc}</p>
            <ul className="space-y-3 mb-8">
              {plan.features.map((feature, fIndex) => (
                <li key={fIndex} className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-[#53B289] mr-3" />
                  <span className="text-[#3A4E62]/80">{feature}</span>
                </li>
              ))}
            </ul>
            <Button className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Started
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you offer 24/7 support?",
            answer: "Yes, we provide 24/7 monitoring and emergency support for critical issues. Our helpdesk operates during business hours (8AM-6PM) with after-hours emergency support available for urgent matters."
          },
          {
            question: "Do you support both Windows and Mac?",
            answer: "Absolutely! Our technicians are certified in both Windows and macOS environments. We provide comprehensive support for mixed environments, ensuring all your devices work seamlessly together."
          },
          {
            question: "Can you provide managed services?",
            answer: "Yes, we specialize in managed IT services. This includes proactive monitoring, maintenance, cybersecurity, data backup, and strategic IT planning to keep your business running smoothly while reducing costs."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function ITSupport() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Managed IT Support",
      "name": "IT Support Auckland",
      "description": "Reliable IT support for Auckland businesses. Comsys IT provides local helpdesk, remote, and onsite support with fast response times.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you offer 24/7 support?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide 24/7 monitoring and emergency support for critical issues. Our helpdesk operates during business hours (8AM-6PM) with after-hours emergency support available for urgent matters."
          }
        },
        {
          "@type": "Question",
          "name": "Do you support both Windows and Mac?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! Our technicians are certified in both Windows and macOS environments. We provide comprehensive support for mixed environments, ensuring all your devices work seamlessly together."
          }
        },
        {
          "@type": "Question",
          "name": "Can you provide managed services?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in managed IT services. This includes proactive monitoring, maintenance, cybersecurity, data backup, and strategic IT planning to keep your business running smoothly while reducing costs."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Support Auckland",
          "item": "https://www.comsys.co.nz/ITSupport"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Support Auckland | Comsys IT"
        description="Reliable IT support for Auckland businesses. Comsys IT provides local helpdesk, remote, and onsite support with fast response times."
        keywords="IT support Auckland, managed IT services, helpdesk support, remote IT support, onsite IT support"
        canonical="https://www.comsys.co.nz/ITSupport"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseSection />
      <FullITSupportSection />
      <ProactiveMonitoringSection />
      <FlexiblePlansSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready for Reliable IT Support?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free IT assessment and discover how we can improve your technology infrastructure.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=ITSupport")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Assessment
              </Button>
            </Link>
            <Link to="https://microsoft.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn About Microsoft Partnership <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}