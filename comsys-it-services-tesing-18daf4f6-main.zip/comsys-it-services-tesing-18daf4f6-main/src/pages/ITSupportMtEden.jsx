
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Mt Eden's businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Thriving Mt Eden
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        In the stylish and bustling hub of Mt Eden Village, boutique businesses, professional services, and popular eateries need IT that is as sophisticated and reliable as they are. Comsys IT provides expert, responsive support tailored to the unique needs of the Mt Eden community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=MtEdenITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Mt Eden Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Small Business Specialists", 
            desc: "IT solutions specifically designed for the professional services, retail, and home offices common in Mt Eden.",
            icon: Building
          },
          { 
            title: "Local Auckland Team", 
            desc: "Fast, friendly support from our Auckland-based technicians who are familiar with the Mt Eden area.",
            icon: Users
          },
          { 
            title: "Professional & Discreet", 
            desc: "Service that respects the character of Mt Eden's professional practices and residential areas.",
            icon: Shield
          },
          { 
            title: "Scalable Solutions", 
            desc: "Flexible IT support that can grow alongside your Mt Eden business, from startup to established practice.",
            icon: CheckCircle
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Building, 
      title: "IT for Professional Services", 
      desc: "For the lawyers, accountants, and consultants in Mt Eden, we deliver secure, efficient, and scalable IT solutions that protect client data and boost productivity.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Users, 
      title: "Boutique Retail & Hospitality IT", 
      desc: "We provide robust IT solutions for Mt Eden's vibrant hospitality and retail scene, including reliable POS systems, secure payment processing, and seamless Guest WiFi.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Privacy", 
      desc: "Protect your valuable client and business data with our robust data backup and cybersecurity solutions, designed to keep your Mt Eden business secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Mt Eden Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Mt Eden businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Industries We Support in Mt Eden
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {[
          {
            title: "Professional Services",
            desc: "Lawyers, accountants, architects, and consultants in Mt Eden rely on us for secure client data management, reliable communication systems, and compliant IT infrastructure."
          },
          {
            title: "Boutique Retail & Hospitality",
            desc: "We support the unique shops, cafes, and restaurants in Mt Eden Village with robust POS systems, guest Wi-Fi, and inventory management solutions."
          },
          {
            title: "Healthcare & Wellness Practitioners",
            desc: "Clinics, therapists, and wellness centers require secure patient record systems, compliant data handling, and reliable appointment booking software."
          },
          {
            title: "Home-Based Businesses",
            desc: "A growing number of Mt Eden entrepreneurs trust us to provide professional, enterprise-level IT support for their home offices, ensuring reliability and security."
          },
          {
            title: "Creative & Design Studios",
            desc: "We provide high-performance workstations, large file management solutions, and collaborative tools for the creative professionals based in the area."
          },
          {
            title: "Real Estate Agencies",
            desc: "Local real estate offices need reliable CRM software, mobile access to listings, and secure document handling for contracts and client information."
          }
        ].map((industry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 p-6 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{industry.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{industry.desc}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-[#53B289]/10 p-8 rounded-2xl border border-[#53B289]/20">
        <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Mt Eden Success Story</h3>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Challenge:</strong> A busy accounting firm in Mt Eden Village was experiencing frequent network outages and slow system performance during peak tax season, impacting their ability to meet client deadlines. Their previous IT provider was unresponsive and lacked local presence.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Solution:</strong> Comsys IT conducted a full audit of their IT infrastructure, upgraded their network hardware, implemented a proactive monitoring system, and deployed a robust data backup solution. We now provide them with our managed IT support package.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed">
          <strong>Result:</strong> The firm has experienced zero downtime in the 18 months since, leading to a 30% increase in productivity during their busiest periods. Our local, responsive support gives them the confidence to focus on their clients, knowing their IT is in expert hands.
        </p>
      </div>
    </div>
  </section>
);

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Mt Eden Service Area & Location
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Onsite Support Across Mt Eden</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Comsys IT provides comprehensive onsite and remote IT support for businesses across the entire Mt Eden suburb. From the bustling hub of Mt Eden Village to the professional offices along Dominion Road and the many home-based businesses on its residential streets, our team is ready to assist.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our local Auckland technicians are familiar with the area, ensuring we can provide prompt and efficient service wherever your business is located in Mt Eden. We understand the value of quick, in-person support when a critical issue arises.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> 30-minute response for Mt Eden businesses</p>
              <p><strong>Coverage:</strong> Mt Eden Village, Dominion Road, and all residential streets</p>
              <p><strong>Support:</strong> Onsite & Remote Support Available</p>
              <p><strong>Specialization:</strong> Professional Services & Small Business IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25529.74088019686!2d174.74312497678586!3d-36.88365114757279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47d4e3895e3d%3A0x500ef6143a29950!2sMount%20Eden%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695861117621!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Mt Eden Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our local IT team provides fast support throughout Mt Eden and surrounding central suburbs.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My business is based in a character building in Mt Eden. Can you handle the IT installation?",
      a: "Yes, absolutely. We have extensive experience working within character and heritage buildings across Auckland, including Mt Eden. We are adept at planning and executing IT installations, such as cabling for networks and security systems, in a way that is discreet and respects the building's unique architecture and integrity."
    },
    {
      q: "How quickly can you get a technician onsite to our office in Mt Eden?",
      a: "For businesses in Mt Eden, we can typically have a technician onsite within 60-90 minutes for urgent issues. Our central Auckland location allows for rapid dispatch to all inner-city suburbs. For non-urgent matters, we schedule visits at your earliest convenience."
    },
    {
      q: "We are a small professional practice in Mt Eden. Are your IT support plans affordable for us?",
      a: "Yes, our support plans are designed to be scalable and affordable for small to medium-sized businesses. We offer flexible packages that can be tailored to your specific needs and budget, ensuring you get enterprise-level support without the enterprise price tag. This provides cost-effective access to a full team of IT experts."
    },
    {
      q: "Do you support businesses that operate from a home office in Mt Eden?",
      a: "We certainly do. Supporting home-based professionals is one of our specialties. We can set up your home office with business-grade security, a professional phone system, and reliable internet to ensure you can operate as efficiently and securely as a traditional office."
    },
    {
      q: "Can you help us secure our client data to meet industry compliance standards?",
      a: "Yes. Data security and compliance are at the core of our services for professional practices. We can implement a multi-layered security strategy, including firewalls, endpoint protection, and secure data backup, to ensure your client data is protected and you meet your industry's regulatory requirements."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Mt Eden Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=MtEdenITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportMtEden() {
  const pageUrl = "https://www.comsys.co.nz/it-support-mt-eden-auckland";
  const title = "IT Support Mt Eden Auckland | Comsys IT | Professional Services";
  const description = "Local IT support for Mt Eden businesses. We specialize in supporting professional services, retail, and home offices. Get fast, reliable tech support today.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT support services for businesses in Mt Eden, Auckland.",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Mt Eden, Auckland"
      },
      "serviceType": [
        "IT Support", "Managed IT Services", "VoIP Solutions", "Business Fibre", "Data Backup"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How quickly can you get a technician onsite to our office in Mt Eden?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "For urgent issues affecting businesses in Mt Eden, we can typically have a technician onsite within 60-90 minutes. Our local Auckland base allows for rapid dispatch to all central suburbs."
          }
        },
        {
          "@type": "Question",
          "name": "Are your IT support plans affordable for small professional practices in Mt Eden?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, our support plans are scalable and designed to be affordable for small to medium-sized businesses like those common in Mt Eden. We offer flexible packages tailored to your specific needs and budget."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Mt Eden, professional services IT, boutique IT support, Auckland IT services"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <IndustriesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
