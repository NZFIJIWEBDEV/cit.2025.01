import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Printer, Wrench, Wifi, Building, DollarSign, Clock, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Printer Services for Auckland Businesses
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Printer setup, maintenance, and repairs for businesses in Auckland. Comsys IT keeps your printers running smoothly.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=PrinterServices")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Printer Support Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const SetupInstallationSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Setup & Installation
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?w=600&h=400&fit=crop" 
            alt="Printer Setup Installation Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Professional Printer Setup</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Get your new printer up and running quickly with professional installation and configuration. 
              We ensure optimal placement, network connectivity, and user access for maximum productivity.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Installation Services Include:</h4>
            {[
              {
                title: "Physical Setup & Placement",
                desc: "Optimal positioning for accessibility and workflow efficiency"
              },
              {
                title: "Network Configuration",
                desc: "WiFi or ethernet connection with secure network access"
              },
              {
                title: "Driver Installation",
                desc: "Latest drivers installed on all workstations and mobile devices"
              },
              {
                title: "User Training",
                desc: "Training staff on basic operations, maintenance, and troubleshooting"
              },
              {
                title: "Security Setup",
                desc: "Access controls, user authentication, and secure printing features"
              },
              {
                title: "Testing & Optimization",
                desc: "Print quality testing and performance optimization"
              }
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-50 rounded-lg p-4"
              >
                <h5 className="font-semibold text-[#3A4E62] mb-2">{service.title}</h5>
                <p className="text-sm text-[#3A4E62]/80">{service.desc}</p>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-[#3A4E62] mb-3">Printer Brands We Support:</h4>
            <div className="grid md:grid-cols-2 gap-2 text-sm text-[#3A4E62]/80">
              <div>• HP • Canon • Epson • Brother</div>
              <div>• Xerox • Ricoh • Kyocera • Lexmark</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const RepairsTroubleshootingSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Repairs & Troubleshooting
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Common Print Issues",
            icon: Printer,
            problems: [
              "Paper jams and feeding problems",
              "Poor print quality or faded output",
              "Printer not responding or offline",
              "Error messages and warning lights",
              "Slow printing or long delays",
              "Network connectivity issues"
            ]
          },
          {
            title: "Hardware Repairs",
            icon: Wrench,
            problems: [
              "Broken paper trays and covers",
              "Worn out rollers and belts",
              "Faulty sensors and switches",
              "Power supply and motherboard issues",
              "Print head cleaning and replacement",
              "Mechanical component repairs"
            ]
          },
          {
            title: "Software & Network",
            icon: Wifi,
            problems: [
              "Driver conflicts and updates",
              "Print spooler service issues",
              "Network configuration problems",
              "Mobile printing setup",
              "Cloud printing configuration",
              "User permission and access issues"
            ]
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-6">
              <category.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6">{category.title}</h3>
            <ul className="space-y-3">
              {category.problems.map((problem, pIndex) => (
                <li key={pIndex} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-[#3A4E62]/80">{problem}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-red-50 border border-red-200 rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-red-800 mb-4">Emergency Printer Repair Service</h3>
          <p className="text-lg text-red-700 mb-6">
            When your business-critical printer fails, we provide same-day emergency repair service. 
            Our technicians carry common parts and can resolve most issues on the first visit.
          </p>
          <div className="grid md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-3xl font-bold text-red-600">2 Hour</div>
              <div className="text-sm text-red-700">Emergency Response</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-red-600">90%</div>
              <div className="text-sm text-red-700">Fixed First Visit</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-red-600">24/7</div>
              <div className="text-sm text-red-700">Emergency Hotline</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const NetworkPrintingSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Network Printing
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Shared Network Printing Solutions</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Enable efficient printing across your entire office network. Share printers among multiple users, 
              departments, and locations with secure, managed access controls.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Network Printing Features:</h4>
            {[
              {
                title: "Multi-User Access",
                desc: "Multiple users can print to the same device with queue management"
              },
              {
                title: "Print Management Software",
                desc: "Monitor usage, set quotas, and control access by user or department"
              },
              {
                title: "Mobile & Remote Printing",
                desc: "Print from smartphones, tablets, and remote locations securely"
              },
              {
                title: "Secure Print Release",
                desc: "Hold jobs until user authentication prevents sensitive document exposure"
              },
              {
                title: "Department Cost Tracking",
                desc: "Track printing costs by department or project for accurate billing"
              },
              {
                title: "Automatic Driver Distribution",
                desc: "Deploy printer drivers automatically to new computers and users"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-[#3A4E62] mb-2">{feature.title}</h5>
                <p className="text-sm text-[#3A4E62]/80">{feature.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Network Printing Benefits:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Reduce hardware costs by sharing fewer devices</li>
              <li>• Improve security with user authentication</li>
              <li>• Track and control printing costs effectively</li>
              <li>• Enable flexible work arrangements</li>
            </ul>
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1577562212200-b2b07540a2b6?w=600&h=400&fit=crop" 
            alt="Network Printing Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const ManagedPrintServicesSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Managed Print Services
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?w=600&h=400&fit=crop" 
            alt="Managed Print Services Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Print Management Solution</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Take the hassle out of printer management with our comprehensive managed print services. 
              Fixed monthly costs, automatic supply delivery, and proactive maintenance included.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-6 mb-8">
            <h4 className="text-lg font-semibold text-[#3A4E62] mb-4">What's Included:</h4>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h5 className="font-semibold text-[#3A4E62] mb-2">Hardware & Maintenance:</h5>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Printer lease or purchase</li>
                  <li>• Regular maintenance visits</li>
                  <li>• Parts and labor coverage</li>
                  <li>• Replacement units if needed</li>
                </ul>
              </div>
              <div>
                <h5 className="font-semibold text-[#3A4E62] mb-2">Supplies & Support:</h5>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Automatic toner delivery</li>
                  <li>• All consumables included</li>
                  <li>• 24/7 technical support</li>
                  <li>• Usage monitoring & reporting</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Managed Print Benefits:</h4>
            {[
              {
                icon: DollarSign,
                title: "Predictable Costs",
                desc: "Fixed monthly fee covers everything - no surprise repair bills or supply costs"
              },
              {
                icon: Clock,
                title: "Reduced Downtime",
                desc: "Proactive monitoring prevents issues before they impact productivity"
              },
              {
                icon: CheckCircle,
                title: "Simplified Management",
                desc: "One point of contact for all your printing needs and support"
              },
              {
                icon: Building,
                title: "Scalable Solution",
                desc: "Easily add or remove devices as your business grows or changes"
              }
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <benefit.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h5 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h5>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center">
            <Link to={createPageUrl("ContactUs?subject=ManagedPrint")}>
              <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                Get Managed Print Quote
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you repair all brands?",
            answer: "Yes, we service and repair all major printer brands including HP, Canon, Epson, Brother, Xerox, Ricoh, Kyocera, and Lexmark. Our technicians are trained on various printer technologies and carry common parts for most popular models. For specialty or older equipment, we can source parts as needed."
          },
          {
            question: "Do you offer managed print contracts?",
            answer: "Absolutely! Our managed print services include equipment lease or purchase, automatic toner delivery, regular maintenance, parts and labor coverage, and 24/7 support for a fixed monthly fee. This provides predictable costs and ensures your printers are always running optimally."
          },
          {
            question: "Can you connect printers to WiFi?",
            answer: "Yes, we specialize in wireless printer setup and configuration. We can connect your printers to your existing WiFi network, configure security settings, install drivers on all devices, and provide mobile printing capabilities. We ensure secure, reliable wireless printing for your entire office."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function PrinterServices() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Printer Services",
      "name": "Printer Services Auckland",
      "description": "Printer setup, maintenance, and repairs for businesses in Auckland. Comsys IT keeps your printers running smoothly.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you repair all brands?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we service and repair all major printer brands including HP, Canon, Epson, Brother, Xerox, Ricoh, Kyocera, and Lexmark. Our technicians are trained on various printer technologies and carry common parts for most popular models. For specialty or older equipment, we can source parts as needed."
          }
        },
        {
          "@type": "Question",
          "name": "Do you offer managed print contracts?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! Our managed print services include equipment lease or purchase, automatic toner delivery, regular maintenance, parts and labor coverage, and 24/7 support for a fixed monthly fee. This provides predictable costs and ensures your printers are always running optimally."
          }
        },
        {
          "@type": "Question",
          "name": "Can you connect printers to WiFi?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in wireless printer setup and configuration. We can connect your printers to your existing WiFi network, configure security settings, install drivers on all devices, and provide mobile printing capabilities. We ensure secure, reliable wireless printing for your entire office."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Printer Services Auckland",
          "item": "https://www.comsys.co.nz/PrinterServices"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="Printer Services Auckland | Comsys IT"
        description="Printer setup, maintenance, and repairs for businesses in Auckland. Comsys IT keeps your printers running smoothly."
        keywords="printer repair Auckland, printer setup, managed print services, network printing, printer maintenance"
        canonical="https://www.comsys.co.nz/PrinterServices"
        schemas={schemas}
      />
      
      <PageHero />
      <SetupInstallationSection />
      <RepairsTroubleshootingSection />
      <NetworkPrintingSection />
      <ManagedPrintServicesSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Need Reliable Printer Support?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get professional printer services that keep your business printing efficiently and cost-effectively.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=PrinterSupport")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Printer Support Quote
              </Button>
            </Link>
            <Link to="https://www.hp.com/nz-en/printers" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Browse Business Printers <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}