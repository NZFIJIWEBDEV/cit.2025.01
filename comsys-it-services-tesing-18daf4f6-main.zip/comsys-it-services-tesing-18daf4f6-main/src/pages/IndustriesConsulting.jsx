import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Users, Briefcase, Cloud, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Consulting Firms in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland consulting firms. Comsys IT provides secure collaboration tools, client data protection, and reliable IT infrastructure for consultants.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ConsultingIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Consulting IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

export default function IndustriesConsulting() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Consulting Firms in Auckland",
      "description": "IT support for Auckland consulting firms. Comsys IT provides secure collaboration tools, client data protection, and reliable IT infrastructure for consultants.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Consulting IT Support" }
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Consulting Firms Auckland | Comsys IT"
        description="IT support for Auckland consulting firms. Comsys IT provides secure collaboration tools, client data protection, and reliable IT infrastructure for consultants."
        keywords="consulting IT support Auckland, consultant technology, collaboration tools, consulting firm IT, professional services IT"
        canonical="https://www.comsys.co.nz/IndustriesConsulting"
        schemas={schemas}
      />
      
      <PageHero />
      {/* Add more sections as needed */}
    </div>
  );
}