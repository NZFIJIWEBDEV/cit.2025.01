import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Heart, Shield, Camera, Phone, ExternalLink, Users } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Aged Care Providers in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Reliable IT solutions for aged care providers in Auckland. Comsys IT delivers secure systems, CCTV, and VoIP for aged care facilities.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=AgedCareIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Aged Care IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ITNeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Aged Care
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=600&h=400&fit=crop" 
            alt="Aged Care IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Critical IT Requirements for Aged Care</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Aged care facilities require specialized IT solutions that prioritize resident safety, 
              family communication, regulatory compliance, and secure management of sensitive health information.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Heart,
                title: "Resident Safety Systems",
                desc: "Emergency call systems, monitoring, and rapid response capabilities"
              },
              {
                icon: Shield,
                title: "Health Data Security",
                desc: "Protection of resident medical records and personal information"
              },
              {
                icon: Camera,
                title: "Security & Monitoring",
                desc: "CCTV systems for facility security and resident safety"
              },
              {
                icon: Users,
                title: "Family Communication",
                desc: "Video calling and communication systems for resident-family connections"
              }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Aged Care Industry Challenges:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Regulatory compliance with health and safety standards</li>
              <li>• Staff communication and coordination across shifts</li>
              <li>• Family engagement and communication needs</li>
              <li>• Emergency response and notification systems</li>
              <li>• Resident privacy and dignity requirements</li>
              <li>• Integration with healthcare systems</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SecurityCCTVSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Security & CCTV Systems
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Comprehensive Security Solutions</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Aged care facilities require advanced security systems that balance resident safety with 
              privacy and dignity. Our solutions provide comprehensive monitoring while respecting individual rights.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">CCTV System Features:</h4>
            {[
              {
                title: "Strategic Camera Placement",
                desc: "Common areas, entrances, and corridors while respecting private spaces"
              },
              {
                title: "High-Definition Recording",
                desc: "Clear 4K video quality for accurate incident documentation"
              },
              {
                title: "Night Vision Capability",
                desc: "24/7 monitoring with infrared technology for low-light conditions"
              },
              {
                title: "Remote Monitoring",
                desc: "Access live feeds and recordings from mobile devices and computers"
              },
              {
                title: "Motion Detection Alerts",
                desc: "Intelligent alerts for unusual activity or emergency situations"
              },
              {
                title: "Secure Data Storage",
                desc: "Encrypted recording storage with customizable retention periods"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h5 className="font-semibold text-green-800 mb-2">{feature.title}</h5>
                <p className="text-sm text-green-700">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1504813184591-01572f98c85f?w=600&h=400&fit=crop" 
            alt="Aged Care CCTV Security Auckland"
            className="rounded-xl shadow-lg w-full"
          />
          
          <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-yellow-800 mb-3">Security Benefits:</h4>
            <ul className="space-y-2 text-yellow-700">
              <li>• Enhanced resident safety and staff protection</li>
              <li>• Deterrent against theft and inappropriate behavior</li>
              <li>• Evidence for incident investigation and reporting</li>
              <li>• Family peace of mind about loved ones' safety</li>
              <li>• Compliance with aged care facility regulations</li>
              <li>• Integration with emergency response systems</li>
            </ul>
          </div>
          
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Privacy Protection:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• No cameras in private resident rooms or bathrooms</li>
              <li>• Privacy masking for sensitive areas</li>
              <li>• Access controls limiting who can view footage</li>
              <li>• Audit trails of all system access and usage</li>
              <li>• Compliance with Privacy Act 2020 requirements</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CommunicationSolutionsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Communication Solutions
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            category: "VoIP Phone Systems",
            features: [
              "Multi-line systems for staff coordination",
              "Emergency hotline connections",
              "Call recording for compliance",
              "Mobile integration for on-call staff",
              "Auto-attendant for incoming calls",
              "Conference calling capabilities"
            ],
            icon: "📞"
          },
          {
            category: "Video Communication",
            features: [
              "Family video calling systems",
              "Telehealth consultations",
              "Group video calls for activities",
              "Large screen displays in common areas",
              "Mobile video calling support",
              "Recording capabilities for special events"
            ],
            icon: "📹"
          },
          {
            category: "Emergency Systems",
            features: [
              "Nurse call button systems",
              "Emergency broadcast capabilities",
              "Staff paging and alert systems",
              "Integration with security cameras",
              "Automated emergency notifications",
              "Response time tracking"
            ],
            icon: "🚨"
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
          >
            <div className="text-4xl mb-4 text-center">{category.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6 text-center">{category.category}</h3>
            <ul className="space-y-3">
              {category.features.map((feature, fIndex) => (
                <li key={fIndex} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                  <span className="text-[#3A4E62]/80 text-sm">{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Integrated Communication Platform</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-8">
            Our communication solutions are designed specifically for aged care facilities, 
            integrating all communication needs into a single, easy-to-use platform.
          </p>
          <div className="grid md:grid-cols-2 gap-8 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">For Staff:</h4>
              <ul className="space-y-2">
                {[
                  "Instant communication between shifts",
                  "Emergency alert systems",
                  "Patient call management",
                  "Mobile phone integration",
                  "Conference calling for meetings"
                ].map((staff, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{staff}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">For Families:</h4>
              <ul className="space-y-2">
                {[
                  "Scheduled video calls with residents",
                  "Emergency contact notifications",
                  "Care team communication updates",
                  "Group calls for family meetings",
                  "Easy-to-use interface for seniors"
                ].map((family, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{family}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Aged Care Providers
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Specialized Aged Care IT Expertise</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand the unique challenges of aged care facilities and provide specialized IT solutions 
              that enhance resident care while meeting regulatory requirements and supporting staff efficiency.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                title: "Aged Care Industry Experience",
                desc: "Deep understanding of aged care workflows, regulations, and resident needs"
              },
              {
                title: "24/7 Emergency Support",
                desc: "Critical IT support for systems that can't fail when resident safety is at stake"
              },
              {
                title: "Regulatory Compliance",
                desc: "Solutions designed to meet aged care standards and audit requirements"
              },
              {
                title: "Staff Training & Support",
                desc: "Comprehensive training for care staff on communication and safety systems"
              },
              {
                title: "Family Engagement Tools",
                desc: "Technology that helps maintain strong family connections with residents"
              },
              {
                title: "Scalable Solutions",
                desc: "IT systems that grow with your facility and adapt to changing needs"
              }
            ].map((benefit, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Heart className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
            <blockquote className="text-[#3A4E62]/80 italic mb-4">
              "Comsys IT installed our complete security and communication system. The CCTV gives families 
              peace of mind, while the video calling system has transformed how our residents stay connected 
              with loved ones. Emergency response times improved by 60% with the new nurse call integration."
            </blockquote>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-[#3A4E62]">Margaret Thompson</div>
                <div className="text-sm text-[#3A4E62]/70">Facility Manager, Sunset Manor Aged Care</div>
              </div>
            </div>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-8">
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Aged Care IT Services Include:</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Safety & Security:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• CCTV security systems</li>
                  <li>• Emergency call systems</li>
                  <li>• Access control systems</li>
                  <li>• Fire safety integration</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Communication:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• VoIP phone systems</li>
                  <li>• Video calling platforms</li>
                  <li>• Staff communication tools</li>
                  <li>• Family engagement systems</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide onsite support for aged care?",
            answer: "Yes, we provide dedicated onsite support for aged care facilities. Our technicians understand the sensitive nature of aged care environments and work respectfully around residents and staff. We offer scheduled maintenance visits, emergency callouts, and staff training to ensure your systems operate smoothly and safely."
          },
          {
            question: "Can you install CCTV for facilities?",
            answer: "Absolutely. We specialize in aged care CCTV installations that balance security with resident privacy and dignity. Our systems include strategic camera placement in common areas and corridors, high-definition recording, motion detection, remote monitoring capabilities, and secure storage with appropriate retention policies, all while complying with Privacy Act requirements."
          },
          {
            question: "Do you help with resident data security?",
            answer: "Yes, we implement comprehensive data security measures to protect sensitive resident information. This includes encrypted data storage, access controls limiting who can view resident records, audit trails of all data access, secure backup systems, and compliance with Privacy Act 2020 and health information standards. We ensure resident confidentiality while maintaining system accessibility for authorized staff."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesAgedCare() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Aged Care Providers Auckland",
      "description": "Reliable IT solutions for aged care providers in Auckland. Comsys IT delivers secure systems, CCTV, and VoIP for aged care facilities.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": {
          "@type": "City",
          "name": "Auckland"
        },
        "serviceType": "Aged Care IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide onsite support for aged care?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide dedicated onsite support for aged care facilities. Our technicians understand the sensitive nature of aged care environments and work respectfully around residents and staff. We offer scheduled maintenance visits, emergency callouts, and staff training to ensure your systems operate smoothly and safely."
          }
        },
        {
          "@type": "Question",
          "name": "Can you install CCTV for facilities?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We specialize in aged care CCTV installations that balance security with resident privacy and dignity. Our systems include strategic camera placement in common areas and corridors, high-definition recording, motion detection, remote monitoring capabilities, and secure storage with appropriate retention policies, all while complying with Privacy Act requirements."
          }
        },
        {
          "@type": "Question",
          "name": "Do you help with resident data security?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we implement comprehensive data security measures to protect sensitive resident information. This includes encrypted data storage, access controls limiting who can view resident records, audit trails of all data access, secure backup systems, and compliance with Privacy Act 2020 and health information standards. We ensure resident confidentiality while maintaining system accessibility for authorized staff."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Industries",
          "item": "https://www.comsys.co.nz/Industries"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Solutions for Aged Care Auckland",
          "item": "https://www.comsys.co.nz/IndustriesAgedCare"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Aged Care Auckland | Comsys IT"
        description="Reliable IT solutions for aged care providers in Auckland. Comsys IT delivers secure systems, CCTV, and VoIP for aged care facilities."
        keywords="aged care IT support Auckland, nursing home CCTV, aged care communication systems, resident data security"
        canonical="https://www.comsys.co.nz/IndustriesAgedCare"
        schemas={schemas}
      />
      
      <PageHero />
      <ITNeedsSection />
      <SecurityCCTVSection />
      <CommunicationSolutionsSection />
      <BenefitsSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Enhance Your Aged Care Facility with Smart IT Solutions
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get specialized IT systems designed for aged care facilities. Improve resident safety, 
            family communication, and staff efficiency with professional IT support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=AgedCareITConsultation")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Aged Care IT Assessment
              </Button>
            </Link>
            <Link to={createPageUrl("CCTVBusiness")}>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn About CCTV Solutions
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}