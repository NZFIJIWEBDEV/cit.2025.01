
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Milford businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Professional IT Support for Milford
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the premium retail stores, professional services, and local businesses in Milford, sophisticated and reliable IT is a necessity. Comsys IT provides expert, discreet, and responsive support tailored to the high standards of the Milford community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=MilfordITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Milford Professionals & Retailers Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            title: "Support for Professional Services",
            desc: "Expertise in supporting law firms, accountants, healthcare clinics, and consultants common in the Milford area.",
            icon: Building
          },
          {
            title: "Premium Retail IT Solutions",
            desc: "Specialized support for high-end retail, including POS systems, inventory management, and secure payment processing.",
            icon: CheckCircle
          },
          {
            title: "Discreet & Professional Service",
            desc: "Our technicians provide courteous, professional, and discreet service that respects your business environment.",
            icon: Users
          },
          {
            title: "North Shore Local Team",
            desc: "Fast, responsive support from our local North Shore team who can be onsite in Milford quickly when needed.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
  const services = [
    {
      icon: Building,
      title: "IT for Professional Services",
      desc: "For the lawyers, accountants, and consultants in Milford, we deliver secure, efficient, and scalable IT solutions that protect client data and boost productivity.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    {
      icon: Shield,
      title: "Advanced Data & Privacy Protection",
      desc: "Protect your sensitive personal and business information with our advanced cybersecurity services, including data encryption, secure cloud backups, and proactive threat monitoring.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    {
      icon: Users,
      title: "Discreet Onsite & Remote Support",
      desc: "Our professional technicians provide prompt, discreet, and expert support, both remotely and onsite, ensuring minimal disruption to your business in Milford.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Milford Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Milford businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Supporting Milford's Professional & Retail Sectors
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {[
          {
            title: "Professional Services",
            desc: "IT support for Milford's lawyers, accountants, and consultants, focusing on data security, privacy, and uptime."
          },
          {
            title: "Healthcare & Medical Clinics",
            desc: "Providing secure, compliant IT systems for doctors, dentists, and specialists to protect patient data and ensure reliability."
          },
          {
            title: "High-End Retail & Boutiques",
            desc: "Expert support for POS systems, inventory management, e-commerce integration, and secure payment systems in Milford."
          },
          {
            title: "Real Estate Agencies",
            desc: "Reliable IT for managing listings, client communications, and mobile access for agents on the go in the Milford area."
          },
          {
            title: "Hospitality & Cafes",
            desc: "Supporting cafes and restaurants with guest Wi-Fi, modern POS systems, and reliable network infrastructure."
          },
          {
            title: "Home-Based Professionals",
            desc: "Delivering enterprise-level IT security and support for the many consultants and professionals working from home in Milford."
          }
        ].map((industry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 p-6 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{industry.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{industry.desc}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-[#53B289]/10 p-8 rounded-2xl border border-[#53B289]/20">
        <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Milford Success Story</h3>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Challenge:</strong> A prominent law firm in Milford was concerned about the security of their sensitive client data and frustrated by their slow, outdated server. Their previous IT provider was unresponsive and lacked specialization.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Solution:</strong> Comsys IT migrated the firm to a secure, modern cloud server, enhancing accessibility and performance. We implemented multi-layered cybersecurity protocols, including advanced email filtering and encrypted data backups, and put them on a proactive managed services plan.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed">
          <strong>Result:</strong> The firm now operates with complete confidence in their data security and privacy. System speed has increased by over 300%, boosting staff productivity. Our responsive, professional support allows the partners to focus on their clients, not their technology.
        </p>
      </div>
    </div>
  </section>
);

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Your Local IT Partner in Milford
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Onsite Support on the North Shore</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Comsys IT is a proud North Shore based company, perfectly positioned to provide fast and efficient onsite support to businesses throughout Milford. Whether you're located in the Milford Shopping Centre, on Kitchener Road, or in a nearby office park, our local team is just minutes away.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             This local presence, combined with our powerful remote support tools, ensures that your IT issues are resolved with maximum speed and minimum disruption to your business.
            </p>
          </div>

          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Fast local response for the Milford area</p>
              <p><strong>Coverage:</strong> Milford, Takapuna, Castor Bay, and surrounding North Shore suburbs</p>
              <p><strong>Support:</strong> Onsite, Remote, and Managed IT Services</p>
              <p><strong>Specialization:</strong> Professional Services & Premium Retail IT</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12779.130638515093!2d174.76813158716383!3d-36.7865239!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d39600a94483f%3A0x500ef6143a2b400!2sMilford%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695863262650!5m2!1sen!2snz"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Milford Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our North Shore team offers dedicated IT support across Milford and surrounding areas.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My medical practice in Milford needs IT support that understands patient privacy. Can you help?",
      a: "Yes, this is a core area of our expertise. We understand the importance of patient confidentiality and the requirements of the Health Information Privacy Code. We implement secure systems and protocols to ensure your patient data is protected, your network is secure, and your practice remains compliant."
    },
    {
      q: "Our retail store in Milford Shopping Centre needs better POS and inventory system support. Is this something you do?",
      a: "Absolutely. We provide expert support for a wide range of Point of Sale (POS) and inventory management systems. We can ensure your systems are reliable, secure, and integrated, minimizing transaction issues and providing you with accurate stock data. We also provide support outside of peak retail hours to minimize disruption."
    },
    {
      q: "What is the primary benefit of your managed IT service for a small Milford law firm?",
      a: "The primary benefit is peace of mind and proactive prevention. Instead of waiting for a critical system to fail, we are constantly monitoring your IT environment to prevent issues. This maximizes your billable hours by minimizing downtime and ensures your data is always secure, allowing you to focus entirely on your legal work."
    },
    {
      q: "Can you install a discreet but effective CCTV system for my boutique store?",
      a: "Yes. We specialize in designing and installing security systems that are both highly effective and aesthetically pleasing. We use modern, compact cameras and conceal wiring to ensure the system blends into your store's decor while providing complete coverage and excellent image quality."
    },
    {
      q: "How can you make our team more productive with technology?",
      a: "We focus on optimizing your workflow. This can involve migrating you to faster cloud services like Microsoft 365 for better collaboration, implementing a VoIP phone system for more efficient communication, and ensuring your network and computers are always running at peak speed. By removing technological friction, your team can naturally become more productive."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Milford Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=MilfordITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportMilford() {
  const pageUrl = "https://www.comsys.co.nz/it-support-milford-auckland";
  const title = "IT Support Milford | Comsys IT | North Shore Professionals";
  const description = "Premium IT support for businesses in Milford, Auckland. We specialize in supporting professional services and retail with managed IT, security, and VoIP.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Premium IT Support for businesses in Milford and the North Shore.",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Level 1, 30 St Benedicts Street",
        "addressLocality": "Auckland",
        "postalCode": "1010",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Milford, Auckland"
      },
      "serviceType": [
        "IT Support", "Managed IT Services", "Retail IT Support", "Professional Services IT", "CCTV Installation"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "My medical practice in Milford needs IT support that understands patient privacy. Can you help?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we have deep expertise in supporting healthcare clinics and understand the importance of patient data privacy under the Health Information Privacy Code. We implement secure, compliant systems to protect your practice."
          }
        },
        {
          "@type": "Question",
          "name": "Our retail store in Milford Shopping Centre needs better POS support. Is this something you do?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We provide expert support for a wide range of Point of Sale (POS) and inventory management systems, ensuring they are reliable, secure, and efficient to support your retail operations."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Milford, North Shore IT services, professional services IT, Milford business IT"
        canonical={pageUrl}
        schemas={schemas}
      />

      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <IndustriesSection /> {/* IndustriesSection was not removed in the outline, so preserving it */}
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
