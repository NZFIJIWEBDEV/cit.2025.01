import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Zap, Cloud, Shield, Code } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for IT Startups in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Scalable IT infrastructure for Auckland tech startups. Comsys IT provides cloud solutions, cybersecurity, and IT support for growing tech companies.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=StartupIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Startup IT Consultation
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

export default function IndustriesITStartups() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for IT Startups in Auckland",
      "description": "Scalable IT infrastructure for Auckland tech startups. Comsys IT provides cloud solutions, cybersecurity, and IT support for growing tech companies.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Startup IT Support" }
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for IT Startups Auckland | Comsys IT"
        description="Scalable IT infrastructure for Auckland tech startups. Comsys IT provides cloud solutions, cybersecurity, and IT support for growing tech companies."
        keywords="startup IT support Auckland, tech startup IT, scalable IT infrastructure, startup cloud solutions, tech company IT"
        canonical="https://www.comsys.co.nz/IndustriesITStartups"
        schemas={schemas}
      />
      
      <PageHero />
      {/* Add more sections as needed */}
    </div>
  );
}