import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Laptop, Wrench, Clock, HardDrive, Cpu, Monitor, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        PC & Laptop Repair Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Affordable PC and laptop repairs in Auckland. Comsys IT fixes hardware, software, and performance issues for businesses and individuals.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=PCRepairQuote")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Repair Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const CommonIssuesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Common Issues We Fix
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { 
            title: "Slow Performance", 
            desc: "Computer running slowly, freezing, or taking forever to boot up",
            icon: Cpu,
            symptoms: ["Long boot times", "Programs freezing", "Blue screen errors", "High CPU usage"]
          },
          { 
            title: "Screen Problems", 
            desc: "Cracked screens, display issues, or no image showing",
            icon: Monitor,
            symptoms: ["Cracked LCD screen", "Black screen", "Flickering display", "Dead pixels"]
          },
          { 
            title: "Hardware Failures", 
            desc: "Hard drive failures, memory issues, or component problems",
            icon: HardDrive,
            symptoms: ["Hard drive clicking", "RAM errors", "Overheating", "Power issues"]
          },
          { 
            title: "Virus & Malware", 
            desc: "Computer infected with viruses, malware, or ransomware",
            icon: Wrench,
            symptoms: ["Pop-up ads", "Slow internet", "Suspicious programs", "File encryption"]
          },
          { 
            title: "Software Issues", 
            desc: "Operating system problems, corrupted files, or software conflicts",
            icon: Laptop,
            symptoms: ["Won't boot up", "Program crashes", "Missing files", "Update errors"]
          },
          { 
            title: "Network Problems", 
            desc: "WiFi connectivity issues or network adapter problems",
            icon: CheckCircle,
            symptoms: ["No internet", "Slow connection", "WiFi dropping out", "Network errors"]
          }
        ].map((issue, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8 hover:shadow-lg transition-shadow"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-6">
              <issue.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{issue.title}</h3>
            <p className="text-[#3A4E62]/80 mb-6">{issue.desc}</p>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-3">Common Symptoms:</h4>
              <ul className="space-y-1">
                {issue.symptoms.map((symptom, sIndex) => (
                  <li key={sIndex} className="flex items-center text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                    <span className="text-[#3A4E62]/80">{symptom}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const HardwareUpgradesSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Hardware Upgrades
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=600&h=400&fit=crop" 
            alt="PC Hardware Upgrade Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Boost Your Computer's Performance</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Don't buy a new computer when an upgrade might be all you need. We can significantly improve your system's speed and performance with targeted hardware upgrades.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { 
                title: "SSD Upgrades", 
                desc: "Replace slow hard drives with lightning-fast SSDs", 
                benefit: "Up to 10x faster boot times",
                price: "From $180"
              },
              { 
                title: "RAM Memory Upgrades", 
                desc: "Add more memory for better multitasking", 
                benefit: "Handle more programs simultaneously",
                price: "From $120"
              },
              { 
                title: "Graphics Card Upgrades", 
                desc: "Better graphics for gaming, design, and video", 
                benefit: "Improved visual performance",
                price: "From $250"
              },
              { 
                title: "CPU & Motherboard", 
                desc: "Complete system refresh for maximum performance", 
                benefit: "Like having a brand new computer",
                price: "From $400"
              }
            ].map((upgrade, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-md">
                <div className="flex justify-between items-start mb-3">
                  <h4 className="text-lg font-semibold text-[#3A4E62]">{upgrade.title}</h4>
                  <span className="text-[#53B289] font-bold">{upgrade.price}</span>
                </div>
                <p className="text-[#3A4E62]/80 mb-2">{upgrade.desc}</p>
                <p className="text-sm text-[#53B289] font-medium">{upgrade.benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const VirusRemovalSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Virus Removal
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Virus & Malware Removal</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Is your computer infected with viruses, malware, or ransomware? We use professional-grade tools and techniques to completely remove all threats and protect your system.
            </p>
          </div>
          
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-red-800 mb-3">Signs Your Computer May Be Infected:</h4>
            <ul className="space-y-2 text-red-700">
              <li>• Computer running much slower than usual</li>
              <li>• Pop-up ads appearing constantly</li>
              <li>• Programs opening or closing by themselves</li>
              <li>• Browser redirecting to suspicious websites</li>
              <li>• Files mysteriously disappearing or encrypted</li>
              <li>• Unusual network activity or data usage</li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Our Virus Removal Process:</h4>
            {[
              "Complete system scan using multiple professional tools",
              "Remove all viruses, malware, and potentially unwanted programs",
              "Repair system files and registry entries",
              "Update all software and security patches",
              "Install and configure reliable antivirus protection",
              "Provide prevention tips and security recommendations"
            ].map((step, index) => (
              <div key={index} className="flex items-start space-x-3">
                <span className="bg-[#53B289] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                  {index + 1}
                </span>
                <span className="text-[#3A4E62]/80">{step}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&h=400&fit=crop" 
            alt="Virus Removal Services Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const FastTurnaroundSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Fast Turnaround Times
      </h2>
      <div className="grid md:grid-cols-3 gap-8">
        {[
          {
            title: "Same Day Service",
            time: "Same Day",
            desc: "Many software issues and simple repairs can be completed the same day you bring your device in.",
            icon: Clock,
            color: "text-green-600"
          },
          {
            title: "Next Day Service",
            time: "24 Hours",
            desc: "Most hardware repairs including screen replacements and component upgrades are completed within 24 hours.",
            icon: Wrench,
            color: "text-blue-600"
          },
          {
            title: "Complex Repairs",
            time: "2-3 Days",
            desc: "Complex repairs requiring special parts or extensive troubleshooting typically take 2-3 business days.",
            icon: HardDrive,
            color: "text-orange-600"
          }
        ].map((service, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg text-center"
          >
            <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-6 mx-auto">
              <service.icon className={`w-8 h-8 ${service.color}`} />
            </div>
            <div className={`text-3xl font-bold ${service.color} mb-2`}>{service.time}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{service.title}</h3>
            <p className="text-[#3A4E62]/80">{service.desc}</p>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">No Fix, No Fee Guarantee</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-6">
            We're confident in our repair abilities. If we can't fix your device, you don't pay for the repair attempt. 
            We'll only charge for any parts that were used or if you approve additional services.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=RepairQuote")}>
              <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                Get Free Diagnosis
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "How long does a laptop repair take?",
            answer: "Most laptop repairs are completed within 24-48 hours. Simple software issues can often be fixed the same day, while hardware repairs like screen replacements typically take 1-2 business days. We'll provide you with a time estimate when you drop off your device."
          },
          {
            question: "Do you replace parts?",
            answer: "Yes, we stock common replacement parts and can source specific components as needed. We use high-quality replacement parts and offer warranties on all hardware we install. For specialized parts, we can order them quickly from our supplier network."
          },
          {
            question: "Can you recover data?",
            answer: "Yes, data recovery is one of our specialties. We can recover files from damaged hard drives, corrupted systems, and even accidentally deleted files. We use professional data recovery tools and techniques, with success rates over 90% for most common data loss scenarios."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function PCLaptopRepair() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Computer Repair",
      "name": "PC & Laptop Repairs Auckland",
      "description": "Affordable PC and laptop repairs in Auckland. Comsys IT fixes hardware, software, and performance issues for businesses and individuals.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How long does a laptop repair take?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Most laptop repairs are completed within 24-48 hours. Simple software issues can often be fixed the same day, while hardware repairs like screen replacements typically take 1-2 business days. We'll provide you with a time estimate when you drop off your device."
          }
        },
        {
          "@type": "Question",
          "name": "Do you replace parts?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we stock common replacement parts and can source specific components as needed. We use high-quality replacement parts and offer warranties on all hardware we install. For specialized parts, we can order them quickly from our supplier network."
          }
        },
        {
          "@type": "Question",
          "name": "Can you recover data?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, data recovery is one of our specialties. We can recover files from damaged hard drives, corrupted systems, and even accidentally deleted files. We use professional data recovery tools and techniques, with success rates over 90% for most common data loss scenarios."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "PC & Laptop Repairs Auckland",
          "item": "https://www.comsys.co.nz/PCLaptopRepair"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="PC & Laptop Repairs Auckland | Comsys IT"
        description="Affordable PC and laptop repairs in Auckland. Comsys IT fixes hardware, software, and performance issues for businesses and individuals."
        keywords="PC repair Auckland, laptop repair Auckland, computer repair, virus removal, hardware upgrade Auckland"
        canonical="https://www.comsys.co.nz/PCLaptopRepair"
        schemas={schemas}
      />
      
      <PageHero />
      <CommonIssuesSection />
      <HardwareUpgradesSection />
      <VirusRemovalSection />
      <FastTurnaroundSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Need Your Computer Fixed Fast?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Bring your device in for a free diagnosis and get back to work quickly with our expert repair services.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=ComputerRepair")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Diagnosis
              </Button>
            </Link>
            <Link to="https://www.intel.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Hardware Specifications <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}