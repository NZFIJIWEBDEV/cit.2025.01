import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Home, Phone, Users, Database } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Real Estate Agencies in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support and VoIP for Auckland real estate agencies. Comsys IT keeps your agents connected and your data secure.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=RealEstateIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Real Estate IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Challenges for Real Estate
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop" 
            alt="Real Estate IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Keeping Agents Connected and Competitive</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Real estate is a mobile business. Agents need reliable technology to stay connected with clients, 
              access property information on the go, and close deals from anywhere.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Phone, title: "Mobile Communication", desc: "Agents need reliable phone systems that work from home, office, or showing properties." },
              { icon: Database, title: "CRM & Lead Management", desc: "Integrating communication systems with property management and CRM software." },
              { icon: Users, title: "Remote Agent Support", desc: "Supporting agents who work from home or are frequently out of the office." },
              { icon: Home, title: "Client Data Security", desc: "Protecting sensitive client information and financial data from cyber threats." }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const VoIPRemoteSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        VoIP for Remote Agents
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Stay Connected Anywhere</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Our VoIP solutions ensure your agents can make and receive calls using their business number 
              whether they're at home, in the office, or showing a property.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "Mobile app to use office number on personal smartphone.",
              "Call forwarding and routing to ensure no missed leads.",
              "Auto-attendant to direct calls to available agents.",
              "Call recording for training and quality assurance.",
              "Integration with popular real estate CRM systems.",
              "Voicemail-to-email for instant message notifications."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Real Estate VoIP Benefits:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Never miss a potential buyer or seller call</li>
              <li>• Professional image with consistent business number</li>
              <li>• Lower costs compared to traditional phone systems</li>
              <li>• Easy scaling as your agency grows</li>
            </ul>
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=600&h=400&fit=crop" 
            alt="Real Estate VoIP Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const CRMSupportSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        CRM & Software Support
      </h2>
       <div className="grid md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
        >
          <div className="text-4xl mb-4">📊</div>
          <h3 className="text-xl font-bold text-[#3A4E62] mb-4">CRM Integration</h3>
          <p className="text-[#3A4E62]/80 mb-4">We integrate your phone system and IT infrastructure with popular real estate CRM and property management platforms.</p>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>Click-to-call directly from your CRM.</li>
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>Automatic call logging and contact updates.</li>
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>Lead tracking and follow-up automation.</li>
          </ul>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
        >
          <div className="text-4xl mb-4">🏠</div>
          <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Property Management Software</h3>
          <p className="text-[#3A4E62]/80 mb-4">Support for specialized real estate software including MLS platforms, property listing tools, and transaction management systems.</p>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>MLS and listing platform integration.</li>
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>Document management and e-signature solutions.</li>
            <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2"/>Mobile access to property information.</li>
          </ul>
        </motion.div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Real Estate Agencies
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Closes Deals</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            We provide reliable IT and communication solutions that help your agents stay responsive, 
            professional, and competitive in Auckland's dynamic real estate market.
          </p>
          {[
            "Increased lead conversion with better communication systems.",
            "Enhanced professional image with reliable technology.",
            "Improved agent productivity with mobile-friendly solutions.",
            "Better client data security and privacy protection.",
            "Scalable technology that grows with your agency."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Since Comsys IT set up our VoIP system, our agents can take calls anywhere using their business number. We haven't missed a single lead, and our response time to enquiries has improved dramatically. It's been a game-changer for our sales."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Home className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Lisa Chen</div>
              <div className="text-sm text-[#3A4E62]/70">Managing Director, Auckland Realty Plus</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you integrate with real estate CRM systems?",
            answer: "Yes, we have experience integrating communication and IT systems with popular real estate CRM platforms. This includes features like click-to-call, automatic call logging, and ensuring your agents have seamless access to client information and property details."
          },
          {
            question: "Can agents use their business number on mobile?",
            answer: "Absolutely. Our VoIP solutions include mobile apps that allow your agents to make and receive calls using their business number on their personal smartphones. This ensures they maintain a professional image and never miss important calls, whether they're at home, in the office, or showing properties."
          },
          {
            question: "Do you provide IT support for remote agents?",
            answer: "Yes, we specialize in supporting remote and mobile workers, which is perfect for real estate agents. We provide secure remote access solutions, cloud-based systems, and responsive technical support to keep your agents productive wherever they work."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesRealEstate() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Real Estate Agencies Auckland",
      "description": "IT support and VoIP for Auckland real estate agencies. Comsys IT keeps your agents connected and your data secure.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Real Estate IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you integrate with real estate CRM systems?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we have experience integrating communication and IT systems with popular real estate CRM platforms. This includes features like click-to-call, automatic call logging, and ensuring your agents have seamless access to client information and property details." }
        },
        {
          "@type": "Question", "name": "Can agents use their business number on mobile?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. Our VoIP solutions include mobile apps that allow your agents to make and receive calls using their business number on their personal smartphones. This ensures they maintain a professional image and never miss important calls, whether they're at home, in the office, or showing properties." }
        },
        {
          "@type": "Question", "name": "Do you provide IT support for remote agents?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we specialize in supporting remote and mobile workers, which is perfect for real estate agents. We provide secure remote access solutions, cloud-based systems, and responsive technical support to keep your agents productive wherever they work." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Real Estate Agencies Auckland", "item": "https://www.comsys.co.nz/IndustriesRealEstate" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Real Estate Auckland | Comsys IT"
        description="IT support and VoIP for Auckland real estate agencies. Comsys IT keeps your agents connected and your data secure."
        keywords="real estate IT support Auckland, VoIP for real estate agents, CRM integration, real estate technology"
        canonical="https://www.comsys.co.nz/IndustriesRealEstate"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <VoIPRemoteSection />
      <CRMSupportSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}