
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Hillsborough businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Hillsborough Businesses
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the professional services, home-based businesses, and local enterprises in Hillsborough, reliable and discreet IT support is essential. Comsys IT provides expert, tailored technology solutions to ensure your business operates securely and efficiently, allowing you to focus on your clients and community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=HillsboroughITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Hillsborough Home-Based Businesses Trust Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            title: "Home Office Specialists",
            desc: "Expert setup and support for professional home offices, ensuring enterprise-level performance and security.",
            icon: Home
          },
          {
            title: "Reliable Connectivity",
            desc: "We provide high-speed business fibre and robust WiFi solutions perfect for video conferencing and large file transfers.",
            icon: Wifi
          },
          {
            title: "Discreet & Professional",
            desc: "Our technicians provide respectful, professional service that is mindful of your home environment.",
            icon: Users
          },
          {
            title: "Local Auckland Team",
            desc: "Fast, friendly, and reliable support from our local team who can easily service the Hillsborough area.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    {
      icon: Home,
      title: "Home Office & Professional IT",
      desc: "We specialize in creating secure, high-performance home office environments for the many professionals and consultants working from Hillsborough, with business-grade internet and robust data security.",
      link: "HomeFibre",
      imageUrl: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Users,
      title: "Managed IT for Small Businesses",
      desc: "Our managed IT plans are perfect for local businesses in Hillsborough. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Shield,
      title: "Data Security & Privacy",
      desc: "Protect your valuable client and business data with our robust data backup and cybersecurity solutions, designed to keep your Hillsborough business secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Hillsborough Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Hillsborough businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
    <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Your Local IT Support in Hillsborough</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Comsys IT provides friendly, professional IT support to home-based businesses and residents throughout Hillsborough and the surrounding Auckland suburbs.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12758.11894901594!2d174.757388849646!3d-36.92484933128913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47a4d955e4e7%3A0x500ef6143a29b30!2sHillsborough%2C%20Auckland!5e0!3m2!1sen!2snz!4v1700016100876!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Hillsborough, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Can you make my home office IT as secure as a corporate office?',
      a: 'Yes, we can. We provide enterprise-grade security solutions that are scaled for home office use. This includes business-grade antivirus, secure data backup, and network security to protect your sensitive business and client information.'
    },
    {
      q: 'My WiFi is unreliable in my Hillsborough home. Can you fix it?',
      a: 'Absolutely. We specialize in diagnosing and fixing poor WiFi. We can install modern mesh WiFi systems that provide strong, reliable, and seamless coverage throughout your entire home, eliminating dead spots and dropouts.'
    },
    {
      q: 'Do you offer ongoing support for home-based businesses?',
      a: 'Yes, we offer flexible monthly support plans for home-based businesses. This provides peace of mind knowing that you have a professional IT team you can call on for any technical issues, just like in a large company.'
    },
    {
      q: 'Is business-grade fibre available for residential properties in Hillsborough?',
      a: 'In many cases, yes. We can assess your Hillsborough address and advise on the best available business-grade internet connections, which often provide higher reliability and better support than standard residential plans.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Hillsborough Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=HillsboroughITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportHillsborough() {
  const pageUrl = "https://www.comsys.co.nz/it-support-hillsborough";
  const title = "IT Support Hillsborough | Small Business & Home Office IT Auckland";
  const description = "Expert IT support for small businesses, home-based businesses, and professionals in Hillsborough. Comsys IT provides business-grade internet, WiFi, and data security solutions.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support for Small Businesses and Home Offices",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": "Auckland, NZ",
        "telephone": "0800724526"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Hillsborough, Auckland"
      },
      "description": "Professional IT support for small businesses, home offices, and professional services in Hillsborough, Auckland.",
      "name": "IT Support Hillsborough"
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Areas We Serve", "item": "https://www.comsys.co.nz/AreasWeServe" },
        { "@type": "ListItem", "position": 3, "name": "IT Support Hillsborough", "item": pageUrl }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can you make my home office IT as secure as a corporate office?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we can. We provide enterprise-grade security solutions that are scaled for home office use. This includes business-grade antivirus, secure data backup, and network security to protect your sensitive business and client information."
          }
        },
        {
          "@type": "Question",
          "name": "My WiFi is unreliable in my Hillsborough home. Can you fix it?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We specialize in diagnosing and fixing poor WiFi. We can install modern mesh WiFi systems that provide strong, reliable, and seamless coverage throughout your entire home, eliminating dead spots and dropouts."
          }
        },
        {
          "@type": "Question",
          "name": "Do you offer ongoing support for home-based businesses?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we offer flexible monthly support plans for home-based businesses. This provides peace of mind knowing that you have a professional IT team you can call on for any technical issues, just like in a large company."
          }
        },
        {
          "@type": "Question",
          "name": "Is business-grade fibre available for residential properties in Hillsborough?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "In many cases, yes. We can assess your Hillsborough address and advise on the best available business-grade internet connections, which often provide higher reliability and better support than standard residential plans."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Hillsborough, home office IT support, small business IT Auckland, professional services IT Hillsborough"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
