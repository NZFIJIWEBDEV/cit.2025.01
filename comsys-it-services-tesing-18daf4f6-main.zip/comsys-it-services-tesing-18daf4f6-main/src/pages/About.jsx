import React from 'react';
import AboutSection from '../components/sections/About';
import Seo from '../components/layout/Seo';

export default function AboutPage() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList", 
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "About Us",
          "item": "https://www.comsys.co.nz/About"
        }
      ]
    }
  ];

  return (
    <div className="pt-20">
      <Seo
        title="About Comsys IT | Auckland IT Support Company"
        description="Learn about Comsys IT, Auckland's trusted IT support company. We provide reliable IT services, CCTV, VoIP, and business technology solutions across New Zealand."
        keywords="about Comsys IT, Auckland IT company, IT support team, New Zealand IT services"
        canonical="https://www.comsys.co.nz/About"
        schemas={schemas}
      />
      <AboutSection />
    </div>
  );
}