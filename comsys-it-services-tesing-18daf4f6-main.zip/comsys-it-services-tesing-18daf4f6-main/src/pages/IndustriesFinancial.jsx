import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, DollarSign, Shield, TrendingUp, Lock, ExternalLink, AlertTriangle } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Financial Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Trusted IT solutions for Auckland financial firms. Comsys IT offers secure IT support, backup, and VoIP systems for the finance industry.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=FinancialServicesIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Financial IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Challenges in Finance IT
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&h=400&fit=crop" 
            alt="Financial Services IT Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Critical IT Requirements for Financial Services</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Financial services firms face stringent regulatory requirements, cybersecurity threats, 
              and the need for real-time data processing while maintaining client trust and confidentiality.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Shield,
                title: "Regulatory Compliance",
                desc: "Meeting strict financial industry regulations and audit requirements"
              },
              {
                icon: Lock,
                title: "Cybersecurity Threats",
                desc: "Financial firms are prime targets for sophisticated cyber attacks"
              },
              {
                icon: TrendingUp,
                title: "Real-Time Processing",
                desc: "Need for instant data processing and transaction systems"
              },
              {
                icon: DollarSign,
                title: "Client Data Protection",
                desc: "Safeguarding sensitive financial and personal client information"
              }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4 p-4 bg-red-50 rounded-lg border border-red-200"
              >
                <challenge.icon className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-red-800 mb-2">{challenge.title}</h4>
                  <p className="text-red-700 text-sm">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-yellow-800 mb-3">Financial Services Statistics:</h4>
            <ul className="space-y-2 text-yellow-700">
              <li>• Financial services experience 300+ cyberattacks per firm annually</li>
              <li>• Average cost of financial data breach: $5.97 million</li>
              <li>• 95% of financial firms have experienced attempted cyber attacks</li>
              <li>• Regulatory fines for data breaches can reach $50+ million</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SecureNetworksSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Secure Networks & Data
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Bank-Level Security Framework</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Financial services require the highest level of security. Our multi-layered security approach 
              provides bank-grade protection while maintaining system performance and accessibility.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Security Layers:</h4>
            {[
              {
                title: "Zero Trust Architecture",
                desc: "Never trust, always verify - comprehensive access controls for all users and devices"
              },
              {
                title: "Advanced Encryption",
                desc: "AES-256 encryption for all data in transit and at rest, with secure key management"
              },
              {
                title: "Multi-Factor Authentication",
                desc: "Strong authentication protocols including biometric and hardware token options"
              },
              {
                title: "Network Segmentation",
                desc: "Isolated networks for different business functions and security levels"
              },
              {
                title: "Real-Time Monitoring",
                desc: "24/7 security operations center monitoring for threats and anomalies"
              },
              {
                title: "Incident Response",
                desc: "Immediate threat response and containment procedures"
              }
            ].map((security, index) => (
              <div key={index} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h5 className="font-semibold text-green-800 mb-2">{security.title}</h5>
                <p className="text-sm text-green-700">{security.desc}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600&h=400&fit=crop" 
            alt="Financial Data Security Auckland"
            className="rounded-xl shadow-lg w-full"
          />
          
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Financial Compliance Standards:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Reserve Bank of New Zealand (RBNZ) requirements</li>
              <li>• Anti-Money Laundering and Countering Financing of Terrorism Act</li>
              <li>• Financial Markets Authority (FMA) regulations</li>
              <li>• Privacy Act 2020 data protection</li>
              <li>• Payment Card Industry (PCI) DSS standards</li>
              <li>• International financial reporting standards</li>
            </ul>
          </div>
          
          <div className="mt-6 bg-red-50 border border-red-200 rounded-xl p-6">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="text-lg font-semibold text-red-800 mb-2">Cyber Threat Landscape:</h4>
                <ul className="space-y-1 text-red-700 text-sm">
                  <li>• Ransomware targeting financial data</li>
                  <li>• Phishing attacks on client credentials</li>
                  <li>• Advanced persistent threats (APTs)</li>
                  <li>• Insider threat risks</li>
                  <li>• Supply chain vulnerabilities</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CloudSolutionsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Cloud Solutions for Finance
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            category: "Trading & Investment Platforms",
            systems: [
              "Bloomberg Terminal",
              "Thomson Reuters Eikon",
              "MetaTrader platforms",
              "Trading risk management systems",
              "Portfolio management tools",
              "Real-time market data feeds"
            ],
            icon: "📈"
          },
          {
            category: "Core Banking Systems",
            systems: [
              "Temenos T24",
              "Oracle FLEXCUBE",
              "FIS Profile",
              "Jack Henry Symitar",
              "Payment processing systems",
              "Loan origination platforms"
            ],
            icon: "🏦"
          },
          {
            category: "Regulatory & Compliance",
            systems: [
              "AML transaction monitoring",
              "FATCA/CRS reporting",
              "Regulatory reporting systems",
              "Risk management platforms",
              "Audit trail systems",
              "Compliance management tools"
            ],
            icon: "📊"
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
          >
            <div className="text-4xl mb-4 text-center">{category.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6 text-center">{category.category}</h3>
            <ul className="space-y-3">
              {category.systems.map((system, sIndex) => (
                <li key={sIndex} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                  <span className="text-[#3A4E62]/80 text-sm">{system}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Specialized Financial IT Services</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-8">
            Our financial services IT specialists understand regulatory requirements and provide 
            expert support for trading platforms, core banking systems, and compliance tools.
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Trading Systems:</h4>
              <ul className="space-y-2">
                {[
                  "Bloomberg terminal support",
                  "Trading platform integration",
                  "Market data feed management",
                  "Risk management system setup",
                  "High-frequency trading infrastructure"
                ].map((service, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{service}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Banking Infrastructure:</h4>
              <ul className="space-y-2">
                {[
                  "Core banking system support",
                  "Payment processing integration",
                  "ATM and branch connectivity",
                  "Mobile banking platforms",
                  "Customer relationship management"
                ].map((banking, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{banking}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Compliance & Security:</h4>
              <ul className="space-y-2">
                {[
                  "Regulatory reporting automation",
                  "AML transaction monitoring",
                  "Fraud detection systems",
                  "Audit trail management",
                  "Risk assessment tools"
                ].map((compliance, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{compliance}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Working with Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Financial Services Expertise</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand the critical nature of financial services and provide specialized IT solutions 
              that meet regulatory requirements while supporting business growth and client service.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                title: "Regulatory Compliance Assurance",
                desc: "Complete compliance framework meeting RBNZ, FMA, and AML/CFT requirements"
              },
              {
                title: "99.99% Uptime Guarantee",
                desc: "Mission-critical system reliability for trading and banking operations"
              },
              {
                title: "Real-Time Monitoring",
                desc: "24/7 monitoring of critical financial systems and immediate incident response"
              },
              {
                title: "Disaster Recovery Planning",
                desc: "Comprehensive business continuity plans with rapid recovery capabilities"
              },
              {
                title: "Cybersecurity Expertise",
                desc: "Advanced threat protection against sophisticated financial cyber attacks"
              },
              {
                title: "Scalable Infrastructure",
                desc: "IT solutions that grow with your business and adapt to market demands"
              }
            ].map((benefit, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
            <blockquote className="text-[#3A4E62]/80 italic mb-4">
              "Comsys IT implemented our trading platform infrastructure with zero downtime. Their understanding 
              of financial regulations and cybersecurity requirements was exceptional. We've processed over 
              $500M in transactions with 99.99% system uptime since implementation."
            </blockquote>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-[#3A4E62]">James Robertson</div>
                <div className="text-sm text-[#3A4E62]/70">CTO, Auckland Investment Partners</div>
              </div>
            </div>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-8">
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Financial IT Services Include:</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Trading & Investment:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Bloomberg terminal support</li>
                  <li>• Trading platform management</li>
                  <li>• Market data integration</li>
                  <li>• Risk management systems</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Security & Compliance:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Regulatory compliance systems</li>
                  <li>• Cybersecurity monitoring</li>
                  <li>• Data encryption services</li>
                  <li>• Audit trail management</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide IT audits for financial companies?",
            answer: "Yes, we conduct comprehensive IT audits specifically designed for financial services firms. Our audits cover cybersecurity assessments, regulatory compliance reviews, system performance evaluations, and risk assessments. We provide detailed reports with recommendations to meet RBNZ, FMA, and other regulatory requirements while improving operational efficiency."
          },
          {
            question: "How do you secure sensitive data?",
            answer: "We implement bank-grade security measures including AES-256 encryption, zero trust architecture, multi-factor authentication, network segmentation, and 24/7 security monitoring. All solutions meet or exceed financial industry standards including PCI DSS, AML/CFT requirements, and Privacy Act 2020 compliance. Data is stored with New Zealand residency requirements."
          },
          {
            question: "Do you offer disaster recovery?",
            answer: "Absolutely. We provide comprehensive disaster recovery solutions with Recovery Time Objectives (RTO) of under 1 hour for critical financial systems. Our solutions include automated failover, real-time data replication, geographically distributed backup sites, and regular disaster recovery testing to ensure business continuity during any disruption."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesFinancial() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Financial Services Auckland",
      "description": "Trusted IT solutions for Auckland financial firms. Comsys IT offers secure IT support, backup, and VoIP systems for the finance industry.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": {
          "@type": "City",
          "name": "Auckland"
        },
        "serviceType": "Financial Services IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide IT audits for financial companies?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we conduct comprehensive IT audits specifically designed for financial services firms. Our audits cover cybersecurity assessments, regulatory compliance reviews, system performance evaluations, and risk assessments. We provide detailed reports with recommendations to meet RBNZ, FMA, and other regulatory requirements while improving operational efficiency."
          }
        },
        {
          "@type": "Question",
          "name": "How do you secure sensitive data?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We implement bank-grade security measures including AES-256 encryption, zero trust architecture, multi-factor authentication, network segmentation, and 24/7 security monitoring. All solutions meet or exceed financial industry standards including PCI DSS, AML/CFT requirements, and Privacy Act 2020 compliance. Data is stored with New Zealand residency requirements."
          }
        },
        {
          "@type": "Question",
          "name": "Do you offer disaster recovery?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We provide comprehensive disaster recovery solutions with Recovery Time Objectives (RTO) of under 1 hour for critical financial systems. Our solutions include automated failover, real-time data replication, geographically distributed backup sites, and regular disaster recovery testing to ensure business continuity during any disruption."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Industries",
          "item": "https://www.comsys.co.nz/Industries"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Solutions for Financial Services Auckland",
          "item": "https://www.comsys.co.nz/IndustriesFinancial"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Financial Services Auckland | Comsys IT"
        description="Trusted IT solutions for Auckland financial firms. Comsys IT offers secure IT support, backup, and VoIP systems for the finance industry."
        keywords="financial services IT support Auckland, banking IT solutions, trading platform support, financial compliance IT"
        canonical="https://www.comsys.co.nz/IndustriesFinancial"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <SecureNetworksSection />
      <CloudSolutionsSection />
      <BenefitsSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Secure Your Financial Services IT Infrastructure
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get bank-grade IT security and compliance solutions designed specifically for financial services. 
            Protect client assets and maintain regulatory compliance with expert IT support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=FinancialITAudit")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Financial IT Audit
              </Button>
            </Link>
            <Link to="https://www.rbnz.govt.nz" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View RBNZ Requirements <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}