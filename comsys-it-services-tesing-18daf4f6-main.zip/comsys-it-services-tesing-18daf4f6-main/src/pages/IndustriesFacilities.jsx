import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Building, Video, Network, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Facilities Management in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Integrated IT, CCTV, and network solutions for Auckland facilities management. Comsys IT ensures seamless operations and security.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=FacilitiesIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Facilities IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Facilities Management
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1600880292210-8593810474d5?w=600&h=400&fit=crop" 
            alt="Facilities Management IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Integrating Building Systems & Technology</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Facilities management relies on integrated IT systems to monitor, control, and secure buildings, 
              ensuring operational efficiency and safety for occupants.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Video, title: "Integrated CCTV Systems", desc: "Centralized security camera monitoring across multiple facilities." },
              { icon: Network, title: "Building Automation Networks", desc: "Reliable networks for BMS, HVAC, and access control systems." },
              { icon: Shield, title: "Cybersecurity for OT", desc: "Protecting operational technology from cyber threats." },
              { icon: Building, title: "Multi-site Management", desc: "Managing IT and security systems across a portfolio of properties." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CCTVSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Integrated CCTV Solutions
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Centralized Security Monitoring</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We design and install integrated CCTV systems that allow you to monitor all your facilities from a single, centralized location, 
              enhancing security and response times.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "High-definition IP cameras for clear footage.",
              "Network Video Recorders (NVRs) with ample storage.",
              "Remote access from any device (phone, tablet, computer).",
              "AI-powered video analytics for threat detection.",
              "Integration with access control and alarm systems.",
              "Regular maintenance and system health checks."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">CCTV Benefits for Facilities:</h4>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Enhanced Security</h5>
              <p className="text-sm text-[#3A4E62]/80">Deter theft, vandalism, and unauthorized access across all properties.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Operational Oversight</h5>
              <p className="text-sm text-[#3A4E62]/80">Monitor day-to-day operations, contractor work, and safety compliance.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Remote Management</h5>
              <p className="text-sm text-[#3A4E62]/80">View live and recorded footage from anywhere, at any time.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Facilities Management
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Streamlined Operations, Enhanced Security</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our integrated IT solutions help facilities managers improve operational efficiency, 
            reduce costs, and provide a safer environment for tenants and staff.
          </p>
          {[
            "Single point of contact for IT, CCTV, and network needs.",
            "Improved building security and safety.",
            "Increased operational efficiency through automation.",
            "Reduced risk of cyber threats to building systems.",
            "Proactive maintenance to prevent system downtime."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT integrated our CCTV and access control systems across our entire portfolio of commercial buildings. The centralized management has saved us countless hours and significantly improved our security posture. Their team is responsive and understands the unique needs of facilities management."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Building className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">David Chen</div>
              <div className="text-sm text-[#3A4E62]/70">Head of Facilities, Auckland Property Group</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you integrate with building management systems (BMS)?",
            answer: "Yes, we design and support the network infrastructure required for building management systems (BMS), HVAC controls, and other operational technology. We ensure these critical systems are secure and operate on a reliable network foundation."
          },
          {
            question: "Can you manage CCTV across multiple sites?",
            answer: "Absolutely. We specialize in designing and implementing centralized CCTV solutions that allow you to monitor and manage security cameras across multiple properties from a single interface. This includes remote access, cloud storage, and proactive system health monitoring."
          },
          {
            question: "Do you provide support for access control systems?",
            answer: "Yes, we support the IT and network components of modern access control systems. We can help integrate your access control with your CCTV and IT networks for a comprehensive security and management solution, ensuring seamless and secure operation."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesFacilities() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Facilities Management in Auckland",
      "description": "Integrated IT, CCTV, and network solutions for Auckland facilities management. Comsys IT ensures seamless operations and security.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Facilities Management IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you integrate with building management systems (BMS)?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we design and support the network infrastructure required for building management systems (BMS), HVAC controls, and other operational technology. We ensure these critical systems are secure and operate on a reliable network foundation." }
        },
        {
          "@type": "Question", "name": "Can you manage CCTV across multiple sites?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in designing and implementing centralized CCTV solutions that allow you to monitor and manage security cameras across multiple properties from a single interface. This includes remote access, cloud storage, and proactive system health monitoring." }
        },
        {
          "@type": "Question", "name": "Do you provide support for access control systems?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we support the IT and network components of modern access control systems. We can help integrate your access control with your CCTV and IT networks for a comprehensive security and management solution, ensuring seamless and secure operation." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Facilities Management in Auckland", "item": "https://www.comsys.co.nz/IndustriesFacilities" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Facilities Management Auckland | Comsys IT"
        description="Integrated IT, CCTV, and network solutions for Auckland facilities management. Comsys IT ensures seamless operations and security."
        keywords="facilities management IT, building management systems IT, multi-site CCTV Auckland, access control IT support"
        canonical="https://www.comsys.co.nz/IndustriesFacilities"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <CCTVSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}