
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Swanson businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Swanson Businesses
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the close-knit community of small businesses, home-based entrepreneurs, and local services in Swanson, having a reliable IT partner you can trust is essential. Comsys IT provides friendly, expert, and affordable IT support tailored to the needs of the Swanson community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=SwansonITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why the Swanson Community Trusts Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Genuinely Local Service", 
            desc: "As a West Auckland based company, we provide fast, friendly, and personal service to our neighbours in Swanson.",
            icon: Users
          },
          { 
            title: "Home Business Experts", 
            desc: "We specialize in setting up professional and secure IT systems for the many home-based businesses in Swanson.",
            icon: Home
          },
          { 
            title: "Reliable Connectivity", 
            desc: "Expertise in providing the best possible internet solutions, including fibre and rural options for the Swanson area.",
            icon: Wifi
          },
          { 
            title: "Affordable & Approachable", 
            desc: "We offer cost-effective support plans and down-to-earth advice that small community businesses can rely on.",
            icon: CheckCircle
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT for Small Businesses", 
      desc: "Our managed IT plans are perfect for local businesses in Swanson. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Home, 
      title: "Home Office & Lifestyle Blocks", 
      desc: "We specialize in creating secure, high-performance home office environments and providing reliable internet solutions for lifestyle properties in and around Swanson.",
      link: "HomeFibre",
      imageUrl: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Backup", 
      desc: "Protect your valuable business and personal data with our robust data backup and cybersecurity solutions, designed to keep your Swanson-based operations secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Swanson Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Swanson businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Your Local Support in Swanson
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">West Auckland Based, Swanson Focused</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Based in West Auckland, the Comsys IT team is just a short drive from Swanson. This local proximity means we can provide fast, responsive onsite support whenever it's needed, supplementing our excellent remote helpdesk services.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             We are committed to serving the local communities of West Auckland, and Swanson is a key area we are proud to support. We understand the value of friendly, reliable, face-to-face service.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Fast local response for Swanson community</p>
              <p><strong>Coverage:</strong> Swanson Village and surrounding residential and rural areas</p>
              <p><strong>Support:</strong> Onsite, Remote, and Managed IT Services</p>
              <p><strong>Specialization:</strong> Home Office & Small Community Business IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25547.40823908892!2d174.55745817678586!3d-36.88450124757279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d694f42555555%3A0x500ef6143a2b400!2sSwanson%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695862804598!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Swanson Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our West Auckland team provides dedicated IT support to the Swanson community.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "The internet at my Swanson home office is unreliable. Can you fix it?",
      a: "Yes. This is a common problem we solve. We will first check if fibre is available at your address. If so, we'll get you connected. If not, we will assess the best rural broadband, 4G/5G, or satellite options to provide you with the most stable and fast connection possible for your specific Swanson location."
    },
    {
      q: "Is it worth getting a professional IT setup for my home-based business in Swanson?",
      a: "Absolutely. A professional setup improves your efficiency, enhances your security, and boosts your professional image. Reliable internet, a separate business phone line, and secure data backup are essential investments that pay for themselves through increased productivity and peace of mind."
    },
    {
      q: "How much does IT support cost for a small business in Swanson?",
      a: "We offer scalable and affordable monthly support plans. The cost depends on the number of users and the complexity of your needs. Our basic plans are very cost-effective and provide a huge amount of value compared to paying for emergency callouts. We can provide a free, no-obligation quote tailored to you."
    },
    {
      q: "What is the biggest IT mistake small Swanson businesses make?",
      a: "The most common mistake is neglecting data backup. Many small businesses operate without a reliable, automated backup system, putting their entire business at risk from a single hard drive failure or ransomware attack. We make setting up a secure backup system our first priority for all new clients."
    },
    {
      q: "Can you help me choose the right computer for my business?",
      a: "Yes, we provide hardware procurement as part of our service. We can assess your needs and recommend the best-value laptops, desktops, and other equipment. We source from major brands and ensure you get reliable, business-grade hardware that will last."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Swanson Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=SwansonITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportSwanson() {
  const pageUrl = "https://www.comsys.co.nz/it-support-swanson-auckland";
  const title = "IT Support Swanson | Comsys IT | Home Office & Small Business";
  const description = "Local IT support for Swanson's small and home-based businesses. We provide reliable internet, data backup, and professional tech support. Call your local experts!";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Local IT support for home offices and small businesses in Swanson, Auckland.",
      "url": pageUrl,
      "telephone": "0800724526", // Updated to new phone number from CTA
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Swanson, Auckland"
      },
      "serviceType": [
        "Home Office IT Support", "Small Business IT", "Rural Broadband", "Data Backup", "VoIP Phone Systems"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "The internet at my Swanson home office is unreliable. Can you fix it?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, this is a common issue we resolve in Swanson. We will assess your location to determine the best fibre, rural broadband, or wireless solution to provide you with a stable and fast connection."
          }
        },
        {
          "@type": "Question",
          "name": "Is it worth getting a professional IT setup for my home business in Swanson?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. A professional IT setup from Comsys improves your efficiency, security, and professional image. Reliable internet, a separate business phone line, and secure data backup are essential investments that pay for themselves."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Swanson, West Auckland IT services, home office IT, lifestyle block internet"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
