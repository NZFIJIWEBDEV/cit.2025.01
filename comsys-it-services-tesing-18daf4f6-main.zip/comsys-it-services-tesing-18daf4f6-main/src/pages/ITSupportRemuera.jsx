
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Remuera businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Premium IT Support for Remuera Professionals
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        Remuera is a hub for Auckland's leading professional services, from specialist medical clinics to prestigious law firms. Businesses here demand an IT partner that operates with the same level of professionalism, discretion, and excellence. Comsys IT provides premium, reliable, and secure IT support tailored for the unique needs of the Remuera business community.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=RemueraITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        The Trusted IT Partner for Remuera's Professionals
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Expertise in Professional Services", 
            desc: "Specialized IT support for medical, legal, and financial practices, understanding the need for compliance and confidentiality.",
            icon: Building
          },
          { 
            title: "Uncompromising Data Security", 
            desc: "Advanced cybersecurity measures to protect sensitive client and patient information, a top priority for any Remuera business.",
            icon: Shield
          },
          { 
            title: "Discreet & Professional Onsite Support", 
            desc: "Our technicians are professional, courteous, and work efficiently to minimize disruption in your practice or office.",
            icon: Users
          },
          { 
            title: "Rapid Local Response", 
            desc: "Based centrally, our team provides fast onsite support to Remuera, ensuring minimal downtime for your critical operations.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
  const services = [
    { 
      icon: Users, 
      title: "Managed IT Services for Professionals", 
      desc: "Our managed services plan for Remuera businesses is like having a dedicated, in-house IT department. We proactively monitor your systems 24/7 to prevent problems before they occur. This includes regular maintenance, software updates, and performance optimization, ensuring your practice management or financial software runs smoothly. For a fixed monthly fee, you get unlimited remote and onsite support, giving you predictable costs and peace of mind.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Shield, 
      title: "Advanced Cybersecurity & Data Protection", 
      desc: "For businesses in Remuera handling sensitive data, security is non-negotiable. We implement multi-layered security strategies, including advanced firewalls, endpoint protection, email filtering, and regular security audits. Our data backup and recovery solutions ensure your critical information is securely backed up and can be restored quickly in the event of a disaster, protecting your reputation and ensuring business continuity.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Phone, 
      title: "Professional VoIP Communication Systems", 
      desc: "Project an image of professionalism with a modern VoIP phone system. Our solutions offer crystal-clear call quality and advanced features like auto-attendants, call forwarding to mobiles, and video conferencing. A VoIP system is perfect for Remuera-based practices needing to manage client calls efficiently and maintain a professional presence, whether in the office or working remotely.",
      link: "VoIPSolutions",
      imageUrl: "https://images.unsplash.com/photo-1596524430615-b46475ddff6e?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Remuera Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Remuera businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CaseStudySection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-6">Remuera Success Story</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
                A specialist medical clinic on Remuera Road was facing significant IT challenges with their outdated server, which was slow, unreliable, and posed a security risk to sensitive patient data. They couldn't afford any downtime during practice hours.
            </p>
            <div className="bg-gray-50 rounded-2xl p-8 shadow-lg border border-gray-200">
                <p className="text-lg text-[#3A4E62] italic leading-relaxed">
                    "Comsys IT engineered a seamless migration to a secure, compliant cloud platform over a single weekend. We arrived on Monday morning to a faster, more reliable system with zero disruption to our patient schedule. Their understanding of the medical sector's needs was exceptional. We now have them on a managed service plan, and our IT runs flawlessly, allowing us to focus entirely on our patients. It's the best investment we've made for our Remuera practice."
                </p>
                <p className="mt-6 font-semibold text-[#3A4E62]">- Practice Manager, Remuera Medical Specialists</p>
            </div>
        </div>
    </section>
);

const MapSection = () => (
    <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Your Local IT Support in Remuera</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Comsys IT provides fast, onsite support to all businesses within Remuera and surrounding areas. Our central location ensures we can be at your office promptly to resolve any critical issues.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12759.509780076046!2d174.78065484964593!3d-36.87780003058852!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4868d9a20249%3A0x500ef6143a2b4b0!2sRemuera%2C%20Auckland!5e0!3m2!1sen!2snz!4v1700015562789!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Remuera, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Our Remuera-based medical practice uses specialized software. Can you support it?',
      a: 'Absolutely. We have extensive experience supporting a wide range of industry-specific software, including medical and legal practice management systems. We work with your software vendor to ensure seamless operation, updates, and troubleshooting.'
    },
    {
      q: 'How do you ensure the confidentiality of our client data?',
      a: 'Data confidentiality is our highest priority. We employ multi-layered security protocols, including data encryption, access controls, and secure backup solutions. All our technicians are bound by strict confidentiality agreements, making us a trusted IT partner for professional services in Remuera.'
    },
    {
      q: 'What is your response time for an urgent IT issue at our Remuera office?',
      a: 'For urgent issues, we offer a rapid response guarantee. Our central location allows us to have a technician onsite in Remuera quickly, typically within the hour, to begin resolving any critical problems and minimize business disruption.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Remuera Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=RemueraITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);


export default function ITSupportRemuera() {
  const pageUrl = "https://www.comsys.co.nz/it-support-remuera";
  const title = "IT Support Remuera | Professional Business IT Services";
  const description = "Premium IT support for businesses in Remuera. Comsys IT provides specialised support for medical, legal, and professional services with a focus on security and reliability.";
  
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": "Auckland, NZ",
        "telephone": "0800724526"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Remuera, Auckland"
      },
      "description": "Professional IT support services for businesses located in Remuera, Auckland, including managed IT, cybersecurity, and data backup.",
      "name": "IT Support Remuera"
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Areas We Serve", "item": "https://www.comsys.co.nz/AreasWeServe" },
        { "@type": "ListItem", "position": 3, "name": "IT Support Remuera", "item": pageUrl }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Our Remuera-based medical practice uses specialized software. Can you support it?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We have extensive experience supporting a wide range of industry-specific software, including medical and legal practice management systems. We work with your software vendor to ensure seamless operation, updates, and troubleshooting."
          }
        },
        {
          "@type": "Question",
          "name": "How do you ensure the confidentiality of our client data?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Data confidentiality is our highest priority. We employ multi-layered security protocols, including data encryption, access controls, and secure backup solutions. All our technicians are bound by strict confidentiality agreements, making us a trusted IT partner for professional services in Remuera."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Remuera, Remuera IT services, medical IT support Auckland, legal IT services Remuera"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <CaseStudySection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
