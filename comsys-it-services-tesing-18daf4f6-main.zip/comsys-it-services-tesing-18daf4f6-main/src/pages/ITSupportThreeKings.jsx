
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&id=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Three Kings businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Professional IT Support for Three Kings
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the professional services, community organizations, and local businesses in the central Auckland suburb of Three Kings, reliable and efficient IT is paramount. Comsys IT provides expert, responsive support tailored to help your organization thrive.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ThreeKingsITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Three Kings Businesses Partner with Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Professional Services IT", 
            desc: "Specialized support for the accountants, lawyers, and consultants operating in and around the Three Kings area.",
            icon: Building
          },
          { 
            title: "Central Auckland Coverage", 
            desc: "Our strategic location allows for rapid onsite response to any business in the Three Kings vicinity.",
            icon: Clock
          },
          { 
            title: "Proactive System Management", 
            desc: "We focus on preventative maintenance to ensure your IT systems are always reliable, minimizing unexpected downtime.",
            icon: Shield
          },
          { 
            title: "Scalable for Growth", 
            desc: "Our IT solutions are designed to grow with your business, from a small local service to a larger enterprise.",
            icon: CheckCircle
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Building, 
      title: "IT for Professional Services", 
      desc: "For the lawyers, accountants, and consultants in Three Kings, we deliver secure, efficient, and scalable IT solutions that protect client data and boost productivity.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Users, 
      title: "Managed IT for SMEs", 
      desc: "Our managed IT plans are perfect for the diverse range of small to medium businesses in Three Kings. Get unlimited helpdesk support and proactive monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Backup", 
      desc: "Protect your valuable business and client data with our robust data backup and cybersecurity solutions, designed to keep your Three Kings business secure and resilient.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Three Kings Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Three Kings businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CaseStudySection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-6">Three Kings Success Story</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
                A busy accounting firm in Three Kings was dealing with an ageing server that was slow, unreliable, and posed a security risk to confidential client financial data. They needed a modern solution without disrupting their operations.
            </p>
            <div className="bg-gray-50 rounded-2xl p-8 shadow-lg border border-gray-200">
                <p className="text-lg text-[#3A4E62] italic leading-relaxed">
                    "Comsys IT was fantastic. They planned and executed a seamless migration to a secure cloud-based system over a single weekend, meaning zero downtime for our team. We came in on Monday to a faster, more secure, and more reliable system that allows us to work from anywhere. Their understanding of data security and the needs of a professional practice was outstanding. We now have them on a managed IT plan, and it’s the best decision we've made for our firm's efficiency and security."
                </p>
                <p className="mt-6 font-semibold text-[#3A4E62]">- Partner, Three Kings Accounting Practice</p>
            </div>
        </div>
    </section>
);

const MapSection = () => (
    <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Your Local IT Support in Three Kings</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Comsys IT provides fast, professional support to all businesses in Three Kings and the surrounding central Auckland suburbs. Our team is ready to help you succeed.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12760.10697992928!2d174.7471248496459!3d-36.89965383088719!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d476b8a263ce9%3A0x500ef6143a29b20!2sThree%20Kings%2C%20Auckland!5e0!3m2!1sen!2snz!4v1700016000123!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Three Kings, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Do you provide specialized IT support for professional services in Three Kings?',
      a: 'Yes, we have extensive experience supporting professional services firms such as accountants, lawyers, and consultants. We understand the critical importance of data security, confidentiality, and system reliability for these businesses.'
    },
    {
      q: 'How can you ensure the security of my confidential client data?',
      a: 'We implement a multi-layered security strategy including data encryption, secure cloud storage, robust firewalls, and regular security audits. Our solutions are designed to meet the high standards required for handling sensitive professional information.'
    },
    {
      q: 'What is the response time for an urgent issue in Three Kings?',
      a: 'For critical, business-stopping issues, we offer a rapid response guarantee. Our central Auckland location allows us to be onsite in Three Kings quickly, typically within the hour, to begin resolving the problem.'
    },
    {
      q: 'Can you help us transition our old server to a modern cloud-based system?',
      a: 'Absolutely. Cloud migration is one of our specialities. We can plan and manage a seamless transition from an old in-house server to a secure, modern cloud platform like Microsoft 365, often with minimal to no downtime.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Three Kings Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=ThreeKingsITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportThreeKings() {
  const pageUrl = "https://www.comsys.co.nz/it-support-three-kings";
  const title = "IT Support Three Kings | Professional IT Services Auckland";
  const description = "Expert IT support for businesses in Three Kings. Comsys IT provides managed services, data security, and cloud solutions for professional services and local businesses.";
  
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": "Auckland, NZ",
        "telephone": "0800724526"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Three Kings, Auckland"
      },
      "description": "Professional IT support and managed services for businesses in Three Kings, Auckland.",
      "name": "IT Support Three Kings"
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Areas We Serve", "item": "https://www.comsys.co.nz/AreasWeServe" },
        { "@type": "ListItem", "position": 3, "name": "IT Support Three Kings", "item": pageUrl }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide specialized IT support for professional services in Three Kings?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we have extensive experience supporting professional services firms such as accountants, lawyers, and consultants. We understand the critical importance of data security, confidentiality, and system reliability for these businesses."
          }
        },
        {
          "@type": "Question",
          "name": "How can you ensure the security of my confidential client data?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We implement a multi-layered security strategy including data encryption, secure cloud storage, robust firewalls, and regular security audits. Our solutions are designed to meet the high standards required for handling sensitive professional information."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Three Kings, professional services IT, small business IT Auckland"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <CaseStudySection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
