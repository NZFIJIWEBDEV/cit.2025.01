import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

const tiers = [
  {
    name: 'Home User',
    price: 'Custom',
    description: 'Perfect for individuals and families needing occasional support.',
    features: ['PC & Laptop Repair', 'WiFi & Broadband Setup', 'Virus Removal', 'Personal Data Backup'],
    cta: 'Get a Quote',
  },
  {
    name: 'Small Business',
    price: 'Managed',
    description: 'Comprehensive IT management for growing businesses.',
    features: ['Proactive IT Support', '24/7 Monitoring', 'Cybersecurity Protection', 'Data Backup & Recovery', 'Microsoft 365 Management'],
    cta: 'Book a Consultation',
    popular: true,
  },
  {
    name: 'Enterprise',
    price: 'Bespoke',
    description: 'Custom-built IT solutions for large-scale operations.',
    features: ['Dedicated Account Manager', 'Advanced Network Architecture', 'Custom VoIP & Broadband', 'Web Design & Hosting', 'Full IT Outsourcing'],
    cta: 'Contact Sales',
  },
];

export default function PricingPage() {
  return (
    <div className="bg-gray-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-[#3A4E62]">Plans & Pricing</h1>
          <p className="mt-4 text-xl text-[#3A4E62]/80 max-w-2xl mx-auto">
            Transparent pricing for every need. From home users to enterprise-level corporations, we have a plan that fits.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`bg-white rounded-2xl p-8 shadow-lg border ${
                tier.popular ? 'border-[#53B289] scale-105' : 'border-gray-200'
              }`}
            >
              {tier.popular && (
                <div className="text-center mb-4">
                  <span className="bg-[#53B289] text-white text-sm font-semibold px-4 py-1 rounded-full">Most Popular</span>
                </div>
              )}
              <h2 className="text-2xl font-bold text-[#3A4E62] text-center">{tier.name}</h2>
              <p className="text-4xl font-bold text-center my-4 text-[#3A4E62]">{tier.price}</p>
              <p className="text-center text-[#3A4E62]/70 h-12">{tier.description}</p>
              <Button
                className={`w-full my-6 ${tier.popular ? 'bg-[#53B289] hover:bg-[#4aa07b]' : 'bg-[#3A4E62] hover:bg-[#2a3749]'}`}
              >
                {tier.cta}
              </Button>
              <ul className="space-y-4">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="w-5 h-5 text-[#53B289] mr-3" />
                    <span className="text-[#3A4E62]/90">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}