import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Settings, Database, Zap, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Engineering Firms in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland engineering firms. Comsys IT delivers secure networks, software support, and backup solutions for engineers.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=EngineeringIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Engineering IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Engineers
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=600&h=400&fit=crop" 
            alt="Engineering IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">High-Performance IT for Complex Projects</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Engineering firms require powerful workstations, robust networks, and specialized software 
              to handle complex designs, calculations, and collaborative projects.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: Settings, title: "CAD & Engineering Software", desc: "Support for AutoCAD, SolidWorks, ANSYS, and other specialized engineering applications." },
              { icon: Database, title: "Large File Management", desc: "High-speed networks and storage solutions for handling large design files and datasets." },
              { icon: Zap, title: "High-Performance Computing", desc: "Powerful workstations and servers for complex calculations and rendering tasks." },
              { icon: Shield, title: "IP Protection", desc: "Secure storage and backup of valuable intellectual property and design data." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CADSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        CAD & Software Support
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Expert Support for Engineering Software</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We provide specialized support for CAD and engineering software, ensuring your tools 
              perform optimally and your team stays productive.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "Installation and configuration of CAD software.",
              "License management and optimization.",
              "Performance tuning for heavy computational tasks.",
              "Integration between design and project management tools.",
              "Custom software training and support.",
              "Troubleshooting and technical support for engineering applications."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Supported Software Includes:</h4>
          <div className="grid grid-cols-2 gap-4">
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">AutoCAD</span>
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">SolidWorks</span>
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">Revit</span>
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">ANSYS</span>
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">MATLAB</span>
            <span className="bg-gray-50 p-3 rounded-lg text-center font-medium text-[#3A4E62]">SketchUp Pro</span>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const StorageSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Secure Data Storage
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Protecting Your Engineering Assets</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Your designs and engineering data are valuable intellectual property. We provide 
            secure, high-performance storage solutions that protect and preserve your work.
          </p>
          {[
            "High-speed NAS and SAN storage solutions.",
            "Automated backup of CAD files and project data.",
            "Version control and file history management.",
            "Secure remote access to engineering files.",
            "Disaster recovery planning for critical data."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Storage Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Performance</h5>
              <p className="text-sm text-[#3A4E62]/80">Fast access to large files reduces wait times and improves productivity.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Security</h5>
              <p className="text-sm text-[#3A4E62]/80">Encrypted storage protects your valuable engineering intellectual property.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Collaboration</h5>
              <p className="text-sm text-[#3A4E62]/80">Centralized storage enables seamless team collaboration on projects.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Powers Innovation</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our engineering IT solutions are designed to maximize your team's productivity, 
            protect your valuable work, and provide the performance you need for complex projects.
          </p>
          {[
            "Optimized performance for CAD and engineering software.",
            "Secure storage and backup of valuable design data.",
            "Reliable network infrastructure for large file transfers.",
            "Expert support for specialized engineering applications.",
            "Scalable solutions that grow with your engineering firm."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT completely transformed our engineering workflow. The new high-speed network and storage system cut our file access times by 75%. Their support for our CAD software has been outstanding, and we've had zero data loss incidents since they implemented our backup solution."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Dr. James Wilson</div>
              <div className="text-sm text-[#3A4E62]/70">Principal Engineer, Auckland Engineering Solutions</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support CAD software?",
            answer: "Yes, we provide comprehensive support for major CAD and engineering software including AutoCAD, SolidWorks, Revit, ANSYS, and MATLAB. Our team has expertise in installation, configuration, license management, and troubleshooting to keep your engineering tools running smoothly."
          },
          {
            question: "Can you handle large file storage?",
            answer: "Absolutely. We specialize in high-performance storage solutions designed for engineering firms that work with large CAD files, datasets, and project archives. Our storage systems provide fast access speeds, secure backup, and scalable capacity to meet your growing needs."
          },
          {
            question: "Do you provide fast fibre for engineers?",
            answer: "Yes, we provide ultra-fast business fibre internet specifically optimized for engineering workflows. Our high-speed connections support large file uploads/downloads, cloud-based CAD platforms, video conferencing with clients, and seamless collaboration with remote team members or clients."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesEngineering() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Engineering Firms in Auckland",
      "description": "IT support for Auckland engineering firms. Comsys IT delivers secure networks, software support, and backup solutions for engineers.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Engineering IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support CAD software?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive support for major CAD and engineering software including AutoCAD, SolidWorks, Revit, ANSYS, and MATLAB. Our team has expertise in installation, configuration, license management, and troubleshooting to keep your engineering tools running smoothly." }
        },
        {
          "@type": "Question", "name": "Can you handle large file storage?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We specialize in high-performance storage solutions designed for engineering firms that work with large CAD files, datasets, and project archives. Our storage systems provide fast access speeds, secure backup, and scalable capacity to meet your growing needs." }
        },
        {
          "@type": "Question", "name": "Do you provide fast fibre for engineers?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide ultra-fast business fibre internet specifically optimized for engineering workflows. Our high-speed connections support large file uploads/downloads, cloud-based CAD platforms, video conferencing with clients, and seamless collaboration with remote team members or clients." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Engineering Firms in Auckland", "item": "https://www.comsys.co.nz/IndustriesEngineering" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Engineering Firms Auckland | Comsys IT"
        description="IT support for Auckland engineering firms. Comsys IT delivers secure networks, software support, and backup solutions for engineers."
        keywords="engineering IT support Auckland, CAD software support, engineering data storage, high-performance computing"
        canonical="https://www.comsys.co.nz/IndustriesEngineering"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <CADSection />
      <StorageSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}