
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, ShoppingCart } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Ponsonby's stylish businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Stylish IT Support for Ponsonby
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        On Ponsonby Road, where style and innovation meet, your business's technology needs to be flawless. Comsys IT provides premium, design-conscious IT support for the high-end boutiques, creative agencies, and bustling hospitality venues that make Ponsonby iconic.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=PonsonbyITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Ponsonby Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Creative Industry Expertise", 
            desc: "Specialized IT solutions for Ponsonby's creative agencies, design studios, and innovative startups.",
            icon: Building
          },
          { 
            title: "Central Auckland Coverage", 
            desc: "Rapid onsite support from our Auckland-based team who understand inner-city business needs.",
            icon: Clock
          },
          { 
            title: "Modern Tech Solutions", 
            desc: "Cutting-edge IT infrastructure that matches Ponsonby's forward-thinking business environment.",
            icon: Server
          },
          { 
            title: "Flexible Service Options", 
            desc: "Scalable support packages designed for growing creative and hospitality businesses.",
            icon: Shield
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: ShoppingCart, 
      title: "Boutique Retail & Hospitality IT", 
      desc: "We provide seamless POS systems, secure payment processing, and elegant Guest WiFi solutions that enhance the premium customer experience expected on Ponsonby Road.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Users, 
      title: "IT for Creative Agencies", 
      desc: "For the design, marketing, and creative firms in Ponsonby, we offer specialized support for both Mac and PC environments, ensuring your technology fuels creativity without interruption.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Advanced Cybersecurity", 
      desc: "Protect your high-value business and client data with our comprehensive cybersecurity services, including advanced threat protection, data encryption, and proactive monitoring.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Ponsonby Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Ponsonby businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Ponsonby Service Area & Location
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Ponsonby Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our Auckland IT team provides comprehensive coverage throughout Ponsonby, from the vibrant Ponsonby Road commercial strip to the residential areas and converted industrial spaces housing creative studios. We service businesses in heritage buildings, modern developments, and the unique warehouse conversions that make Ponsonby a hub for innovative companies.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our technicians understand Ponsonby's eclectic mix of building types and the specific needs of creative businesses. We can work around artistic installations, navigate heritage building constraints, and provide IT solutions that complement the area's creative and innovative atmosphere while maintaining professional reliability.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> 15-minute response for Ponsonby businesses</p>
              <p><strong>Coverage:</strong> Complete Ponsonby area including Ponsonby Road and side streets</p>
              <p><strong>Parking:</strong> Familiar with Ponsonby parking and access challenges</p>
              <p><strong>Creative Focus:</strong> Specialized support for creative and hospitality businesses</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12759.442891234567!2d174.73987654321!3d-36.85432109876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47fh123456789%3A0x500ef6143a299f2!2sPonsonby%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Ponsonby Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our Auckland IT team provides fast onsite support throughout Ponsonby and surrounding inner-city areas.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "Do you provide specialized IT support for creative agencies in Ponsonby?",
      a: "Yes, we specialize in supporting creative agencies, design studios, and digital businesses with their unique IT requirements. This includes high-performance workstation setup, creative software optimization, large file storage solutions, fast internet connectivity, and backup systems designed to protect valuable creative assets and client work."
    },
    {
      q: "Can you handle IT support for restaurants and hospitality businesses in Ponsonby?",
      a: "Absolutely! We provide comprehensive IT support for Ponsonby's vibrant hospitality scene, including point-of-sale systems, reservation management, customer Wi-Fi solutions, inventory tracking, and payment processing systems. We understand the fast-paced environment of restaurants and cafes and provide solutions that enhance customer experience."
    },
    {
      q: "What makes your Ponsonby IT support different for creative businesses?",
      a: "We understand the unique workflow demands of creative industries. Our services include specialized support for design software, color-accurate display calibration, high-speed file transfer solutions, collaborative cloud platforms, and backup systems that protect irreplaceable creative work. We also provide flexible support that accommodates the often non-traditional working hours of creative businesses."
    },
    {
      q: "Do you provide emergency IT support for Ponsonby businesses?",
      a: "Yes, we provide rapid emergency IT support with priority response for critical issues. Our Auckland-based team can reach Ponsonby quickly, and we offer 24/7 remote support for urgent problems. We understand that creative deadlines and hospitality operations can't afford extended downtime, so we prioritize emergency response."
    },
    {
      q: "Can you help with business fibre internet for high-bandwidth creative work in Ponsonby?",
      a: "Yes, we provide ultra-fast business fibre internet specifically designed for bandwidth-intensive creative work. Our enterprise-grade connections support large file uploads, video streaming, cloud collaboration, and real-time client presentations. We ensure your internet connection never becomes a bottleneck for your creative projects."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Ponsonby Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=PonsonbyITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportPonsonby() {
  const pageUrl = "https://www.comsys.co.nz/it-support-ponsonby-auckland";
  const title = "Premium IT Support for Ponsonby Businesses | Comsys IT";
  const description = "Comsys IT provides premium, design-conscious IT support for Ponsonby's high-end boutiques, creative agencies, and hospitality venues. Seamless tech solutions for stylish businesses.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT support services for Ponsonby businesses",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Ponsonby, Auckland"
      },
      "serviceType": [
        "IT Support", "Retail IT", "Hospitality IT", "Creative Agency IT", "Cybersecurity", "VoIP Solutions", "CCTV Systems", "Business Fibre", "Data Backup"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide specialized IT support for creative agencies in Ponsonby?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in supporting creative agencies, design studios, and digital businesses with high-performance workstations, creative software optimization, and backup systems designed to protect valuable creative assets."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Ponsonby, creative agency IT, retail IT support Ponsonby, hospitality IT"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
