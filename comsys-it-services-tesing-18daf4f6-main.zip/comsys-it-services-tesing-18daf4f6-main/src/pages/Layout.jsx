

import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/sections/Footer';
import BackToTopButton from '@/components/layout/BackToTopButton';
import { ToastProvider } from '@/components/ui/toast';
import TopBar from '@/components/layout/TopBar';

export default function Layout({ children, currentPageName }) {
  const { pathname } = useLocation();

  const businessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "COMSYS IT & Communications",
    "image": "https://comsys.co.nz/wp-content/uploads/2024/02/logo-5-1-1.png",
    "@id": "https://www.comsys.co.nz/",
    "url": "https://www.comsys.co.nz/",
    "telephone": "0800 724 526",
    "priceRange": "$$",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Level 1, 30 St Benedicts Street, Eden Terrace",
      "addressLocality": "Auckland",
      "postalCode": "1010",
      "addressCountry": "NZ"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": -36.8622,
      "longitude": 174.7618
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday"
      ],
      "opens": "08:00",
      "closes": "18:00"
    },
    "sameAs": [
      "https://www.facebook.com/comsysnz/",
      "https://www.linkedin.com/company/comsys-it-&-communications-ltd/"
    ]
  };

  useEffect(() => {
    // Smooth scroll to top on route change
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  useEffect(() => {
    // Set global HTML attributes and schema
    document.documentElement.lang = 'en-NZ';
    
    const scriptId = 'ld-json-business-schema';
    // Remove existing script to prevent duplicates on hot-reloads
    const existingScript = document.getElementById(scriptId);
    if(existingScript) {
        existingScript.remove();
    }

    const script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify(businessSchema);
    document.head.appendChild(script);

    // Add prerender.io meta tag if not already present
    if (!document.querySelector('meta[name="prerender-spa-fallback"]')) {
      const metaTag = document.createElement('meta');
      metaTag.name = 'prerender-spa-fallback';
      metaTag.content = 'true';
      document.head.appendChild(metaTag);
    }
  }, []); // Run only once on initial layout load

  return (
    <ToastProvider>
      <div className="bg-gray-50 text-[#3A4E62] min-h-screen">
        <TopBar />
        <Header />
        <main className="flex-grow">{children}</main>
        <BackToTopButton />
        <Footer />
      </div>
    </ToastProvider>
  );
}

