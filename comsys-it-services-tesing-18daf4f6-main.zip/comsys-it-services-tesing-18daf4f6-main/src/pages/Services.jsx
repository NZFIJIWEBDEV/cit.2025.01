import React from 'react';
import ServicesSection from '../components/sections/Services';
import Seo from '../components/layout/Seo';

export default function ServicesPage() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem", 
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        }
      ]
    }
  ];

  return (
    <div className="pt-20">
      <Seo
        title="IT Services Auckland | Comsys IT"
        description="Comprehensive IT services for Auckland businesses. IT support, CCTV installation, VoIP solutions, business fibre, and managed services from Comsys IT."
        keywords="IT services Auckland, managed IT, CCTV installation, VoIP systems, business fibre, cybersecurity Auckland"
        canonical="https://www.comsys.co.nz/Services"
        schemas={schemas}
      />
      <ServicesSection />
    </div>
  );
}