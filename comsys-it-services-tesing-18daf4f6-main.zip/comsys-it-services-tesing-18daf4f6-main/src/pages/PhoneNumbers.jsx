import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Globe, Award, TrendingUp, Users, Shield, MapPin, Star, Zap, CheckCircle, DollarSign, Building, HeartHandshake, Megaphone, Crown, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ContactSection from '@/components/sections/Contact';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function PhoneNumbers() {
  const numberTypes = [
    {
      icon: MapPin,
      title: "Local Numbers",
      description: "Establish a local presence in any New Zealand calling area with dedicated local phone numbers. Perfect for businesses wanting to connect with regional customers.",
      details: "Local numbers create trust and familiarity with customers in specific regions. They're cost-effective for customers to call and help establish your business as part of the local community, even if you're physically located elsewhere."
    },
    {
      icon: Award,
      title: "Toll-Free Numbers (0800/0508)",
      description: "Professional toll-free numbers that allow customers to contact you without any calling charges, enhancing accessibility and customer satisfaction.",
      details: "Toll-free numbers project a professional image, improve customer experience by removing cost barriers, and can serve as powerful marketing tools when combined with memorable vanity options."
    },
    {
      icon: Globe,
      title: "International Numbers",
      description: "Access phone numbers from over 50 countries including Australia, UK, Europe, US & Canada to establish a global presence.",
      details: "International numbers allow you to appear local to customers worldwide, reduce their calling costs, and expand your market reach without physical offices in those countries."
    },
    {
      icon: Crown,
      title: "Premium Rate Numbers (0900)",
      description: "Generate revenue through premium rate services like contests, information lines, or specialized consultation services.",
      details: "Premium rate numbers are perfect for businesses offering paid information services, competitions, or premium consultations where the caller pays for specialized content or services."
    },
    {
      icon: Star,
      title: "Vanity Numbers",
      description: "Choose highly memorable local or toll-free numbers that spell out your business name or are easy to remember.",
      details: "Vanity numbers like 0800-PLUMBER or 0800-123-456 are powerful branding tools that increase recall rates, make advertising more effective, and help customers remember your number."
    },
    {
      icon: Phone,
      title: "Number Porting",
      description: "Keep your existing phone number when switching to COMSYS. Our seamless porting process ensures no disruption to your business.",
      details: "Number porting allows you to maintain business continuity, keep existing marketing materials, and ensure customers can still reach you on familiar numbers while gaining access to advanced features."
    }
  ];

  const tollFreeBenefits = [
    {
      icon: HeartHandshake,
      title: "Enhanced Customer Experience",
      description: "Remove cost barriers for customers calling your business, leading to increased satisfaction, longer conversations, and higher likelihood of repeat business."
    },
    {
      icon: Building,
      title: "Professional Business Image",
      description: "Project enterprise-level credibility even as a small business. Toll-free numbers give companies of any size a polished, established appearance."
    },
    {
      icon: Megaphone,
      title: "Powerful Marketing Tool",
      description: "Easy-to-remember toll-free numbers become part of your brand identity. They're perfect for advertising campaigns, business cards, and promotional materials."
    },
    {
      icon: TrendingUp,
      title: "Competitive Advantage",
      description: "Stand out from competitors who don't offer free calling. This simple feature can be the deciding factor for cost-conscious customers choosing between providers."
    }
  ];

  const pricingTiers = [
    {
      minutes: "300 Minutes",
      price: "Contact for Pricing",
      features: [
        "300 calling minutes included",
        "NZ Fixed/Mobile calls covered",
        "Pay-as-you-go rates for overage",
        "Monthly billing cycle"
      ]
    },
    {
      minutes: "600 Minutes",
      price: "Contact for Pricing",
      features: [
        "600 calling minutes included",
        "NZ Fixed/Mobile calls covered",
        "Pay-as-you-go rates for overage",
        "Monthly billing cycle"
      ],
      popular: true
    },
    {
      minutes: "900 Minutes",
      price: "Contact for Pricing",
      features: [
        "900 calling minutes included",
        "NZ Fixed/Mobile calls covered",
        "Pay-as-you-go rates for overage",
        "Monthly billing cycle"
      ]
    },
    {
      minutes: "1200 Minutes",
      price: "Contact for Pricing",
      features: [
        "1200 calling minutes included",
        "NZ Fixed/Mobile calls covered",
        "Pay-as-you-go rates for overage",
        "Monthly billing cycle"
      ]
    }
  ];

  const faqs = [
    {
      q: "How quickly can I get a new phone number?",
      a: "Most local and toll-free numbers can be provisioned within 24-48 hours. International numbers may take 1-5 business days depending on the country. Vanity numbers may require additional time based on availability."
    },
    {
      q: "Can I port my existing business number to COMSYS?",
      a: "Yes! We offer seamless number porting services. The process typically takes 1-3 business days for local numbers. We handle all the paperwork and coordination with your previous provider to ensure no downtime."
    },
    {
      q: "What's included with my phone number?",
      a: "All phone numbers include basic call routing, voicemail, and integration with our Cloud PBX features. Additional features like call recording, advanced analytics, and AI transcription can be added to any number."
    },
    {
      q: "Can I have multiple numbers on the same account?",
      a: "Absolutely! You can have multiple local numbers, toll-free numbers, and international numbers all managed through the same COMSYS account. This is perfect for businesses operating in multiple regions."
    },
    {
      q: "What happens to my number if I change my plan?",
      a: "Your phone numbers belong to you. If you change plans or providers, you can port your numbers with you. We believe in number portability and won't hold your business hostage."
    },
    {
      q: "Are there any setup fees for new numbers?",
      a: "Setup fees vary by number type. Local numbers typically have no setup fee, while specialty numbers like vanity or international numbers may have one-time provisioning costs. Contact us for specific pricing."
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl lg:text-6xl font-bold mb-6"
            >
              Professional Phone Numbers
              <span className="block text-[#53B289]">For Every Business Need</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-white/90 max-w-3xl mx-auto mb-8"
            >
              From local numbers to international presence, toll-free accessibility to premium services - 
              COMSYS provides comprehensive phone number solutions across New Zealand, Australia, and over 50 countries worldwide.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white px-8 py-4">
                  Get Your Number Today
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to={createPageUrl("VoIPSolutions")}>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#3A4E62] px-8 py-4">
                  View VoIP Plans
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Number Types Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Complete Range of Professional Phone Numbers
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Whether you need local presence, national accessibility, or global reach, 
              we have the perfect phone number solution for your business requirements.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {numberTypes.map((type, index) => (
              <motion.div
                key={type.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 border-l-4 border-l-[#53B289]">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#53B289] rounded-lg flex items-center justify-center mb-4">
                      <type.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl text-[#3A4E62]">{type.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-[#3A4E62]/80 mb-4">{type.description}</p>
                    <p className="text-sm text-[#3A4E62]/60">{type.details}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Toll-Free Benefits */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Why Toll-Free Numbers Transform Your Business
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Toll-free numbers aren't just about free calls - they're strategic business tools 
              that enhance customer relationships and boost your professional credibility.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {tollFreeBenefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-[#53B289]/5 to-[#C0E3D4]/10 rounded-2xl p-8"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-[#53B289] rounded-xl flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{benefit.title}</h3>
                    <p className="text-[#3A4E62]/80 leading-relaxed">{benefit.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/20">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Toll-Free Calling Plans
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
              Choose from our range of toll-free calling bundles, or pay as you go. 
              All plans include your toll-free number and comprehensive call management features.
            </p>
            <div className="bg-[#53B289]/10 border border-[#53B289]/30 rounded-lg p-4 inline-block">
              <p className="text-[#53B289] font-semibold">
                📞 Toll-Free Numbers: Contact us for current pricing and availability
              </p>
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pricingTiers.map((tier, index) => (
              <motion.div
                key={tier.minutes}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative ${tier.popular ? 'transform scale-105' : ''}`}
              >
                <Card className={`h-full ${tier.popular ? 'border-[#53B289] border-2' : 'border-gray-200'}`}>
                  {tier.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="bg-[#53B289] text-white px-4 py-1 rounded-full text-sm font-semibold">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold text-[#3A4E62]">
                      {tier.minutes}
                    </CardTitle>
                    <div className="text-3xl font-bold text-[#53B289] mt-2">
                      {tier.price}
                    </div>
                    <p className="text-sm text-gray-600">per month</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-[#53B289] mr-3 flex-shrink-0 mt-0.5" />
                          <span className="text-[#3A4E62]/80 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Link to={createPageUrl("ContactUs")}>
                      <Button 
                        className={`w-full mt-6 ${tier.popular ? 'bg-[#53B289] hover:bg-[#4aa07b]' : 'bg-gray-600 hover:bg-gray-700'}`}
                      >
                        Get Quote
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-[#3A4E62]/60 mb-4">
              Need a custom solution? We can create calling plans tailored to your specific requirements.
            </p>
            <Link to={createPageUrl("ContactUs")}>
              <Button variant="outline" size="lg" className="border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white">
                Request Custom Quote
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How to Get Numbers */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              How to Get Your Phone Numbers
            </h2>
            <p className="text-xl text-[#3A4E62]/80 mb-8">
              Getting started with professional phone numbers is simple. 
              Choose any phone number type when signing up for our VoIP plans.
            </p>
            
            <div className="bg-gradient-to-r from-[#53B289]/10 to-[#C0E3D4]/20 rounded-2xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">
                All Phone Numbers Work With Our VoIP Solutions
              </h3>
              <p className="text-[#3A4E62]/80 mb-6">
                Every phone number integrates seamlessly with our Cloud PBX, SIP Trunks, 
                and advanced calling features. Get the complete communication solution your business needs.
              </p>
              <Link to={createPageUrl("VoIPSolutions")}>
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                  View VoIP Plans
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Everything you need to know about our phone number services
            </p>
          </motion.div>

          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <AccordionItem value={`item-${index}`} className="bg-white/70 backdrop-blur-sm rounded-xl shadow-sm mb-4 border border-gray-200">
                  <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-[#3A4E62] to-[#53B289] text-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-6">
              Ready to Get Your Professional Phone Numbers?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Join thousands of New Zealand businesses who trust COMSYS for their communication needs. 
              Get started today with a free consultation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-white text-[#3A4E62] hover:bg-gray-100 px-8 py-4">
                  Get Free Consultation
                </Button>
              </Link>
              <Link to={createPageUrl("VoIPSolutions")}>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#3A4E62] px-8 py-4">
                  View All VoIP Plans
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <ContactSection />
    </div>
  );
}