import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Shield, Scale, Lock, FileText, ExternalLink, AlertTriangle } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Law Firms in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Secure, reliable IT solutions for Auckland law firms. Comsys IT provides data security, VoIP, and IT support tailored for legal practices.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=LegalIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Legal IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Challenges Law Firms Face
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&h=400&fit=crop" 
            alt="Legal IT Challenges Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Unique IT Challenges in Legal Practice</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Law firms face unique IT challenges that require specialized expertise and understanding 
              of the legal industry's strict security, compliance, and confidentiality requirements.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: AlertTriangle,
                title: "Data Security & Client Confidentiality",
                desc: "Protecting sensitive client information and maintaining attorney-client privilege"
              },
              {
                icon: Scale,
                title: "Regulatory Compliance",
                desc: "Meeting strict legal industry regulations and professional standards"
              },
              {
                icon: FileText,
                title: "Document Management",
                desc: "Organizing and securing large volumes of case documents and legal files"
              },
              {
                icon: Lock,
                title: "Cybersecurity Threats",
                desc: "Law firms are prime targets for cyber attacks due to valuable client data"
              }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4 p-4 bg-red-50 rounded-lg border border-red-200"
              >
                <challenge.icon className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-red-800 mb-2">{challenge.title}</h4>
                  <p className="text-red-700 text-sm">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-yellow-800 mb-3">Industry Statistics:</h4>
            <ul className="space-y-2 text-yellow-700">
              <li>• 25% of law firms experienced a data breach in the last year</li>
              <li>• 60% of legal professionals work remotely or hybrid</li>
              <li>• 80% of firms struggle with outdated IT systems</li>
              <li>• Average cost of legal data breach: $10.93 million</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ITSupportSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Support for Legal Software
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            category: "Practice Management",
            software: [
              "MYOB Practice",
              "LawMaster",
              "InfoTrack",
              "Actionstep",
              "LexisNexis",
              "Thomson Reuters"
            ],
            icon: "⚖️"
          },
          {
            category: "Document Management",
            software: [
              "NetDocuments",
              "iManage",
              "Microsoft SharePoint",
              "DocuSign",
              "Adobe Document Cloud",
              "Worldox"
            ],
            icon: "📁"
          },
          {
            category: "Communication & VoIP",
            software: [
              "Microsoft Teams",
              "Zoom",
              "Cisco Webex",
              "RingCentral",
              "8x8 VoIP",
              "Custom PBX Systems"
            ],
            icon: "📞"
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg"
          >
            <div className="text-4xl mb-4 text-center">{category.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6 text-center">{category.category}</h3>
            <ul className="space-y-3">
              {category.software.map((software, sIndex) => (
                <li key={sIndex} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                  <span className="text-[#3A4E62]/80">{software}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Specialized Legal IT Support</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-6">
            Our technicians understand legal workflows and can provide specialized support for 
            practice management systems, ensuring minimal disruption to your legal operations.
          </p>
          <div className="grid md:grid-cols-2 gap-6 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-3">Software Support:</h4>
              <ul className="space-y-2">
                {[
                  "Installation and configuration",
                  "User training and onboarding",
                  "Integration between systems",
                  "Performance optimization"
                ].map((service, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                    <span className="text-[#3A4E62]/80">{service}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-3">Ongoing Maintenance:</h4>
              <ul className="space-y-2">
                {[
                  "Regular updates and patches",
                  "Backup and disaster recovery",
                  "24/7 technical support",
                  "Compliance monitoring"
                ].map((maintenance, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                    <span className="text-[#3A4E62]/80">{maintenance}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SecureDataSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Secure Data & Backup
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Attorney-Client Privilege Protection</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Protecting attorney-client privilege is not just important—it's a legal and ethical obligation. 
              Our security measures ensure your client data remains confidential and compliant with legal standards.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">Security Measures:</h4>
            {[
              {
                title: "End-to-End Encryption",
                desc: "All data encrypted in transit and at rest using AES-256 encryption"
              },
              {
                title: "Multi-Factor Authentication",
                desc: "Additional security layers for accessing sensitive legal documents"
              },
              {
                title: "Access Controls",
                desc: "Role-based permissions ensuring only authorized staff access client files"
              },
              {
                title: "Audit Trails",
                desc: "Complete logging of all document access and modifications"
              },
              {
                title: "Secure Cloud Storage",
                desc: "Legal-compliant cloud storage with New Zealand data residency"
              },
              {
                title: "Regular Security Audits",
                desc: "Ongoing assessment and improvement of security measures"
              }
            ].map((security, index) => (
              <div key={index} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h5 className="font-semibold text-green-800 mb-2">{security.title}</h5>
                <p className="text-sm text-green-700">{security.desc}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1555421689-491a97ff2040?w=600&h=400&fit=crop" 
            alt="Legal Data Security Auckland"
            className="rounded-xl shadow-lg w-full"
          />
          
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Legal Backup Requirements:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• 24/7 automated backup monitoring</li>
              <li>• 7-year retention for legal documents</li>
              <li>• Point-in-time recovery capabilities</li>
              <li>• Offsite backup with local data residency</li>
              <li>• Disaster recovery testing quarterly</li>
              <li>• Compliance with Legal Professional Rules</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Comsys IT for Law Firms
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Why Legal Professionals Choose Us</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand the unique challenges of legal practice and provide specialized IT solutions 
              that help law firms operate efficiently while maintaining the highest security standards.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                title: "Legal Industry Expertise",
                desc: "Deep understanding of legal workflows, compliance requirements, and confidentiality needs"
              },
              {
                title: "24/7 Emergency Support",
                desc: "Critical IT support when you need it most, including evenings and weekends"
              },
              {
                title: "Compliance Assurance",
                desc: "Stay compliant with legal professional rules and data protection regulations"
              },
              {
                title: "Cost-Effective Solutions",
                desc: "Predictable IT costs that help with budgeting and reduce unexpected expenses"
              },
              {
                title: "Local Auckland Support",
                desc: "On-site support from technicians who understand the New Zealand legal environment"
              },
              {
                title: "Scalable Services",
                desc: "IT solutions that grow with your practice, from sole practitioners to large firms"
              }
            ].map((benefit, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
            <blockquote className="text-[#3A4E62]/80 italic mb-4">
              "Comsys IT transformed our practice's technology infrastructure. Their understanding of legal 
              requirements and commitment to data security gave us confidence. We've seen a 40% improvement 
              in efficiency and zero security incidents since partnering with them."
            </blockquote>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                <Scale className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-[#3A4E62]">Sarah Mitchell</div>
                <div className="text-sm text-[#3A4E62]/70">Managing Partner, Mitchell & Associates</div>
              </div>
            </div>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-8">
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Our Legal IT Services Include:</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">IT Infrastructure:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Network setup and security</li>
                  <li>• Server management</li>
                  <li>• Workstation configuration</li>
                  <li>• VoIP phone systems</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Legal Software:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Practice management systems</li>
                  <li>• Document management</li>
                  <li>• Time and billing software</li>
                  <li>• Legal research platforms</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support legal case management software?",
            answer: "Yes, we provide comprehensive support for all major legal case management platforms including MYOB Practice, LawMaster, InfoTrack, Actionstep, and LexisNexis. Our technicians are trained on legal software workflows and can handle installation, configuration, integration, user training, and ongoing support to ensure your practice management systems run smoothly."
          },
          {
            question: "How do you secure client data?",
            answer: "We implement multiple layers of security including AES-256 encryption for all data, multi-factor authentication, role-based access controls, and comprehensive audit trails. All our security measures are designed to maintain attorney-client privilege and comply with Legal Professional Rules. We also provide secure cloud storage with New Zealand data residency and regular security audits."
          },
          {
            question: "Do you provide cloud storage for law firms?",
            answer: "Absolutely. We offer secure, compliant cloud storage solutions specifically designed for law firms. Our cloud services include automatic encryption, audit trails, role-based access controls, and compliance with legal professional standards. Data is stored in New Zealand to meet local residency requirements, with automated backup and disaster recovery capabilities."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesLegal() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Law Firms Auckland",
      "description": "Secure, reliable IT solutions for Auckland law firms. Comsys IT provides data security, VoIP, and IT support tailored for legal practices.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": {
          "@type": "City",
          "name": "Auckland"
        },
        "serviceType": "Legal IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you support legal case management software?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide comprehensive support for all major legal case management platforms including MYOB Practice, LawMaster, InfoTrack, Actionstep, and LexisNexis. Our technicians are trained on legal software workflows and can handle installation, configuration, integration, user training, and ongoing support to ensure your practice management systems run smoothly."
          }
        },
        {
          "@type": "Question",
          "name": "How do you secure client data?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We implement multiple layers of security including AES-256 encryption for all data, multi-factor authentication, role-based access controls, and comprehensive audit trails. All our security measures are designed to maintain attorney-client privilege and comply with Legal Professional Rules. We also provide secure cloud storage with New Zealand data residency and regular security audits."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide cloud storage for law firms?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We offer secure, compliant cloud storage solutions specifically designed for law firms. Our cloud services include automatic encryption, audit trails, role-based access controls, and compliance with legal professional standards. Data is stored in New Zealand to meet local residency requirements, with automated backup and disaster recovery capabilities."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Industries",
          "item": "https://www.comsys.co.nz/Industries"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Solutions for Law Firms Auckland",
          "item": "https://www.comsys.co.nz/IndustriesLegal"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Law Firms Auckland | Comsys IT"
        description="Secure, reliable IT solutions for Auckland law firms. Comsys IT provides data security, VoIP, and IT support tailored for legal practices."
        keywords="legal IT support Auckland, law firm IT services, legal data security, practice management software support"
        canonical="https://www.comsys.co.nz/IndustriesLegal"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <ITSupportSection />
      <SecureDataSection />
      <BenefitsSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Secure Your Legal Practice's IT Infrastructure
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get specialized IT support that understands the unique needs of legal professionals. 
            Protect your clients' data and ensure compliance with industry standards.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=LegalITConsultation")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Legal IT Assessment
              </Button>
            </Link>
            <Link to="https://www.lawsociety.org.nz" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                View Legal Compliance Standards <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}