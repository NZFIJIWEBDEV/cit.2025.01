import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Heart, Users, DollarSign, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Non-Profits in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Affordable IT services for non-profits in Auckland. Comsys IT provides reliable IT support, VoIP, and cloud solutions for charities & NGOs.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=NonProfitIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Non-Profit IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Challenges for Non-Profits
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=600&h=400&fit=crop" 
            alt="Non-Profit IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Maximizing Impact with Limited Resources</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Non-profit organizations face unique challenges: tight budgets, the need for transparency, 
              donor data security, and maximizing every dollar to further their mission.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: DollarSign, title: "Budget Constraints", desc: "Making IT affordable while maintaining quality and security standards." },
              { icon: Shield, title: "Donor Data Security", desc: "Protecting sensitive donor information and financial data from cyber threats." },
              { icon: Users, title: "Staff & Volunteer Support", desc: "Supporting diverse tech skill levels across staff and volunteers." },
              { icon: Heart, title: "Mission-Critical Systems", desc: "Ensuring systems that support programs and beneficiaries remain operational." }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const AffordableSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Affordable IT Support
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Special Pricing for Non-Profits</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand that every dollar counts in the non-profit sector. That's why we offer special pricing 
              and flexible solutions designed specifically for charitable organizations and NGOs.
            </p>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-green-800 mb-3">Non-Profit Benefits:</h4>
            <ul className="space-y-2 text-green-700">
              <li>• Up to 20% discount on all IT services</li>
              <li>• Flexible payment terms to match your budget cycles</li>
              <li>• Free initial IT assessment and consultation</li>
              <li>• Access to Microsoft 365 non-profit licensing</li>
              <li>• Priority support for mission-critical systems</li>
            </ul>
          </div>
          
          <ul className="space-y-4">
            {[
              "Transparent, predictable monthly IT costs.",
              "No hidden fees or unexpected charges.",
              "Scalable solutions that grow with your organization.",
              "Expert guidance on technology grants and funding.",
              "Training for staff to maximize technology usage."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=600&h=400&fit=crop" 
            alt="Affordable Non-Profit IT Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const CloudVoIPSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Cloud & VoIP Solutions
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Modern Tools for Modern Missions</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Move your non-profit to the cloud and modernize your communications with VoIP systems 
            that support remote work and improve collaboration.
          </p>
          {[
            "Microsoft 365 setup with non-profit licensing discounts.",
            "Cloud-based donor management and CRM systems.",
            "VoIP phone systems for remote and hybrid staff.",
            "Secure file sharing and collaboration tools.",
            "Online meeting and virtual event platforms."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Non-Profit Cloud Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Cost Savings</h5>
              <p className="text-sm text-[#3A4E62]/80">Reduce IT infrastructure costs by up to 40% with cloud solutions.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Remote Work</h5>
              <p className="text-sm text-[#3A4E62]/80">Enable staff and volunteers to work from anywhere securely.</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Collaboration</h5>
              <p className="text-sm text-[#3A4E62]/80">Improve communication between teams, board members, and volunteers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for NGOs & Charities
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Technology That Amplifies Your Mission</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our non-profit IT solutions are designed to help you focus on what matters most: 
            serving your community and advancing your cause.
          </p>
          {[
            "Secure donor data and maintain public trust.",
            "Reduce IT costs to put more funds toward programs.",
            "Improve efficiency with modern collaboration tools.",
            "Enable remote work for staff and volunteers.",
            "Streamline operations with integrated systems."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT helped us transition to Microsoft 365 with non-profit licensing, saving us thousands annually. Their support has been exceptional, and now our volunteers can access our systems securely from home. This has dramatically improved our operational efficiency."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Maria Rodriguez</div>
              <div className="text-sm text-[#3A4E62]/70">Executive Director, Auckland Community Trust</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you offer discounts for non-profits?",
            answer: "Yes, we offer up to 20% discount on all IT services for registered non-profit organizations. We also help you access Microsoft 365 non-profit licensing which can provide significant savings on software costs."
          },
          {
            question: "Do you help with donor data security?",
            answer: "Absolutely. We implement robust security measures to protect sensitive donor information, including encrypted data storage, secure backup solutions, and staff training on data privacy best practices to maintain donor trust and meet regulatory requirements."
          },
          {
            question: "Can you provide remote IT support?",
            answer: "Yes, we provide comprehensive remote IT support which is perfect for non-profits with distributed teams or volunteer staff working from home. Our remote support is secure, efficient, and helps minimize costs while ensuring your team gets the help they need."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesNonProfits() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Non-Profits in Auckland",
      "description": "Affordable IT services for non-profits in Auckland. Comsys IT provides reliable IT support, VoIP, and cloud solutions for charities & NGOs.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Non-Profit IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you offer discounts for non-profits?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we offer up to 20% discount on all IT services for registered non-profit organizations. We also help you access Microsoft 365 non-profit licensing which can provide significant savings on software costs." }
        },
        {
          "@type": "Question", "name": "Do you help with donor data security?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We implement robust security measures to protect sensitive donor information, including encrypted data storage, secure backup solutions, and staff training on data privacy best practices to maintain donor trust and meet regulatory requirements." }
        },
        {
          "@type": "Question", "name": "Can you provide remote IT support?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide comprehensive remote IT support which is perfect for non-profits with distributed teams or volunteer staff working from home. Our remote support is secure, efficient, and helps minimize costs while ensuring your team gets the help they need." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Non-Profits in Auckland", "item": "https://www.comsys.co.nz/IndustriesNonProfits" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Non-Profits in Auckland | Comsys IT"
        description="Affordable IT services for non-profits in Auckland. Comsys IT provides reliable IT support, VoIP, and cloud solutions for charities & NGOs."
        keywords="non-profit IT support Auckland, charity IT services, NGO technology solutions, affordable IT for charities"
        canonical="https://www.comsys.co.nz/IndustriesNonProfits"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <AffordableSection />
      <CloudVoIPSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}