
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Phone, Shield, Server, MapPin, Clock, Heart, HeartPulse, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Grafton's medical and research facilities"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Specialist IT Support for Grafton
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        As Auckland's premier medical and research precinct, organizations in Grafton require IT support that meets the highest standards of security, reliability, and compliance. Comsys IT provides expert, specialized IT services for healthcare providers, research institutions, and biotech companies.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=GraftonITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Grafton Healthcare & Business?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Healthcare IT Expertise", 
            desc: "Specialized knowledge in healthcare IT requirements, compliance standards, and patient data security.",
            icon: Heart
          },
          { 
            title: "24/7 Critical Support", 
            desc: "Round-the-clock monitoring and support for healthcare systems that cannot afford downtime.",
            icon: Clock
          },
          { 
            title: "Compliance & Security", 
            desc: "Deep understanding of healthcare data protection, privacy requirements, and regulatory compliance.",
            icon: Shield
          },
          { 
            title: "Reliable Infrastructure", 
            desc: "Enterprise-grade IT solutions designed for the mission-critical nature of healthcare operations.",
            icon: Server
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: HeartPulse, 
      title: "Healthcare & Medical IT Support", 
      desc: "We provide specialized IT support for Grafton's medical community, ensuring patient data confidentiality, secure systems, and reliable access to practice management software.",
      link: "IndustriesHealthcare",
      imageUrl: "https://images.unsplash.com/photo-1624727828489-a1e03b79bba8?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Cybersecurity & Compliance", 
      desc: "Our advanced cybersecurity services help Grafton organizations meet their compliance obligations (e.g., HIPAA), protecting against data breaches and ensuring research integrity.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Server, 
      title: "High-Performance Computing & Data", 
      desc: "We can assist with the setup and management of high-performance computing resources and secure data storage solutions essential for research and development in Grafton.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1591696331111-929a5a8f417e?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Grafton Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Grafton businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Grafton Service Area & Healthcare District
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Grafton Healthcare Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our Auckland IT team provides comprehensive coverage throughout the Grafton healthcare district, serving Auckland Hospital, the University of Auckland medical facilities, private practices, specialist clinics, and healthcare administration buildings. We understand the unique challenges of providing IT support in a healthcare environment and can navigate hospital protocols, security requirements, and compliance standards.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our technicians are experienced with healthcare facility access procedures, understand the critical nature of medical IT systems, and can provide support that minimizes disruption to patient care. We maintain the discretion and professionalism required in healthcare environments while delivering rapid, effective technical solutions.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Healthcare Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Priority response for healthcare-critical systems</p>
              <p><strong>Coverage:</strong> Complete Grafton medical district and surrounding areas</p>
              <p><strong>Compliance:</strong> Healthcare data protection and regulatory standards</p>
              <p><strong>Support Hours:</strong> 24/7 monitoring and emergency response</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12760.234567890123!2d174.76543210987654!3d-36.86123456789!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47abc123def4%3A0x500ef6143a299g3!2sGrafton%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Grafton Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our Auckland IT team provides specialized healthcare IT support throughout Grafton and surrounding medical districts.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "Do you provide specialized IT support for healthcare facilities in Grafton?",
      a: "Yes, we specialize in healthcare IT support with deep understanding of medical industry requirements, patient data security, regulatory compliance, and the critical nature of healthcare systems. Our team is experienced with electronic health records, medical device integration, telemedicine platforms, and healthcare-specific software solutions."
    },
    {
      q: "Can you ensure our medical practice meets data protection and compliance requirements?",
      a: "Absolutely! We ensure all IT systems meet healthcare data protection standards including HIPAA compliance, patient privacy requirements, and regulatory standards. Our solutions include encrypted communications, secure data storage, access controls, audit trails, and regular compliance assessments."
    },
    {
      q: "What emergency IT support do you provide for healthcare operations?",
      a: "We provide 24/7 emergency IT support with priority response for healthcare-critical systems. Our team understands that healthcare operations cannot afford downtime, so we maintain round-the-clock monitoring and can provide immediate remote assistance or rapid onsite response for critical issues affecting patient care."
    },
    {
      q: "Do you support telemedicine and electronic health record systems?",
      a: "Yes, we provide comprehensive support for telemedicine platforms, electronic health record systems, patient management software, and digital health tools. We ensure these systems are secure, compliant, and integrated effectively with your existing healthcare infrastructure."
    },
    {
      q: "Can you provide IT support that works within hospital and medical facility protocols?",
      a: "Yes, our technicians are experienced with healthcare facility protocols, understand infection control procedures, can work around patient care schedules, and maintain the discretion and professionalism required in medical environments. We coordinate with facility management to ensure minimal disruption to healthcare operations."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Grafton Organization?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=GraftonITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportGrafton() {
  const pageUrl = "https://www.comsys.co.nz/it-support-grafton-auckland";
  const title = "IT Support Grafton Auckland | Comsys IT - Medical & Research IT Specialists";
  const description = "Specialized IT support for Grafton's medical and research community. Expert IT services for Auckland Hospital, University of Auckland medical facilities, and biotech companies.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT services for Grafton's medical and research community.",
      "url": pageUrl,
      "telephone": "0800724526",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Grafton, Auckland"
      },
      "serviceType": [
        "Healthcare IT Support", 
        "Medical Practice IT", 
        "Research IT Support", 
        "Cybersecurity", 
        "High-Performance Computing"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide specialized IT support for healthcare facilities in Grafton?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in healthcare IT support with deep understanding of medical industry requirements, patient data security, regulatory compliance, and the critical nature of healthcare systems. Our team is experienced with electronic health records, medical device integration, telemedicine platforms, and healthcare-specific software solutions."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Grafton, medical IT support Auckland, healthcare IT services, research IT Grafton"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
