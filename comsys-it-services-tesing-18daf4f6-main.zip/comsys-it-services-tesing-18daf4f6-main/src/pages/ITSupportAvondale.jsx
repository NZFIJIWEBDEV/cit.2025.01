
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Truck, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Avondale's industrial and creative businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Robust IT Support for Avondale
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        Avondale's unique mix of industrial, manufacturing, and creative industries requires a versatile and reliable IT partner. Comsys IT provides comprehensive IT support tailored for the Avondale business community, from robust factory networks to agile cloud solutions for creative agencies.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=AvondaleITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Avondale Businesses Partner with Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Industrial & Creative IT", 
            desc: "Expertise supporting the unique IT needs of Avondale's manufacturing, warehousing, and creative industries.",
            icon: Truck
          },
          { 
            title: "Central West Location", 
            desc: "Our strategic position ensures fast onsite response times for any urgent IT issues across Avondale.",
            icon: Clock
          },
          { 
            title: "Versatile Solutions", 
            desc: "From robust factory networks to cloud systems for creative agencies, we provide solutions for every business type.",
            icon: Server
          },
          { 
            title: "Proactive Security", 
            desc: "We focus on proactive cybersecurity to protect your valuable business data and intellectual property.",
            icon: Shield
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
  const services = [
    { 
      icon: Truck, 
      title: "IT for Manufacturing & Industry", 
      desc: "We provide robust IT solutions for Avondale's industrial sector, including network infrastructure for factory floors, reliable data backup for critical production data, and proactive cybersecurity to prevent operational disruption.",
      link: "IndustriesManufacturing",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Server, 
      title: "Cloud Solutions for Creative Businesses", 
      desc: "For Avondale's growing creative sector, we offer powerful cloud solutions like Microsoft 365 and Google Workspace to facilitate seamless collaboration, secure file backup, and efficient remote work.",
      link: "MicrosoftOffice",
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Users, 
      title: "Managed IT Support for Local Businesses", 
      desc: "For the retailers and professional services in Avondale, our managed IT plans provide complete peace of mind with unlimited helpdesk support and proactive system monitoring for a fixed monthly cost.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Specialized IT Services for Avondale
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Avondale businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CaseStudySection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-6">Avondale Success Story</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
                A light manufacturing business in Avondale was experiencing frequent network outages on their factory floor, causing costly production delays. Their existing IT provider was slow to respond and couldn't offer a permanent solution.
            </p>
            <div className="bg-gray-50 rounded-2xl p-8 shadow-lg border border-gray-200">
                <p className="text-lg text-[#3A4E62] italic leading-relaxed">
                    "The production downtime was killing our margins. We called Comsys IT, and they were a breath of fresh air. They did a full audit of our factory network and installed a robust, modern WiFi and networking solution. Since they took over our IT on a managed plan, we've had zero network-related production stoppages. Their proactive approach and fast, knowledgeable support have been invaluable for our Avondale operation."
                </p>
                <p className="mt-6 font-semibold text-[#3A4E62]">- Operations Manager, Avondale Manufacturing Ltd</p>
            </div>
        </div>
    </section>
);

const MapSection = () => (
    <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Your Local IT Support in Avondale</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Comsys IT provides fast, reliable, and versatile IT support to the diverse range of businesses across Avondale and the wider West Auckland area.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12760.84411130603!2d174.68652034964596!3d-36.88939223073747!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d46c3b6b93a3d%3A0x500ef6143a29b20!2sAvondale%20Auckland!5e0!3m2!1sen!2snz!4v1700016400321!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Avondale, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Can you provide IT support for a factory or industrial environment in Avondale?',
      a: 'Yes, we specialize in providing robust IT solutions for industrial environments. This includes designing and installing durable factory floor networks, ensuring reliable connectivity for machinery, and providing managed services to minimize operational downtime.'
    },
    {
      q: 'Our creative agency in Avondale deals with large files. How can you help?',
      a: 'We can set you up with high-speed business fibre and secure cloud storage solutions (like Microsoft 365 or Google Workspace) that make collaborating on and sharing large files effortless. We also ensure your valuable creative work is securely backed up.'
    },
    {
      q: 'What makes your managed IT services a good fit for a business in Avondale?',
      a: 'Our managed services are perfect for Avondale businesses because they offer proactive, comprehensive support for a fixed monthly cost. This prevents unexpected IT issues, reduces downtime, enhances security, and allows you to budget effectively, which is crucial for any business, from industrial to retail.'
    },
    {
      q: 'How quickly can you respond to an urgent IT issue at our Avondale premises?',
      a: 'For our managed service clients, we provide a rapid response guarantee. Our local Auckland team can be onsite in Avondale quickly to address any critical issues that cannot be resolved remotely, ensuring your business gets back to full operation as soon as possible.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Drive Your Avondale Business Forward with Better IT
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Whatever your industry, reliable technology is key to success. Contact Comsys IT for a free consultation to discover how we can help your Avondale business improve efficiency and security.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=AvondaleITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);


export default function ITSupportAvondale() {
  const pageUrl = "https://www.comsys.co.nz/it-support-avondale";
  const title = "IT Support Avondale | Industrial & Creative Business IT";
  const description = "Versatile IT support for Avondale's diverse business community, from manufacturing and industrial to creative agencies. Comsys IT provides robust, reliable solutions.";
  
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": "Auckland, NZ",
        "telephone": "0800724526"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Avondale, Auckland"
      },
      "description": "Expert IT support for industrial, manufacturing, and creative businesses in Avondale, Auckland.",
      "name": "IT Support Avondale"
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Areas We Serve", "item": "https://www.comsys.co.nz/AreasWeServe" },
        { "@type": "ListItem", "position": 3, "name": "IT Support Avondale", "item": pageUrl }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can you provide IT support for a factory or industrial environment in Avondale?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we specialize in providing robust IT solutions for industrial environments. This includes designing and installing durable factory floor networks, ensuring reliable connectivity for machinery, and providing managed services to minimize operational downtime."
          }
        },
        {
          "@type": "Question",
          "name": "Our creative agency in Avondale deals with large files. How can you help?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We can set you up with high-speed business fibre and secure cloud storage solutions (like Microsoft 365 or Google Workspace) that make collaborating on and sharing large files effortless. We also ensure your valuable creative work is securely backed up."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Avondale, industrial IT support, manufacturing IT Auckland, creative agency IT"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <CaseStudySection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
