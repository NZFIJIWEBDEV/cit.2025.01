
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Bucklands Beach businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Bucklands Beach
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the thriving community of home offices, small businesses, and professional services in Bucklands Beach, reliable technology is key to success. Comsys IT provides friendly, local, and expert IT support to keep your operations running smoothly, securely, and efficiently.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=BucklandsBeachITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-12">
        Why Choose Comsys IT for Your Bucklands Beach Business?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            icon: MapPin,
            title: "Local Expertise, Rapid Response",
            description: "Being based nearby means we understand the unique needs of Bucklands Beach businesses and can provide on-site support quickly when you need it most.",
          },
          {
            icon: Headset,
            title: "Dedicated & Friendly Support",
            description: "Our team provides personalized service, not just automated responses. You'll work with technicians who know your setup.",
          },
          {
            icon: CheckCircle,
            title: "Proactive & Preventative IT",
            description: "We don't just fix problems; we prevent them. Our proactive approach minimizes downtime and keeps your systems running smoothly.",
          },
          {
            icon: Shield,
            title: "Robust Security Solutions",
            description: "Protect your data and systems from evolving cyber threats with our comprehensive cybersecurity measures tailored for your business.",
          },
          {
            icon: Clock,
            title: "Transparent & Fair Pricing",
            description: "No hidden fees or surprises. Our pricing is clear, competitive, and designed to offer the best value for your IT investment.",
          },
          {
            icon: Building,
            title: "Scalable Solutions for Growth",
            description: "Whether you're a home office or a growing SME, our IT solutions are designed to scale with your business needs.",
          },
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 p-8 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center text-center"
          >
            <div className="w-16 h-16 bg-white border border-gray-200 rounded-full flex items-center justify-center mb-4">
              <item.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-3">{item.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{item.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    {
      icon: Users,
      title: "Managed IT Services",
      desc: "Our managed services plan for Bucklands Beach businesses provides proactive 24/7 monitoring, regular maintenance, and unlimited support for a fixed monthly fee, giving you predictable costs and complete peace of mind.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    {
      icon: Shield,
      title: "Advanced Cybersecurity",
      desc: "We implement multi-layered security strategies, including advanced firewalls, endpoint protection, and data backup solutions to protect your Bucklands Beach business from cyber threats and ensure business continuity.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    {
      icon: Home,
      title: "Home Office IT Solutions",
      desc: "We specialize in setting up secure, efficient home offices with reliable internet, data backup, and professional remote support for the many home-based businesses in Bucklands Beach.",
      link: "HomeFibre",
      imageUrl: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Bucklands Beach Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-16 aspect-h-9 w-full ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Bucklands Beach businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold mb-12">
        Serving the Bucklands Beach Community
      </h2>
      <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto mb-10">
        Comsys IT is proud to offer fast and reliable IT support to businesses and residents throughout Bucklands Beach and surrounding East Auckland areas.
      </p>
      <div className="rounded-xl shadow-2xl overflow-hidden aspect-w-16 aspect-h-9 mb-10">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d102244.60636838332!2d174.92095315!3d-36.883733050000005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4b96f122fcb9%3A0x500ef6143a2c5a0!2sBucklands%20Beach%2C%20Auckland!5e0!3m2!1sen!2snz!4v1701720000000!5m2!1sen!2snz"
          width="100%"
          height="450"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Map of Bucklands Beach"
        ></iframe>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ delay: 0.2 }}
      >
        <Link to={createPageUrl("ContactUs?subject=ITServiceAreaQuery")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            See If We Cover Your Area
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What kind of businesses do you support in Bucklands Beach?",
      a: "We support a wide range of businesses, from home offices and sole traders to small and medium-sized enterprises (SMEs) across various industries. If you're based in Bucklands Beach and need reliable IT, we can help."
    },
    {
      q: "How quickly can you respond to an IT emergency in Bucklands Beach?",
      a: "As a local provider, we pride ourselves on rapid response times. For critical issues, we aim to provide remote or on-site support as quickly as possible, often within hours for Bucklands Beach businesses."
    },
    {
      q: "Do you offer ongoing IT support plans or just one-off fixes?",
      a: "Both! We offer flexible managed IT service plans for ongoing proactive support and maintenance, as well as ad-hoc services for specific issues or projects. We can tailor a solution to fit your needs."
    },
    {
      q: "Can you help with home office IT setups in Bucklands Beach?",
      a: "Absolutely. With many professionals working from home in Bucklands Beach, we specialize in ensuring your home office setup is secure, efficient, and reliable, including internet, Wi-Fi, and data backup solutions."
    },
    {
      q: "What makes your IT services different from others in Auckland?",
      a: "Our difference lies in our local focus, personalized approach, and commitment to proactive problem-solving. We build lasting relationships with our Bucklands Beach clients, acting as your trusted IT partner, not just a service provider."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Bucklands Beach Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=BucklandsBeachITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportBucklands() {
  const pageTitle = "IT Support Bucklands Beach, Auckland | Comsys IT";
  const pageDescription = "Comsys IT provides expert IT support, managed services, and cybersecurity solutions for home offices and businesses in Bucklands Beach, East Auckland.";
  const pageUrl = "https://www.comsys.co.nz/it-support-bucklands-beach";
  const keywords = "IT support Bucklands Beach, East Auckland IT services, home office IT support, small business IT Bucklands Beach, managed IT Bucklands Beach, cybersecurity Bucklands Beach";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support",
      "provider": {
        "@type": "Organization",
        "name": "Comsys IT",
        "url": "https://www.comsys.co.nz",
        // Replace with actual logo URL if available
        "logo": "https://www.comsys.co.nz/images/comsys-logo.png"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Bucklands Beach, Auckland"
      },
      "description": pageDescription,
      "url": pageUrl,
      // Image relevant to the service
      "image": "https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
    },
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Level 1, 102 Great South Road",
        "addressLocality": "Epsom",
        "addressRegion": "Auckland",
        "postalCode": "1051",
        "addressCountry": "NZ"
      },
      "telephone": "+64800724526",
      "url": "https://www.comsys.co.nz",
      // Company logo
      "image": "https://www.comsys.co.nz/images/comsys-logo.png",
      "priceRange": "$$",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday"
          ],
          "opens": "09:00",
          "closes": "17:00"
        }
      ],
      "areaServed": [
        {
          "@type": "Place",
          "name": "Bucklands Beach"
        },
        {
          "@type": "Place",
          "name": "East Auckland"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={pageTitle}
        description={pageDescription}
        keywords={keywords}
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
