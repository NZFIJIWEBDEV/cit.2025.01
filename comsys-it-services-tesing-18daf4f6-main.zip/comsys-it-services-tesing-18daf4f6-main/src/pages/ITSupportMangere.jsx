
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, Truck } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Mangere's industrial and logistics businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Industrial IT Support for Māngere
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        As a critical hub for logistics, transport, and industry near Auckland Airport, businesses in Māngere require IT solutions that are robust, reliable, and always on. Comsys IT provides specialized support to keep your operations running 24/7.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=MangereITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

// Placeholder for WhyChooseUsSection - its content was not provided in the outline.
const WhyChooseUsSection = () => (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-10">Why Choose Comsys IT for Māngere?</h2>
        <div className="grid md:grid-cols-3 gap-8 text-left mt-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="flex items-start bg-gray-50 p-6 rounded-lg shadow-sm"
          >
            <CheckCircle className="text-[#53B289] w-6 h-6 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Local Expertise</h3>
              <p className="text-gray-700">Based in Auckland, our team understands the specific IT needs and challenges faced by Māngere businesses.</p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex items-start bg-gray-50 p-6 rounded-lg shadow-sm"
          >
            <Shield className="text-[#53B289] w-6 h-6 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Proactive Support</h3>
              <p className="text-gray-700">We monitor your systems 24/7 to prevent issues before they impact your operations.</p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex items-start bg-gray-50 p-6 rounded-lg shadow-sm"
          >
            <Headset className="text-[#53B289] w-6 h-6 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Dedicated Helpdesk</h3>
              <p className="text-gray-700">Get unlimited support from friendly, experienced technicians ready to assist you.</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Truck, 
      title: "IT for Transport & Logistics", 
      desc: "We provide robust IT solutions for Māngere's logistics sector, including network infrastructure for warehouses, reliable data backup, and cybersecurity to prevent operational disruption.",
      link: "IndustriesTransport",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "24/7 Monitoring & Security", 
      desc: "For businesses that operate around the clock, our 24/7 proactive monitoring and cybersecurity services ensure your Māngere operations are always protected and efficient.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Users, 
      title: "Managed IT Services", 
      desc: "Our managed IT plans provide complete peace of mind with unlimited helpdesk support, strategic advice, and full system management to keep your Māngere business competitive.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Māngere Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Māngere businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Placeholder for MapSection - its content was not provided in the outline.
const MapSection = () => (
  <section className="py-20 bg-gray-100">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-10">Our Local Presence in Māngere</h2>
      <div className="mt-8 rounded-xl overflow-hidden shadow-lg border border-gray-200">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d102029.07297804473!2d174.6974751792618!3d-36.9534606622416!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4681f26a1575%3A0x500ef6143a29930!2sM%C4%81ngere%2C%20Auckland!5e0!3m2!1sen!2snz!4v1709772658428!5m2!1sen!2snz"
          width="100%"
          height="450"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Māngere, Auckland Map"
        ></iframe>
      </div>
      <p className="mt-6 text-lg text-gray-700">Comsys IT proudly serves businesses across Māngere and the wider South Auckland region, offering prompt and reliable on-site support.</p>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What types of businesses do you support in Māngere?",
      a: "We specialize in supporting transport, logistics, and industrial businesses in Māngere, given its strategic location and operational needs. We understand the unique IT challenges of these sectors, including ensuring 24/7 system reliability, robust cybersecurity, and efficient data management for high-volume operations.",
    },
    {
      q: "How quickly can you respond to an IT issue in Māngere?",
      a: "Our local team in Auckland is structured to provide rapid response for businesses in Māngere. We offer immediate remote support and dispatch technicians for on-site issues to minimize downtime, understanding the critical nature of continuous operations for logistics and industrial companies.",
    },
    {
      q: "Do you offer cybersecurity services for Māngere businesses?",
      a: "Yes, cybersecurity is a cornerstone of our service offering. For Māngere businesses handling sensitive logistics data or operating critical industrial systems, we provide comprehensive solutions including threat detection, incident response, network security, and data encryption to protect against cyber threats.",
    },
    {
      q: "Can you help with network infrastructure for large warehouses?",
      a: "Absolutely. We have extensive experience designing, implementing, and managing network infrastructures for large-scale operations like warehouses and distribution centers. This includes robust Wi-Fi solutions, high-speed wired networks, and seamless integration with warehouse management systems to ensure efficient and reliable connectivity.",
    },
    {
      q: "What makes Comsys IT different from other IT providers in Auckland?",
      a: "Comsys IT stands out due to our deep understanding of the Māngere business environment, particularly in logistics and industrial sectors. We offer tailored, proactive IT solutions, 24/7 monitoring, and a dedicated local team committed to long-term partnerships, ensuring your IT infrastructure is an asset, not a liability.",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Māngere Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=MangereITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportMangere() {
  const title = "Industrial IT Support for Māngere | Comsys IT"; // Updated based on PageHero H1
  const description = "Comsys IT provides comprehensive IT support for transport, logistics, and industrial businesses in Māngere, ensuring 24/7 reliability and security.";
  const pageUrl = createPageUrl('ITSupportMangere');
  const schemas = []; // Placeholder for structured data

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Mangere, logistics IT, transport IT support, industrial IT Mangere"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
