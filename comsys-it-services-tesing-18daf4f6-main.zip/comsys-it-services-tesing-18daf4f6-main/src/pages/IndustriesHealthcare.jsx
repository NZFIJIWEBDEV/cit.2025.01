import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, HeartPulse, Shield, Lock, FileText, ExternalLink, AlertTriangle } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Healthcare in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Reliable IT services for Auckland healthcare providers. Comsys IT delivers secure systems, VoIP, and IT support for clinics and medical facilities.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=HealthcareIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Healthcare IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Healthcare Providers
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=600&h=400&fit=crop" 
            alt="Healthcare IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Protecting Patients, Ensuring Care</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Healthcare providers require IT solutions that ensure patient data privacy, 
              provide reliable access to critical systems, and meet stringent regulatory standards.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Shield,
                title: "Patient Data Security",
                desc: "Protecting sensitive health information (PHI) and maintaining patient privacy."
              },
              {
                icon: FileText,
                title: "Regulatory Compliance (HIPAA/HISO)",
                desc: "Meeting strict healthcare industry regulations and privacy laws."
              },
              {
                icon: HeartPulse,
                title: "System Uptime & Reliability",
                desc: "Ensuring EMR/EHR systems and critical applications are always available."
              },
              {
                icon: Lock,
                title: "Cybersecurity & Ransomware",
                desc: "Healthcare is a prime target for ransomware attacks that can disrupt patient care."
              }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4 p-4 bg-red-50 rounded-lg border border-red-200"
              >
                <challenge.icon className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-red-800 mb-2">{challenge.title}</h4>
                  <p className="text-red-700 text-sm">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SecuritySection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Patient Data Security & Compliance
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { 
            title: "Advanced Endpoint Security", 
            desc: "Protecting devices (desktops, laptops, tablets) from malware and ransomware.",
            icon: Shield
          },
          { 
            title: "Secure Data Backup", 
            desc: "Automated, encrypted backups of patient records with rapid recovery.",
            icon: Lock
          },
          { 
            title: "Compliance Audits", 
            desc: "Regular IT audits to ensure ongoing compliance with healthcare standards.",
            icon: FileText 
          }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg text-center"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-4 mx-auto">
              <item.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">{item.title}</h3>
            <p className="text-[#3A4E62]/80">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const SupportSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Support for Medical Software
      </h2>
       <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Seamless EMR/EHR Integration</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            We provide expert support for leading Electronic Medical Record (EMR) and 
            Electronic Health Record (EHR) systems used by healthcare providers in New Zealand.
          </p>
          {[
            "Setup and configuration of EMR/EHR software.",
            "Integration with diagnostic equipment and other systems.",
            "Troubleshooting and support for clinical staff.",
            "Ensuring reliable access and system performance."
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{item}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8">
            <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">Supported Platforms Include:</h4>
            <div className="grid grid-cols-2 gap-4">
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">Medtech Evolution</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">Indici</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">MyPractice</span>
              <span className="bg-white p-3 rounded-lg text-center font-medium text-[#3A4E62]">and more...</span>
            </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Healthcare Providers
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Focus on Patient Care, Not IT</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our healthcare IT solutions are designed to improve operational efficiency, enhance patient data security, 
            and allow your clinical staff to focus on what matters most: patient outcomes.
          </p>
          {[
            "Improved patient data security and privacy.",
            "Increased efficiency through reliable EMR/EHR access.",
            "Reduced risk of ransomware and data breaches.",
            "Peace of mind with ongoing compliance and support.",
            "Faster resolution of IT issues for clinical staff."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT has been instrumental in ensuring our clinic's IT systems are secure and compliant. Their proactive approach to security and fast support for our EMR system means we can focus entirely on our patients. We've had 100% uptime since they took over."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <HeartPulse className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Dr. Mark Stevens</div>
              <div className="text-sm text-[#3A4E62]/70">Practice Manager, Auckland Medical Centre</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support medical practice management software?",
            answer: "Yes, we have extensive experience supporting leading medical software in New Zealand, including Medtech Evolution, Indici, and MyPractice. We help with setup, integration, troubleshooting, and ensuring your systems run smoothly and efficiently."
          },
          {
            question: "How do you ensure patient data security and compliance?",
            answer: "We implement a multi-layered security approach including advanced endpoint protection, secure data backups, firewall management, and staff training. We also conduct regular IT audits to ensure your practice remains compliant with New Zealand's healthcare privacy regulations (like HISO)."
          },
          {
            question: "Do you provide fast support for clinical emergencies?",
            answer: "Absolutely. We understand that in a healthcare setting, IT issues can be critical. We offer prioritized support with fast response times for clinical emergencies to ensure minimal disruption to patient care. Our proactive monitoring often resolves issues before they impact your staff."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesHealthcare() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Healthcare in Auckland",
      "description": "Reliable IT services for Auckland healthcare providers. Comsys IT delivers secure systems, VoIP, and IT support for clinics and medical facilities.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Healthcare IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support medical practice management software?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we have extensive experience supporting leading medical software in New Zealand, including Medtech Evolution, Indici, and MyPractice. We help with setup, integration, troubleshooting, and ensuring your systems run smoothly and efficiently." }
        },
        {
          "@type": "Question", "name": "How do you ensure patient data security and compliance?",
          "acceptedAnswer": { "@type": "Answer", "text": "We implement a multi-layered security approach including advanced endpoint protection, secure data backups, firewall management, and staff training. We also conduct regular IT audits to ensure your practice remains compliant with New Zealand's healthcare privacy regulations (like HISO)." }
        },
        {
          "@type": "Question", "name": "Do you provide fast support for clinical emergencies?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We understand that in a healthcare setting, IT issues can be critical. We offer prioritized support with fast response times for clinical emergencies to ensure minimal disruption to patient care. Our proactive monitoring often resolves issues before they impact your staff." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Healthcare in Auckland", "item": "https://www.comsys.co.nz/IndustriesHealthcare" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Healthcare in Auckland | Comsys IT"
        description="Reliable IT services for Auckland healthcare providers. Comsys IT delivers secure systems, VoIP, and IT support for clinics and medical facilities."
        keywords="healthcare IT support Auckland, medical IT services, EMR support, HIPAA compliance NZ, Medtech support"
        canonical="https://www.comsys.co.nz/IndustriesHealthcare"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <SecuritySection />
      <SupportSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}