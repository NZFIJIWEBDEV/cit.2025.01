import React from 'react';
import { Button } from '@/components/ui/button';
import { Download, HardDrive, Shield } from 'lucide-react';

export default function RemoteSupportPage() {
  return (
    <div className="bg-gray-50 pt-28 pb-20">
      <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
        <Shield className="w-16 h-16 text-[#53B289] mx-auto mb-6" />
        <h1 className="text-4xl lg:text-5xl font-bold text-[#3A4E62]">Remote IT Support</h1>
        <p className="mt-4 text-xl text-[#3A4E62]/80 max-w-2xl mx-auto">
          Get instant, secure, and reliable IT support wherever you are. Our technicians can resolve most issues remotely, saving you time and money.
        </p>
      </div>

      <div className="max-w-5xl mx-auto mt-16 px-6 lg:px-12">
        <div className="bg-white rounded-2xl shadow-lg p-8 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-2xl font-bold text-[#3A4E62] mb-4">Download Our Remote Support Tool</h2>
            <p className="text-[#3A4E62]/80 mb-6">
              To allow our technicians to connect to your computer, please download our secure remote support client. It's a small, safe application that allows for a one-time connection.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-[#53B289] hover:bg-[#4aa07b]">
                <Download className="mr-2 h-4 w-4" /> Download for Windows
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download for Mac
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-4">By downloading, you agree to allow our technician temporary access to your device.</p>
          </div>
          <div className="text-center">
            <img src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=400&h=300&fit=crop" alt="IT Professional providing remote support" className="rounded-lg mx-auto" />
          </div>
        </div>
      </div>
    </div>
  );
}