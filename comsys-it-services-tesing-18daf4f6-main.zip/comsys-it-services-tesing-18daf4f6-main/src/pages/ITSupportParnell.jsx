
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, ShoppingCart } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Parnell's boutique businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Boutique IT Support for Parnell
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        In Auckland's historic and stylish heart, Parnell's art galleries, designer boutiques, and professional firms demand IT that is as sophisticated and reliable as they are. Comsys IT provides premium, tailored support to match the unique character of your Parnell business.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ParnellITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Parnell Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Heritage Building Expertise", 
            desc: "Experience working with Parnell's unique mix of heritage and modern buildings.",
            icon: Building
          },
          { 
            title: "Local Central Auckland Team", 
            desc: "Our technicians know Parnell and can reach you quickly from our Auckland base.",
            icon: Users
          },
          { 
            title: "Boutique Business Focus", 
            desc: "Specialized solutions for Parnell's creative agencies, consultancies, and professional services.",
            icon: CheckCircle
          },
          { 
            title: "Flexible Support Options", 
            desc: "Both remote and onsite support tailored to your business needs and budget.",
            icon: Shield
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: ShoppingCart, 
      title: "Boutique Retail & Gallery IT", 
      desc: "We provide seamless POS systems, secure payment processing, and elegant Guest WiFi solutions that enhance the premium customer experience expected in Parnell.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Building, 
      title: "IT for Professional Firms", 
      desc: "For the law, design, and consultancy firms in Parnell, we deliver secure, high-performance networks, cloud solutions, and proactive managed services to ensure maximum uptime and data protection.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Advanced Cybersecurity", 
      desc: "Protect your high-value business and client data with our comprehensive cybersecurity services, including advanced threat protection, data encryption, and compliance support.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Parnell Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Parnell businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Parnell Service Area & Location
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Parnell Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our Auckland IT team provides comprehensive coverage throughout Parnell, from Parnell Road's heritage precinct to the modern developments near the Domain. We service businesses along the main commercial strips, in converted heritage buildings, and in contemporary office complexes throughout the area.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our technicians understand Parnell's unique character and the special requirements of working in heritage buildings. We can navigate access requirements, work sensitively with building constraints, and provide solutions that complement rather than compromise the area's distinctive charm.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> 15-minute response for Parnell businesses</p>
              <p><strong>Coverage:</strong> Complete Parnell area including heritage and modern buildings</p>
              <p><strong>Parking:</strong> Familiar with Parnell parking and access requirements</p>
              <p><strong>Building Access:</strong> Experienced with heritage building protocols</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12761.87455647496!2d174.77654484871638!3d-36.86054840000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4704e2f4c37d%3A0x500ef6143a299d0!2sParnell%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Parnell Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our Auckland IT team provides fast onsite support throughout Parnell and surrounding central Auckland areas.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "Do you have experience working in Parnell's heritage buildings?",
      a: "Yes, we have extensive experience working in Parnell's heritage buildings and understand the unique challenges they present. Our technicians are skilled at installing modern IT infrastructure while respecting building heritage requirements and working within structural constraints. We coordinate with building management and heritage specialists as needed."
    },
    {
      q: "Can you provide IT support for creative agencies in Parnell?",
      a: "Absolutely! We specialize in supporting creative agencies and design studios with their unique IT requirements. This includes high-performance workstations, large file storage solutions, creative software support, color-accurate displays, and fast internet connections for handling large design files and client presentations."
    },
    {
      q: "What makes your Parnell IT support different from larger providers?",
      a: "We provide personalized service tailored to Parnell's unique business community. Our technicians understand the area's character, building requirements, and the specific needs of boutique businesses. We offer flexible service options, transparent pricing, and build long-term relationships with our clients rather than treating them as account numbers."
    },
    {
      q: "Do you provide emergency IT support for Parnell businesses?",
      a: "Yes, we provide rapid emergency IT support for Parnell businesses. Our local Auckland team can reach Parnell locations quickly, and we offer 24/7 remote support for urgent issues. We understand that creative and professional businesses can't afford extended downtime, so we prioritize emergency response."
    },
    {
      q: "Can you help with business fibre installation in older Parnell buildings?",
      a: "Yes, we have experience installing business fibre in Parnell's diverse building types, from heritage structures to modern developments. We work with building owners and fibre providers to find the best installation approach while respecting any heritage or structural requirements."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Parnell Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=ParnellITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportParnell() {
  const pageUrl = "https://www.comsys.co.nz/it-support-parnell-auckland";
  const title = "IT Support Parnell Auckland | Comsys IT - Boutique Business Solutions";
  const description = "Premium IT support for Parnell businesses, including retail, galleries, and professional firms. Tailored solutions for Auckland's unique heritage and modern business environment.";

  // Define FAQs locally to be accessible for schema generation
  const faqs = [
    {
      q: "Do you have experience working in Parnell's heritage buildings?",
      a: "Yes, we have extensive experience working in Parnell's heritage buildings and understand the unique challenges they present. Our technicians are skilled at installing modern IT infrastructure while respecting building heritage requirements and working within structural constraints. We coordinate with building management and heritage specialists as needed."
    },
    {
      q: "Can you provide IT support for creative agencies in Parnell?",
      a: "Absolutely! We specialize in supporting creative agencies and design studios with their unique IT requirements. This includes high-performance workstations, large file storage solutions, creative software support, color-accurate displays, and fast internet connections for handling large design files and client presentations."
    },
    {
      q: "What makes your Parnell IT support different from larger providers?",
      a: "We provide personalized service tailored to Parnell's unique business community. Our technicians understand the area's character, building requirements, and the specific needs of boutique businesses. We offer flexible service options, transparent pricing, and build long-term relationships with our clients rather than treating them as account numbers."
    },
    {
      q: "Do you provide emergency IT support for Parnell businesses?",
      a: "Yes, we provide rapid emergency IT support for Parnell businesses. Our local Auckland team can reach Parnell locations quickly, and we offer 24/7 remote support for urgent issues. We understand that creative and professional businesses can't afford extended downtime, so we prioritize emergency response."
    },
    {
      q: "Can you help with business fibre installation in older Parnell buildings?",
      a: "Yes, we have experience installing business fibre in Parnell's diverse building types, from heritage structures to modern developments. We work with building owners and fibre providers to find the best installation approach while respecting any heritage or structural requirements."
    }
  ];

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT support services for Parnell businesses",
      "url": pageUrl,
      "telephone": "092423700", // Consider updating to 0800 724 526 if that's the primary
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Parnell, Auckland"
      },
      "serviceType": [
        "IT Support", "VoIP Solutions", "CCTV Systems", "Business Fibre", "Data Backup"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqs.map(faq => ({ // Dynamically generate schema for all FAQs
        "@type": "Question",
        "name": faq.q,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq.a.length > 200 ? faq.a.substring(0, faq.a.indexOf('.', 100) + 1) : faq.a // Truncate answer for schema if too long, finding first period after 100 chars
        }
      }))
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Parnell, boutique IT support, professional services IT Parnell, retail IT Auckland"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection /> {/* Renamed from LocationSection */}
      <FAQSection />
      <CTASection />
    </div>
  );
}
