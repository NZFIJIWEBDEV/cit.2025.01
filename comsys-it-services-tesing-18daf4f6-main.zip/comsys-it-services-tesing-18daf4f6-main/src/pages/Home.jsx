
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import Seo from "@/components/layout/Seo";
import Hero from "@/components/sections/Hero";
import Services from "@/components/sections/Services";
import WhyChooseUs from "@/components/sections/WhyChooseUs";
import PartnerLogos from "@/components/features/PartnerLogos";
import TestimonialsCarousel from "@/components/features/TestimonialsCarousel";
import Stats from "@/components/sections/Stats";
import HowWeWork from "@/components/sections/HowWeWork";
import IndustrySolutions from "@/components/sections/IndustrySolutions";
import HomeFAQ from "@/components/sections/HomeFAQ";
import SecurityBadges from "@/components/features/SecurityBadges";
import CaseStudiesSlider from "@/components/features/CaseStudiesSlider";
import AwardsAndCertifications from "@/components/features/AwardsAndCertifications";
import WiFiCoverageMap from "@/components/interactive/WiFiCoverageMap";
import ExpandableServiceFeatures from "@/components/interactive/ExpandableServiceFeatures";
import ComparisonChart from "@/components/interactive/ComparisonChart";
import { Button } from "@/components/ui/button";
import { Calculator, ArrowRight } from "lucide-react";

const CalculatorCTA = () => (
    <section className="py-20 md:py-28 bg-white relative">
        <div className="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
            <div className="bg-white/80 backdrop-blur-md rounded-3xl p-8 md:p-12 shadow-2xl border border-slate-200/80">
                <div className="flex items-center justify-center mb-6">
                    <div className="bg-gradient-to-br from-slate-700 to-[#3A4E62] p-4 rounded-2xl shadow-lg">
                        <Calculator className="w-10 h-10 text-white" />
                    </div>
                </div>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-5">
                    Curious About Your IT Spending?
                </h2>
                <p className="text-lg md:text-xl text-[#3A4E62]/80 max-w-3xl mx-auto mb-10 leading-relaxed">
                    Use our free interactive calculator to discover how much your business could potentially save by switching to COMSYS for your managed IT services. Get a personalized estimate in under a minute.
                </p>
                <Link to={createPageUrl('ContactUs')}>
                    <Button size="lg" className="bg-gradient-to-r from-slate-800 to-[#3A4E62] hover:shadow-xl hover:scale-105 text-white group transition-all duration-300 ease-in-out px-10 py-7 text-lg font-semibold rounded-2xl shadow-lg">
                        Request a Consultation
                        <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1.5 transition-transform" />
                    </Button>
                </Link>
            </div>
        </div>
    </section>
);


export default function Home() {
  const homeSchema = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "alternateName": "COMSYS IT & Communications",
      "description": "Comsys IT provides reliable IT support, CCTV, VoIP, and business fibre services in Auckland. Expert IT services tailored for businesses across New Zealand.",
      "url": "https://www.comsys.co.nz/",
      "telephone": "09 242 3700",
      "email": "info@comsys.co.nz",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -36.8485,
        "longitude": 174.6334
      },
      "openingHoursSpecification": {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        "opens": "08:00",
        "closes": "18:00"
      },
      "areaServed": [
        {
          "@type": "City",
          "name": "Auckland",
          "containedInPlace": {
            "@type": "Country",
            "name": "New Zealand"
          }
        }
      ],
      "serviceType": [
        "IT Support",
        "CCTV Installation",
        "VoIP Solutions", 
        "Business Fibre",
        "Managed IT Services",
        "Cybersecurity"
      ],
      "sameAs": [
        "https://www.facebook.com/comsysnz/",
        "https://www.linkedin.com/company/comsys-it-&-communications-ltd/"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        }
      ]
    }
  ];

  return (
    <div className="bg-white">
      <Seo
        title="Comsys IT | IT Support, CCTV, VoIP & Business Fibre Solutions"
        description="Comsys IT provides reliable IT support, CCTV, VoIP, and business fibre services in Auckland. Expert IT services tailored for businesses across New Zealand."
        keywords="IT support Auckland, CCTV installation, VoIP solutions, business fibre, managed IT services, cybersecurity Auckland"
        canonical="https://www.comsys.co.nz/"
        ogTitle="Comsys IT | Auckland's Most Trusted IT Support & Solutions"
        ogDescription="Professional IT support, CCTV, VoIP and business fibre solutions for Auckland businesses. Local expertise, reliable service."
        ogImage="https://www.comsys.co.nz/wp-content/uploads/2021/04/Comsys-logo-150x55-1.png"
        schemas={homeSchema}
      />
      
      <Hero />
      <Stats />
      <Services />
      <ExpandableServiceFeatures />
      <CalculatorCTA />
      <WiFiCoverageMap />
      <HowWeWork />
      <WhyChooseUs />
      <ComparisonChart />
      <IndustrySolutions />
      <CaseStudiesSlider />
      <TestimonialsCarousel />
      <AwardsAndCertifications />
      <SecurityBadges />
      <HomeFAQ />
      <PartnerLogos />
    </div>
  );
}
