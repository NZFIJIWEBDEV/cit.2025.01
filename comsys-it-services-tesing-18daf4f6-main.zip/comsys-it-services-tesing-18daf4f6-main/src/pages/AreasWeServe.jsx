
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, MapPin, Clock, Users, Phone } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Areas We Serve in Auckland – Comsys IT
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed"
      >
        Comsys IT delivers professional IT support and technology solutions across Auckland. Whether you're in the CBD, West Auckland, or South Auckland, our team provides fast, reliable, and affordable IT services. From VoIP and business fibre to CCTV and data backup, we keep local businesses connected and secure across all Auckland regions.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=LocalITSupport")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Local IT Support
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ServiceCoverageSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Our Service Coverage in Auckland
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1524813686514-a57563d77965?w=600&h=400&fit=crop" 
            alt="Auckland IT Support Coverage Map"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Complete Auckland Coverage</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Our experienced technicians provide comprehensive IT support across all Auckland regions. 
              No matter where your business is located, we deliver the same high-quality service and rapid response times.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {[
              { region: "Central Auckland", desc: "CBD, Ponsonby, Parnell, Newmarket" },
              { region: "North Auckland", desc: "North Shore, Albany, Takapuna, Browns Bay" },
              { region: "East Auckland", desc: "Howick, Pakuranga, Botany, Bucklands Beach" },
              { region: "South Auckland", desc: "Manukau, Papatoetoe, Māngere, Papakura" },
              { region: "West Auckland", desc: "Henderson, Massey, New Lynn, Te Atatū" }
            ].map((area, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start space-x-4 p-4 bg-[#53B289]/5 rounded-lg border border-[#53B289]/20"
              >
                <MapPin className="w-6 h-6 text-[#53B289] flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-1">{area.region}</h4>
                  <p className="text-sm text-[#3A4E62]/70">{area.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const SuburbsSection = () => {
  const regions = [
    {
      title: "Central Auckland",
      suburbs: [
        { name: "Auckland CBD", page: "ITSupportAucklandCBD" },
        { name: "Ponsonby", page: "ITSupportPonsonby" }, 
        { name: "Parnell", page: "ITSupportParnell" },
        { name: "Newmarket", page: "ITSupportNewmarket" },
        { name: "Grafton", page: "ITSupportGrafton" }, 
        { name: "Grey Lynn", page: "ITSupportGreyLynn" }, 
        { name: "Mt Eden", page: "ITSupportMtEden" }, 
        { name: "Kingsland", page: "ITSupportKingsland" }, 
        { name: "Eden Terrace", page: "ITSupportEdenTerrace" }, 
        { name: "Freeman's Bay", page: "ITSupportFreemans" }
      ]
    },
    {
      title: "West Auckland",
      suburbs: [
        { name: "Henderson", page: "ITSupportHenderson" },
        { name: "Waitākere", page: "ITSupportWaitakere" }, 
        { name: "Massey", page: "ITSupportMassey" }, 
        { name: "New Lynn", page: "ITSupportNewLynn" }, 
        { name: "Kelston", page: "ITSupportKelston" }, 
        { name: "Te Atatū", page: "ITSupportTeAtatu" }, 
        { name: "Glen Eden", page: "ITSupportGlenEden" }, 
        { name: "Glendene", page: "ITSupportGlendene" }, 
        { name: "Swanson", page: "ITSupportSwanson" }, 
        { name: "Ranui", page: "ITSupportRanui" }
      ]
    },
    {
      title: "North Auckland",
      suburbs: [
        { name: "Albany", page: "ITSupportAlbany" },
        { name: "Takapuna", page: "ITSupportTakapuna" },
        { name: "North Shore", page: "ITSupportNorthShore" }, 
        { name: "Glenfield", page: "ITSupportGlenfield" }, 
        { name: "Milford", page: "ITSupportMilford" }, 
        { name: "Birkenhead", page: "ITSupportBirkenhead" }, 
        { name: "Devonport", page: "ITSupportDevonport" }, 
        { name: "Browns Bay", page: "ITSupportBrownsBay" }, 
        { name: "Mairangi Bay", page: "ITSupportMairangiBay" }, 
        { name: "Campbells Bay", page: "ITSupportCampbells" }
      ]
    },
    {
      title: "East Auckland",
      suburbs: [
        { name: "Howick", page: "ITSupportHowick" },
        { name: "Pakuranga", page: "ITSupportPakuranga" }, 
        { name: "East Tamaki", page: "ITSupportEastTamaki"},
        { name: "Botany Downs", page: "ITSupportBotanyDowns" }, 
        { name: "Bucklands Beach", page: "ITSupportBucklands" }, 
        { name: "Panmure", page: "ITSupportPanmure" }, 
        { name: "Glen Innes", page: "ITSupportGlenInnes" },
        { name: "St Heliers", page: "ITSupportStHeliers" }, 
        { name: "Kohimarama", page: "ITSupportKohimarama" }, 
        { name: "Mission Bay", page: "ITSupportMissionBay" }, 
        { name: "Mellons Bay", page: "ITSupportMellonsBay" }
      ]
    },
    {
      title: "South Auckland",
      suburbs: [
        { name: "Manukau", page: "ITSupportManukau" },
        { name: "Papatoetoe", page: "ITSupportPapatoetoe" }, 
        { name: "Ōtāhuhu", page: "ITSupportOtahuhu" }, 
        { name: "Māngere", page: "ITSupportMangere" },
        { name: "Papakura", page: "ITSupportPapakura" },
        { name: "Takanini", page: "ITSupportTakanini" }, 
        { name: "Pukekohe", page: "ITSupportPukekohe" }, 
        { name: "Manurewa", page: "ITSupportManurewa" }, 
        { name: "Flat Bush", page: "ITSupportFlatBush" }
      ]
    },
    {
      title: "Additional Areas",
      suburbs: [
        { name: "Remuera", page: "ITSupportRemuera" }, 
        { name: "Epsom", page: "ITSupportEpsom" }, 
        { name: "Mount Roskill", page: "ITSupportMountRoskill" }, 
        { name: "Onehunga", page: "ITSupportOnehunga" }, 
        { name: "Royal Oak", page: "ITSupportRoyalOak" }, 
        { name: "Three Kings", page: "ITSupportThreeKings" }, 
        { name: "Hillsborough", page: "ITSupportHillsborough" }, 
        { name: "Lynfield", page: "ITSupportLynfield" }, 
        { name: "Blockhouse Bay", page: "ITSupportBlockhouseBay" }, 
        { name: "Avondale", page: "ITSupportAvondale" }
      ]
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Suburbs We Serve in Auckland
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {regions.map((region, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <h3 className="text-xl font-bold text-[#3A4E62] mb-4 flex items-center">
                <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
                {region.title}
              </h3>
              <div className="space-y-2">
                {region.suburbs.map((suburb, subIndex) => {
                  const commonClasses = "inline-block bg-[#53B289]/10 text-[#3A4E62] px-3 py-1 rounded-full text-sm mr-2 mb-2 transition-colors";
                  if (suburb.page) {
                    return (
                      <Link key={subIndex} to={createPageUrl(suburb.page)} className={`${commonClasses} hover:bg-[#53B289]/20 hover:text-[#53B289] font-semibold underline`}>
                        {suburb.name}
                      </Link>
                    );
                  }
                  return (
                    <span key={subIndex} className={`${commonClasses} cursor-default`}>
                      {suburb.name}
                    </span>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const LocalBenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Local IT Support Benefits
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            icon: Clock,
            title: "Fast Response Times",
            desc: "Local technicians mean faster response from across Auckland"
          },
          {
            icon: Users,
            title: "Onsite Support Available", 
            desc: "We can visit your premises in any Auckland suburb"
          },
          {
            icon: CheckCircle,
            title: "Tailored Solutions",
            desc: "IT solutions designed for Auckland businesses"
          },
          {
            icon: Phone,
            title: "Affordable Packages",
            desc: "Competitive monthly IT support rates across all areas"
          }
        ].map((benefit, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <benefit.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{benefit.title}</h3>
            <p className="text-[#3A4E62]/70">{benefit.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Services Available in All Locations
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          { 
            service: "IT Support & Remote Support",
            desc: "24/7 monitoring and helpdesk support across Auckland",
            link: "ITSupport"
          },
          {
            service: "VoIP Phone Systems & SIP Trunks", 
            desc: "Modern business phone solutions for all suburbs",
            link: "VoIPSolutions"
          },
          {
            service: "Business & Home Fibre",
            desc: "High-speed internet connectivity throughout Auckland",
            link: "BusinessFibre"
          },
          {
            service: "CCTV Security Systems",
            desc: "Professional security camera installation and monitoring",
            link: "CCTVBusiness"
          },
          {
            service: "Data Backup & Recovery",
            desc: "Automated backup solutions to protect your data",
            link: "DataBackupRecovery"
          },
          {
            service: "Web Design & Hosting",
            desc: "Professional websites and reliable hosting services", 
            link: "WebDesignHosting"
          }
        ].map((service, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer"
          >
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3 group-hover:text-[#53B289] transition-colors">
              {service.service}
            </h3>
            <p className="text-[#3A4E62]/70 mb-4">{service.desc}</p>
            <Link to={createPageUrl(service.link)}>
              <Button variant="outline" size="sm" className="group-hover:bg-[#53B289] group-hover:text-white group-hover:border-[#53B289] transition-all">
                Learn More
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const LocationSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Find IT Support Near You
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Auckland-Based IT Experts</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Our team is based in Auckland and can quickly reach businesses across the region. 
              Whether you need emergency support or scheduled maintenance, we're never far away.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Comsys IT Head Office
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p>Level 1, 30 St Benedicts Street</p>
              <p>Eden Terrace, Auckland 1010</p>
              <p className="flex items-center">
                <Phone className="w-4 h-4 mr-2 text-[#53B289]" />
                0800 724 526
              </p>
            </div>
          </div>
          
          <div className="bg-blue-50 p-6 rounded-2xl border border-blue-200">
            <h4 className="font-semibold text-[#3A4E62] mb-3">Service Areas Coverage:</h4>
            <ul className="grid grid-cols-2 gap-2 text-sm text-[#3A4E62]/80">
              <li>• Central Auckland (CBD)</li>
              <li>• North Shore</li>
              <li>• West Auckland</li>
              <li>• East Auckland</li>
              <li>• South Auckland</li>
              <li>• Waitākere</li>
            </ul>
          </div>
        </div>
        
        <div className="bg-gray-100 rounded-2xl p-8 text-center">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <MapPin className="w-16 h-16 text-[#53B289] mx-auto mb-4" />
            <h4 className="text-xl font-bold text-[#3A4E62] mb-3">Interactive Map</h4>
            <p className="text-[#3A4E62]/70 mb-6">
              Click below to view our location and service areas on Google Maps
            </p>
            <Button className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer" className="flex items-center">
                View on Google Maps
                <ArrowRight className="ml-2 w-4 h-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Do you provide IT support outside Auckland?',
      a: 'While our primary service area is Auckland, we can provide remote support services to businesses across New Zealand. For on-site support, we focus on the greater Auckland region to ensure rapid response times.'
    },
    {
      q: 'Can you come onsite for support in West Auckland?',
      a: 'Absolutely! We provide on-site IT support to all areas of West Auckland including Henderson, Massey, New Lynn, Te Atatū, and surrounding suburbs. Our local technicians can typically reach West Auckland locations within 30-60 minutes.'
    },
    {
      q: 'Do you offer remote support across New Zealand?',
      a: 'Yes, we provide remote IT support services across New Zealand. Many IT issues can be resolved remotely, allowing us to help businesses nationwide with software problems, system configuration, and ongoing IT management.'
    },
    {
      q: 'What is your response time for different Auckland areas?',
      a: 'Our response times vary by location: Central Auckland (15-30 minutes), North Shore (30-45 minutes), West Auckland (30-60 minutes), East Auckland (45-60 minutes), and South Auckland (30-60 minutes). Emergency support is prioritized across all areas.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg mb-4 border-2 border-[#53B289]/10 hover:border-[#53B289]/30 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
  <section className="py-20 bg-[#3A4E62]">
    <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center text-white">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="space-y-6"
      >
        <h2 className="text-3xl lg:text-4xl font-bold">
          Looking for IT Support in Your Area?
        </h2>
        <p className="text-xl text-white/90 max-w-2xl mx-auto">
          Contact Comsys IT today for fast, reliable, and local IT solutions across Auckland. 
          Our experienced technicians are ready to help your business succeed.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Link to={createPageUrl("ContactUs?subject=LocalITSupport")}>
            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
              Get Free IT Assessment
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <a href="tel:0800724526">
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#3A4E62]">
              <Phone className="mr-2 w-5 h-5" />
              Call 0800 724 526
            </Button>
          </a>
        </div>
      </motion.div>
    </div>
  </section>
);

export default function AreasWeServe() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Professional IT support across Auckland regions",
      "url": "https://www.comsys.co.nz/AreasWeServe",
      "telephone": "0800724526",
      "address": {
        "@type": "PostalAddress", 
        "streetAddress": "Level 1, 30 St Benedicts Street",
        "addressLocality": "Auckland",
        "postalCode": "1010",
        "addressCountry": "NZ"
      },
      "areaServed": [
        { "@type": "City", "name": "Auckland" },
        { "@type": "AdministrativeArea", "name": "Central Auckland" },
        { "@type": "AdministrativeArea", "name": "North Auckland" },
        { "@type": "AdministrativeArea", "name": "East Auckland" },
        { "@type": "AdministrativeArea", "name": "South Auckland" },
        { "@type": "AdministrativeArea", "name": "West Auckland" }
      ],
      "serviceType": [
        "IT Support", "VoIP Solutions", "Business Fibre", "CCTV Systems", "Data Backup"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide IT support outside Auckland?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "While our primary service area is Auckland, we can provide remote support services to businesses across New Zealand."
          }
        },
        {
          "@type": "Question", 
          "name": "Can you come onsite for support in West Auckland?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We provide on-site IT support to all areas of West Auckland including Henderson, Massey, New Lynn, Te Atatū, and surrounding suburbs."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Support Across Auckland | Comsys IT – Areas We Serve"
        description="Comsys IT provides IT support, VoIP, CCTV, and fibre services across Auckland. Serving businesses in North, South, East, and West Auckland suburbs."
        keywords="IT support Auckland suburbs, Auckland IT services, local IT support, Auckland CBD IT, North Shore IT support, West Auckland IT, South Auckland IT"
        canonical="https://www.comsys.co.nz/AreasWeServe"
        schemas={schemas}
      />
      
      <PageHero />
      <ServiceCoverageSection />
      <SuburbsSection />
      <LocalBenefitsSection />
      <ServicesSection />
      <LocationSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
