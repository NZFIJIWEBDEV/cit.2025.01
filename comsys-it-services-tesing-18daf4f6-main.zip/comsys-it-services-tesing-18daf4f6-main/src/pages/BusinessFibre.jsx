
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Download, Upload, Shield, Clock, Users, Zap, HelpCircle, MapPin, Star, ArrowRight, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import AddressPicker from '../components/broadband/AddressPicker';
import ContactSection from '../components/sections/Contact';
import SignupModal from '../components/broadband/SignupModal'; // Added SignupModal import

const businessPlans = [
  {
    name: 'Small Business Fibre',
    price: 95,
    speed: '500/500 Mbps',
    downloadUpload: '500/500 Mbps',
    features: [
      'Business Grade SLA',
      'No fixed term contract',
      'Public IPv4 address included',
      'Coverage areas only',
      'Unlimited data',
      'Priority support'
    ],
    popular: false,
    note: null
  },
  {
    name: 'Small Business Max',
    price: 115,
    speed: '950/500 Mbps',
    downloadUpload: '950/500 Mbps',
    features: [
      'Business Grade SLA',
      'No fixed term contract', 
      'Public IPv4 address included',
      'Coverage areas only',
      'Unlimited data',
      'Enhanced support'
    ],
    popular: true,
    note: null
  },
  {
    name: 'Hyper Fibre 2000',
    price: 155,
    speed: '2000/2000 Mbps',
    downloadUpload: '2000/2000 Mbps',
    features: [
      'Business Grade SLA',
      'No fixed term contract',
      'Public IPv4 address included', 
      'Coverage areas only',
      'Unlimited data',
      'Premium support'
    ],
    popular: false,
    note: 'Note'
  }
];

const features = [
  {
    icon: Shield,
    title: 'Business Grade',
    description: 'SLA-backed connections with guaranteed uptime and priority support'
  },
  {
    icon: Zap,
    title: 'Ultra Fast',
    description: 'Speeds up to 2Gbps for demanding applications and large teams'
  },
  {
    icon: Clock,
    title: 'No Limits',
    description: 'Unlimited data usage - no caps, no throttling, no surprises'
  },
  {
    icon: MapPin,
    title: 'NZ-Wide Coverage',
    description: 'Fibre, Fixed Wireless, and DSL options across New Zealand'
  }
];

const benefits = [
  {
    icon: Shield,
    title: 'Business Grade SLA',
    description: 'Guaranteed uptime and priority support for your business operations'
  },
  {
    icon: Zap,
    title: 'Ultra-Fast Speeds',
    description: 'Symmetric upload and download speeds up to 2Gbps for demanding applications'
  },
  {
    icon: Clock,
    title: 'No Fixed Term',
    description: 'Flexible contracts with no lock-in periods - change or cancel anytime'
  },
  {
    icon: MapPin,
    title: 'Public IPv4',
    description: 'Static public IP address included for hosting and remote access'
  }
];

const speedComparisons = [
  {
    speed: '500/500 Mbps',
    planName: 'Small Business Fibre',
    capabilities: [
      'Up to 15 staff working simultaneously',
      '2-3 HD video calls at once',
      'Quick cloud file sync and backups',
      'Smooth CRM and accounting software',
      'Reliable VoIP for 5-10 phone lines'
    ]
  },
  {
    speed: '950/500 Mbps',
    planName: 'Small Business Max',
    capabilities: [
      'Support for 25+ employees online',
      '4-6 concurrent video conferences',
      'Fast large file uploads to cloud',
      'Multiple remote workers via VPN',
      'Advanced phone system with call recording'
    ]
  },
  {
    speed: '2000/2000 Mbps',
    planName: 'Hyper Fibre 2000',
    capabilities: [
      'Office of 50+ staff with heavy usage',
      'Seamless 4K video conferencing',
      'Real-time collaboration on large projects',
      'Multiple branch office connections',
      'Future-ready for growing bandwidth needs'
    ]
  }
];

const faqs = [
  {
    q: 'What areas do you cover for business fibre?',
    a: 'Our business fibre is available in major New Zealand cities including Auckland, Wellington, Christchurch, and Hamilton. Use our address checker to confirm availability at your specific location.'
  },
  {
    q: 'What does "Business Grade SLA" mean?',
    a: 'A Service Level Agreement (SLA) guarantees specific uptime percentages and response times. Business grade means faster fault resolution, priority support, and compensation if we don\'t meet our commitments.'
  },
  {
    q: 'Can I get a static IP address?',
    a: 'Yes, all our business plans include a public IPv4 address at no extra cost. This allows you to host services, set up VPNs, and enable remote access to your systems.'
  },
  {
    q: 'How long does installation take?',
    a: 'Installation typically takes 5-10 business days from order confirmation. This includes site survey, fibre connection, and equipment setup. We\'ll keep you updated throughout the process.'
  },
  {
    q: 'What happens if my connection goes down?',
    a: 'Business customers get priority support with guaranteed response times. We provide 24/7 monitoring and proactive fault detection to minimize any downtime.'
  },
  {
    q: 'Can I upgrade or downgrade my plan?',
    a: 'Absolutely. With no fixed-term contracts, you can change your plan at any time. Upgrades are typically processed within 24-48 hours.'
  }
];

export default function BusinessFibre() {
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [showSignupModal, setShowSignupModal] = useState(false); // New state for modal visibility
  const [selectedPlan, setSelectedPlan] = useState(null); // New state for selected plan

  const handleSignUp = (plan) => {
    setSelectedPlan(plan);
    setShowSignupModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#3A4E62] via-[#2a3749] to-[#1e2832] pt-32 pb-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
          {/* Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center text-white mb-12"
          >
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Check what's available at your address
            </h1>
            <p className="text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto">
              Enter your business address to see available plans and speeds
            </p>
          </motion.div>

          {/* Address Picker */}
          <div className="mb-8">
            <AddressPicker 
              onAddressSelect={setSelectedAddress}
              placeholder="Enter your business address (e.g., 123 Queen Street, Auckland)"
            />
          </div>
        </div>

        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920&h=1080&fit=crop"
            alt="Modern business office with high-speed internet connectivity"
            className="w-full h-full object-cover opacity-10"
          />
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="py-16 bg-gradient-to-r from-[#C0E3D4]/20 to-[#53B289]/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-[#53B289] rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#3A4E62] mb-2">{feature.title}</h3>
                <p className="text-[#3A4E62]/80 text-sm leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Plan Cards */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Business Broadband Plans
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Choose the perfect plan for your business needs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {businessPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl h-full ${
                  plan.popular ? 'border-[#53B289] border-2 shadow-lg transform scale-105' : 'border-gray-200 hover:shadow-lg'
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 left-0 right-0 bg-[#53B289] text-white text-center py-2 text-sm font-semibold">
                      Most Popular
                    </div>
                  )}
                  
                  <CardHeader className={`text-center ${plan.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                    <CardTitle className="text-xl font-bold text-[#3A4E62] mb-4">
                      {plan.name}
                      {plan.note && <span className="text-sm font-normal text-gray-500 ml-1">{plan.note}</span>}
                    </CardTitle>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-[#53B289]">
                        ${plan.price}/month
                        <span className="text-lg font-normal text-gray-600">+ GST</span>
                      </div>
                    </div>
                    <div className="mt-4">
                      <div className="bg-[#53B289]/10 text-[#53B289] px-4 py-3 rounded-lg">
                        <div className="text-lg font-bold">{plan.downloadUpload}</div>
                        <div className="text-sm">Download/Upload Speed</div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6 flex-1 flex flex-col">
                    {/* Features */}
                    <div className="space-y-3 flex-1">
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-start space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-[#3A4E62] text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Button 
                      onClick={() => handleSignUp(plan)} // Modified to open modal
                      className="w-full bg-[#53B289] hover:bg-[#4aa07b] text-white"
                      size="lg"
                    >
                      Sign Up
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Why Choose Our Business Broadband?
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Get the reliability, speed, and support your business deserves with our enterprise-grade broadband solutions.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#C0E3D4] rounded-2xl flex items-center justify-center mb-6 mx-auto">
                  <benefit.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{benefit.title}</h3>
                <p className="text-[#3A4E62]/80 leading-relaxed">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Speed Comparison */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              What Can You Do With These Speeds?
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              See how our different speed tiers support your business activities
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {speedComparisons.map((comparison, index) => (
              <Card key={comparison.speed} className={`text-center ${index === 1 ? 'border-[#53B289] border-2' : ''}`}>
                <CardHeader>
                  <CardTitle className="text-[#53B289] mb-2">{comparison.speed}</CardTitle>
                  <p className="text-lg font-bold text-[#3A4E62]">{comparison.planName}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-left">
                    {comparison.capabilities.map((capability, i) => (
                      <div key={i} className="flex items-start space-x-3">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{capability}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Everything you need to know about business fibre broadband
            </p>
          </motion.div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <AccordionItem value={`item-${index}`} className="bg-white rounded-xl border border-gray-200 px-6">
                  <AccordionTrigger className="text-left font-semibold text-[#3A4E62] hover:no-underline py-6">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-[#3A4E62]/90 pb-6">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#4aa07b]">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              Ready to upgrade your business broadband?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Get enterprise-grade connectivity with guaranteed speeds and priority support.
            </p>
            <Button 
              size="lg" 
              className="bg-white text-[#53B289] hover:bg-white/90 px-8 py-4 text-lg font-semibold"
            >
              Choose Your Plan Today
            </Button>
          </motion.div>
        </div>
      </section>

      <ContactSection />

      {/* Signup Modal */}
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        selectedPlan={selectedPlan}
      />
    </div>
  );
}
