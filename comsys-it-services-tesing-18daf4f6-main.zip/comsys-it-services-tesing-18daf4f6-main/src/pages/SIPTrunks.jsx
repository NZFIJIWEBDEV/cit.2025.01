import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Server, DollarSign, Scale, Shield, Users, Settings, Globe, Award, Zap, CheckCircle, Lightbulb, TrendingUp, ArrowRight, Building, HeartHandshake, Cpu, Network } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ContactSection from '@/components/sections/Contact';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function SIPTrunks() {
  const features = [
    {
      icon: Settings,
      title: "Customised Plans & Pricing Flexibility",
      description: "Unlike rigid traditional phone systems, our SIP Trunking services offer unparalleled customisation. You have the power to build a plan that precisely matches your business needs and budget. Choose the number of lines, calling channels, and bundles that make sense for you. This approach ensures you only pay for what you use, leading to significant cost efficiencies. We aim for full transparency, providing clear options for Pay-As-You-Go rates or various calling bundles to suit different usage patterns."
    },
    {
      icon: Server,
      title: "Broad PBX System Compatibility",
      description: "Our SIP Trunks are designed to seamlessly integrate with virtually any PBX system that leverages SIP or IAX2 protocols. Whether you're running a legacy system or a modern IP-PBX, our solutions provide reliable connectivity. We offer extensive support and provide detailed configuration guides for many leading PBX solutions, including popular platforms like 3CX, FreePBX, Asterisk, and more, making the setup process straightforward and efficient for your IT team."
    },
    {
      icon: Zap,
      title: "Exceptional High Availability & Redundancy",
      description: "Business communication can't afford downtime. Our SIP Trunking solution is built with robust, built-in redundancy options to ensure uninterrupted service. Features like SIP failover automatically redirect calls if your primary connection is interrupted, ensuring continuous communication. Additionally, integrate with call forwarding capabilities and Voicemail-to-Email for critical message delivery, guaranteeing your business stays connected even during unexpected outages."
    },
    {
      icon: Shield,
      title: "Advanced Fraud Protection & Security",
      description: "Rest assured with our comprehensive security and fraud management systems that actively protect you from costly toll fraud. Our advanced monitoring systems detect suspicious calling patterns, unauthorized access attempts, and unusual usage spikes in real-time. We implement multiple layers of security including IP authentication, call rate limiting, and geographical restrictions to safeguard your business from fraudulent activities that could result in significant financial losses."
    },
    {
      icon: Network,
      title: "Multiple Connectivity Options",
      description: "Choose from various SIP connectivity methods to best suit your infrastructure and technical requirements. Options include SIP Registration for dynamic IP environments, SIP Peering for static IP connections, and IAX2 for Asterisk-based systems. This flexibility ensures optimal performance regardless of your current setup and provides scalable options as your business grows and evolves."
    },
    {
      icon: Award,
      title: "Open-Source & Asterisk Expertise",
      description: "As passionate advocates of open-source solutions, we excel in supporting Asterisk, FreePBX, and other open-source PBX platforms. Our team of specialists understands the nuances of these systems and can provide expert guidance on configuration, optimization, and troubleshooting. We also support IAX2 connectivity, offering you the freedom to choose the communication platform that best fits your technical preferences and business requirements."
    },
    {
      icon: Globe,
      title: "Global Phone Number Provisioning",
      description: "Expand your business reach by provisioning phone numbers from any region in New Zealand, Australia, or from over 50 countries globally. Alternatively, port your existing numbers seamlessly to our network without disruption. This global capability allows you to establish local presence in multiple markets, reduce international calling costs for your customers, and maintain consistent branding across different regions."
    },
    {
      icon: Cpu,
      title: "Advanced Cloud Features Integration",
      description: "Enhance your basic SIP Trunks with powerful Cloud PBX features including Call Recording for compliance and training, AI-powered transcriptions for voicemail and call analysis, advanced analytics for performance monitoring, and intelligent call routing. These cloud-based enhancements transform your simple voice connectivity into a comprehensive business communication platform."
    },
    {
      icon: HeartHandshake,
      title: "Dedicated Expert Support",
      description: "Our services are backed by a skilled team of passionate open-source PBX specialists who provide exceptional customer support via phone, email, and live chat. We don't just provide connectivity – we become your trusted technology partner. Our experts help with initial configuration, ongoing optimization, troubleshooting, and strategic planning to ensure you get maximum value from your communication infrastructure."
    }
  ];

  const benefits = [
    {
      icon: DollarSign,
      title: "Significant Cost Savings",
      description: "Dramatically reduce your telecommunication expenses by eliminating expensive traditional phone line infrastructure and reducing per-minute calling costs. SIP Trunks typically cost 50-70% less than traditional PSTN lines while providing superior features and flexibility."
    },
    {
      icon: Scale,
      title: "Instant Scalability",
      description: "Scale your communication capacity up or down instantly based on business needs. Add or remove lines and services within minutes through our web portal, without waiting for technician visits or hardware installations. Perfect for seasonal businesses or rapid growth scenarios."
    },
    {
      icon: TrendingUp,
      title: "Enhanced Reliability & Call Quality",
      description: "Experience crystal-clear HD voice quality and fewer service disruptions compared to traditional phone systems. Our advanced network infrastructure and redundancy options ensure superior reliability and call quality that enhances professional communications."
    },
    {
      icon: Lightbulb,
      title: "Future-Proof Technology Enhancements",
      description: "Stay ahead of communication trends with regular feature updates and new capabilities. Add advanced cloud features, AI-powered analytics, integration with business applications, and emerging communication tools as they become available."
    }
  ];

  const pricingComponents = [
    {
      title: "SIP Trunk Line",
      price: "Contact for Pricing",
      features: [
        "Choose local NZ phone number or port existing",
        "Includes one calling channel",
        "Unlimited free inbound calls",
        "Optional AI Voice Features",
        "Pay-as-you-go calling rates or bundles"
      ]
    },
    {
      title: "Additional Services",
      items: [
        { name: "Extra Calling Channels", price: "Contact for Pricing" },
        { name: "NZ/AU Numbers", price: "Contact for Pricing" },
        { name: "International Numbers", price: "Varies by Country" },
        { name: "Toll-Free (0800) Numbers", price: "Contact for Pricing" }
      ]
    }
  ];

  const callingBundles = [
    { minutes: "300 minutes", price: "Contact for Pricing", coverage: "NZ & Australia fixed/mobiles + 50+ countries" },
    { minutes: "600 minutes", price: "Contact for Pricing", coverage: "NZ & Australia fixed/mobiles + 50+ countries" },
    { minutes: "1500 minutes", price: "Contact for Pricing", coverage: "NZ & Australia fixed/mobiles + 50+ countries" },
    { minutes: "3000 minutes", price: "Contact for Pricing", coverage: "NZ & Australia fixed/mobiles + 50+ countries" }
  ];

  const supportedPBX = [
    "Asterisk", "3CX", "FreePBX", "Avaya", "Cisco", "Grandstream", 
    "Yealink", "Sangoma", "Elastix", "FusionPBX", "OpenSIPs"
  ];

  const faqs = [
    {
      q: "What exactly are SIP Trunks and how do they work?",
      a: "SIP (Session Initiation Protocol) Trunks are virtual phone lines that enable voice communication over the internet instead of traditional copper phone lines. They connect your PBX system to the public telephone network through your internet connection, allowing you to make and receive calls using VoIP technology while maintaining compatibility with traditional phone numbers and calling features."
    },
    {
      q: "Will SIP Trunks work with my existing PBX system?",
      a: "Most likely, yes! Our SIP Trunks are compatible with virtually any PBX system that supports SIP or IAX2 protocols. This includes popular systems like Asterisk, 3CX, FreePBX, Avaya, Cisco, and many others. We provide detailed configuration guides and technical support to ensure smooth integration with your existing infrastructure."
    },
    {
      q: "How many concurrent calls can I make with SIP Trunks?",
      a: "The number of concurrent calls depends on the number of calling channels you purchase. Each channel supports one simultaneous call. You can start with as few or as many channels as needed and easily add more through our web portal as your business grows."
    },
    {
      q: "What internet connection speed do I need for SIP Trunks?",
      a: "Generally, you need about 100 kbps of bandwidth per concurrent call for good quality voice communication. For example, if you need 10 concurrent calls, you should have at least 1 Mbps of dedicated bandwidth. We recommend having additional bandwidth for other internet activities and redundancy."
    },
    {
      q: "Can I keep my existing phone numbers?",
      a: "Yes! We offer seamless number porting services that allow you to transfer your existing phone numbers to our SIP Trunk service. The porting process typically takes 1-3 business days, and we handle all the coordination with your previous provider to ensure no service disruption."
    },
    {
      q: "What happens if my internet goes down?",
      a: "We offer several redundancy options including SIP failover to backup internet connections, call forwarding to mobile numbers, and voicemail-to-email services. These features ensure your business communications continue even during internet outages, minimizing disruption to your operations."
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl lg:text-6xl font-bold mb-6"
            >
              Enterprise SIP Trunks
              <span className="block text-[#53B289]">Secure, Flexible & Cost-Effective</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-white/90 max-w-3xl mx-auto mb-8"
            >
              Streamline your business communication with our professional SIP Trunking services. 
              Replace expensive traditional phone lines with flexible, scalable internet-based calling 
              that works with any PBX system and delivers significant cost savings.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white px-8 py-4">
                  Start Free Trial
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#3A4E62] px-8 py-4">
                View PBX Compatibility
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* What are SIP Trunks */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
                What are SIP Trunks?
              </h2>
              <p className="text-lg text-[#3A4E62]/80 mb-6 leading-relaxed">
                SIP Trunks are virtual phone lines that replace traditional physical phone lines, 
                enabling your business to make and receive calls over the internet. This modern approach 
                to business communication offers superior flexibility, significant cost savings, and 
                advanced features that traditional phone systems simply cannot match.
              </p>
              <p className="text-lg text-[#3A4E62]/80 mb-8 leading-relaxed">
                By connecting your existing PBX system to our SIP Trunk service, you maintain all 
                your current functionality while gaining access to enterprise-grade features, 
                global calling capabilities, and the scalability to grow with your business.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <DollarSign className="w-8 h-8 text-[#53B289] mb-2" />
                  <h3 className="font-semibold text-[#3A4E62] mb-1">50-70% Cost Savings</h3>
                  <p className="text-sm text-[#3A4E62]/70">Compared to traditional lines</p>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <Scale className="w-8 h-8 text-[#53B289] mb-2" />
                  <h3 className="font-semibold text-[#3A4E62] mb-1">Instant Scaling</h3>
                  <p className="text-sm text-[#3A4E62]/70">Add/remove lines in minutes</p>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=600&fit=crop"
                alt="Modern business communication with SIP Trunks"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#3A4E62]/40 to-transparent rounded-2xl"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Comprehensive SIP Trunk Features
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Our SIP Trunking platform delivers enterprise-grade capabilities designed 
              to enhance your business communications while reducing costs and complexity.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#53B289] rounded-lg flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl text-[#3A4E62]">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-[#3A4E62]/80 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-24 bg-gradient-to-br from-[#C0E3D4]/20 to-[#53B289]/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Benefits of COMSYS SIP Trunks
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Transform your business communications with enterprise-grade SIP Trunks 
              that deliver measurable improvements to your operations and bottom line.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="bg-white rounded-2xl p-8 shadow-lg"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-[#53B289] rounded-xl flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{benefit.title}</h3>
                    <p className="text-[#3A4E62]/80 leading-relaxed">{benefit.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Supported PBX Systems */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Compatible with Leading PBX Systems
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
              Our SIP Trunks work seamlessly with any PBX system that supports SIP or IAX2 protocols. 
              We provide detailed configuration guides and expert support for smooth integration.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {supportedPBX.map((pbx, index) => (
              <motion.div
                key={pbx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg p-6 text-center shadow-sm hover:shadow-md transition-shadow"
              >
                <Server className="w-8 h-8 text-[#53B289] mx-auto mb-3" />
                <h3 className="font-semibold text-[#3A4E62]">{pbx}</h3>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-[#3A4E62]/70 mb-4">
              Don't see your PBX system listed? Contact our experts for compatibility confirmation.
            </p>
            <Link to={createPageUrl("ContactUs")}>
              <Button variant="outline" className="border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white">
                Check Compatibility
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Flexible SIP Trunk Pricing
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">
              Build a custom plan that fits your exact needs and budget. 
              Pay only for what you use with transparent, predictable pricing.
            </p>
            <div className="bg-[#53B289]/10 border border-[#53B289]/30 rounded-lg p-4 inline-block">
              <p className="text-[#53B289] font-semibold">
                📞 Contact us for current pricing and a custom quote tailored to your requirements
              </p>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <Card className="border-[#53B289]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-[#3A4E62] flex items-center">
                  <Phone className="w-6 h-6 mr-3 text-[#53B289]" />
                  SIP Trunk Line
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#53B289] mb-4">Contact for Pricing</div>
                <ul className="space-y-3">
                  {pricingComponents[0].features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-[#53B289] mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-[#3A4E62]/80">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-[#53B289]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-[#3A4E62] flex items-center">
                  <Settings className="w-6 h-6 mr-3 text-[#53B289]" />
                  Add-On Services
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pricingComponents[1].items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100">
                      <span className="text-[#3A4E62]">{item.name}</span>
                      <span className="font-semibold text-[#53B289]">{item.price}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mb-12">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-8 text-center">
              Global Calling Bundles
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {callingBundles.map((bundle, index) => (
                <Card key={index} className="text-center border-[#53B289]/20">
                  <CardHeader>
                    <CardTitle className="text-lg text-[#3A4E62]">{bundle.minutes}</CardTitle>
                    <div className="text-2xl font-bold text-[#53B289]">{bundle.price}</div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-[#3A4E62]/70">{bundle.coverage}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="text-center">
            <p className="text-[#3A4E62]/70 mb-6">
              Need a custom solution? We can create SIP Trunk plans tailored to your specific requirements.
            </p>
            <Link to={createPageUrl("ContactUs")}>
              <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-[#3A4E62] mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-[#3A4E62]/80">
              Everything you need to know about our SIP Trunk services
            </p>
          </motion.div>

          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <AccordionItem value={`item-${index}`} className="bg-white/70 backdrop-blur-sm rounded-xl shadow-sm mb-4 border border-gray-200">
                  <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-[#3A4E62] to-[#53B289] text-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-6">
              Ready to Transform Your Business Communications?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Join thousands of New Zealand businesses saving money and improving communication with our SIP Trunk solutions. 
              Start your free trial today and experience the difference.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("ContactUs")}>
                <Button size="lg" className="bg-white text-[#3A4E62] hover:bg-gray-100 px-8 py-4">
                  Start Free Trial
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#3A4E62] px-8 py-4">
                Get Custom Quote
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <ContactSection />
    </div>
  );
}