import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Eye, Lock, Smartphone, Award, Users, CheckCircle, ArrowRight, Phone, Mail, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CCTVHome() {
  const services = [
    {
      icon: Eye,
      title: "HD CCTV Systems",
      description: "Crystal clear 4K surveillance cameras with night vision capabilities and weather-resistant housing for all environments.",
      features: ["4K Ultra HD Resolution", "Night Vision", "Weather Resistant", "Motion Detection"]
    },
    {
      icon: Smartphone,
      title: "Remote Monitoring",
      description: "View your property from anywhere in the world with our mobile apps and cloud-based monitoring solutions.",
      features: ["Mobile App Access", "Cloud Storage", "Real-time Alerts", "Multi-device Support"]
    },
    {
      icon: Lock,
      title: "Access Control",
      description: "Secure entry systems including keycard access, biometric scanners, and automated gate controls.",
      features: ["Keycard Systems", "Biometric Access", "Automated Gates", "Visitor Management"]
    },
    {
      icon: Shield,
      title: "Alarm Systems",
      description: "Comprehensive security alarm systems with 24/7 monitoring and rapid response capabilities.",
      features: ["24/7 Monitoring", "Rapid Response", "Multiple Sensors", "Professional Installation"]
    }
  ];

  const whyChooseUs = [
    "15+ years of security industry experience",
    "Licensed and certified security professionals",
    "24/7 emergency support and monitoring",
    "Custom solutions for every property type",
    "Competitive pricing with quality guarantees",
    "Full installation and ongoing maintenance"
  ];

  const stats = [
    { number: "500+", label: "Properties Secured" },
    { number: "15+", label: "Years Experience" },
    { number: "24/7", label: "Support Available" },
    { number: "99.9%", label: "Uptime Guaranteed" }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&h=800&fit=crop"
            alt="Professional CCTV installation"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 to-gray-800/60"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="inline-flex items-center space-x-2 bg-red-600/20 backdrop-blur-sm border border-red-600/30 rounded-full px-4 py-2"
                >
                  <Shield className="w-4 h-4 text-red-400" />
                  <span className="text-red-400 font-medium text-sm">Auckland's Security Specialists</span>
                </motion.div>
                
                <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight">
                  Advanced CCTV & 
                  <span className="block bg-gradient-to-r from-red-400 to-orange-500 bg-clip-text text-transparent">
                    Security Solutions
                  </span>
                </h1>
                <p className="text-xl text-white/90 max-w-lg leading-relaxed">
                  Protect your home or business with professional-grade security systems. 
                  From HD CCTV to access control, we provide comprehensive security solutions 
                  tailored to your needs.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link to={createPageUrl("CCTVBusiness")}>
                  <Button 
                    size="lg"
                    className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 text-lg font-medium group shadow-xl hover:shadow-2xl transition-all duration-300"
                  >
                    Business Security
                    <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Link to={createPageUrl("CCTVResidential")}>
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-medium transition-all duration-300"
                  >
                    Home Security
                  </Button>
                </Link>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-4 gap-4 pt-8">
                {stats.map((stat, index) => (
                  <motion.div 
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.0 + index * 0.1 }}
                    className="text-center"
                  >
                    <div className="text-2xl font-bold text-white mb-1">{stat.number}</div>
                    <div className="text-white/70 text-xs">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Contact Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-2xl"
            >
              <div className="text-center mb-6">
                <Shield className="w-12 h-12 text-red-600 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Get Your Free Security Assessment</h3>
                <p className="text-gray-600">Our experts will evaluate your property and recommend the perfect security solution.</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <Phone className="w-5 h-5 text-red-600" />
                  <div>
                    <div className="font-semibold text-gray-900">Call Now</div>
                    <div className="text-red-600 font-medium">0800 CCTV NZ</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <Mail className="w-5 h-5 text-red-600" />
                  <div>
                    <div className="font-semibold text-gray-900">Email Us</div>
                    <div className="text-red-600 font-medium">security@comsys.co.nz</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-red-600" />
                  <div>
                    <div className="font-semibold text-gray-900">Service Area</div>
                    <div className="text-gray-600">Auckland & Surrounding Areas</div>
                  </div>
                </div>
              </div>
              
              <Button className="w-full mt-6 bg-red-600 hover:bg-red-700 text-white" size="lg">
                Book Free Assessment
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Complete Security Solutions
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From basic surveillance to comprehensive security systems, we provide 
              everything you need to protect what matters most.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 group border border-gray-200/50 hover:border-red-200">
                  <CardHeader>
                    <div className="w-16 h-16 bg-gradient-to-r from-red-600 to-orange-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                      <service.icon className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-2xl font-bold text-gray-900">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, i) => (
                        <li key={i} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">
                Why Choose COMSYS Security?
              </h2>
              <div className="space-y-4">
                {whyChooseUs.map((reason, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="w-6 h-6 text-red-600 flex-shrink-0" />
                    <span className="text-lg text-gray-700">{reason}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&h=400&fit=crop"
                alt="Professional security installation team"
                className="w-full h-96 object-cover rounded-3xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-red-600/20 to-transparent rounded-3xl"></div>
              
              {/* Achievement badges */}
              <div className="absolute -bottom-8 -left-8 bg-white rounded-2xl p-6 shadow-xl border">
                <div className="flex items-center space-x-3">
                  <Award className="w-8 h-8 text-red-600" />
                  <div>
                    <div className="font-bold text-gray-900">Licensed & Certified</div>
                    <div className="text-gray-600 text-sm">Professional Installation Team</div>
                  </div>
                </div>
              </div>
              
              <div className="absolute -top-8 -right-8 bg-white rounded-2xl p-6 shadow-xl border">
                <div className="flex items-center space-x-3">
                  <Users className="w-8 h-8 text-red-600" />
                  <div>
                    <div className="font-bold text-gray-900">500+ Happy Clients</div>
                    <div className="text-gray-600 text-sm">Across Auckland</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-red-600 to-orange-500">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Ready to Secure Your Property?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Get a free security assessment and discover how our professional CCTV 
              and security systems can protect your home or business.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 text-lg font-medium"
              >
                Get Free Quote
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-red-600 px-8 py-4 text-lg font-medium"
              >
                Call 0800 CCTV NZ
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}