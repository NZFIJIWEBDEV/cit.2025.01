import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Store, CreditCard, Wifi, Shield } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Retail Stores in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for Auckland retail businesses. Comsys IT provides POS system support, secure WiFi, and reliable IT infrastructure for shops.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=RetailIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Retail IT Quote
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const NeedsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        IT Needs of Retail Businesses
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop" 
            alt="Retail IT Solutions Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Keeping Your Store Running Smoothly</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Retail businesses rely on technology for sales processing, inventory management, and customer experience. 
              Any IT downtime directly impacts sales and customer satisfaction.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { icon: CreditCard, title: "POS System Support", desc: "Reliable support for point-of-sale systems and payment processing." },
              { icon: Wifi, title: "Customer & Staff WiFi", desc: "Secure, fast WiFi networks for customers and staff operations." },
              { icon: Store, title: "Inventory Management", desc: "IT infrastructure to support inventory and retail management systems." },
              { icon: Shield, title: "Payment Security", desc: "PCI compliance and security for customer payment data." }
            ].map((need, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <need.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{need.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{need.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const POSSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        POS System Support & Security
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Never Miss a Sale</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We provide comprehensive support for all major POS systems, ensuring your sales processing is always reliable, 
              secure, and compliant with payment industry standards.
            </p>
          </div>
          
          <ul className="space-y-4">
            {[
              "24/7 monitoring of POS systems and payment processing.",
              "PCI DSS compliance support and security assessments.",
              "Network optimization for fast transaction processing.",
              "Integration with inventory and e-commerce platforms.",
              "Regular security updates and system maintenance.",
              "Backup internet solutions to prevent sales disruptions."
            ].map((item) => (
              <li key={item} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-[#3A4E62]/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h4 className="text-xl font-semibold text-[#3A4E62] mb-4">POS System Benefits:</h4>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Increased Sales</h5>
              <p className="text-sm text-[#3A4E62]/80">Fast, reliable transactions mean shorter queues and happier customers.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Better Inventory Control</h5>
              <p className="text-sm text-[#3A4E62]/80">Real-time inventory updates and automated reordering.</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-semibold text-[#3A4E62] mb-2">Payment Security</h5>
              <p className="text-sm text-[#3A4E62]/80">PCI compliant systems protect customer payment data.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits for Retail Stores
      </h2>
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Enhancing Your Customer Experience</h3>
          <p className="text-[#3A4E62]/80 text-lg mb-6">
            Our retail IT solutions help you provide better customer service, increase sales, 
            and streamline operations so you can focus on growing your business.
          </p>
          {[
            "Minimized downtime for critical sales systems.",
            "Enhanced customer experience with fast transactions.",
            "Improved inventory accuracy and management.",
            "Secure customer data and payment processing.",
            "Scalable IT solutions that grow with your business."
          ].map((benefit) => (
            <div key={benefit} className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-[#53B289] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="text-[#3A4E62]/80 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
          <blockquote className="text-[#3A4E62]/80 italic mb-4">
            "Comsys IT completely transformed our store's technology. Our new POS system is lightning fast, and the customer WiFi has been a hit with our shoppers. Most importantly, we haven't had a single payment processing issue since they took over our IT support. Sales are up 12% since the upgrade."
          </blockquote>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-semibold text-[#3A4E62]">Lisa Chen</div>
              <div className="text-sm text-[#3A4E62]/70">Owner, Auckland Fashion Boutique</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you support all major POS systems?",
            answer: "Yes, we provide support for all major point-of-sale systems including Vend, Square, Lightspeed, and many others. We ensure your POS hardware and software are properly configured, regularly updated, and integrated with your network and payment processing systems."
          },
          {
            question: "Can you help with PCI compliance?",
            answer: "Absolutely. We help retail businesses achieve and maintain PCI DSS compliance by implementing secure network configurations, regular security assessments, and best practices for handling payment card data. This protects both your business and your customers."
          },
          {
            question: "Do you provide customer WiFi solutions?",
            answer: "Yes, we design and install secure customer WiFi networks that enhance the shopping experience while keeping your business network separate and secure. We can also implement customer authentication, usage monitoring, and marketing integration features."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesRetail() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Retail Stores in Auckland",
      "description": "IT support for Auckland retail businesses. Comsys IT provides POS system support, secure WiFi, and reliable IT infrastructure for shops.",
      "provider": { "@type": "LocalBusiness", "name": "Comsys IT", "areaServed": { "@type": "City", "name": "Auckland" }, "serviceType": "Retail IT Support" }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question", "name": "Do you support all major POS systems?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we provide support for all major point-of-sale systems including Vend, Square, Lightspeed, and many others. We ensure your POS hardware and software are properly configured, regularly updated, and integrated with your network and payment processing systems." }
        },
        {
          "@type": "Question", "name": "Can you help with PCI compliance?",
          "acceptedAnswer": { "@type": "Answer", "text": "Absolutely. We help retail businesses achieve and maintain PCI DSS compliance by implementing secure network configurations, regular security assessments, and best practices for handling payment card data. This protects both your business and your customers." }
        },
        {
          "@type": "Question", "name": "Do you provide customer WiFi solutions?",
          "acceptedAnswer": { "@type": "Answer", "text": "Yes, we design and install secure customer WiFi networks that enhance the shopping experience while keeping your business network separate and secure. We can also implement customer authentication, usage monitoring, and marketing integration features." }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Industries", "item": "https://www.comsys.co.nz/Industries" },
        { "@type": "ListItem", "position": 3, "name": "IT Solutions for Retail Stores in Auckland", "item": "https://www.comsys.co.nz/IndustriesRetail" }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Retail Stores Auckland | Comsys IT"
        description="IT support for Auckland retail businesses. Comsys IT provides POS system support, secure WiFi, and reliable IT infrastructure for shops."
        keywords="retail IT support Auckland, POS system support, retail WiFi, PCI compliance, retail technology"
        canonical="https://www.comsys.co.nz/IndustriesRetail"
        schemas={schemas}
      />
      
      <PageHero />
      <NeedsSection />
      <POSSection />
      <BenefitsSection />
      <FAQSection />
    </div>
  );
}