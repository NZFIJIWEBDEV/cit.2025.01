
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { 
  Cloud, DollarSign, SlidersHorizontal, Smartphone, Bot, Mic, Mail, BookUser, 
  ScreenShare, BellRing, PhoneForwarded, Moon, Pause, UserCircle, 
  ShieldOff, ShieldCheck, Users, List, Map, Bell, WifiOff, Megaphone, Printer, 
  Music, KeyRound, Zap, EyeOff, RotateCw, PhoneIncoming, Calculator, Ban, 
  ParkingCircle, PhoneOutgoing, PhoneCall, ArrowRightLeft, Clock, Monitor, 
  Signal, Volume2, GitBranch, Lock, Server, BarChart, MessageSquare, PlayCircle,
  ArrowRight
} from 'lucide-react';

const benefits = [
  {
    icon: Cloud,
    title: 'Cloud Hosted',
    description: 'Our platform removes costly hardware and maintenance, offering a flexible solution accessible from anywhere.'
  },
  {
    icon: DollarSign,
    title: 'Huge Cost Savings',
    description: 'With no large upfront costs or onsite IT needed, Comsys Cloud PBX saves you both time and money.'
  },
  {
    icon: SlidersHorizontal,
    title: 'Self Management',
    description: 'Our web portal lets you manage features, add lines, view call records, and more—all at your fingertips.'
  },
  {
    icon: Smartphone,
    title: 'Office Mobility',
    description: 'Comsys Cloud PBX is location-independent—take calls anywhere with a desk phone or Comsys Connect on mobile devices.'
  }
];

const features = [
  { icon: Bot, title: "Auto Attendant", description: "Provides incoming callers with pre-recorded options to navigate to their desired destination." },
  { icon: Mic, title: "Call Recording", description: "Enhance customer service or ensure regulatory compliance with complimentary call recording." },
  { icon: Mail, title: "Advanced Voicemail", description: "Receive Voicemail recordings direct to your email along with an AI-powered transcription." },
  { icon: BookUser, title: "Global Address Book", description: "A centralised address book of contacts that alerts users to known incoming callers." },
  { icon: ScreenShare, title: "Web Conferencing", description: "Enhance collaboration and reduce travel costs with an efficient platform enabling real-time online meetings." },
  { icon: BellRing, title: "Simultaneous Ring", description: "Receive calls on up to five phones simultaneously, following customisable business rules." },
  { icon: PhoneForwarded, title: "Call Forwarding", description: "Setup calls to forward when you are on the phone or if you do not answer." },
  { icon: Moon, title: "Do Not Disturb", description: "Automatically forward calls to voicemail or play busy tone if you do not wish to be disturbed." },
  { icon: Pause, title: "Call Waiting", description: "Choose whether to answer another call if you are already on the phone." },
  { icon: UserCircle, title: "Caller ID", description: "See the phone number of incoming callers." },
  { icon: ShieldOff, title: "Call Rejection Options", description: "Choose whether to accept calls from anonymous callers and specify your own list of blacklisted numbers." },
  { icon: ShieldCheck, title: "Call Screening", description: "Choose whether to screen all or just anonymous incoming calls." },
  { icon: Users, title: "Group Call Pickup", description: "Answer calls for other phones on your account." },
  { icon: List, title: "Call Queuing", description: "Give up to 10 agents the ability to queue calls, applying a variety of common Call Centre rules." },
  { icon: Users, title: "Hunt Groups", description: "Select up to 10 numbers to hunt for incoming calls, each with different timeouts." },
  { icon: Map, title: "Geographic Forwarding", description: "Directs call to appropriate extension based on the caller's geographic location." },
  { icon: Bell, title: "Call Notifications", description: "Notifies users of calls that have been missed." },
  { icon: WifiOff, title: "Network Call Forward", description: "Set a call forward number for device unavailability due to power or internet outages." },
  { icon: Megaphone, title: "Intercom", description: "Receive direct intercom messages through your phone's speaker, without the need to answer the call." },
  { icon: Printer, title: "Fax to Email", description: "Receive fax messages via email with your own digital fax line." },
  { icon: Music, title: "Caller Tunes", description: "Upload music that will replace ringing when people call you." },
  { icon: KeyRound, title: "Authorisation PIN Code", description: "Force callers to enter a PIN code before making calls on your account (i.e., expensive international calls)." },
  { icon: Zap, title: "Speed Dial", description: "Program 8 speed dial numbers so you can quickly make calls by entering a single digit." },
  { icon: EyeOff, title: "Call Privacy", description: "Choose whether to make anonymous calls by blocking or replacing your own Caller ID." },
  { icon: RotateCw, title: "Last Number Redial", description: "Dial *66 to redial the last number you called. Select your confirmation options here." },
  { icon: PhoneIncoming, title: "Call Return", description: "Dial *69 to dial the last number that called you. Select your confirmation options here." },
  { icon: Calculator, title: "Dial Plan Options", description: "Configure certain phone numbers to be dialled without requiring an area or country code." },
  { icon: Ban, title: "Call Barring", description: "Create rules to restrict certain outbound calls." },
  { icon: ParkingCircle, title: "Call Parking", description: "Temporarily parks a call to be picked up by another extension." },
  { icon: PhoneOutgoing, title: "Remote Call Back", description: "Have Cloud PBX call you, so you can make a call via the Comsys network." },
  { icon: PhoneCall, title: "Remote Dial Tone", description: "Make calls from your Cloud PBX account from another phone by remotely dialling in to initiate the call." },
  { icon: ArrowRightLeft, title: "Call Transfer", description: "During a call, transfer the other person to a new number, performing either an attended or blind transfer." },
  { icon: Music, title: "Music On Hold", description: "Upload your own music to be played to callers when they are on hold." },
  { icon: Clock, title: "Time Based Rules", description: "Many cloud features can be configured differently based on the date and time." },
  { icon: Users, title: "Phone Conferencing", description: "Use your Cloud PBX number and create a room to talk with others at the same time." },
  { icon: Monitor, title: "Line Monitoring", description: "Monitor the status of phone lines and presence of users." },
  { icon: Signal, title: "Voice Quality Options", description: "Choose from a wide range of different Voice codecs." },
  { icon: Volume2, title: "High Definition Voice", description: "High definition audio (G722) also available for internal calls and calls across the Comsys network." },
  { icon: GitBranch, title: "SIP Peering", description: "If you have an IP PBX directly connected to the Internet you configure your account as a SIP peer." },
  { icon: Lock, title: "Secure SIP", description: "TLS support for secure encrypted transmission of SIP for increased security." },
  { icon: Lock, title: "Secure RTP", description: "Encrypted your calls audio stream to increase security and eliminate NAT traversal issues." },
  { icon: Server, title: "Network Redundancy", description: "Cloud PBX provides numerous options to facilitate redundancy of your phone system." },
  { icon: GitBranch, title: "IAX Trunking", description: "Use Asterisk's IAX2 protocol as an alternative to SIP." },
  { icon: BarChart, title: "Analytics and Reporting", description: "Monitor call metrics and generate reports." },
  { icon: MessageSquare, title: "SMS Notifications", description: "Receive SMS messages to notify you about certain events (i.e., new voicemail)." },
  { icon: PlayCircle, title: "Message Playback", description: "Playback a voice recording to calls when they dial your number." }
];

export default function CloudPBX() {
  return (
    <div className="bg-white text-[#3A4E62]">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/20">
        <div className="max-w-5xl mx-auto px-6 lg:px-12 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6"
          >
            What is Comsys Cloud PBX?
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-[#3A4E62]/80 max-w-4xl mx-auto leading-relaxed"
          >
            Comsys Cloud PBX is a hosted business phone system that provides enterprise-level voice features to businesses of all sizes. As a cloud-based solution, it replaces traditional on-site hardware with a flexible, scalable system that manages calls, voicemails, and communications over the internet. This model offers significant cost savings by eliminating expensive hardware and maintenance while providing a predictable monthly fee.
          </motion.p>
           <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-lg text-[#3A4E62]/80 max-w-4xl mx-auto leading-relaxed mt-4"
          >
            With Comsys Cloud PBX, businesses benefit from advanced features like call forwarding, voicemail-to-email, and virtual receptionists. The system's scalability ensures it grows with your business, while its flexibility supports remote work from any device. Additionally, high reliability and disaster recovery features keep your communications seamless and secure, enhancing overall productivity and connectivity.
          </motion.p>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6"
              >
                <div className="w-16 h-16 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] rounded-2xl flex items-center justify-center mb-6 mx-auto">
                  <benefit.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{benefit.title}</h3>
                <p className="text-[#3A4E62]/80 leading-relaxed">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">Cloud PBX Features Explained</h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Our Cloud PBX platform is always evolving, with enterprise-grade features that ensure seamless communication.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (index % 3) * 0.1 }}
              >
                <Card className="h-full bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all duration-300 border border-[#C0E3D4]/30 hover:border-[#53B289]/50 flex flex-col">
                  <CardHeader className="flex flex-row items-center space-x-4">
                    <div className="w-12 h-12 bg-[#53B289]/10 rounded-lg flex items-center justify-center">
                      <feature.icon className="w-6 h-6 text-[#53B289]" />
                    </div>
                    <CardTitle className="text-lg text-[#3A4E62]">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-[#3A4E62]/80 flex-grow">
                    {feature.description}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center bg-gradient-to-r from-[#3A4E62] to-[#4A5E72] rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to get started?</h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Our VoIP plans include ALL of these features and more.
          </p>
          <Link to={createPageUrl("Pricing")}>
            <Button
              size="lg"
              className="bg-[#53B289] hover:bg-[#4aa07b] text-white px-8 py-4 text-lg font-medium group shadow-xl hover:shadow-2xl transition-all duration-300"
            >
              See VoIP Plans
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
