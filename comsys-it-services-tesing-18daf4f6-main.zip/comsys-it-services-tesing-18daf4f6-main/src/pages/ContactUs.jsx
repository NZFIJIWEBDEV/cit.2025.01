import React from 'react';
import ContactSection from '../components/sections/Contact';
import Seo from '../components/layout/Seo';

export default function ContactUsPage() {
  const schemas = [
    {
      "@context": "https://schema.org", 
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Contact Us", 
          "item": "https://www.comsys.co.nz/ContactUs"
        }
      ]
    }
  ];

  return (
    <div className="pt-20">
      <Seo
        title="Contact Comsys IT | Get IT Support Quote Auckland"
        description="Contact Comsys IT for reliable IT support, CCTV, VoIP, and business technology services in Auckland. Call 09 242 3700 or get a free quote today."
        keywords="contact Comsys IT, IT support Auckland, get IT quote, Auckland IT company contact"
        canonical="https://www.comsys.co.nz/ContactUs"
        schemas={schemas}
      />
      <ContactSection />
    </div>
  );
}