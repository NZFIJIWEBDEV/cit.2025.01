
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Freemans Bay businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Innovative Freemans Bay
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        Home to a dynamic mix of creative agencies, tech startups, and established professional services, Freemans Bay requires agile and sophisticated IT solutions. Comsys IT provides expert support tailored to the fast-paced, innovative businesses in this key city fringe suburb.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=FreemansBayITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Freemans Bay Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            title: "Corporate IT Specialists",
            desc: "Expertise in supporting the demanding requirements of corporate offices and professional services firms.",
            icon: Building
          },
          {
            title: "Enterprise-Level Security",
            desc: "Implementing robust cybersecurity measures to protect the high-value data common in Freemans Bay businesses.",
            icon: Shield
          },
          {
            title: "Executive & VIP Support",
            desc: "Providing discreet, priority support for company executives and key personnel.",
            icon: Users
          },
          {
            title: "Rapid Inner-City Response",
            desc: "Our central location ensures we provide the fastest possible onsite support to Freemans Bay.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    {
      icon: Users,
      title: "Managed IT for Creative & Tech",
      desc: "We provide proactive support for both Mac and PC environments, ensuring your creative workflows and tech stacks are always optimized, secure, and reliable.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Server,
      title: "Cloud Solutions & Scalability",
      desc: "Leverage the power of the cloud with our expert implementation of Microsoft 365, Google Workspace, and other solutions that allow your Freemans Bay business to scale efficiently.",
      link: "MicrosoftOffice",
      imageUrl: "https://images.unsplash.com/photo-1586953208448-3151cf78716c?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Shield,
      title: "Cybersecurity & IP Protection",
      desc: "Protect your valuable intellectual property and client data with our advanced cybersecurity services, including robust backups, threat detection, and proactive security management.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Freemans Bay Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Freemans Bay businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Premier Onsite Support for Freemans Bay
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Your Trusted Freemans Bay IT Partner</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Comsys IT provides premium onsite IT support to the entire Freemans Bay precinct. Our technicians are experienced in working within corporate office environments, demonstrating the professionalism and discretion required when supporting high-stakes businesses and their executive teams.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
             Our proximity allows for rapid deployment for any critical issues, ensuring that business disruption is kept to an absolute minimum, a crucial factor for the high-value operations typical of Freemans Bay.
            </p>
          </div>

          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Priority onsite response for corporate clients</p>
              <p><strong>Coverage:</strong> All corporate parks and offices in Freemans Bay</p>
              <p><strong>Support:</strong> Strategic Managed Services & Executive Support</p>
              <p><strong>Specialization:</strong> Corporate, Financial, and Professional Services IT</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12769.96781297593!2d174.74312497678586!3d-36.85244014757279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d479d2b868e49%3A0x500ef6143a28900!2sFreemans%20Bay%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695861917578!5m2!1sen!2snz"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Freemans Bay Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our team provides rapid, professional IT support to the entire Freemans Bay business community.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "My company has very strict data security and compliance requirements. Can you meet them?",
      a: "Yes. We specialize in providing IT services for businesses with high security and compliance needs, such as financial and legal firms. Our advanced cybersecurity services, data management policies, and reporting can be tailored to meet your specific industry regulations and corporate governance standards."
    },
    {
      q: "We need IT support that is professional and discreet enough for our corporate headquarters. Is this something you provide?",
      a: "Absolutely. We pride ourselves on the professionalism and discretion of our technicians. We understand the etiquette required in a corporate environment, especially when providing support to senior executives. Our team is trained to be efficient, quiet, and respectful of your workplace culture."
    },
    {
      q: "What are 'strategic' managed services and how do they benefit a Freemans Bay business?",
      a: "Strategic managed services go beyond day-to-day support. We act as your virtual Chief Information Officer (vCIO), providing high-level technology planning, budgeting, and strategy. This ensures your IT investments are directly contributing to your business goals, driving innovation, and providing a competitive advantage, which is essential for businesses in a prime location like Freemans Bay."
    },
    {
      q: "Can you provide priority support for our executive team?",
      a: "Yes, we offer VIP and executive support packages. This provides a dedicated, priority channel for your key personnel to ensure any IT issues they face are resolved immediately with the highest level of service, minimizing disruption to their critical work."
    },
    {
      q: "How do you ensure business continuity for a business like ours?",
      a: "Our business continuity services involve creating a comprehensive plan to keep your critical systems running during any disaster. This includes resilient infrastructure with automatic failover, robust data backup with rapid recovery capabilities, and clear communication protocols. For a Freemans Bay business, this means your operations can continue, protecting your revenue and reputation."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Freemans Bay Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=FreemansBayITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportFreemansBay() {
  const pageUrl = "https://www.comsys.co.nz/it-support-freemans-bay-auckland";
  const title = "IT Support Freemans Bay | Comsys IT | Creative & Tech Focus";
  const description = "Expert IT support for creative agencies and tech startups in Freemans Bay. Specializing in cloud solutions, Mac/PC support, and robust cybersecurity.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "Expert IT support for creative agencies and tech startups in Freemans Bay, Auckland.",
      "url": pageUrl,
      "telephone": "092423700",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Freemans Bay, Auckland"
      },
      "serviceType": [
        "Managed IT Services", "Cloud Solutions", "Cybersecurity", "IT Support for Creative Agencies", "IT Support for Tech Startups"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "My company has very strict data security and compliance requirements. Can you meet them?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. We specialize in providing IT services for businesses with high security and compliance needs, like those in finance and law. Our services can be tailored to meet your specific industry regulations and corporate governance standards."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide priority support for our executive team?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we offer VIP and executive support packages. This provides a dedicated, priority channel for your key personnel to ensure any IT issues they face are resolved immediately with the highest level of service."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Freemans Bay, creative agency IT, tech startup IT support, Auckland IT services"
        canonical={pageUrl}
        schemas={schemas}
      />

      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
