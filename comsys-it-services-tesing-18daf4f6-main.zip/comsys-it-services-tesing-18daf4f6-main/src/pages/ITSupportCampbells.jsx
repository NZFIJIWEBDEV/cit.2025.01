import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">IT Support in Campbells Bay, Auckland</motion.h1>
      <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto">Comsys IT delivers professional IT support and technology services to businesses in Campbells Bay. Our local team provides fast and reliable IT solutions including VoIP, CCTV, fibre internet, and data backup.</motion.p>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-10"><Link to={createPageUrl("ContactUs?subject=ITSupportCampbells")}><Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">Get Campbells Bay IT Support<ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" /></Button></Link></motion.div>
    </div>
  </section>
);

export default function ITSupportCampbells() {
  return (
    <div className="bg-gray-50"><Seo title="IT Support Campbells Bay Auckland | Comsys IT" description="Comsys IT provides IT support, VoIP, CCTV, and fibre internet services in Campbells Bay, North Shore Auckland. Local experts for businesses." keywords="IT support Campbells Bay, North Shore IT services, Campbells Bay business IT" /><PageHero /></div>
  );
}