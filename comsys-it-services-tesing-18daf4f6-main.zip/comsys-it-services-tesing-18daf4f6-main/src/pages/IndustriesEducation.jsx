import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, BookOpen, Wifi, Shield, Monitor, ExternalLink, Users } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        IT Solutions for Schools in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        IT support for schools and education providers in Auckland. Comsys IT delivers WiFi upgrades, security, and IT support for learning.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=EducationIT")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Education IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const ChallengesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Challenges in Education IT
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <img 
            src="https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600&h=400&fit=crop" 
            alt="Education IT Solutions Auckland Schools"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Modern Learning Technology Requirements</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Schools today face unique IT challenges with the need to support digital learning, 
              manage multiple devices, ensure student safety online, and maintain reliable connectivity 
              for both in-person and remote learning scenarios.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                icon: Wifi,
                title: "Reliable Internet Access",
                desc: "High-speed WiFi for hundreds of simultaneous users and devices"
              },
              {
                icon: Monitor,
                title: "Device Management",
                desc: "Managing laptops, tablets, interactive whiteboards, and BYOD policies"
              },
              {
                icon: Shield,
                title: "Student Safety Online",
                desc: "Content filtering, cyberbullying prevention, and digital citizenship"
              },
              {
                icon: BookOpen,
                title: "Learning Platform Integration",
                desc: "Seamless access to educational software and online learning platforms"
              }
            ].map((challenge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-4"
              >
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <challenge.icon className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{challenge.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{challenge.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-orange-800 mb-3">Education Technology Statistics:</h4>
            <ul className="space-y-2 text-orange-700">
              <li>• 95% of schools report insufficient bandwidth for digital learning</li>
              <li>• Average school manages 200+ devices per 100 students</li>
              <li>• 78% of teachers require regular IT support for classroom technology</li>
              <li>• 60% increase in online learning platform usage post-COVID</li>
              <li>• 1 in 5 students lack reliable internet access at home</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const WiFiNetworkSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        WiFi & Network Upgrades
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Enterprise-Grade School WiFi</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Educational environments require robust, scalable WiFi networks that can handle hundreds 
              of concurrent users across classrooms, libraries, halls, and outdoor areas while maintaining 
              security and content filtering.
            </p>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-[#3A4E62]">WiFi Network Features:</h4>
            {[
              {
                title: "High-Density Coverage",
                desc: "Enterprise access points designed for 30+ devices per classroom"
              },
              {
                title: "Seamless Roaming",
                desc: "Students and teachers stay connected while moving between areas"
              },
              {
                title: "Bandwidth Management",
                desc: "Quality of Service (QoS) prioritizing educational content and video conferencing"
              },
              {
                title: "Content Filtering",
                desc: "Age-appropriate internet access with customizable filtering policies"
              },
              {
                title: "Guest Network Access",
                desc: "Separate secure networks for visitors, parents, and events"
              },
              {
                title: "Network Monitoring",
                desc: "24/7 monitoring and proactive maintenance to prevent downtime"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h5 className="font-semibold text-green-800 mb-2">{feature.title}</h5>
                <p className="text-sm text-green-700">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&h=400&fit=crop" 
            alt="School WiFi Network Auckland"
            className="rounded-xl shadow-lg w-full"
          />
          
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-blue-800 mb-3">Network Benefits for Education:</h4>
            <ul className="space-y-2 text-blue-700">
              <li>• Support for 1:1 device programs and BYOD policies</li>
              <li>• Reliable video conferencing for remote learning</li>
              <li>• Fast access to cloud-based educational platforms</li>
              <li>• Seamless software updates and content delivery</li>
              <li>• Enhanced collaboration tools for students and teachers</li>
              <li>• Professional development and training capabilities</li>
            </ul>
          </div>
          
          <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-yellow-800 mb-3">Funding & Budget Considerations:</h4>
            <ul className="space-y-2 text-yellow-700">
              <li>• Ministry of Education ICT funding opportunities</li>
              <li>• Bulk purchasing discounts for educational institutions</li>
              <li>• Staged implementation to spread costs over time</li>
              <li>• Long-term service agreements for predictable budgeting</li>
              <li>• ROI through improved learning outcomes and efficiency</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const DeviceManagementSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Device Management
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            category: "Student Devices",
            devices: [
              "Chromebooks and laptops",
              "iPads and tablets",
              "BYOD smartphone integration",
              "Interactive whiteboards",
              "Document cameras",
              "3D printers and maker tools"
            ],
            icon: "💻"
          },
          {
            category: "Classroom Technology",
            devices: [
              "Interactive projectors",
              "Audio enhancement systems",
              "Video conferencing equipment",
              "Digital microscopes",
              "VR/AR headsets",
              "Robotics and coding kits"
            ],
            icon: "📚"
          },
          {
            category: "Administrative Systems",
            devices: [
              "Student information systems (SIS)",
              "Learning management systems (LMS)",
              "Library management systems",
              "Attendance and assessment tools",
              "Parent communication portals",
              "Financial management software"
            ],
            icon: "🏫"
          }
        ].map((category, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-gray-200"
          >
            <div className="text-4xl mb-4 text-center">{category.icon}</div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-6 text-center">{category.category}</h3>
            <ul className="space-y-3">
              {category.devices.map((device, dIndex) => (
                <li key={dIndex} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                  <span className="text-[#3A4E62]/80 text-sm">{device}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <div className="bg-[#53B289]/10 rounded-2xl p-8 max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Comprehensive Device Management Services</h3>
          <p className="text-lg text-[#3A4E62]/80 mb-8">
            From initial setup to ongoing maintenance, we provide complete device lifecycle management 
            for educational institutions, ensuring technology enhances rather than hinders learning.
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Setup & Deployment:</h4>
              <ul className="space-y-2">
                {[
                  "Bulk device configuration and imaging",
                  "Educational software installation",
                  "User account and permission setup",
                  "Content filtering and security policies",
                  "Asset tagging and inventory management"
                ].map((setup, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{setup}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Ongoing Support:</h4>
              <ul className="space-y-2">
                {[
                  "Remote troubleshooting and support",
                  "Software updates and security patches",
                  "Hardware repair and replacement",
                  "User training for teachers and staff",
                  "Performance monitoring and optimization"
                ].map((support, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{support}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3A4E62] mb-4">Security & Compliance:</h4>
              <ul className="space-y-2">
                {[
                  "Student data privacy protection",
                  "Content filtering and monitoring",
                  "Cyberbullying prevention tools",
                  "Digital citizenship education support",
                  "Compliance with education regulations"
                ].map((security, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <CheckCircle className="w-4 h-4 text-[#53B289] mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-[#3A4E62]/80">{security}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const WhySchoolsChooseSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Schools Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Education Technology Specialists</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              We understand the unique challenges of educational environments and provide specialized 
              IT solutions that enhance learning outcomes while ensuring student safety and data protection.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                title: "Education Industry Experience",
                desc: "Specialized knowledge of school IT needs, curriculum integration, and educational software"
              },
              {
                title: "Student Safety Focus",
                desc: "Comprehensive online safety measures, content filtering, and digital citizenship support"
              },
              {
                title: "Scalable Solutions",
                desc: "IT infrastructure that grows with your school and adapts to changing educational needs"
              },
              {
                title: "Budget-Conscious Approach",
                desc: "Cost-effective solutions designed for educational budgets with flexible payment options"
              },
              {
                title: "Teacher Training & Support",
                desc: "Comprehensive training programs to help educators effectively use classroom technology"
              },
              {
                title: "Holiday and After-Hours Service",
                desc: "Scheduled maintenance during school breaks to minimize disruption to learning"
              }
            ].map((benefit, index) => (
              <div key={index} className="flex space-x-4">
                <div className="w-12 h-12 bg-[#53B289]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-6 h-6 text-[#53B289]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#3A4E62] mb-2">{benefit.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-8">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-6">Client Success Story</h3>
            <blockquote className="text-[#3A4E62]/80 italic mb-4">
              "Comsys IT transformed our school's technology infrastructure. The new WiFi network supports 
              our 1:1 Chromebook program flawlessly, and their ongoing support means our teachers can focus 
              on teaching, not troubleshooting technology. Student engagement has increased significantly."
            </blockquote>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#53B289] rounded-full flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-[#3A4E62]">David Williams</div>
                <div className="text-sm text-[#3A4E62]/70">Principal, Auckland Primary School</div>
              </div>
            </div>
          </div>
          
          <div className="bg-[#53B289]/10 rounded-xl p-8">
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">Education IT Services Include:</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Infrastructure:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Enterprise WiFi networks</li>
                  <li>• Device management and support</li>
                  <li>• Interactive classroom technology</li>
                  <li>• Network security and filtering</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-[#3A4E62] mb-2">Support & Training:</h4>
                <ul className="space-y-1 text-sm text-[#3A4E62]/80">
                  <li>• Teacher technology training</li>
                  <li>• Help desk and technical support</li>
                  <li>• Educational software integration</li>
                  <li>• Digital citizenship programs</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide IT support for classrooms?",
            answer: "Yes, we provide comprehensive classroom IT support including setup and maintenance of interactive whiteboards, projectors, tablets, laptops, and educational software. Our technicians work during school hours when needed and provide remote support to minimize classroom disruption. We also offer teacher training to help educators effectively use classroom technology."
          },
          {
            question: "Do you help with online learning systems?",
            answer: "Absolutely. We support various learning management systems (LMS) like Google Classroom, Microsoft Teams for Education, and Moodle. Our services include platform setup, user management, integration with student information systems, troubleshooting, and training for teachers and administrators on effective online learning delivery."
          },
          {
            question: "Can you manage student devices?",
            answer: "Yes, we provide complete student device management including bulk setup and configuration of Chromebooks, iPads, and laptops. Our services include software deployment, security policies, content filtering, asset tracking, repair coordination, and support for BYOD (Bring Your Own Device) programs with appropriate network access controls."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function IndustriesEducation() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "IT Solutions for Schools Auckland",
      "description": "IT support for schools and education providers in Auckland. Comsys IT delivers WiFi upgrades, security, and IT support for learning.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "areaServed": {
          "@type": "City",
          "name": "Auckland"
        },
        "serviceType": "Education IT Support"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide IT support for classrooms?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide comprehensive classroom IT support including setup and maintenance of interactive whiteboards, projectors, tablets, laptops, and educational software. Our technicians work during school hours when needed and provide remote support to minimize classroom disruption. We also offer teacher training to help educators effectively use classroom technology."
          }
        },
        {
          "@type": "Question",
          "name": "Do you help with online learning systems?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We support various learning management systems (LMS) like Google Classroom, Microsoft Teams for Education, and Moodle. Our services include platform setup, user management, integration with student information systems, troubleshooting, and training for teachers and administrators on effective online learning delivery."
          }
        },
        {
          "@type": "Question",
          "name": "Can you manage student devices?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide complete student device management including bulk setup and configuration of Chromebooks, iPads, and laptops. Our services include software deployment, security policies, content filtering, asset tracking, repair coordination, and support for BYOD (Bring Your Own Device) programs with appropriate network access controls."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Industries",
          "item": "https://www.comsys.co.nz/Industries"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "IT Solutions for Schools Auckland",
          "item": "https://www.comsys.co.nz/IndustriesEducation"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="IT Solutions for Schools & Education Auckland | Comsys IT"
        description="IT support for schools and education providers in Auckland. Comsys IT delivers WiFi upgrades, security, and IT support for learning."
        keywords="school IT support Auckland, education technology, classroom WiFi, student device management, education IT services"
        canonical="https://www.comsys.co.nz/IndustriesEducation"
        schemas={schemas}
      />
      
      <PageHero />
      <ChallengesSection />
      <WiFiNetworkSection />
      <DeviceManagementSection />
      <WhySchoolsChooseSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Transform Learning with Modern Education Technology
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get specialized IT solutions designed for educational environments. Enhance student learning, 
            improve teacher efficiency, and ensure digital safety with expert education IT support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=EducationITAssessment")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Education IT Assessment
              </Button>
            </Link>
            <Link to={createPageUrl("WiFiUpgrade")}>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn About WiFi Solutions
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}