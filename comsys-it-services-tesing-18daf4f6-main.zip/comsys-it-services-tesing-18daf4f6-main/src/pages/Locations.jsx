import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Car, Users, Globe, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function Locations() {
  const locations = [
    {
      country: "New Zealand",
      flag: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/48fe88390_nz-flag.png",
      offices: [
        {
          city: "Auckland",
          isHeadOffice: true,
          address: "26 Bancroft Crescent, Glendene, Auckland 0602",
          phone: "09 242 3700",
          email: "info@comsys.co.nz",
          hours: "Monday - Friday: 8:00 AM - 6:00 PM",
          services: ["IT Support", "CCTV Systems", "Voice Solutions", "Broadband"],
          description: "Our main headquarters serving the greater Auckland region with comprehensive IT and security solutions."
        },
        {
          city: "Christchurch",
          isHeadOffice: false,
          address: "Hornby Office, Christchurch City",
          phone: "03 242 1030",
          email: "christchurch@comsys.co.nz",
          hours: "Monday - Friday: 8:00 AM - 5:30 PM",
          services: ["IT Support", "CCTV Systems", "Voice Solutions"],
          description: "Serving the South Island with professional IT services and security solutions for businesses and homes."
        }
      ]
    },
    {
      country: "Fiji",
      flag: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f02f17126_fiji.png",
      offices: [
        {
          city: "Sigatoka",
          isHeadOffice: false,
          address: "Lot 1 Off Queens Road olosara, Sigatoka, Fiji",
          phone: "+679 XXX XXXX",
          email: "fiji@comsys.co.nz",
          hours: "Monday - Friday: 9:00 AM - 5:00 PM",
          services: ["IT Consulting", "Network Solutions", "Business Support"],
          description: "Expanding our services to the Pacific region, providing technology solutions for Fijian businesses."
        }
      ]
    }
  ];

  const serviceAreas = [
    {
      region: "Greater Auckland",
      areas: ["Auckland CBD", "North Shore", "West Auckland", "South Auckland", "Manukau", "Waitakere"],
      coverage: "Full service area"
    },
    {
      region: "Canterbury Region",
      areas: ["Christchurch City", "Selwyn", "Waimakariri", "Ashburton", "Timaru", "Rolleston"],
      coverage: "Full service area"
    },
    {
      region: "Nationwide",
      areas: ["Wellington", "Hamilton", "Tauranga", "Dunedin", "Palmerston North", "Napier"],
      coverage: "Remote support & consultation"
    }
  ];

  const whyLocalMatters = [
    {
      icon: Clock,
      title: "Rapid Response Times",
      description: "Local technicians mean faster on-site support when you need it most"
    },
    {
      icon: Users,
      title: "Community Understanding",
      description: "We understand local business needs and regulatory requirements"
    },
    {
      icon: Car,
      title: "On-Site Service",
      description: "Face-to-face support and installation services in your area"
    },
    {
      icon: Globe,
      title: "Regional Expertise",
      description: "Deep knowledge of local infrastructure and connectivity options"
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-br from-[#3A4E62] via-[#2a3749] to-[#1e2832] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=600&fit=crop"
            alt="New Zealand landscape"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#3A4E62]/90 to-[#2a3749]/70"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Our Locations
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Serving businesses and homes across New Zealand and the Pacific region 
              with local expertise and personalized support.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Locations Grid */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          {locations.map((country, countryIndex) => (
            <motion.div
              key={country.country}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: countryIndex * 0.2 }}
              className="mb-16"
            >
              {/* Country Header */}
              <div className="flex items-center space-x-4 mb-8">
                <img
                  src={country.flag}
                  alt={`${country.country} flag`}
                  className="w-12 h-12 rounded-full object-cover shadow-lg"
                />
                <h2 className="text-3xl font-bold text-[#3A4E62]">{country.country}</h2>
              </div>

              {/* Offices Grid */}
              <div className="grid lg:grid-cols-2 gap-8">
                {country.offices.map((office, officeIndex) => (
                  <motion.div
                    key={office.city}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: officeIndex * 0.1 }}
                  >
                    <Card className="h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 border border-[#C0E3D4]/30 hover:border-[#53B289]/50">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-2xl font-bold text-[#3A4E62] flex items-center space-x-3">
                            <MapPin className="w-6 h-6 text-[#53B289]" />
                            <span>{office.city}</span>
                          </CardTitle>
                          {office.isHeadOffice && (
                            <div className="bg-[#53B289] text-white text-xs font-bold px-3 py-1 rounded-full">
                              HEAD OFFICE
                            </div>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-[#3A4E62]/80 leading-relaxed">{office.description}</p>
                        
                        {/* Contact Information */}
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <MapPin className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-0.5" />
                            <div>
                              <div className="font-semibold text-[#3A4E62]">Address</div>
                              <div className="text-[#3A4E62]/80">{office.address}</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-3">
                            <Phone className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                            <div>
                              <div className="font-semibold text-[#3A4E62]">Phone</div>
                              <a href={`tel:${office.phone.replace(/\s/g, '')}`} className="text-[#53B289] hover:underline">
                                {office.phone}
                              </a>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-3">
                            <Mail className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                            <div>
                              <div className="font-semibold text-[#3A4E62]">Email</div>
                              <a href={`mailto:${office.email}`} className="text-[#53B289] hover:underline">
                                {office.email}
                              </a>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-3">
                            <Clock className="w-5 h-5 text-[#53B289] flex-shrink-0" />
                            <div>
                              <div className="font-semibold text-[#3A4E62]">Hours</div>
                              <div className="text-[#3A4E62]/80">{office.hours}</div>
                            </div>
                          </div>
                        </div>

                        {/* Services */}
                        <div>
                          <div className="font-semibold text-[#3A4E62] mb-2">Services Available</div>
                          <div className="flex flex-wrap gap-2">
                            {office.services.map((service, serviceIndex) => (
                              <span
                                key={serviceIndex}
                                className="bg-[#53B289]/10 text-[#53B289] px-3 py-1 rounded-full text-sm font-medium"
                              >
                                {service}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex space-x-3 pt-4">
                          <Button 
                            className="flex-1 bg-[#53B289] hover:bg-[#4aa07b] text-white"
                            onClick={() => window.open(`https://maps.google.com/?q=${encodeURIComponent(office.address)}`, '_blank')}
                          >
                            Get Directions
                          </Button>
                          <Button 
                            variant="outline" 
                            className="flex-1 border-[#53B289] text-[#53B289] hover:bg-[#53B289] hover:text-white"
                            onClick={() => window.open(`tel:${office.phone.replace(/\s/g, '')}`, '_self')}
                          >
                            Call Now
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
              Service Coverage Areas
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              We provide comprehensive IT and security services across New Zealand, 
              with on-site support in major regions and remote assistance nationwide.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {serviceAreas.map((area, index) => (
              <motion.div
                key={area.region}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-gradient-to-br from-[#C0E3D4]/20 to-[#53B289]/10 border border-[#C0E3D4]/30">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold text-[#3A4E62] text-center">
                      {area.region}
                    </CardTitle>
                    <div className="text-center">
                      <span className="bg-[#53B289] text-white px-4 py-2 rounded-full text-sm font-medium">
                        {area.coverage}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {area.areas.map((location, locationIndex) => (
                        <div key={locationIndex} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-[#53B289] flex-shrink-0" />
                          <span className="text-[#3A4E62]/80 text-sm">{location}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Local Matters */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/20">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-[#3A4E62] mb-6">
              Why Choose Local Service?
            </h2>
            <p className="text-xl text-[#3A4E62]/80 max-w-3xl mx-auto">
              Having local offices means better service, faster response times, 
              and technicians who understand your regional needs.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyLocalMatters.map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-[#C0E3D4]/30"
              >
                <div className="w-16 h-16 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] rounded-2xl flex items-center justify-center mb-6 mx-auto">
                  <reason.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{reason.title}</h3>
                <p className="text-[#3A4E62]/80">{reason.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-24 bg-gradient-to-r from-[#53B289] to-[#C0E3D4]">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Contact your nearest COMSYS office today for a free consultation 
              and discover how we can help your business succeed.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-white text-[#53B289] hover:bg-gray-100 px-8 py-4 text-lg font-medium"
              >
                Get Free Consultation
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-[#53B289] px-8 py-4 text-lg font-medium"
              >
                Find Your Local Office
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}