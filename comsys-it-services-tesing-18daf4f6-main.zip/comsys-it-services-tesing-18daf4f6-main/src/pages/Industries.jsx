import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { ArrowRight, HeartPulse, Scale, Building, BookOpen, Users, Briefcase, Truck, Leaf, Factory, Store, Utensils, Bed, Dumbbell, Car, Scissors, Code, Palette, CheckSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const industriesList = [
  { name: 'Healthcare', slug: 'IndustriesHealthcare', icon: HeartPulse, summary: 'Secure, compliant IT for GPs, dental, and allied health clinics.' },
  { name: 'Legal Firms', slug: 'IndustriesLegal', icon: Scale, summary: 'Reliable IT support focusing on data security and client confidentiality.' },
  { name: 'Accounting & Bookkeeping', slug: 'IndustriesAccounting', icon: Briefcase, summary: 'Streamlining financial workflows with secure and efficient IT systems.' },
  { name: 'Financial Services & Insurance', slug: 'IndustriesFinancial', icon: Users, summary: 'Robust IT infrastructure for brokers and financial service providers.' },
  { name: 'Aged Care & Retirement', slug: 'IndustriesAgedCare', icon: HeartPulse, summary: 'Technology solutions improving resident care and operational efficiency.' },
  { name: 'Education', slug: 'IndustriesEducation', icon: BookOpen, summary: 'Safe and effective IT environments for schools, ECEs, and training centers.' },
  { name: 'Government & Councils', slug: 'IndustriesGovernment', icon: Building, summary: 'Secure and resilient IT services for local and government bodies.' },
  { name: 'Non-profits/NGOs', slug: 'IndustriesNonProfits', icon: Users, summary: 'Cost-effective IT solutions to help non-profits maximize their impact.' },
  { name: 'Construction & Trades', slug: 'IndustriesConstruction', icon: Building, summary: 'Rugged and reliable IT for job sites and back-office operations.' },
  { name: 'Engineering & Architecture', slug: 'IndustriesEngineering', icon: Briefcase, summary: 'High-performance IT for complex design and project management.' },
  { name: 'Real Estate & Property', slug: 'IndustriesRealEstate', icon: Building, summary: 'Mobile and flexible IT solutions for agents and property managers.' },
  { name: 'Facilities Management', slug: 'IndustriesFacilities', icon: Building, summary: 'Integrated IT systems to manage properties and utilities efficiently.' },
  { name: 'Warehousing & Logistics', slug: 'IndustriesWarehousing', icon: Truck, summary: 'Optimizing supply chains with robust inventory and fleet IT.' },
  { name: 'Transport & Fleet', slug: 'IndustriesTransport', icon: Truck, summary: 'IT solutions for vehicle tracking, dispatch, and fleet management.' },
  { name: 'Agriculture & Horticulture', slug: 'IndustriesAgriculture', icon: Leaf, summary: 'Technology to enhance productivity and sustainability in agriculture.' },
  { name: 'Manufacturing', slug: 'IndustriesManufacturing', icon: Factory, summary: 'Ensuring operational uptime with reliable shop-floor and office IT.' },
  { name: 'Retail', slug: 'IndustriesRetail', icon: Store, summary: 'POS, inventory, and multi-site IT support for retail businesses.' },
  { name: 'Hospitality', slug: 'IndustriesHospitality', icon: Utensils, summary: 'IT for cafes, restaurants, and bars, from POS to guest Wi-Fi.' },
  { name: 'Hotels & Tourism', slug: 'IndustriesTourism', icon: Bed, summary: 'Guest-centric technology solutions for hotels, motels, and tourism.' },
  { name: 'Gyms & Fitness', slug: 'IndustriesFitness', icon: Dumbbell, summary: 'IT systems for member management, access control, and operations.' },
  { name: 'Automotive', slug: 'IndustriesAutomotive', icon: Car, summary: 'Specialized IT for workshops and dealerships.' },
  { name: 'Beauty & Clinics', slug: 'IndustriesBeauty', icon: Scissors, summary: 'IT for appointment booking, client management, and POS systems.' },
  { name: 'IT & SaaS Startups', slug: 'IndustriesITStartups', icon: Code, summary: 'Scalable cloud infrastructure and support for tech companies.' },
  { name: 'Marketing & Creative', slug: 'IndustriesMarketing', icon: Palette, summary: 'High-performance workstations and collaboration tools for agencies.' },
  { name: 'Consulting Firms', slug: 'IndustriesConsulting', icon: Briefcase, summary: 'Secure and mobile IT for professional service consultants.' },
];

export default function IndustriesHubPage() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-br from-[#3A4E62] via-[#2a3749] to-[#1e2832] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1200&h=600&fit=crop"
            alt="Diverse team collaborating"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#3A4E62]/90 to-[#2a3749]/70"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Industries We Support
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              We provide specialised IT solutions for a wide range of New Zealand industries, 
              understanding the unique challenges and compliance needs of your sector.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Industries Grid */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {industriesList.map((industry, index) => (
              <motion.div
                key={industry.slug}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link to={createPageUrl(industry.slug)}>
                  <Card className="h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 border border-[#C0E3D4]/30 hover:border-[#53B289]/50 hover:-translate-y-2 flex flex-col">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] rounded-xl flex items-center justify-center">
                          <industry.icon className="w-6 h-6 text-white" />
                        </div>
                        <CardTitle className="text-xl font-bold text-[#3A4E62]">{industry.name}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <p className="text-[#3A4E62]/80 leading-relaxed">{industry.summary}</p>
                    </CardContent>
                    <div className="p-6 pt-0 mt-auto">
                       <span className="font-semibold text-[#53B289] flex items-center group">
                          Learn More <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                       </span>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Tailor Section */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-6">
              How We Tailor IT For Your Industry
            </h2>
            <p className="text-xl text-[#3A4E62]/80 mb-8">
              We don't believe in one-size-fits-all. Our process involves deep-diving into your industry's specific workflows, compliance standards, and technology challenges to build a truly bespoke IT strategy.
            </p>
            <div className="grid md:grid-cols-3 gap-8 text-left">
                <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-bold text-lg text-[#3A4E62] mb-2">1. Industry-Specific Audit</h3>
                    <p className="text-[#3A4E62]/80 text-sm">We assess your current setup against industry best practices and compliance requirements (e.g., NZ Privacy Act, sector-specific regulations).</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-bold text-lg text-[#3A4E62] mb-2">2. Custom Solution Design</h3>
                    <p className="text-[#3A4E62]/80 text-sm">We recommend and implement tools and configurations that solve your specific problems, from EMR systems in healthcare to job-site connectivity in construction.</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-bold text-lg text-[#3A4E62] mb-2">3. Proactive, Relevant Support</h3>
                    <p className="text-[#3A4E62]/80 text-sm">Our helpdesk understands your software and priorities, ensuring faster resolutions for issues that matter most to your operations.</p>
                </div>
            </div>
        </div>
      </section>
      
      {/* Final CTA */}
      <section className="bg-gradient-to-r from-[#53B289] to-[#C0E3D4] py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
                Find Your Industry's IT Solution
            </h2>
            <p className="text-xl text-white/90 mb-8">
                Let's discuss how tailored IT support can transform your business.
            </p>
            <Link to={createPageUrl("ContactUs")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100 px-8 py-4 text-lg font-medium">
                Book a Free Consultation
              </Button>
            </Link>
        </div>
      </section>
    </div>
  );
}