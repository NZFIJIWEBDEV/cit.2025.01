import React from "react";
import ITCostCalculator from "../components/interactive/ITCostCalculator";
import { Calculator } from "lucide-react";

export default function ITCalculatorPage() {
  return (
    <div className="bg-white pt-24 md:pt-32 pb-16 md:pb-24">
       <ITCostCalculator />
    </div>
  );
}