
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, Truck, ShoppingCart, ShoppingBag } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for East Tamaki's industrial businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        Industrial IT Support for East Tamaki
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        As Auckland's industrial heartland, businesses in East Tamaki require robust, reliable, and highly secure IT infrastructure. Comsys IT specializes in providing powerful IT support for the manufacturing, logistics, and warehousing sectors that drive this vital commercial hub.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=EastTamakiITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12">Why Choose Comsys IT for East Tamaki?</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg shadow-sm">
          <CheckCircle className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Local Expertise</h3>
          <p className="text-[#3A4E62]/80">Deep understanding of East Tamaki's business landscape and industrial IT needs.</p>
        </div>
        <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg shadow-sm">
          <Phone className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Rapid Response</h3>
          <p className="text-[#3A4E62]/80">On-site and remote support ensures minimal downtime for your operations.</p>
        </div>
        <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg shadow-sm">
          <Shield className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Tailored Solutions</h3>
          <p className="text-[#3A4E62]/80">Custom IT strategies built for manufacturing, logistics, and warehousing.</p>
        </div>
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Truck, 
      title: "IT for Manufacturing & Logistics", 
      desc: "We provide robust IT solutions for East Tamaki's industrial sector, including network infrastructure for factory floors, reliable data backup, and cybersecurity to prevent operational disruption.",
      link: "IndustriesManufacturing",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Cybersecurity for Industrial Control Systems", 
      desc: "Protect your critical operational technology (OT) and industrial control systems (ICS) from cyber threats with our specialized security audits, network segmentation, and monitoring services.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Server, 
      title: "Managed IT Services", 
      desc: "Our managed IT plans provide complete peace of mind with 24/7 proactive monitoring, unlimited helpdesk support, and strategic advice to keep your East Tamaki business efficient and competitive.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the East Tamaki Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`grid lg:grid-cols-2 gap-8 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}
            >
              <div className={`aspect-w-16 aspect-h-9 ${index % 2 === 1 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for East Tamaki businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Service Area Map</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Our Auckland IT team provides fast onsite support for industrial and commercial businesses across East Tamaki.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25492.204558580208!2d174.87635295!3d-36.9404221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4c9d57a4b861%3A0x500ef6143a299d0!2sEast%20Tamaki%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of East Tamaki, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What types of businesses do you support in East Tamaki?",
      a: "Comsys IT specializes in providing IT support for industrial and commercial businesses in East Tamaki, particularly those in manufacturing, logistics, and warehousing. Our solutions are tailored to the unique demands of these sectors, including managing industrial control systems (ICS) and ensuring robust operational technology (OT) security."
    },
    {
      q: "Do you offer onsite IT support in East Tamaki?",
      a: "Yes, we provide rapid onsite IT support for businesses throughout East Tamaki. Our local presence ensures quick response times for critical issues, helping to minimize downtime and keep your operations running smoothly."
    },
    {
      q: "What makes your IT services different for industrial businesses?",
      a: "Our key differentiator is our deep understanding of industrial IT environments. We go beyond typical office IT to address the complexities of factory floor networks, real-time operational systems, specialized software, and the critical need for cybersecurity in industrial control systems. We focus on reliability, resilience, and security tailored for manufacturing and logistics."
    },
    {
      q: "Can you help with cybersecurity for our East Tamaki business?",
      a: "Absolutely. Cybersecurity is a cornerstone of our services. For East Tamaki businesses, we offer comprehensive cybersecurity solutions including network protection, data encryption, threat detection, incident response, and specialized protection for industrial control systems (ICS) and operational technology (OT) environments."
    },
      {
      q: "How quickly can Comsys IT respond to an urgent issue?",
      a: "As a local provider serving East Tamaki, we pride ourselves on our rapid response times. For urgent issues, we aim to provide immediate remote support and dispatch onsite technicians as quickly as possible to resolve critical problems efficiently, ensuring minimal disruption to your business."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your East Tamaki Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=EastTamakiITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportEastTamaki() {
  const pageUrl = "https://www.comsys.co.nz/it-support-east-tamaki-auckland";
  const title = "Industrial IT Support East Tamaki Auckland | Comsys IT";
  const description = "Comsys IT provides specialist industrial IT support, cybersecurity, managed services, and fibre internet for manufacturing, logistics, and warehousing businesses in East Tamaki.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "image": "https://www.comsys.co.nz/images/comsys-logo.png",
      "url": "https://www.comsys.co.nz/it-support-east-tamaki-auckland",
      "telephone": "+64800724526",
      "priceRange": "$$$",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "368B Church Street",
        "addressLocality": "Penrose",
        "addressRegion": "Auckland",
        "postalCode": "1061",
        "addressCountry": "NZ"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -36.904856,
        "longitude": 174.805828
      },
      "hasMap": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25492.204558580208!2d174.87635295!3d-36.9404221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4c9d57a4b861%3A0x500ef6143a299d0!2sEast%20Tamaki%2C%20Auckland!5e0!3m2!1sen!2snz!4v1695264380628!5m2!1sen!2snz",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday"
          ],
          "opens": "08:30",
          "closes": "17:00"
        }
      ],
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "East Tamaki, Auckland"
      },
      "serviceType": [
        "IT Support",
        "Managed IT Services",
        "Cybersecurity",
        "Network Solutions",
        "Data Backup & Recovery",
        "VoIP Services",
        "CCTV Installation",
        "Fibre Internet Installation"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support for Manufacturing and Logistics",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT"
      },
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "East Tamaki, Auckland"
      },
      "description": "Specialized IT support services for industrial businesses in East Tamaki, including manufacturing, logistics, and warehousing.",
      "url": "https://www.comsys.co.nz/it-support-east-tamaki-auckland"
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support East Tamaki, industrial IT services, manufacturing IT support, logistics IT Auckland"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
