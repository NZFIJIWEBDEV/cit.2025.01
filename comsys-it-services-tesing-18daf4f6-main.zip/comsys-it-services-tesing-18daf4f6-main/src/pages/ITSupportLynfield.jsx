
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, ShoppingCart } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Lynfield businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Businesses in Lynfield
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the diverse mix of local businesses, retail stores, and professional services in Lynfield, reliable and community-focused IT support is essential. Comsys IT provides friendly, expert technology solutions to help your Lynfield business thrive.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=LynfieldITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Lynfield Businesses Rely on Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            title: "Retail & Local Business IT",
            desc: "Specialized support for retail stores, cafes, and local service providers, including POS and inventory systems.",
            icon: ShoppingCart
          },
          {
            title: "Community-Focused Service",
            desc: "Friendly, approachable support from a team that understands the importance of local community businesses.",
            icon: Users
          },
          {
            title: "Affordable & Scalable",
            desc: "Cost-effective IT packages that provide exceptional value and can scale as your Lynfield business grows.",
            icon: CheckCircle
          },
          {
            title: "Local Auckland Team",
            desc: "Fast and reliable support from our local Auckland technicians who are familiar with the Lynfield area.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    {
      icon: Users,
      title: "Managed IT for Small Businesses",
      desc: "Our managed IT plans are perfect for local businesses in Lynfield. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Home,
      title: "Home Office & Professional IT",
      desc: "We specialize in creating secure, high-performance home office environments for the many professionals and consultants working from Lynfield.",
      link: "HomeFibre",
      imageUrl: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200&h=800&fit=crop&q=80"
    },
    {
      icon: Shield,
      title: "Data Security & Privacy",
      desc: "Protect your valuable client and business data with our robust data backup and cybersecurity solutions, designed to keep your Lynfield business secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80"
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Lynfield Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img
                  src={service.imageUrl}
                  alt={`${service.title} for Lynfield businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
    <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-8">Your Local IT Support in Lynfield</h2>
            <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-8">Comsys IT provides friendly, affordable, and expert IT support to the vibrant community of businesses in Lynfield and the surrounding Auckland suburbs.</p>
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12759.186638848404!2d174.71764684964596!3d-36.91572973105747!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d471555555555%3A0x500ef6143a29b20!2sLynfield%2C%20Auckland!5e0!3m2!1sen!2snz!4v1700016200654!5m2!1sen!2snz" width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Map of Lynfield, Auckland"></iframe>
            </div>
        </div>
    </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: 'Do you offer IT support for retail stores and POS systems in Lynfield?',
      a: 'Yes, absolutely. We have extensive experience supporting retail businesses, including setting up, maintaining, and troubleshooting a wide variety of Point-of-Sale (POS) systems and inventory management software.'
    },
    {
      q: 'Can you set up a reliable Guest WiFi network for my cafe or store in Lynfield?',
      a: 'Yes, we can install a professional, secure, and fast Guest WiFi network for your customers. This provides a great amenity for your patrons while keeping your private business network completely separate and secure.'
    },
    {
      q: 'Are your IT support plans affordable for a small local business in Lynfield?',
      a: 'Our support plans are designed to be cost-effective and scalable. We offer a range of packages to suit different budgets and needs, providing enterprise-level support at a price that small local businesses in Lynfield can afford.'
    },
    {
      q: 'What is the advantage of managed IT services for a small business?',
      a: 'Managed IT services give you the benefit of having a full team of IT experts for a flat monthly fee. We proactively manage your technology to prevent problems, which is more cost-effective than waiting for things to break. This leads to less downtime, better security, and predictable costs.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem
                value={`item-${index}`}
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Lynfield Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=LynfieldITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportLynfield() {
  const pageUrl = "https://www.comsys.co.nz/it-support-lynfield";
  const title = "IT Support Lynfield | Local & Retail Business IT Services";
  const description = "Friendly and affordable IT support for retail and local businesses in Lynfield. Comsys IT offers managed services, POS support, and high-speed internet solutions.";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "IT Support for Businesses", // Updated
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": "Auckland, NZ",
        "telephone": "0800724526"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Lynfield, Auckland"
      },
      "description": "Affordable IT support and managed services for retail and local businesses in Lynfield, Auckland.",
      "name": "IT Support Lynfield"
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.comsys.co.nz/" },
        { "@type": "ListItem", "position": 2, "name": "Areas We Serve", "item": "https://www.comsys.co.nz/AreasWeServe" },
        { "@type": "ListItem", "position": 3, "name": "IT Support Lynfield", "item": pageUrl }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you offer IT support for retail stores and POS systems in Lynfield?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, absolutely. We have extensive experience supporting retail businesses, including setting up, maintaining, and troubleshooting a wide variety of Point-of-Sale (POS) systems and inventory management software."
          }
        },
        {
          "@type": "Question",
          "name": "Can you set up a reliable Guest WiFi network for my cafe or store in Lynfield?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we can install a professional, secure, and fast Guest WiFi network for your customers. This provides a great amenity for your patrons while keeping your private business network completely separate and secure."
          }
        },
        {
          "@type": "Question",
          "name": "Are your IT support plans affordable for a small local business in Lynfield?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Our support plans are designed to be cost-effective and scalable. We offer a range of packages to suit different budgets and needs, providing enterprise-level support at a price that small local businesses in Lynfield can afford."
          }
        },
        {
          "@type": "Question",
          "name": "What is the advantage of managed IT services for a small business?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Managed IT services give you the benefit of having a full team of IT experts for a flat monthly fee. We proactively manage your technology to prevent problems, which is more cost-effective than waiting for things to break. This leads to less downtime, better security, and predictable costs."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Lynfield, small business IT Auckland, home office IT support, Lynfield business IT"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
