
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset, Truck } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1613917714489-c43cce3a7553?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Takanini's growing businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Growing Takanini
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        As a rapidly developing area in South Auckland, Takanini's new commercial, retail, and industrial businesses need a forward-thinking IT partner. Comsys IT provides scalable, modern, and reliable IT support to help your Takanini business grow and succeed.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=TakaniniITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12">Why Choose Comsys IT in Takanini?</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="bg-gray-50 p-8 rounded-lg shadow-md flex flex-col items-center"
        >
          <MapPin className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Local Takanini Expertise</h3>
          <p className="text-gray-600">Our team understands the unique IT needs and infrastructure of the Takanini area, ensuring fast and relevant support.</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-gray-50 p-8 rounded-lg shadow-md flex flex-col items-center"
        >
          <Shield className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Proactive & Secure</h3>
          <p className="text-gray-600">We don't just fix problems; we prevent them. Our proactive monitoring and robust security solutions keep your business safe.</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="bg-gray-50 p-8 rounded-lg shadow-md flex flex-col items-center"
        >
          <Users className="w-12 h-12 text-[#53B289] mb-4" />
          <h3 className="text-xl font-semibold text-[#3A4E62] mb-2">Dedicated Support</h3>
          <p className="text-gray-600">Benefit from a dedicated account manager and responsive support team, always ready to assist your Takanini business.</p>
        </motion.div>
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Building, 
      title: "IT for New Commercial & Retail", 
      desc: "We provide complete IT fit-outs for new retail and commercial spaces in Takanini, including network cabling, POS systems, CCTV, and ongoing managed support.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Truck, 
      title: "Industrial & Logistics IT", 
      desc: "For Takanini's industrial zones, we deliver specialized support for warehousing and logistics, ensuring your supply chain operations are always efficient and secure.",
      link: "IndustriesTransport",
      imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Users, 
      title: "Scalable Managed IT Services", 
      desc: "Our managed IT plans are designed to grow with your Takanini business, offering enterprise-level support that fits your budget and scales as you succeed.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Takanini Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Takanini businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12">Our Local Reach in Takanini</h2>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto"
      >
        Comsys IT proudly serves businesses across the entire Takanini area, from its bustling commercial centres to its industrial parks.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="relative w-full aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-xl"
      >
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d102078.69466398934!2d174.88726588671872!3d-37.0305886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d4ee228414437%3A0x500ef6143a29900!2sTakanini%2C%20Auckland!5e0!3m2!1sen!2snz!4v1701768802951!5m2!1sen!2snz"
          width="100%"
          height="100%"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Takanini, Auckland map"
          className="absolute top-0 left-0 w-full h-full border-0"
        ></iframe>
      </motion.div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What IT services does Comsys IT offer in Takanini?",
      a: "Comsys IT provides comprehensive IT support for Takanini businesses, including managed IT services, network infrastructure setup, cybersecurity solutions, cloud services, data backup & recovery, VoIP phone systems, and CCTV installation. We specialize in IT fit-outs for new commercial/retail spaces and industrial IT support."
    },
    {
      q: "Do you provide on-site support in Takanini?",
      a: "Yes, our local team offers prompt on-site IT support for businesses throughout Takanini and the wider South Auckland region. We understand the importance of quick response times for critical issues."
    },
    {
      q: "How can Comsys IT help my new Takanini business?",
      a: "For new businesses in Takanini, we offer end-to-end IT setup, including network design and cabling, hardware procurement, software installation, and seamless integration of essential business systems. We ensure your technology foundation is robust and scalable from day one."
    },
    {
      q: "Are your services suitable for industrial businesses in Takanini?",
      a: "Absolutely. We have extensive experience with industrial and logistics IT requirements. This includes support for warehouse management systems, ruggedized hardware, robust wireless networks, and surveillance systems tailored to industrial environments."
    },
    {
      q: "What makes Comsys IT different from other providers?",
      a: "We combine local Takanini knowledge with enterprise-grade IT solutions. Our proactive approach, dedicated support, transparent communication, and commitment to helping your business grow set us apart. We focus on long-term partnerships, not just quick fixes."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Takanini Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=TakaniniITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportTakanini() {
  const title = "IT Support for Growing Takanini | Comsys IT";
  const description = "Comsys IT offers scalable, modern IT support for Takanini businesses. Specializing in IT fit-outs, industrial IT, and managed services for South Auckland's new commercial, retail, and industrial zones.";
  const pageUrl = createPageUrl("ITSupportTakanini");
  const schemas = []; // No specific schema provided in outline, keeping it empty

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Takanini, South Auckland IT services, new business IT, industrial IT Takanini"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
