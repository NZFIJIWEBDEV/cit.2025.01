
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1579294950198-3a8024251e6b?auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Manurewa businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Manurewa Businesses
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        For the diverse and hardworking community of small businesses, retail stores, and local services in Manurewa, having reliable and affordable IT support is essential. Comsys IT provides friendly, expert technology solutions tailored to help your Manurewa business grow.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=ManurewaITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12">
        Why Manurewa Businesses Choose Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { icon: Shield, title: "Proactive Security", description: "We implement advanced cybersecurity measures to protect your business from evolving threats." },
          { icon: Clock, title: "Fast Local Response", description: "Our Auckland-based team provides quick on-site and remote support when you need it most." },
          { icon: Users, title: "Tailored Solutions", description: "From small retail shops to growing enterprises, we customize IT solutions to fit your unique needs." },
          { icon: CheckCircle, title: "Proven Expertise", description: "With years of experience, we deliver reliable, efficient, and cost-effective IT services." },
          { icon: Phone, title: "Friendly Helpdesk", description: "Get unlimited support from our approachable experts who speak your language, not tech jargon." },
          { icon: Building, title: "Business Growth Focused", description: "We align IT strategies with your business goals to help you achieve sustainable growth." },
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="p-8 rounded-xl shadow-lg bg-gray-50 flex flex-col items-center text-center transition-all hover:shadow-xl hover:scale-[1.02]"
          >
            <div className="p-4 bg-[#53B289]/10 rounded-full mb-6">
              <item.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-3">{item.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{item.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT for Small Businesses", 
      desc: "Our managed IT plans are perfect for local businesses in Manurewa. Get unlimited helpdesk support and proactive 24/7 monitoring for a predictable monthly fee.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Data Security & Backup", 
      desc: "Protect your valuable business and customer data with our robust data backup and cybersecurity solutions, designed to keep your Manurewa business secure.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    },
    { 
      icon: Wifi, 
      title: "Business & Home Fibre", 
      desc: "Ensure your Manurewa business or home office has the connectivity it needs to thrive with our reliable, high-speed business and home fibre internet solutions.",
      link: "BusinessFibre",
      imageUrl: "https://images.unsplash.com/photo-1631173733712-e881b2a24f67?w=1200&h=800&fit=crop&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Manurewa Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Manurewa businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapSection = () => (
  <section className="py-20 bg-gray-100">
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] mb-12">
        Serving Manurewa and Surrounding Areas
      </h2>
      <p className="text-lg text-[#3A4E62]/80 max-w-3xl mx-auto mb-10">
        Comsys IT is proud to be a local IT partner for businesses across Manurewa and the wider South Auckland region. Our team is always ready to provide fast and reliable service right where you are.
      </p>
      <div className="rounded-xl shadow-xl overflow-hidden aspect-w-16 aspect-h-9 w-full max-w-4xl mx-auto">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d102008.38407482315!2d174.79252309855598!3d-37.00445695276332!2m3!1f0!2m1!3sManurewa%20Auckland!5e0!3m2!1sen!2snz!4v1701389825424!5m2!1sen!2snz"
          width="100%"
          height="450"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Map of Manurewa, Auckland"
        ></iframe>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "What types of businesses do you support in Manurewa?",
      a: "Comsys IT supports a diverse range of businesses in Manurewa, including small businesses, retail stores, local services, offices, and more. We tailor our IT solutions to meet the specific needs of each client.",
    },
    {
      q: "How quickly can you respond to an IT issue in Manurewa?",
      a: "As a local Auckland-based IT provider, we pride ourselves on our fast response times. For critical issues, we aim to provide immediate remote support and can dispatch on-site technicians quickly to Manurewa.",
    },
    {
      q: "Do you offer ongoing IT support plans or just one-off services?",
      a: "We offer both! While we can assist with one-off IT issues, our most popular option is our managed IT service plans, which provide proactive monitoring, unlimited helpdesk support, and predictable monthly costs, ensuring your systems are always running smoothly.",
    },
    {
      q: "Can you help with setting up new office IT infrastructure?",
      a: "Absolutely. We specialize in comprehensive IT setups for new businesses or office relocations, including network design, server installation, Wi-Fi solutions, workstation setup, and cloud integration, ensuring a seamless transition.",
    },
    {
      q: "Is data backup and recovery important for my Manurewa business?",
      a: "Yes, incredibly important. Data is the lifeblood of any business. We provide robust data backup and disaster recovery solutions to protect your valuable information from accidental deletion, hardware failure, cyberattacks, or natural disasters, ensuring business continuity.",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Manurewa Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=ManurewaITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportManurewa() {
  const suburb = "Manurewa"; 
  const title = `IT Support ${suburb} Auckland | Comsys IT`;
  const description = `Comsys IT provides IT support, VoIP, CCTV, and fibre internet services in ${suburb}, South Auckland. Local experts for businesses.`;
  const pageUrl = createPageUrl(`ITSupport${suburb.replace(/\s+/g, '')}`); 
  const schemas = []; 

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Manurewa, South Auckland IT services, Manurewa business IT, small business IT support"
        canonical={pageUrl}
        schemas={schemas}
      />
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
