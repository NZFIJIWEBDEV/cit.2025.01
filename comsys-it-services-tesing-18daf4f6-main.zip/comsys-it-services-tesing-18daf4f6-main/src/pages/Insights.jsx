import React, { useState, useEffect } from 'react';
import { Post } from '@/api/entities';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

export default function InsightsPage() {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoading(true);
      try {
        const fetchedPosts = await Post.list('-publishedDate');
        setPosts(fetchedPosts);
      } catch (error) {
        console.error("Failed to fetch posts:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPosts();
  }, []);

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-[#3A4E62] to-[#1e2832]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl lg:text-6xl font-bold text-white mb-6"
          >
            Insights &amp; IT Strategy
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-white/90 max-w-3xl mx-auto"
          >
            Expert analysis on cybersecurity, cloud computing, and productivity to help your NZ business thrive.
          </motion.p>
        </div>
      </section>

      {/* Posts Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          {isLoading ? (
            <div className="text-center text-[#3A4E62]">Loading articles...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)}>
                    <Card className="h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 border border-[#C0E3D4]/30 hover:border-[#53B289]/50 hover:-translate-y-2 flex flex-col group overflow-hidden">
                      <CardHeader className="p-0">
                        <img 
                          src={post.featuredImageUrl} 
                          alt={post.title} 
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </CardHeader>
                      <CardContent className="p-6 flex flex-col flex-grow">
                        <Badge variant="secondary" className="bg-[#53B289]/10 text-[#53B289] border-[#53B289]/20 w-fit mb-3">{post.category}</Badge>
                        <h2 className="text-xl font-bold text-[#3A4E62] mb-3 flex-grow">{post.title}</h2>
                        <p className="text-[#3A4E62]/80 leading-relaxed mb-4">{post.excerpt}</p>
                        <div className="text-sm text-[#3A4E62]/60 flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                          <div className="flex items-center space-x-2">
                             <User className="w-4 h-4" />
                             <span>{post.authorName}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4" />
                            <time dateTime={post.publishedDate}>
                              {format(new Date(post.publishedDate), 'd MMM, yyyy')}
                            </time>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}