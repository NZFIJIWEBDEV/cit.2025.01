import React from 'react';
import { motion } from 'framer-motion';
import { Home, Shield, Eye, Lock, Smartphone, Baby, Car, AlertTriangle, CheckCircle, ArrowRight, Phone, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CCTVResidential() {
  const homeSolutions = [
    {
      icon: Eye,
      title: "HD Security Cameras",
      description: "Crystal clear 4K surveillance cameras with night vision, weatherproof housing, and smart motion detection for complete home monitoring.",
      features: [
        "4K Ultra HD resolution",
        "Color night vision technology",
        "Weather-resistant design",
        "Smart motion alerts",
        "Two-way audio communication",
        "Local and cloud storage"
      ],
      price: "From $899",
      popular: false
    },
    {
      icon: Smartphone,
      title: "Smart Home Integration",
      description: "Seamlessly integrate with your existing smart home devices including Alexa, Google Home, and smartphone apps for complete control.",
      features: [
        "Mobile app control",
        "Voice assistant integration",
        "Smart home automation",
        "Real-time notifications",
        "Geofencing capabilities",
        "Family member access"
      ],
      price: "From $1,299",
      popular: true
    },
    {
      icon: Lock,
      title: "Door & Window Sensors",
      description: "Comprehensive entry point monitoring with wireless sensors that instantly alert you to any unauthorized access attempts.",
      features: [
        "Wireless sensor network",
        "Instant break-in alerts",
        "Battery life monitoring",
        "Easy DIY installation",
        "Pet-friendly options",
        "Multiple zone monitoring"
      ],
      price: "From $599",
      popular: false
    },
    {
      icon: AlertTriangle,
      title: "24/7 Monitoring Service",
      description: "Professional monitoring service with trained security personnel watching over your home around the clock and coordinating emergency response.",
      features: [
        "24/7 professional monitoring",
        "Police dispatch coordination",
        "Fire and medical alerts",
        "Backup communication systems",
        "Family emergency contacts",
        "Mobile app notifications"
      ],
      price: "From $39/month",
      popular: false
    }
  ];

  const homeAreas = [
    {
      icon: Home,
      title: "Front Door & Entry",
      description: "Monitor who's at your door with doorbell cameras and entry point surveillance.",
      coverage: "Main entrances, doorbell cam, porch monitoring"
    },
    {
      icon: Car,
      title: "Driveway & Garage",
      description: "Protect your vehicles and monitor access to your property with dedicated coverage.",
      coverage: "Vehicle protection, garage monitoring, driveway alerts"
    },
    {
      icon: Baby,
      title: "Indoor Living Areas",
      description: "Keep an eye on children, pets, and indoor activities with discreet indoor cameras.",
      coverage: "Living rooms, play areas, pet monitoring"
    },
    {
      icon: Shield,
      title: "Backyard & Perimeter",
      description: "Comprehensive outdoor coverage to monitor your entire property perimeter.",
      coverage: "Garden monitoring, fence line coverage, outdoor recreation areas"
    }
  ];

  const packages = [
    {
      name: "Basic Protection",
      price: "899",
      setup: "Professional Installation Included",
      features: [
        "2 HD outdoor cameras",
        "Mobile app access",
        "Motion detection alerts",
        "Night vision capability",
        "Local video storage",
        "Basic technical support"
      ],
      ideal: "Perfect for apartments and small homes"
    },
    {
      name: "Complete Coverage",
      price: "1,599",
      setup: "Professional Installation Included",
      features: [
        "4 HD cameras (indoor/outdoor)",
        "Smart home integration",
        "Advanced motion analytics",
        "Two-way audio communication",
        "Cloud storage included",
        "Priority technical support",
        "Mobile alerts & notifications"
      ],
      ideal: "Ideal for most family homes",
      popular: true
    },
    {
      name: "Premium Security",
      price: "2,299",
      setup: "Professional Installation Included",
      features: [
        "6+ HD cameras with 4K option",
        "Full smart home integration",
        "AI-powered detection",
        "Professional monitoring option",
        "Unlimited cloud storage",
        "24/7 technical support",
        "Advanced analytics dashboard",
        "Emergency response coordination"
      ],
      ideal: "Best for large homes and maximum security"
    }
  ];

  const benefits = [
    {
      title: "Deter Crime",
      stat: "60%",
      description: "Homes with visible security systems experience 60% fewer break-in attempts."
    },
    {
      title: "Insurance Savings",
      stat: "Up to 15%",
      description: "Many home insurance providers offer discounts for professionally installed security systems."
    },
    {
      title: "Peace of Mind",
      stat: "24/7",
      description: "Monitor your home from anywhere in the world and receive instant alerts."
    },
    {
      title: "Property Value",
      stat: "+3-5%",
      description: "Professional security systems can increase your home's resale value."
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-teal-700 overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=1200&h=800&fit=crop"
            alt="Beautiful family home with security"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-green-900/90 to-teal-800/70"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 py-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="inline-flex items-center space-x-2 bg-emerald-600/20 backdrop-blur-sm border border-emerald-600/30 rounded-full px-4 py-2"
                >
                  <Home className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400 font-medium text-sm">Home Security Specialists</span>
                </motion.div>
                
                <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Protect Your
                  <span className="block bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                    Family & Home
                  </span>
                </h1>
                <p className="text-xl text-white/90 max-w-lg leading-relaxed">
                  Advanced home security systems designed for New Zealand families. 
                  From smart doorbells to complete surveillance networks, keep your 
                  loved ones safe with professional-grade protection.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link to={createPageUrl("ContactUs?subject=HomeSecurity")}>
                  <Button 
                    size="lg"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 text-lg font-medium group shadow-xl hover:shadow-2xl transition-all duration-300"
                  >
                    Get Free Quote
                    <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-medium transition-all duration-300"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call 0800 CCTV NZ
                </Button>
              </div>

              {/* Quick Benefits */}
              <div className="grid grid-cols-2 gap-6 pt-8">
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-4">
                  <div className="text-2xl font-bold text-white">From $899</div>
                  <div className="text-white/70 text-sm">Complete installation included</div>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-4">
                  <div className="text-2xl font-bold text-white">Same Day</div>
                  <div className="text-white/70 text-sm">Installation available</div>
                </div>
              </div>
            </motion.div>

            {/* Package Preview */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-3xl p-8 shadow-2xl"
            >
              <div className="text-center mb-6">
                <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 rounded-full px-4 py-2 text-sm font-medium mb-4">
                  <Shield className="w-4 h-4" />
                  <span>Most Popular</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Complete Coverage Package</h3>
                <div className="text-4xl font-bold text-emerald-600">$1,599</div>
                <div className="text-gray-600 text-sm">Professional installation included</div>
              </div>
              
              <ul className="space-y-3 mb-6">
                {[
                  "4 HD cameras (indoor/outdoor)",
                  "Smart home integration", 
                  "Mobile app control",
                  "Motion detection alerts",
                  "Night vision capability",
                  "Cloud storage included"
                ].map((feature, i) => (
                  <li key={i} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white" size="lg">
                Choose This Package
              </Button>
              
              <div className="text-center text-gray-500 text-sm mt-4">
                ✓ No contracts ✓ 2-year warranty ✓ Free support
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Home Security Solutions */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Complete Home Security Solutions
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From basic camera systems to comprehensive smart home security, 
              we provide everything you need to protect your family and property.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {homeSolutions.map((solution, index) => (
              <motion.div
                key={solution.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative"
              >
                {solution.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                    <div className="bg-emerald-600 text-white text-sm font-bold px-4 py-2 rounded-full">
                      Most Popular
                    </div>
                  </div>
                )}
                <Card className="h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 group border border-gray-200/50 hover:border-emerald-200">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="w-16 h-16 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <solution.icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-emerald-600">{solution.price}</div>
                    </div>
                    <CardTitle className="text-2xl font-bold text-gray-900">{solution.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-6 leading-relaxed">{solution.description}</p>
                    <ul className="space-y-2">
                      {solution.features.map((feature, i) => (
                        <li key={i} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 text-white">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Coverage Areas */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Complete Home Coverage
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our security systems are designed to cover every area of your home, 
              ensuring comprehensive protection for your family and belongings.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {homeAreas.map((area, index) => (
              <motion.div
                key={area.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center bg-gray-50 rounded-2xl p-8 hover:bg-emerald-50 transition-colors group"
              >
                <div className="w-16 h-16 bg-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <area.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{area.title}</h3>
                <p className="text-gray-600 mb-4">{area.description}</p>
                <div className="text-sm text-emerald-600 font-medium">{area.coverage}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Packages */}
      <section className="py-24 bg-gradient-to-br from-emerald-50 to-teal-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Choose Your Security Package
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional installation included with all packages. No hidden fees, 
              no contracts, just transparent pricing for complete peace of mind.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative"
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                    <div className="bg-emerald-600 text-white text-sm font-bold px-6 py-2 rounded-full">
                      Most Popular Choice
                    </div>
                  </div>
                )}
                <Card className={`h-full bg-white shadow-lg hover:shadow-xl transition-all duration-300 ${pkg.popular ? 'border-2 border-emerald-600' : 'border border-gray-200'}`}>
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</CardTitle>
                    <div className="flex items-center justify-center mb-4">
                      <DollarSign className="w-6 h-6 text-emerald-600" />
                      <span className="text-4xl font-bold text-gray-900">{pkg.price}</span>
                    </div>
                    <div className="text-emerald-600 font-medium text-sm">{pkg.setup}</div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {pkg.features.map((feature, i) => (
                        <li key={i} className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="bg-emerald-50 rounded-lg p-3 mb-6">
                      <div className="text-sm text-emerald-800 font-medium">{pkg.ideal}</div>
                    </div>
                    <Button 
                      className={`w-full ${pkg.popular ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-gray-900 hover:bg-gray-800'} text-white`}
                      size="lg"
                    >
                      Choose This Package
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">
                Why Invest in Home Security?
              </h2>
              <div className="grid grid-cols-2 gap-8">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={benefit.title}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="text-center"
                  >
                    <div className="text-4xl font-bold text-emerald-600 mb-2">{benefit.stat}</div>
                    <div className="text-lg font-semibold text-gray-900 mb-2">{benefit.title}</div>
                    <div className="text-gray-600 text-sm">{benefit.description}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop"
                alt="Family feeling safe at home"
                className="w-full h-96 object-cover rounded-3xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-600/20 to-transparent rounded-3xl"></div>
              
              {/* Floating testimonial */}
              <div className="absolute -bottom-8 -left-8 bg-white rounded-2xl p-6 shadow-xl border max-w-sm">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">Sarah M.</div>
                    <div className="text-gray-600 text-sm">Auckland Homeowner</div>
                  </div>
                </div>
                <p className="text-gray-700 text-sm italic">
                  "The peace of mind knowing my family is safe is priceless. The system is so easy to use!"
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-emerald-600 to-teal-500">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Protect Your Family Today
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Get a free quote and professional consultation to find the perfect 
              security solution for your home. Same-day installation available.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-white text-emerald-600 hover:bg-gray-100 px-8 py-4 text-lg font-medium"
              >
                Get Free Quote
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-4 text-lg font-medium"
              >
                Call 0800 CCTV NZ
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}