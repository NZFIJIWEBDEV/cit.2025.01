import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Shield, Cloud, Database, Clock, HardDrive, AlertTriangle, ExternalLink } from 'lucide-react';
import Seo from '../components/layout/Seo';

const PageHero = () => (
  <section className="relative bg-gradient-to-br from-[#3A4E62] to-[#2a3749] text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-grid-slate-100/10"></div>
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
      >
        Data Backup and Recovery Services in Auckland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-300 max-w-3xl mx-auto"
      >
        Protect your business with secure data backup and fast recovery solutions. Comsys IT ensures your files are safe and can be restored quickly in case of disaster.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=DataBackupQuote")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group">
            Get Backup Assessment
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyBackupMattersSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Backups Matter
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="bg-red-50 border border-red-200 rounded-xl p-8 mb-8">
            <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
            <h3 className="text-2xl font-bold text-red-800 mb-4">The Cost of Data Loss</h3>
            <ul className="space-y-3 text-red-700">
              <li>• 60% of companies close within 6 months of major data loss</li>
              <li>• Average cost of data breach: $4.45 million globally</li>
              <li>• 93% of companies without data recovery plan fail within one year</li>
              <li>• Average downtime cost: $5,600 per minute</li>
            </ul>
          </div>
        </div>
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Common Causes of Data Loss</h3>
          {[
            { title: "Ransomware Attacks", desc: "Increasing by 41% year-over-year", icon: Shield },
            { title: "Hardware Failures", desc: "Hard drives fail every 4-6 years on average", icon: HardDrive },
            { title: "Human Error", desc: "Accidental deletion or overwriting of files", icon: AlertTriangle },
            { title: "Natural Disasters", desc: "Floods, fires, earthquakes, power surges", icon: Cloud }
          ].map((cause, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex space-x-4 p-4 bg-gray-50 rounded-lg"
            >
              <cause.icon className="w-6 h-6 text-[#53B289] flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-[#3A4E62]">{cause.title}</h4>
                <p className="text-[#3A4E62]/80 text-sm">{cause.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const BackupRecoveryServicesSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Backup & Recovery Services
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { 
            title: "Automated Daily Backups", 
            desc: "Set-and-forget backup solution that runs automatically every night",
            features: ["Incremental backups", "Bandwidth optimization", "Email notifications", "Backup verification"],
            icon: Clock 
          },
          { 
            title: "Cloud & Local Hybrid", 
            desc: "Best of both worlds with local speed and cloud security",
            features: ["Local NAS storage", "Cloud replication", "Geographic distribution", "Lightning-fast restores"],
            icon: Cloud 
          },
          { 
            title: "Instant Recovery Options", 
            desc: "Get back to work quickly with multiple recovery methods",
            features: ["File-level recovery", "System image restoration", "Virtual machine recovery", "Bare metal restore"],
            icon: Database 
          }
        ].map((service, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-8 shadow-lg"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-xl flex items-center justify-center mb-6">
              <service.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-xl font-bold text-[#3A4E62] mb-4">{service.title}</h3>
            <p className="text-[#3A4E62]/80 mb-6">{service.desc}</p>
            <ul className="space-y-2">
              {service.features.map((feature, fIndex) => (
                <li key={fIndex} className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 text-[#53B289] mr-2" />
                  <span className="text-[#3A4E62]/80">{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const DisasterRecoverySection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Disaster Recovery Planning
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Comprehensive Recovery Strategy</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6">
              Beyond just backups, we create complete disaster recovery plans that ensure your business can continue operating even during major disruptions.
            </p>
          </div>
          
          <div className="space-y-6">
            {[
              { title: "Recovery Time Objective (RTO)", desc: "Target time to restore operations after an incident", metric: "< 4 hours" },
              { title: "Recovery Point Objective (RPO)", desc: "Maximum acceptable data loss measured in time", metric: "< 15 minutes" },
              { title: "Business Impact Analysis", desc: "Identify critical systems and prioritize recovery", metric: "100% coverage" },
              { title: "Testing & Validation", desc: "Regular testing to ensure recovery procedures work", metric: "Monthly tests" }
            ].map((item, index) => (
              <div key={index} className="flex justify-between items-center p-4 bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-semibold text-[#3A4E62]">{item.title}</h4>
                  <p className="text-sm text-[#3A4E62]/80">{item.desc}</p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold text-[#53B289]">{item.metric}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <img 
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=600&h=400&fit=crop" 
            alt="Disaster Recovery Planning Auckland"
            className="rounded-xl shadow-lg w-full"
          />
        </div>
      </div>
    </div>
  </section>
);

const BenefitsSection = () => (
  <section className="py-20 bg-gradient-to-br from-gray-50 to-[#C0E3D4]/10">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Benefits of Choosing Comsys IT
      </h2>
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Technical Excellence</h3>
          {[
            "Enterprise-grade backup solutions using Veeam and CommVault",
            "256-bit AES encryption for data in transit and at rest",
            "Immutable backup copies protected from ransomware",
            "Multi-tier storage with automatic lifecycle management",
            "Cross-platform support for Windows, Mac, and Linux",
            "Application-aware backups for databases and email systems"
          ].map((benefit, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="space-y-8">
          <h3 className="text-2xl font-bold text-[#3A4E62]">Business Benefits</h3>
          {[
            "99.9% backup success rate with monitoring and alerting",
            "Compliance with GDPR, HIPAA, and NZ Privacy Act requirements",
            "24/7 monitoring with proactive issue resolution",
            "Predictable monthly costs with no hidden fees",
            "Local Auckland support team for rapid response",
            "Detailed reporting and audit trails for compliance"
          ].map((benefit, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-[#53B289] flex-shrink-0 mt-1" />
              <span className="text-[#3A4E62]/80">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Frequently Asked Questions
      </h2>
      <div className="space-y-8">
        {[
          {
            question: "Do you provide offsite backups?",
            answer: "Yes, we provide secure offsite cloud backups to multiple geographic locations including Auckland and overseas data centers. This ensures your data is protected even in the event of a local disaster affecting your primary location."
          },
          {
            question: "Can you restore full systems?",
            answer: "Absolutely! We offer bare metal recovery which can restore your entire server or workstation to new hardware. We also provide granular recovery options for individual files, folders, databases, and email items, giving you flexibility in how you recover your data."
          },
          {
            question: "Is backup automatic?",
            answer: "Yes, our backup solutions are fully automated. Once configured, backups run according to your schedule (typically nightly) without any manual intervention. You'll receive email reports confirming successful backups and immediate alerts if any issues arise."
          }
        ].map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-r from-[#53B289]/5 to-[#C0E3D4]/10 rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold text-[#3A4E62] mb-4">{faq.question}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{faq.answer}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default function DataBackupRecovery() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Data Backup and Recovery",
      "name": "Data Backup & Recovery Auckland",
      "description": "Protect your business with secure data backup and fast recovery solutions. Comsys IT ensures your files are safe and can be restored quickly in case of disaster.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Comsys IT",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Auckland",
          "addressCountry": "NZ"
        },
        "telephone": "09 242 3700"
      },
      "areaServed": {
        "@type": "City",
        "name": "Auckland"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Do you provide offsite backups?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, we provide secure offsite cloud backups to multiple geographic locations including Auckland and overseas data centers. This ensures your data is protected even in the event of a local disaster affecting your primary location."
          }
        },
        {
          "@type": "Question",
          "name": "Can you restore full systems?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely! We offer bare metal recovery which can restore your entire server or workstation to new hardware. We also provide granular recovery options for individual files, folders, databases, and email items, giving you flexibility in how you recover your data."
          }
        },
        {
          "@type": "Question",
          "name": "Is backup automatic?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, our backup solutions are fully automated. Once configured, backups run according to your schedule (typically nightly) without any manual intervention. You'll receive email reports confirming successful backups and immediate alerts if any issues arise."
          }
        }
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.comsys.co.nz/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://www.comsys.co.nz/Services"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Data Backup & Recovery Auckland",
          "item": "https://www.comsys.co.nz/DataBackupRecovery"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title="Data Backup & Recovery Auckland | Comsys IT"
        description="Protect your business with secure data backup and fast recovery solutions. Comsys IT ensures your files are safe and can be restored quickly in case of disaster."
        keywords="data backup Auckland, disaster recovery, business continuity, cloud backup, data protection Auckland"
        canonical="https://www.comsys.co.nz/DataBackupRecovery"
        schemas={schemas}
      />
      
      <PageHero />
      <WhyBackupMattersSection />
      <BackupRecoveryServicesSection />
      <DisasterRecoverySection />
      <BenefitsSection />
      <FAQSection />
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#53B289] to-[#C0E3D4] text-white text-center">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Don't Risk Losing Your Data
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get a free backup assessment and protect your business with enterprise-grade data protection.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ContactUs?subject=DataBackup")}>
              <Button size="lg" className="bg-white text-[#53B289] hover:bg-gray-100">
                Get Free Backup Assessment
              </Button>
            </Link>
            <Link to="https://www.veeam.com" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#53B289]">
                Learn About Enterprise Backup <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}