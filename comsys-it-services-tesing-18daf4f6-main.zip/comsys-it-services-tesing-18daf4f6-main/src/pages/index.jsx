import Layout from "./Layout.jsx";

import Home from "./Home";

import DataBackupRecovery from "./DataBackupRecovery";

import ITSupport from "./ITSupport";

import PCLaptopRepair from "./PCLaptopRepair";

import WiFiUpgrade from "./WiFiUpgrade";

import MicrosoftOffice from "./MicrosoftOffice";

import PrinterServices from "./PrinterServices";

import VoIPSolutions from "./VoIPSolutions";

import WebDesignHosting from "./WebDesignHosting";

import About from "./About";

import Services from "./Services";

import ContactUs from "./ContactUs";

import Pricing from "./Pricing";

import RemoteSupport from "./RemoteSupport";

import BusinessFibre from "./BusinessFibre";

import HomeFibre from "./HomeFibre";

import PhoneNumbers from "./PhoneNumbers";

import SIPTrunks from "./SIPTrunks";

import CCTVHome from "./CCTVHome";

import CCTVBusiness from "./CCTVBusiness";

import CCTVResidential from "./CCTVResidential";

import Locations from "./Locations";

import Industries from "./Industries";

import IndustriesLegal from "./IndustriesLegal";

import IndustriesAccounting from "./IndustriesAccounting";

import IndustriesFinancial from "./IndustriesFinancial";

import IndustriesAgedCare from "./IndustriesAgedCare";

import IndustriesEducation from "./IndustriesEducation";

import IndustriesGovernment from "./IndustriesGovernment";

import IndustriesNonProfits from "./IndustriesNonProfits";

import IndustriesConstruction from "./IndustriesConstruction";

import IndustriesEngineering from "./IndustriesEngineering";

import IndustriesRealEstate from "./IndustriesRealEstate";

import IndustriesFacilities from "./IndustriesFacilities";

import IndustriesWarehousing from "./IndustriesWarehousing";

import IndustriesTransport from "./IndustriesTransport";

import IndustriesAgriculture from "./IndustriesAgriculture";

import IndustriesManufacturing from "./IndustriesManufacturing";

import IndustriesRetail from "./IndustriesRetail";

import IndustriesHospitality from "./IndustriesHospitality";

import IndustriesTourism from "./IndustriesTourism";

import IndustriesFitness from "./IndustriesFitness";

import IndustriesAutomotive from "./IndustriesAutomotive";

import IndustriesBeauty from "./IndustriesBeauty";

import IndustriesITStartups from "./IndustriesITStartups";

import IndustriesMarketing from "./IndustriesMarketing";

import IndustriesConsulting from "./IndustriesConsulting";

import CloudPBX from "./CloudPBX";

import Insights from "./Insights";

import BlogPost from "./BlogPost";

import IndustriesHealthcare from "./IndustriesHealthcare";

import ITCalculator from "./ITCalculator";

import AreasWeServe from "./AreasWeServe";

import ITSupportHenderson from "./ITSupportHenderson";

import ITSupportTakapuna from "./ITSupportTakapuna";

import ITSupportAlbany from "./ITSupportAlbany";

import ITSupportManukau from "./ITSupportManukau";

import ITSupportAucklandCBD from "./ITSupportAucklandCBD";

import ITSupportNewmarket from "./ITSupportNewmarket";

import ITSupportHowick from "./ITSupportHowick";

import ITSupportPapakura from "./ITSupportPapakura";

import ITSupportEastTamaki from "./ITSupportEastTamaki";

import ITSupportBrownsBay from "./ITSupportBrownsBay";

import ITSupportPakuranga from "./ITSupportPakuranga";

import ITSupportMilford from "./ITSupportMilford";

import ITSupportNewLynn from "./ITSupportNewLynn";

import ITSupportDevonport from "./ITSupportDevonport";

import ITSupportBotanyDowns from "./ITSupportBotanyDowns";

import ITSupportParnell from "./ITSupportParnell";

import ITSupportMassey from "./ITSupportMassey";

import ITSupportPukekohe from "./ITSupportPukekohe";

import ITSupportGlenEden from "./ITSupportGlenEden";

import ITSupportTeAtatu from "./ITSupportTeAtatu";

import ITSupportPonsonby from "./ITSupportPonsonby";

import ITSupportGrafton from "./ITSupportGrafton";

import ITSupportGreyLynn from "./ITSupportGreyLynn";

import ITSupportMtEden from "./ITSupportMtEden";

import ITSupportKingsland from "./ITSupportKingsland";

import ITSupportEdenTerrace from "./ITSupportEdenTerrace";

import ITSupportFreemans from "./ITSupportFreemans";

import ITSupportWaitakere from "./ITSupportWaitakere";

import ITSupportKelston from "./ITSupportKelston";

import ITSupportGlendene from "./ITSupportGlendene";

import ITSupportSwanson from "./ITSupportSwanson";

import ITSupportRanui from "./ITSupportRanui";

import ITSupportNorthShore from "./ITSupportNorthShore";

import ITSupportGlenfield from "./ITSupportGlenfield";

import ITSupportBirkenhead from "./ITSupportBirkenhead";

import ITSupportMairangiBay from "./ITSupportMairangiBay";

import ITSupportCampbells from "./ITSupportCampbells";

import ITSupportBucklands from "./ITSupportBucklands";

import ITSupportPanmure from "./ITSupportPanmure";

import ITSupportGlenInnes from "./ITSupportGlenInnes";

import ITSupportPapatoetoe from "./ITSupportPapatoetoe";

import ITSupportOtahuhu from "./ITSupportOtahuhu";

import ITSupportMangere from "./ITSupportMangere";

import ITSupportTakanini from "./ITSupportTakanini";

import ITSupportManurewa from "./ITSupportManurewa";

import ITSupportFlatBush from "./ITSupportFlatBush";

import ITSupportFreemansBay from "./ITSupportFreemansBay";

import ITSupportCampbellsBay from "./ITSupportCampbellsBay";

import ITSupportRemuera from "./ITSupportRemuera";

import ITSupportEpsom from "./ITSupportEpsom";

import ITSupportMountRoskill from "./ITSupportMountRoskill";

import ITSupportOnehunga from "./ITSupportOnehunga";

import ITSupportRoyalOak from "./ITSupportRoyalOak";

import ITSupportThreeKings from "./ITSupportThreeKings";

import ITSupportHillsborough from "./ITSupportHillsborough";

import ITSupportLynfield from "./ITSupportLynfield";

import ITSupportBlockhouseBay from "./ITSupportBlockhouseBay";

import ITSupportAvondale from "./ITSupportAvondale";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    DataBackupRecovery: DataBackupRecovery,
    
    ITSupport: ITSupport,
    
    PCLaptopRepair: PCLaptopRepair,
    
    WiFiUpgrade: WiFiUpgrade,
    
    MicrosoftOffice: MicrosoftOffice,
    
    PrinterServices: PrinterServices,
    
    VoIPSolutions: VoIPSolutions,
    
    WebDesignHosting: WebDesignHosting,
    
    About: About,
    
    Services: Services,
    
    ContactUs: ContactUs,
    
    Pricing: Pricing,
    
    RemoteSupport: RemoteSupport,
    
    BusinessFibre: BusinessFibre,
    
    HomeFibre: HomeFibre,
    
    PhoneNumbers: PhoneNumbers,
    
    SIPTrunks: SIPTrunks,
    
    CCTVHome: CCTVHome,
    
    CCTVBusiness: CCTVBusiness,
    
    CCTVResidential: CCTVResidential,
    
    Locations: Locations,
    
    Industries: Industries,
    
    IndustriesLegal: IndustriesLegal,
    
    IndustriesAccounting: IndustriesAccounting,
    
    IndustriesFinancial: IndustriesFinancial,
    
    IndustriesAgedCare: IndustriesAgedCare,
    
    IndustriesEducation: IndustriesEducation,
    
    IndustriesGovernment: IndustriesGovernment,
    
    IndustriesNonProfits: IndustriesNonProfits,
    
    IndustriesConstruction: IndustriesConstruction,
    
    IndustriesEngineering: IndustriesEngineering,
    
    IndustriesRealEstate: IndustriesRealEstate,
    
    IndustriesFacilities: IndustriesFacilities,
    
    IndustriesWarehousing: IndustriesWarehousing,
    
    IndustriesTransport: IndustriesTransport,
    
    IndustriesAgriculture: IndustriesAgriculture,
    
    IndustriesManufacturing: IndustriesManufacturing,
    
    IndustriesRetail: IndustriesRetail,
    
    IndustriesHospitality: IndustriesHospitality,
    
    IndustriesTourism: IndustriesTourism,
    
    IndustriesFitness: IndustriesFitness,
    
    IndustriesAutomotive: IndustriesAutomotive,
    
    IndustriesBeauty: IndustriesBeauty,
    
    IndustriesITStartups: IndustriesITStartups,
    
    IndustriesMarketing: IndustriesMarketing,
    
    IndustriesConsulting: IndustriesConsulting,
    
    CloudPBX: CloudPBX,
    
    Insights: Insights,
    
    BlogPost: BlogPost,
    
    IndustriesHealthcare: IndustriesHealthcare,
    
    ITCalculator: ITCalculator,
    
    AreasWeServe: AreasWeServe,
    
    ITSupportHenderson: ITSupportHenderson,
    
    ITSupportTakapuna: ITSupportTakapuna,
    
    ITSupportAlbany: ITSupportAlbany,
    
    ITSupportManukau: ITSupportManukau,
    
    ITSupportAucklandCBD: ITSupportAucklandCBD,
    
    ITSupportNewmarket: ITSupportNewmarket,
    
    ITSupportHowick: ITSupportHowick,
    
    ITSupportPapakura: ITSupportPapakura,
    
    ITSupportEastTamaki: ITSupportEastTamaki,
    
    ITSupportBrownsBay: ITSupportBrownsBay,
    
    ITSupportPakuranga: ITSupportPakuranga,
    
    ITSupportMilford: ITSupportMilford,
    
    ITSupportNewLynn: ITSupportNewLynn,
    
    ITSupportDevonport: ITSupportDevonport,
    
    ITSupportBotanyDowns: ITSupportBotanyDowns,
    
    ITSupportParnell: ITSupportParnell,
    
    ITSupportMassey: ITSupportMassey,
    
    ITSupportPukekohe: ITSupportPukekohe,
    
    ITSupportGlenEden: ITSupportGlenEden,
    
    ITSupportTeAtatu: ITSupportTeAtatu,
    
    ITSupportPonsonby: ITSupportPonsonby,
    
    ITSupportGrafton: ITSupportGrafton,
    
    ITSupportGreyLynn: ITSupportGreyLynn,
    
    ITSupportMtEden: ITSupportMtEden,
    
    ITSupportKingsland: ITSupportKingsland,
    
    ITSupportEdenTerrace: ITSupportEdenTerrace,
    
    ITSupportFreemans: ITSupportFreemans,
    
    ITSupportWaitakere: ITSupportWaitakere,
    
    ITSupportKelston: ITSupportKelston,
    
    ITSupportGlendene: ITSupportGlendene,
    
    ITSupportSwanson: ITSupportSwanson,
    
    ITSupportRanui: ITSupportRanui,
    
    ITSupportNorthShore: ITSupportNorthShore,
    
    ITSupportGlenfield: ITSupportGlenfield,
    
    ITSupportBirkenhead: ITSupportBirkenhead,
    
    ITSupportMairangiBay: ITSupportMairangiBay,
    
    ITSupportCampbells: ITSupportCampbells,
    
    ITSupportBucklands: ITSupportBucklands,
    
    ITSupportPanmure: ITSupportPanmure,
    
    ITSupportGlenInnes: ITSupportGlenInnes,
    
    ITSupportPapatoetoe: ITSupportPapatoetoe,
    
    ITSupportOtahuhu: ITSupportOtahuhu,
    
    ITSupportMangere: ITSupportMangere,
    
    ITSupportTakanini: ITSupportTakanini,
    
    ITSupportManurewa: ITSupportManurewa,
    
    ITSupportFlatBush: ITSupportFlatBush,
    
    ITSupportFreemansBay: ITSupportFreemansBay,
    
    ITSupportCampbellsBay: ITSupportCampbellsBay,
    
    ITSupportRemuera: ITSupportRemuera,
    
    ITSupportEpsom: ITSupportEpsom,
    
    ITSupportMountRoskill: ITSupportMountRoskill,
    
    ITSupportOnehunga: ITSupportOnehunga,
    
    ITSupportRoyalOak: ITSupportRoyalOak,
    
    ITSupportThreeKings: ITSupportThreeKings,
    
    ITSupportHillsborough: ITSupportHillsborough,
    
    ITSupportLynfield: ITSupportLynfield,
    
    ITSupportBlockhouseBay: ITSupportBlockhouseBay,
    
    ITSupportAvondale: ITSupportAvondale,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/DataBackupRecovery" element={<DataBackupRecovery />} />
                
                <Route path="/ITSupport" element={<ITSupport />} />
                
                <Route path="/PCLaptopRepair" element={<PCLaptopRepair />} />
                
                <Route path="/WiFiUpgrade" element={<WiFiUpgrade />} />
                
                <Route path="/MicrosoftOffice" element={<MicrosoftOffice />} />
                
                <Route path="/PrinterServices" element={<PrinterServices />} />
                
                <Route path="/VoIPSolutions" element={<VoIPSolutions />} />
                
                <Route path="/WebDesignHosting" element={<WebDesignHosting />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/Services" element={<Services />} />
                
                <Route path="/ContactUs" element={<ContactUs />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/RemoteSupport" element={<RemoteSupport />} />
                
                <Route path="/BusinessFibre" element={<BusinessFibre />} />
                
                <Route path="/HomeFibre" element={<HomeFibre />} />
                
                <Route path="/PhoneNumbers" element={<PhoneNumbers />} />
                
                <Route path="/SIPTrunks" element={<SIPTrunks />} />
                
                <Route path="/CCTVHome" element={<CCTVHome />} />
                
                <Route path="/CCTVBusiness" element={<CCTVBusiness />} />
                
                <Route path="/CCTVResidential" element={<CCTVResidential />} />
                
                <Route path="/Locations" element={<Locations />} />
                
                <Route path="/Industries" element={<Industries />} />
                
                <Route path="/IndustriesLegal" element={<IndustriesLegal />} />
                
                <Route path="/IndustriesAccounting" element={<IndustriesAccounting />} />
                
                <Route path="/IndustriesFinancial" element={<IndustriesFinancial />} />
                
                <Route path="/IndustriesAgedCare" element={<IndustriesAgedCare />} />
                
                <Route path="/IndustriesEducation" element={<IndustriesEducation />} />
                
                <Route path="/IndustriesGovernment" element={<IndustriesGovernment />} />
                
                <Route path="/IndustriesNonProfits" element={<IndustriesNonProfits />} />
                
                <Route path="/IndustriesConstruction" element={<IndustriesConstruction />} />
                
                <Route path="/IndustriesEngineering" element={<IndustriesEngineering />} />
                
                <Route path="/IndustriesRealEstate" element={<IndustriesRealEstate />} />
                
                <Route path="/IndustriesFacilities" element={<IndustriesFacilities />} />
                
                <Route path="/IndustriesWarehousing" element={<IndustriesWarehousing />} />
                
                <Route path="/IndustriesTransport" element={<IndustriesTransport />} />
                
                <Route path="/IndustriesAgriculture" element={<IndustriesAgriculture />} />
                
                <Route path="/IndustriesManufacturing" element={<IndustriesManufacturing />} />
                
                <Route path="/IndustriesRetail" element={<IndustriesRetail />} />
                
                <Route path="/IndustriesHospitality" element={<IndustriesHospitality />} />
                
                <Route path="/IndustriesTourism" element={<IndustriesTourism />} />
                
                <Route path="/IndustriesFitness" element={<IndustriesFitness />} />
                
                <Route path="/IndustriesAutomotive" element={<IndustriesAutomotive />} />
                
                <Route path="/IndustriesBeauty" element={<IndustriesBeauty />} />
                
                <Route path="/IndustriesITStartups" element={<IndustriesITStartups />} />
                
                <Route path="/IndustriesMarketing" element={<IndustriesMarketing />} />
                
                <Route path="/IndustriesConsulting" element={<IndustriesConsulting />} />
                
                <Route path="/CloudPBX" element={<CloudPBX />} />
                
                <Route path="/Insights" element={<Insights />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/IndustriesHealthcare" element={<IndustriesHealthcare />} />
                
                <Route path="/ITCalculator" element={<ITCalculator />} />
                
                <Route path="/AreasWeServe" element={<AreasWeServe />} />
                
                <Route path="/ITSupportHenderson" element={<ITSupportHenderson />} />
                
                <Route path="/ITSupportTakapuna" element={<ITSupportTakapuna />} />
                
                <Route path="/ITSupportAlbany" element={<ITSupportAlbany />} />
                
                <Route path="/ITSupportManukau" element={<ITSupportManukau />} />
                
                <Route path="/ITSupportAucklandCBD" element={<ITSupportAucklandCBD />} />
                
                <Route path="/ITSupportNewmarket" element={<ITSupportNewmarket />} />
                
                <Route path="/ITSupportHowick" element={<ITSupportHowick />} />
                
                <Route path="/ITSupportPapakura" element={<ITSupportPapakura />} />
                
                <Route path="/ITSupportEastTamaki" element={<ITSupportEastTamaki />} />
                
                <Route path="/ITSupportBrownsBay" element={<ITSupportBrownsBay />} />
                
                <Route path="/ITSupportPakuranga" element={<ITSupportPakuranga />} />
                
                <Route path="/ITSupportMilford" element={<ITSupportMilford />} />
                
                <Route path="/ITSupportNewLynn" element={<ITSupportNewLynn />} />
                
                <Route path="/ITSupportDevonport" element={<ITSupportDevonport />} />
                
                <Route path="/ITSupportBotanyDowns" element={<ITSupportBotanyDowns />} />
                
                <Route path="/ITSupportParnell" element={<ITSupportParnell />} />
                
                <Route path="/ITSupportMassey" element={<ITSupportMassey />} />
                
                <Route path="/ITSupportPukekohe" element={<ITSupportPukekohe />} />
                
                <Route path="/ITSupportGlenEden" element={<ITSupportGlenEden />} />
                
                <Route path="/ITSupportTeAtatu" element={<ITSupportTeAtatu />} />
                
                <Route path="/ITSupportPonsonby" element={<ITSupportPonsonby />} />
                
                <Route path="/ITSupportGrafton" element={<ITSupportGrafton />} />
                
                <Route path="/ITSupportGreyLynn" element={<ITSupportGreyLynn />} />
                
                <Route path="/ITSupportMtEden" element={<ITSupportMtEden />} />
                
                <Route path="/ITSupportKingsland" element={<ITSupportKingsland />} />
                
                <Route path="/ITSupportEdenTerrace" element={<ITSupportEdenTerrace />} />
                
                <Route path="/ITSupportFreemans" element={<ITSupportFreemans />} />
                
                <Route path="/ITSupportWaitakere" element={<ITSupportWaitakere />} />
                
                <Route path="/ITSupportKelston" element={<ITSupportKelston />} />
                
                <Route path="/ITSupportGlendene" element={<ITSupportGlendene />} />
                
                <Route path="/ITSupportSwanson" element={<ITSupportSwanson />} />
                
                <Route path="/ITSupportRanui" element={<ITSupportRanui />} />
                
                <Route path="/ITSupportNorthShore" element={<ITSupportNorthShore />} />
                
                <Route path="/ITSupportGlenfield" element={<ITSupportGlenfield />} />
                
                <Route path="/ITSupportBirkenhead" element={<ITSupportBirkenhead />} />
                
                <Route path="/ITSupportMairangiBay" element={<ITSupportMairangiBay />} />
                
                <Route path="/ITSupportCampbells" element={<ITSupportCampbells />} />
                
                <Route path="/ITSupportBucklands" element={<ITSupportBucklands />} />
                
                <Route path="/ITSupportPanmure" element={<ITSupportPanmure />} />
                
                <Route path="/ITSupportGlenInnes" element={<ITSupportGlenInnes />} />
                
                <Route path="/ITSupportPapatoetoe" element={<ITSupportPapatoetoe />} />
                
                <Route path="/ITSupportOtahuhu" element={<ITSupportOtahuhu />} />
                
                <Route path="/ITSupportMangere" element={<ITSupportMangere />} />
                
                <Route path="/ITSupportTakanini" element={<ITSupportTakanini />} />
                
                <Route path="/ITSupportManurewa" element={<ITSupportManurewa />} />
                
                <Route path="/ITSupportFlatBush" element={<ITSupportFlatBush />} />
                
                <Route path="/ITSupportFreemansBay" element={<ITSupportFreemansBay />} />
                
                <Route path="/ITSupportCampbellsBay" element={<ITSupportCampbellsBay />} />
                
                <Route path="/ITSupportRemuera" element={<ITSupportRemuera />} />
                
                <Route path="/ITSupportEpsom" element={<ITSupportEpsom />} />
                
                <Route path="/ITSupportMountRoskill" element={<ITSupportMountRoskill />} />
                
                <Route path="/ITSupportOnehunga" element={<ITSupportOnehunga />} />
                
                <Route path="/ITSupportRoyalOak" element={<ITSupportRoyalOak />} />
                
                <Route path="/ITSupportThreeKings" element={<ITSupportThreeKings />} />
                
                <Route path="/ITSupportHillsborough" element={<ITSupportHillsborough />} />
                
                <Route path="/ITSupportLynfield" element={<ITSupportLynfield />} />
                
                <Route path="/ITSupportBlockhouseBay" element={<ITSupportBlockhouseBay />} />
                
                <Route path="/ITSupportAvondale" element={<ITSupportAvondale />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}