
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone, Shield, Server, Video, Building, Users, MapPin, Clock, Home, Wifi, Mail, Headset } from 'lucide-react';
import Seo from '../components/layout/Seo';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PageHero = () => (
  <section className="relative text-white py-24 md:py-32">
    <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
    <img 
      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
      alt="Professional IT support for Kingsland's vibrant businesses"
      className="absolute inset-0 w-full h-full object-cover z-[-1]"
    />
    <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center relative z-10">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
        style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}
      >
        IT Support for Vibrant Kingsland
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-lg md:text-xl text-slate-200 max-w-4xl mx-auto leading-relaxed"
        style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}
      >
        In the heart of Kingsland's bustling village atmosphere, creative agencies, trendy bars, and innovative businesses need IT that just works. Comsys IT provides fast, reliable, and expert IT support tailored to the unique, fast-paced environment of Kingsland.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-10"
      >
        <Link to={createPageUrl("ContactUs?subject=KingslandITConsultation")}>
          <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white group text-lg px-8 py-6 font-semibold">
            Get Your Free IT Health Check
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUsSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Why Choose Comsys IT for Kingsland Businesses?
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { 
            title: "Hospitality IT Experts", 
            desc: "Specialized support for POS systems, guest Wi-Fi, and payment solutions for Kingsland's cafes, bars, and restaurants.",
            icon: Building
          },
          { 
            title: "Event-Ready Support", 
            desc: "IT solutions that can handle the surge in demand during major events at nearby Eden Park.",
            icon: Wifi
          },
          { 
            title: "Creative Agency Focus", 
            desc: "High-performance IT for the creative and digital businesses that thrive in Kingsland.",
            icon: CheckCircle
          },
          { 
            title: "Rapid Local Response", 
            desc: "Our Auckland team provides fast onsite support, crucial for the fast-paced Kingsland environment.",
            icon: Clock
          }
        ].map((reason, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-6 bg-gray-50 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <div className="w-16 h-16 bg-[#53B289]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <reason.icon className="w-8 h-8 text-[#53B289]" />
            </div>
            <h3 className="text-lg font-bold text-[#3A4E62] mb-3">{reason.title}</h3>
            <p className="text-[#3A4E62]/70">{reason.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => {
    const services = [
    { 
      icon: Users, 
      title: "Managed IT for Hospitality & Retail", 
      desc: "We provide robust IT solutions for Kingsland's busy hospitality and retail sectors, including reliable POS systems, secure payment processing, and seamless Guest WiFi.",
      link: "ITSupport",
      imageUrl: "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Server, 
      title: "IT Support for Creative Agencies", 
      desc: "For the many creative and design studios in Kingsland, we offer specialized support for both Mac and PC environments, high-speed networks, and secure cloud collaboration tools.",
      link: "MicrosoftOffice",
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&h=800&fit=crop&q=80"
    },
    { 
      icon: Shield, 
      title: "Proactive Cybersecurity", 
      desc: "Protect your business and customer data with our comprehensive cybersecurity services, including proactive monitoring, data backup, and threat prevention for total peace of mind.",
      link: "DataBackupRecovery",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1517694712202-1428bc3835b6?auto=format&fit=crop&w=1920&q=80" 
              alt="Modern IT infrastructure background"
              className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-50 via-gray-50/90 to-gray-50/80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Premium IT Services for the Kingsland Area
        </h2>
        <div className="space-y-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-8 items-center"
            >
              <div className={`aspect-w-4 aspect-h-3 ${index % 2 === 0 ? 'lg:order-last' : ''}`}>
                <img 
                  src={service.imageUrl}
                  alt={`${service.title} for Kingsland businesses`}
                  className="rounded-xl shadow-lg w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="w-16 h-16 bg-white/50 backdrop-blur-sm border border-gray-200/50 rounded-2xl flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-[#53B289]" />
                </div>
                <h3 className="text-2xl font-bold text-[#3A4E62]">{service.title}</h3>
                <p className="text-[#3A4E62]/80 text-lg leading-relaxed">{service.desc}</p>
                <Link to={createPageUrl(service.link)}>
                  <Button variant="outline" className="group bg-white/50 hover:bg-white transition-colors">
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Industries We Power in Kingsland
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {[
          {
            title: "Restaurants, Cafes & Bars",
            desc: "The core of Kingsland's economy. We provide essential IT for POS, bookings, payments, and guest services to keep them running smoothly."
          },
          {
            title: "Creative & Digital Agencies",
            desc: "We support marketing, design, and web development agencies with the high-performance tools they need to innovate and deliver."
          },
          {
            title: "Boutique Retailers",
            desc: "From fashion to specialty goods, we ensure retail businesses have reliable inventory and sales systems to serve their customers."
          },
          {
            title: "Event Management & Services",
            desc: "For businesses that service Eden Park events, we provide the robust, temporary, and scalable IT solutions they need."
          },
          {
            title: "Professional Services",
            desc: "We support the local architects, consultants, and small firms in Kingsland with secure and professional IT systems."
          },
          {
            title: "Entertainment & Venues",
            desc: "Beyond hospitality, we support other entertainment venues with their unique ticketing, sound, and operational tech needs."
          }
        ].map((industry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 p-6 rounded-2xl hover:bg-[#53B289]/5 transition-colors"
          >
            <h3 className="text-xl font-bold text-[#3A4E62] mb-3">{industry.title}</h3>
            <p className="text-[#3A4E62]/80 leading-relaxed">{industry.desc}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-[#53B289]/10 p-8 rounded-2xl border border-[#53B289]/20">
        <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Kingsland Success Story</h3>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Challenge:</strong> A popular bar in Kingsland suffered from frequent POS system crashes and Wi-Fi outages during packed game nights at Eden Park. Lost sales and customer frustration were becoming a major problem.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed mb-4">
          <strong>Solution:</strong> Comsys IT installed a resilient, commercial-grade network with dedicated business fibre. We upgraded their POS hardware and configured a separate, high-capacity guest Wi-Fi network, alongside a proactive monitoring service.
        </p>
        <p className="text-[#3A4E62]/80 text-lg leading-relaxed">
          <strong>Result:</strong> The bar now operates with zero transaction failures during major events. Staff can process orders 50% faster, and positive online reviews frequently mention the reliable free Wi-Fi, leading to increased customer loyalty and revenue, even on the busiest nights.
        </p>
      </div>
    </div>
  </section>
);

const MapSection = () => (
  <section className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-6 lg:px-12">
      <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
        Serving the Heart of Kingsland
      </h2>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-[#3A4E62] mb-4">Responsive Support for Kingsland Businesses</h3>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              Our IT support services cover the entire Kingsland area, from the bustling strip of cafes and shops on New North Road to the side streets housing creative studios and offices. We are perfectly positioned to provide rapid onsite support when needed, especially for hospitality businesses where uptime is critical.
            </p>
            <p className="text-[#3A4E62]/80 text-lg mb-6 leading-relaxed">
              We understand the local environment, including the logistical challenges during major Eden Park events, and plan our support to ensure your business remains operational when it matters most.
            </p>
          </div>
          
          <div className="bg-[#53B289]/10 p-6 rounded-2xl border border-[#53B289]/20">
            <h4 className="font-semibold text-[#3A4E62] mb-3 flex items-center">
              <MapPin className="w-5 h-5 text-[#53B289] mr-2" />
              Service Details
            </h4>
            <div className="space-y-2 text-[#3A4E62]/80">
              <p><strong>Response Time:</strong> Priority response for hospitality businesses</p>
              <p><strong>Coverage:</strong> Kingsland Village, New North Road, and surrounding streets</p>
              <p><strong>Event Support:</strong> Proactive checks and standby support for major event days</p>
              <p><strong>Specialization:</strong> Hospitality, Retail, and Creative Agency IT</p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="aspect-w-16 aspect-h-12 rounded-xl overflow-hidden shadow-2xl border-4 border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6381.996173007428!2d174.7408344964539!3d-36.87274092955365!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d0d47c2505581ad%3A0x500ef6143a29950!2sKingsland%2C%20Auckland%201021!5e0!3m2!1sen!2snz!4v1695861448834!5m2!1sen!2snz"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Kingsland Auckland IT Support Service Area Map"
            ></iframe>
          </div>
          <p className="text-sm text-[#3A4E62]/70 mt-4">
            Our team provides fast, responsive IT support across Kingsland, ensuring businesses thrive.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const FAQSection = () => {
  const faqs = [
    {
      q: "Can your IT systems handle the pressure of a big game day at Eden Park?",
      a: "Yes. This is one of our key specialties for Kingsland businesses. We deploy robust, commercial-grade networks and business fibre that are designed to perform under high-traffic conditions. We ensure your POS, payment systems, and guest Wi-Fi remain stable and fast, even when the local infrastructure is under strain from large crowds."
    },
    {
      q: "We run a cafe in Kingsland. What's the most important IT service for us?",
      a: "For a cafe, the most critical services are a rock-solid Point-of-Sale (POS) system and a reliable internet connection. We provide support for both, ensuring your transactions are fast and your operations are never interrupted. A secure and seamless guest Wi-Fi network is also a major benefit for attracting and retaining customers."
    },
    {
      q: "My creative agency is in Kingsland. Do you understand our specific needs?",
      a: "Absolutely. We support numerous creative agencies and understand the need for high-performance Mac and PC workstations, fast access to cloud storage, large file transfer capabilities, and robust data backup for your valuable project files. We ensure your technology empowers your creativity, rather than hindering it."
    },
    {
      q: "How quickly can you respond to an issue at my Kingsland business?",
      a: "We offer priority support for our hospitality clients in Kingsland, as we know every minute of downtime equals lost revenue. For critical system failures like a POS outage, we provide immediate remote troubleshooting and can have a technician onsite extremely quickly, typically within the hour."
    },
    {
      q: "Is it expensive to get professional IT support for a small bar in Kingsland?",
      a: "No, our support plans are designed to be affordable and scalable. We offer fixed-fee monthly packages that provide you with comprehensive support and peace of mind without unpredictable costs. Investing in professional IT support is often more cost-effective than the losses incurred from just a few hours of downtime on a busy night."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <h2 className="text-3xl lg:text-4xl font-bold text-[#3A4E62] text-center mb-16">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <AccordionItem 
                value={`item-${index}`} 
                className="bg-gray-50/90 backdrop-blur-sm rounded-2xl shadow-sm mb-4 border border-gray-200/80 hover:border-gray-300 transition-colors"
              >
                <AccordionTrigger className="p-6 text-left font-semibold text-lg text-[#3A4E62] hover:no-underline hover:text-[#53B289] transition-colors">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="p-6 pt-0 text-base text-[#3A4E62]/90 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

const CTASection = () => (
    <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-gradient-to-r from-[#3A4E62] to-[#2a3749] rounded-2xl shadow-2xl p-10 md:p-16 text-white text-center"
            >
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                    Ready to Elevate Your Kingsland Business?
                </h2>
                <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                    Don't let technology hold you back. Let Comsys IT provide the professional, reliable support you deserve. Contact us today for a free, no-obligation consultation.
                </p>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                    <div className="lg:col-span-1 bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center hover:bg-white/20 transition-all">
                        <h3 className="text-xl font-semibold mb-4">Request a Consultation</h3>
                        <Link to={createPageUrl("ContactUs?subject=KingslandITConsultation")}>
                            <Button size="lg" className="bg-[#53B289] hover:bg-[#4aa07b] text-white w-full">
                                Get a Free Quote
                                <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </Link>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Headset className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Speak to an Expert</h3>
                        <a href="tel:0800724526" className="text-2xl font-bold hover:text-[#53B289] transition-colors">
                           0800 724 526
                        </a>
                    </div>
                    
                    <div className="bg-white/10 p-6 rounded-lg flex flex-col items-center justify-center">
                        <Mail className="w-8 h-8 mb-3 text-[#53B289]" />
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <a href="mailto:support@comsys.co.nz" className="text-lg hover:text-[#53B289] transition-colors">
                            support@comsys.co.nz
                        </a>
                    </div>
                </div>
            </motion.div>
        </div>
    </section>
);

export default function ITSupportKingsland() {
  const pageUrl = "https://www.comsys.co.nz/it-support-kingsland-auckland";
  const title = "IT Support Kingsland | Comsys IT | Hospitality & Event Experts";
  const description = "IT support for Kingsland's hospitality and creative businesses. We provide event-ready POS, Wi-Fi, and network support near Eden Park. Get a free IT health check today!";

  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Comsys IT",
      "description": "IT support for hospitality, retail, and creative businesses in Kingsland, Auckland, specializing in event-ready systems.",
      "url": pageUrl,
      "telephone": "0800724526",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "26 Bancroft Crescent, Glendene",
        "addressLocality": "Auckland",
        "postalCode": "0602",
        "addressCountry": "NZ"
      },
      "areaServed": {
        "@type": "Place",
        "name": "Kingsland, Auckland"
      },
      "serviceType": [
        "Hospitality IT Support", "POS Systems", "Event Wi-Fi", "Creative Agency IT", "Business Fibre", "Cybersecurity"
      ]
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can your IT systems handle the pressure of a big game day at Eden Park?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, this is a key specialty. We deploy commercial-grade networks and business fibre designed to perform under high-traffic conditions, ensuring your POS and payment systems remain stable during major events in Kingsland."
          }
        },
        {
          "@type": "Question",
          "name": "My creative agency is in Kingsland. Do you understand our specific needs?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. We support creative agencies with high-performance workstations, fast cloud storage for large files, collaborative software support, and robust data backup solutions to protect your valuable project files."
          }
        },
        {
          "@type": "Question",
          "name": "We run a cafe in Kingsland. What's the most important IT service for us?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "For a cafe, the most critical services are a rock-solid Point-of-Sale (POS) system and a reliable internet connection. We provide support for both, ensuring your transactions are fast and your operations are never interrupted. A secure and seamless guest Wi-Fi network is also a major benefit for attracting and retaining customers."
          }
        },
        {
          "@type": "Question",
          "name": "How quickly can you respond to an issue at my Kingsland business?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We offer priority support for our hospitality clients in Kingsland, as we know every minute of downtime equals lost revenue. For critical system failures like a POS outage, we provide immediate remote troubleshooting and can have a technician onsite extremely quickly, typically within the hour."
          }
        },
        {
          "@type": "Question",
          "name": "Is it expensive to get professional IT support for a small bar in Kingsland?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "No, our support plans are designed to be affordable and scalable. We offer fixed-fee monthly packages that provide you with comprehensive support and peace of mind without unpredictable costs. Investing in professional IT support is often more cost-effective than the losses incurred from just a few hours of downtime on a busy night."
          }
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50">
      <Seo
        title={title}
        description={description}
        keywords="IT support Kingsland, hospitality IT, retail IT support, creative agency IT Kingsland, Kingsland business IT, Eden Park IT support"
        canonical={pageUrl}
        schemas={schemas}
      />
      
      <PageHero />
      <WhyChooseUsSection />
      <ServicesSection />
      <IndustriesSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
}
