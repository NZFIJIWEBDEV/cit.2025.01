import { base44 } from './base44Client';


export const contact = base44.functions.contact;

export const addCustomer = base44.functions.addCustomer;

export const sendEmail = base44.functions.sendEmail;

export const testEmail = base44.functions.testEmail;

export const botDetection = base44.functions.botDetection;

export const prerender = base44.functions.prerender;

